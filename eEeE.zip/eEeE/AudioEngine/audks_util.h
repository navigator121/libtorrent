//**@@@*@@@****************************************************
//
// Microsoft Windows
// Copyright (C) Microsoft Corporation. All rights reserved.
//
//**@@@*@@@****************************************************

//
// FileName:    util.h
//
// Abstract:    
//      This is the header file for general helper functions
//

#pragma once
//
// Get the size for a WAVEFORMATEX-based structure.  It properly handles extended
// structures (such as WAVEFORMATEXTENSIBLE), and WAVE_FORMAT_PCM structures with bogus sizes.
//
DWORD GetWfxSize(const WAVEFORMATEX* pwfxSrc);

#if 0
// Debug Trace Macro's

#define AUDKS_TRACE_LOWEST (6)
#define AUDKS_TRACE_LOW (5)
#define AUDKS_TRACE_NORMAL (4)
#define AUDKS_TRACE_HIGH (3)
#define AUDKS_TRACE_HIGHEST (2)
#define AUDKS_TRACE_ERROR (1)
#define AUDKS_TRACE_MUTED (0)
#define AUDKS_TRACE_ALWAYS (-1)

//The higher the numer, the more the debug output
// Range is from 0 to 6.
void audks_debug_printf(WORD wDebugLevel, LPCTSTR pszFormat, ... );
#else

void audio_log_err(char *, ...);
void audio_log_war(char *, ...);
void audio_log_inf(char *, ...);
void audio_log_trc(char *, ...);

#endif

//#ifdef __FUNCTION__
#if 0
#define AUDKS_TRACE_ENTER() audks_debug_printf(AUDKS_TRACE_LOWEST, TEXT("%s Enter"), __FUNCTION__ "()")
#define AUDKS_TRACE_LEAVE()  audks_debug_printf(AUDKS_TRACE_LOWEST, TEXT("%s Leave"), __FUNCTION__ "()")
#define AUDKS_TRACE_LEAVE_HRESULT(hr) audks_debug_printf(AUDKS_TRACE_LOWEST, TEXT("%s Leave, returning %#08x"), __FUNCTION__,hr)
#else
#define AUDKS_TRACE_ENTER() 
#define AUDKS_TRACE_LEAVE() 
//#define AUDKS_TRACE_LEAVE_HRESULT(hr) audks_debug_printf(AUDKS_TRACE_LOWEST, TEXT("%s, line %s, returning %#08x"), __FILE__,__LINE__,hr)
#define AUDKS_TRACE_LEAVE_HRESULT(hr) 
#endif

