
#include "audio_defs.h"

/*****************************************************************************/
static BOOL CALLBACK _next
/*****************************************************************************/
(
LPGUID lpGUID, 
LPCTSTR lpszDesc,
LPCTSTR lpszDrvName, 
LPVOID lpContext 
)
{
	BOOL b = TRUE;

	if (lpGUID)
	{
		audio_log_inf("audio_drv_mic_next -- \"%s\", driver:%s", lpszDesc, lpszDrvName);
#ifndef _WIN32_WCE
		if (strcmp((char *)lpContext, lpszDesc) == 0)
#else
		if (strcmp((char *)lpContext, (const char*)lpszDesc) == 0)
#endif
		{
			gAudio.Drv.Dx.Mic.lpGUID = lpGUID;
			b = FALSE;
		}
	}
	return b;
}

/*****************************************************************************/
DWORD					auddx_mic_init
/*****************************************************************************/
(
char *pszDeviceName
)
{
	unsigned long rc = AUDIO_IF_ERR_NONE;
	Audio_tDrvDxMic *pMic = &gAudio.Drv.Dx.Mic;
	HRESULT hr;

	hr = DirectSoundCaptureEnumerate(_next, pszDeviceName);

	Sleep(20);

	hr = DirectSoundCaptureCreate8(
			pMic->lpGUID, 
			&pMic->pDs, 
			NULL);
	
	if (hr == DS_OK)
	{
		DSCCAPS DsCaps;
		DsCaps.dwSize = sizeof(DsCaps);
		hr = pMic->pDs->GetCaps(&DsCaps);
		if (hr == DS_OK)
		{
			audio_log_inf("audio_drv_mic_init -- caps for \"%s\"", pszDeviceName);
			audio_log_inf("flags 0x%x", DsCaps.dwFlags);
			audio_log_inf("flag DSCAPS_CERTIFIED  0x%x", DsCaps.dwFlags&DSCAPS_CERTIFIED);
			audio_log_inf("flag DSCAPS_EMULDRIVER  0x%x", DsCaps.dwFlags&DSCAPS_EMULDRIVER);
//			audio_log_inf("flag DSCCAPS_MULTIPLECAPTURE   0x%x", DsCaps.dwFlags&DSCCAPS_MULTIPLECAPTURE );
			audio_log_inf("dwFormats 0x%x", DsCaps.dwFormats);
			audio_log_inf("dwFormats&WAVE_FORMAT_1M16 0x%x", DsCaps.dwFormats&WAVE_FORMAT_1M16);
			audio_log_inf("dwFormats&WAVE_FORMAT_1S16 0x%x", DsCaps.dwFormats&WAVE_FORMAT_1S16);
			audio_log_inf("dwFormats&WAVE_FORMAT_2M16 0x%x", DsCaps.dwFormats&WAVE_FORMAT_2M16);
			audio_log_inf("dwFormats&WAVE_FORMAT_2S16 0x%x", DsCaps.dwFormats&WAVE_FORMAT_2S16);
			audio_log_inf("dwFormats&WAVE_FORMAT_4M16 0x%x", DsCaps.dwFormats&WAVE_FORMAT_4M16);
			audio_log_inf("dwFormats&WAVE_FORMAT_4S16 0x%x", DsCaps.dwFormats&WAVE_FORMAT_4S16);
#ifndef _WIN32_WCE
			audio_log_inf("dwFormats&WAVE_FORMAT_96M16 0x%x", DsCaps.dwFormats&WAVE_FORMAT_96M16);
			audio_log_inf("dwFormats&WAVE_FORMAT_96S16 0x%x", DsCaps.dwFormats&WAVE_FORMAT_96S16);
#endif
			audio_log_inf("dwChannels %d", DsCaps.dwChannels);
		}
		else
		{
			audio_log_war("audio_drv_mic_init -- GetCaps %s failed with 0x%x", pszDeviceName, hr);
		}

		DSCBUFFERDESC  BufDesc;
		WAVEFORMATEX BufFmt;


		// 80ms, mono, 16 bits
		memset(&BufFmt, 0, sizeof(BufFmt));
		BufFmt.wFormatTag = WAVE_FORMAT_PCM;//it was 1 originally
		BufFmt.nChannels = 1;
		BufFmt.nSamplesPerSec = AUDIO_DRV_FS;
		BufFmt.wBitsPerSample = 16;
		BufFmt.nAvgBytesPerSec = (BufFmt.wBitsPerSample >> 3) * BufFmt.nChannels * BufFmt.nSamplesPerSec;
		BufFmt.nBlockAlign = (BufFmt.wBitsPerSample >> 3) * BufFmt.nChannels;
		BufFmt.cbSize = 0;

		memset(&BufDesc, 0, sizeof(BufDesc));
		BufDesc.dwSize = sizeof(BufDesc);
		BufDesc.dwFlags =	DSCBCAPS_WAVEMAPPED|
							0;
		BufDesc.dwBufferBytes = AUDIO_DRV_MIC_BUF_SZ;
		BufDesc.dwReserved = 0;
		BufDesc.lpwfxFormat = &BufFmt;
		BufDesc.dwFXCount = 0;
		BufDesc.lpDSCFXDesc = NULL;

		hr =  pMic->pDs->CreateCaptureBuffer(&BufDesc, &pMic->pDsBuf, NULL);
		if (hr != DS_OK)
		{
			audio_log_err("audio_drv_mic_init -- buff create failed with 0x%x", hr);
			rc |= AUDIO_IF_ERR_DRV_MIC | AUDIO_IF_ERR_FAILED;
		}
	}
	else
	{
		audio_log_err("audio_drv_mic_init -- create failed with hr = 0x%x", hr);
		rc |= AUDIO_IF_ERR_DRV_MIC | AUDIO_IF_ERR_FAILED;
	}
	pMic->dwED = AUDIO_ED;
	pMic->dwSD = AUDIO_SD;

	return rc;
}
/*****************************************************************************/
DWORD					auddx_mic_start
/*****************************************************************************/
(
)
{
	unsigned long rc = AUDIO_IF_ERR_NONE;
	Audio_tDrvDxMic *pMic = &gAudio.Drv.Dx.Mic;
	HRESULT hr;

	hr = pMic->pDsBuf->Start(DSCBSTART_LOOPING);
	if (hr == DS_OK)
	{
		audio_log_inf("audio_drv_mic_start -- started");
		audio_tmr_peek(AUDIO_TMR_BASE, &pMic->fStartTime);
		pMic->fTime = 0;
		pMic->fTimeMin = 1.e3F;
#if 0
		DWORD dwReadOffset = 0;
		for (;;)
		{
			hr = pMic->pDsBuf->GetCurrentPosition(NULL, &dwReadOffset);
			if (hr == DS_OK)
			{
				if (dwReadOffset > AUDIO_DRV_MIC_BLK_SZ*AUDIO_DRV_MIC_PRIME)
				{
					pMic->dwReadOffset = AUDIO_DRV_MIC_BLK_SZ;
					break;
				}
				else
				{
					Sleep(5);
				}
			}
			else
			{
				audio_log_err("audio_drv_mic_start -- get pos failed with 0x%x", hr);
			}
		}
//		audio_log_inf("audio_drv_mic_init -- started, delay is %d samples [%6.2fms]", 
//			dwReadOffset,dwReadOffset*(0.5e3F/AUDIO_DRV_FS));
#endif
	}
	else
	{
		audio_log_err("audio_drv_mic_start -- start failed with 0x%x", hr);
		rc |= AUDIO_IF_ERR_DRV_MIC | AUDIO_IF_ERR_FAILED;
	}
	return rc;
}
/*****************************************************************************/
DWORD					auddx_mic_poll
/*****************************************************************************/
(
)
{
	DWORD rc = AUDIO_IF_ERR_NONE;
	Audio_tDrvDxMic *pMic = &gAudio.Drv.Dx.Mic;
	DWORD dwCaptureOffset = 0;
	DWORD dwReadOffset = 0;
	HRESULT hr;

//	return rc;

	if ((pMic->dwED != AUDIO_ED) || (pMic->dwSD != AUDIO_SD))
	{
		audio_log_err("audio_drv_mic_poll -- in mem corupted"); 
		return AUDIO_IF_ERR_MEM_CORRUPTED;
	}

	audio_tmr_start(AUDIO_TMR_MIC_POLL);
	hr = pMic->pDsBuf->GetCurrentPosition(&dwCaptureOffset, &dwReadOffset);
	if (hr == DS_OK)
	{
		int iDlt = 0;
		// see if a blk was written - and we can read a next block
		if (dwReadOffset > pMic->dwReadOffset)
		{
			iDlt = dwReadOffset - pMic->dwReadOffset;
		}
		else if (dwReadOffset < pMic->dwReadOffset) // wrap-around
		{
			iDlt = (AUDIO_DRV_MIC_BUF_SZ - pMic->dwReadOffset)+dwReadOffset;
		}
		else // ==
		{
			iDlt = 0;
		}

		if (iDlt > AUDIO_DRV_MIC_BLK_SZ)
		{
			void *pv1;
			DWORD dwSz1;
			int iReadFrom = int(pMic->dwReadOffset) - int(AUDIO_DRV_MIC_BLK_SZ);
			if (iReadFrom < 0)
				iReadFrom += AUDIO_DRV_MIC_BUF_SZ;

			hr = pMic->pDsBuf->Lock(DWORD(iReadFrom), 
							AUDIO_DRV_MIC_BLK_SZ, // sz
							&pv1, &dwSz1,
							NULL, NULL,
							0);
			if (hr == DS_OK)
			{
				if (dwSz1 < AUDIO_DRV_MIC_BLK_SZ)
					audio_log_err("audio_drv_mic_poll -- size: %d < %d", 
						dwSz1, AUDIO_DRV_MIC_BLK_SZ);

//				copy data out
				memcpy(pMic->asData, pv1, AUDIO_DRV_MIC_BLK_SZ);
				hr = pMic->pDsBuf->Unlock(pv1, AUDIO_DRV_MIC_BLK_SZ, NULL, 0);
				if (hr == DS_OK)
				{
					pMic->dwReadOffset += AUDIO_DRV_MIC_BLK_SZ;
					if (pMic->dwReadOffset >= AUDIO_DRV_MIC_BUF_SZ)
					{
						pMic->dwReadOffset -= AUDIO_DRV_MIC_BUF_SZ;
					}
					audio_tmr_restart(AUDIO_TMR_MIC_BLK, NULL);

	//				printf(".");

					// we allow 1 spike per minute, i.e. 3 per 3 minutes
					pMic->fCrit -= AUDIO_CRIT_MAX/(100.0F*60.F*3.F);
					if (pMic->fCrit < 0)
						pMic->fCrit = 0;

					// recover mic timing and collect jitter stts
					float fTime = gAudio.Drv.fNow - pMic->fStartTime;
					pMic->fTime += 20.F;
					float fDlt = fTime - pMic->fTime;

					if (fDlt > 0)
						pMic->fTime += AUDIO_DRV_MIC_PTAU * fDlt;
					else
						pMic->fTime += AUDIO_DRV_MIC_NTAU * fDlt;

					// wait for 1 sec, get min from fDlt, add it to pMic->fTime
					pMic->iTimeCnt++;
					if (pMic->iTimeCnt < 50)
					{
						if (pMic->fTimeMin > fDlt)
							pMic->fTimeMin = fDlt;
					}
					else if (pMic->iTimeCnt == 50)
					{
						pMic->fTime += pMic->fTimeMin;
					}
					else
					{
						pMic->iTimeCnt = 51;
						audio_hstgm_add(&gAudio.TmrCtrl.aTmr[AUDIO_TMR_MIC_JITTER].Hstgm, fDlt);
					}
				}
				else
				{
					audio_log_err("audio_drv_mic_poll -- unlock failed with 0x%x", hr);
				}
				pMic->iBlksRead++;

			}
			else
			{
				audio_log_err("audio_drv_mic_poll -- lock failed with 0x%x", hr);
			}
		}
		else //if (iDlt == 0)
		{
			; // nothing to do
		}
	}
	else
	{
		audio_log_err("audio_drv_mic_poll -- get pos failed with 0x%x", hr);
	}
	audio_tmr_stop(AUDIO_TMR_MIC_POLL, NULL);

	if (hr != DS_OK)
		rc |= AUDIO_IF_ERR_DRV_MIC | AUDIO_IF_ERR_FAILED;

	if ((pMic->dwED != AUDIO_ED) || (pMic->dwSD != AUDIO_SD))
	{
		audio_log_err("audio_drv_mic_poll -- out mem corupted"); 
		rc |= AUDIO_IF_ERR_MEM_CORRUPTED;
	}

	return rc;
}
/*****************************************************************************/
DWORD					auddx_mic_stop
/*****************************************************************************/
(
)
{
	HRESULT hr;

	if(NULL != gAudio.Drv.Dx.Mic.pDsBuf)
	{
		hr = gAudio.Drv.Dx.Mic.pDsBuf->Stop();
		if(DS_OK != hr)
			audio_log_err("auddx_mic_stop -- FAILED to Stop DirectSoundCaptureBuffer");

		hr = gAudio.Drv.Dx.Mic.pDsBuf->Release();
		if(DS_OK != hr)
			audio_log_err("auddx_mic_stop -- FAILED to Release DirectSoundCaptureBuffer");
	}

	if(NULL != gAudio.Drv.Dx.Mic.pDs)
	{
		hr = gAudio.Drv.Dx.Mic.pDs->Release();
		if(DS_OK != hr)
			audio_log_err("auddx_mic_stop -- FAILED to Release DirectSoundCapture");

	}

	return AUDIO_IF_ERR_NONE;
}
