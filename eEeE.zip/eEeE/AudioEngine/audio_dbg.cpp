#include <xmmintrin.h>
#include "audio_defs.h"
#define _LOG_NOW 0




/* ------------------------------------------------------------------- */
void                audio_log_inf
/* ------------------------------------------------------------------- */
(
char *pFmt, ...
)
{
	if (gAudio.Dbg.iLogLevel >= AUDIO_IF_LOG_LEVEL_INFO)
	{
		char acBuff[MAX_PATH];
		Audio_tDbgLogQ	*pLogQ = &gAudio.Dbg.LogQ;

		// - max number of writers... just to be safe
		if (pLogQ->lSz < AUDIO_DBG_LOGQ_SZ-5)
		{
			LONG idx = InterlockedIncrement(&pLogQ->lWriteIdx);
			idx--;

			float fTime = 0;
			audio_tmr_peek(0, &fTime);

			va_list  argPtr;                  /* Argument list pointer        */
			va_start(argPtr, pFmt );         /* Initialize va_ functions     */
			_vsnprintf(acBuff, MAX_PATH-30, pFmt, argPtr);
			va_end( argPtr );                 /* Close va_ functions          */

			char *pc = &pLogQ->aacData[idx&(AUDIO_DBG_LOGQ_SZ-1)][0];
			sprintf(pc, "inf [%15.6fs] %7d : %s", 
				fTime*1.e-3, gAudio.Drv.iFrameNo, acBuff);
#if (_LOG_NOW == 1)
			if (gAudio.Dbg.Win.wUiMode & 0x8000)
				printf("%s\n", pc);
#endif
			InterlockedIncrement(&pLogQ->lSz);
			if (pLogQ->lSz > AUDIO_DBG_LOGQ_SZ/2)
				SetEvent(gAudio.Dbg.ahEvents[AUDIO_DBG_EVENT_ACTION]);
		}
		else
			pLogQ->iOverflows++;
	}
}
/* ------------------------------------------------------------------- */
void                audio_log_err
/* ------------------------------------------------------------------- */
(
char *pFmt, ...
)
{
	if (gAudio.Dbg.iLogLevel >= AUDIO_IF_LOG_LEVEL_ERROR)
	{
		char acBuff[MAX_PATH];
		Audio_tDbgLogQ	*pLogQ = &gAudio.Dbg.LogQ;

		// - max number of writers... just to be safe
		if (pLogQ->lSz < AUDIO_DBG_LOGQ_SZ-5)
		{
			LONG idx = InterlockedIncrement(&pLogQ->lWriteIdx);
			idx--;

			float fTime = 0;
			audio_tmr_peek(0, &fTime);

			va_list  argPtr;                  /* Argument list pointer        */
			va_start(argPtr, pFmt );         /* Initialize va_ functions     */
			_vsnprintf(acBuff, MAX_PATH-30, pFmt, argPtr);
			va_end( argPtr );                 /* Close va_ functions          */

			char *pc = &pLogQ->aacData[idx&(AUDIO_DBG_LOGQ_SZ-1)][0];
			sprintf(pc, "ERR [%15.6fs] %7d : %s", 
				fTime*1.e-3, gAudio.Drv.iFrameNo, acBuff);
#if (_LOG_NOW == 1)
			if (gAudio.Dbg.Win.wUiMode & 0x8000)
				printf("%s\n", pc);	
#endif
			InterlockedIncrement(&pLogQ->lSz);
			if (pLogQ->lSz > AUDIO_DBG_LOGQ_SZ/2)
				SetEvent(gAudio.Dbg.ahEvents[AUDIO_DBG_EVENT_ACTION]);
		}
		else
			pLogQ->iOverflows++;
	}
}
/* ------------------------------------------------------------------- */
void                audio_log_war
/* ------------------------------------------------------------------- */
(
char *pFmt, ...
)
{
	if (gAudio.Dbg.iLogLevel >= AUDIO_IF_LOG_LEVEL_WARNING)
	{
		char acBuff[MAX_PATH];
		Audio_tDbgLogQ	*pLogQ = &gAudio.Dbg.LogQ;

		// - max number of writers... just to be safe
		if (pLogQ->lSz < AUDIO_DBG_LOGQ_SZ-5)
		{
			LONG idx = InterlockedIncrement(&pLogQ->lWriteIdx);
			idx--;

			float fTime = 0;
			audio_tmr_peek(0, &fTime);

			va_list  argPtr;                  /* Argument list pointer        */
			va_start(argPtr, pFmt );         /* Initialize va_ functions     */
			_vsnprintf(acBuff, MAX_PATH-30, pFmt, argPtr);
			va_end( argPtr );                 /* Close va_ functions          */

			char *pc = &pLogQ->aacData[idx&(AUDIO_DBG_LOGQ_SZ-1)][0];
			sprintf(pc, "war [%15.6fs] %7d : %s", 
				fTime/1.e3, gAudio.Drv.iFrameNo, acBuff);
	#if (_LOG_NOW == 1)
			if (gAudio.Dbg.Win.wUiMode & 0x8000)
				printf("%s\n", pc);
	#endif
			InterlockedIncrement(&pLogQ->lSz);
			if (pLogQ->lSz > AUDIO_DBG_LOGQ_SZ/2)
				SetEvent(gAudio.Dbg.ahEvents[AUDIO_DBG_EVENT_ACTION]);
		}
		else
			pLogQ->iOverflows++;
	}
}


/* ------------------------------------------------------------------- */
void                audio_log_trc
/* ------------------------------------------------------------------- */
(
char *pFmt, ...
)
{
	if (gAudio.Dbg.iLogLevel >= AUDIO_IF_LOG_LEVEL_TRACE)
	{
		char acBuff[MAX_PATH];
		Audio_tDbgLogQ	*pLogQ = &gAudio.Dbg.LogQ;

		// - max number of writers... just to be safe
		if (pLogQ->lSz < AUDIO_DBG_LOGQ_SZ-5)
		{
			LONG idx = InterlockedIncrement(&pLogQ->lWriteIdx);
			idx--;

			float fTime = 0;
			audio_tmr_peek(0, &fTime);

			va_list  argPtr;                  /* Argument list pointer        */
			va_start(argPtr, pFmt );         /* Initialize va_ functions     */
			_vsnprintf(acBuff, MAX_PATH-30, pFmt, argPtr);
			va_end( argPtr );                 /* Close va_ functions          */

			char *pc = &pLogQ->aacData[idx&(AUDIO_DBG_LOGQ_SZ-1)][0];
			sprintf(pc, "trc [%15.6fs] %7d : %s", 
				fTime/1.e3, gAudio.Drv.iFrameNo, acBuff);
#if (_LOG_NOW == 1)
			if (gAudio.Dbg.Win.wUiMode & 0x8000)
				printf("%s\n", pc);
#endif
			InterlockedIncrement(&pLogQ->lSz);
			if (pLogQ->lSz > AUDIO_DBG_LOGQ_SZ/2)
				SetEvent(gAudio.Dbg.ahEvents[AUDIO_DBG_EVENT_ACTION]);
		}
		else
			pLogQ->iOverflows++;
	}
}





/*****************************************************************************/
static void					audio_dbg_poll_log
/*****************************************************************************/
(
) 
{
	Audio_tDbgLogQ	*pLogQ = &gAudio.Dbg.LogQ;

	while (pLogQ->lSz > 0)
	{
		char *pc = &pLogQ->aacData[pLogQ->iReadIdx][0];
		if (pLogQ->fdLog)
			fprintf(pLogQ->fdLog, "%s\n", pc);
#if (_LOG_NOW == 0)
		if (gAudio.Dbg.Win.wUiMode & 0x8000)
			printf("%s\n", pc);
#endif


		InterlockedDecrement(&pLogQ->lSz);

		pLogQ->iReadIdx++;
		pLogQ->iReadIdx &= (AUDIO_DBG_LOGQ_SZ-1);
	}
}
/*****************************************************************************/
static void					audio_dbg_poll
/*****************************************************************************/
(
) 
{
	if (gAudio.Dbg.dwSD != AUDIO_SD) 
	{
		audio_log_err("audio_dbg_poll -- SD in");
		gAudio.Dbg.dwSD = AUDIO_SD;
	}
	if (gAudio.Dbg.dwED != AUDIO_ED) 
	{
		audio_log_err("audio_dbg_poll -- ED in");
		gAudio.Dbg.dwED = AUDIO_ED;
	}

	audio_dbg_poll_log();
	audio_dbg_poll_rec();
	if (gAudio.Dbg.Win.bCreated && gAudio.Dbg.Win.bActive)
	{
		// might be not every time
		audio_dbg_plot();
	}

	if (gAudio.Dbg.dwSD != AUDIO_SD) 
	{
		audio_log_err("audio_dbg_poll -- SD out");
		gAudio.Dbg.dwSD = AUDIO_SD;
	}
	if (gAudio.Dbg.dwED != AUDIO_ED) 
	{
		audio_log_err("audio_dbg_poll -- ED out");
		gAudio.Dbg.dwED = AUDIO_ED;
	}
//	printf(".");
}
/*****************************************************************************/
DWORD WINAPI			AudioDbgThreadProc
/*****************************************************************************/
(
LPVOID lpParam // TBD; thread priority, mm timer duration, etc
) 
{ 
	DWORD rc = AUDIO_IF_ERR_NONE;
	int iFailed = 0;
#if 0
	if (SetThreadPriority(gAudio.Dbg.hThread, THREAD_PRIORITY_ABOVE_NORMAL))
	{
		audio_log_inf("AudioDbgThreadProc -- set to priority %d", 
			THREAD_PRIORITY_ABOVE_NORMAL);
	}
	else
	{
		audio_log_err("AudioDbgThreadProc -- failed to set priority %d [0x%08x]",
			THREAD_PRIORITY_ABOVE_NORMAL, GetLastError());
	}
#endif

//	audio_log_inf("AudioDbgThreadProc -- started %d", gAudio.Dbg.LogQ.lSz);
	// open DbgWin
	_MM_SET_FLUSH_ZERO_MODE(_MM_FLUSH_ZERO_ON);

	gAudio.Dbg.bRunning = true;

	if (gAudio.Dbg.Win.wUiMode)
	{
		gAudio.Dbg.Win.bCreated = audio_dbg_open_win();
		if (!gAudio.Dbg.Win.bCreated)
		{
			audio_log_err("AudioDbgThreadProc -- create win failed");
		}
		else
		{
			audio_log_inf("AudioDbgThreadProc -- create win ok");
		}
	}
	else
	{
		audio_log_inf("AudioDbgThreadProc -- no win");
	}

	SetEvent(gAudio.Dbg.hStartEvent);

	for (;;)
	{
        MSG msg ; 
		DWORD dwQuit = 0; 

        // Read all of the messages in this next loop, 
        // removing each message as we read it.
        while (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) 
        { 
            // If it is a quit message, exit.
            if (msg.message == WM_QUIT)  
			{
                dwQuit = 1; 
				break;
			}
            // Otherwise, dispatch the message.
            DispatchMessage(&msg); 
        } // End of PeekMessage while loop.

		if (dwQuit)	break;

		DWORD dw = MsgWaitForMultipleObjects(
			AUDIO_DBG_EVENTS,
			gAudio.Dbg.ahEvents,
			FALSE,
			AUDIO_DBG_THREAD_TIMEOUT,
			QS_ALLINPUT);

		if (dw == WAIT_TIMEOUT)
		{
			// it's a highly unreliable timer. implemenation/os dependend.
			// can fire earler or later, whatever...
			audio_dbg_poll();
		}
		else if (dw == WAIT_FAILED)
		{
			audio_log_err("AudioDbgThreadProc -- wait failed");
			iFailed++;
			if (iFailed > 100)
			{
				audio_log_err("AudioDbgThreadProc -- too many failures");
				audio_dbg_poll();
				rc = AUDIO_IF_ERR_FAILED;
				break;
			}
		}
		else
		{
			DWORD dwEvent = dw - WAIT_OBJECT_0;
			if (dwEvent == AUDIO_DBG_EVENT_QUIT) // quit request
			{
				audio_log_inf("AudioDbgThreadProc - event AUDIO_DBG_EVENT_QUIT");
				PostQuitMessage(0);
//				break;
			}
			else if (dwEvent == AUDIO_DBG_EVENT_ACTION) // action
			{
				audio_tmr_restart(AUDIO_TMR_DBG_THREAD, NULL);
				// flush the q
				audio_dbg_poll();
			} 
			else if (dwEvent == AUDIO_DBG_EVENT_WIN_OPEN) 
			{
				audio_log_inf("AudioDbgThreadProc - event AUDIO_DBG_EVENT_WIN_OPEN");
				audio_dbg_win_activate(true);

			}
			else if (dwEvent == AUDIO_DBG_EVENT_WIN_CLOSE) 
			{
				audio_log_inf("AudioDbgThreadProc - event AUDIO_DBG_EVENT_WIN_CLOSE");
				audio_dbg_win_activate(false);
			}
			else if (dwEvent == AUDIO_DBG_EVENTS)
			{
				// new windows message arrived
				continue;
			}
		}
	}
	// close DbgWin
	if (gAudio.Dbg.Win.bCreated)
	{
		audio_dbg_delete_win(gAudio.Dbg.Win.hWnd);
	}

	audio_utl_thread_stts(
		GetCurrentThread(), 
		&gAudio.CpuStts.fDbgThreadKernelModePercentage,
		&gAudio.CpuStts.fDbgThreadUserModePercentage);

	audio_log_inf("AudioDbgThreadProc -- %7.2f%% in kernel, %7.2f%% in user mode", 
		gAudio.CpuStts.fDbgThreadKernelModePercentage,
		gAudio.CpuStts.fDbgThreadUserModePercentage
		);

	for (int k = 0; k < AUDIO_DBG_EVENTS; k++)
    {
        CloseHandle(gAudio.Dbg.ahEvents[k]);
    }

	CloseHandle(gAudio.Dbg.hStartEvent);
	gAudio.Dbg.bRunning = false;

	return rc;
}

/*****************************************************************************/
static bool				_try_sse
/*****************************************************************************/
(
)
{
	__try {
		__asm {
			xorps xmm0, xmm0        // executing SSE instruction
		}
	}
	#pragma warning (suppress: 6320)
	__except (EXCEPTION_EXECUTE_HANDLER) {
		if (_exception_code() == STATUS_ILLEGAL_INSTRUCTION) {
				return false;
		}
		return false;
	}
	return true;
}
/*****************************************************************************/
DWORD						AudioIf_init
/*****************************************************************************/
(
char *pszLogFileName, // NULL if none
int	iLogLevel,
char *pszRecFilesDirectory, // NULL if none
WORD wRecMask, // if pszRecFilesDirectory != NULL
WORD wUiMode
)
{
	unsigned long rc = AUDIO_IF_ERR_NONE;

	if (gAudio.Dbg.bRunning)
	{
		audio_log_err("AudioIf_init -- already started");
		return AUDIO_IF_ERR_ALREADY_EXISTS;
	}


	// requires Vista/XP/2000Pro/NT4.0
	BOOL b = IsProcessorFeaturePresent(PF_XMMI_INSTRUCTIONS_AVAILABLE);
	if (!b)
	{
		b = _try_sse();

		if (!b)
			return AUDI0_IF_ERR_HW_NOT_SUPPORTED;
	}
//	memset(&gAudio.Dbg, 0, sizeof(gAudio.Dbg));
	memset(&gAudio, 0, sizeof(gAudio));
	gAudio.Dbg.Win.wUiMode = wUiMode;
	gAudio.Dbg.Rec.wMask = wRecMask;
	gAudio.Dbg.dwSD = AUDIO_SD;
	gAudio.Dbg.dwED = AUDIO_ED;

	audio_create();

	if (pszRecFilesDirectory)
	{
		strncpy(gAudio.Dbg.acRecFilesDirectory, pszRecFilesDirectory, MAX_PATH);
	}

	if (pszLogFileName)
	{
		gAudio.Dbg.LogQ.fdLog = fopen(pszLogFileName, "w");
		if (gAudio.Dbg.LogQ.fdLog == NULL)
			rc |= AUDIO_IF_ERR_WARNING | AUDIO_IF_ERR_FILE_IO;
		gAudio.Dbg.iLogLevel = iLogLevel;
	}

	for (int k = 0; k < AUDIO_DBG_EVENTS; k++)
	{
		gAudio.Dbg.ahEvents[k] = CreateEvent(NULL, FALSE, FALSE, NULL);
		if (gAudio.Dbg.ahEvents[k] == NULL)
		{
			rc = AUDIO_IF_ERR_FAILED;
			break;
		}
	}
	if (rc == AUDIO_IF_ERR_NONE)
	{
		gAudio.Dbg.hStartEvent = CreateEvent(NULL, FALSE, FALSE, NULL);
		if (gAudio.Dbg.hStartEvent == NULL)
		{
			audio_log_err("AudioIf_init -- Create StartEvent failed");
			rc |= AUDIO_IF_ERR_FAILED;
		}
		else
		{
			audio_log_inf("AudioIf_init -- built on " __DATE__ " at " __TIME__);

			gAudio.Dbg.hThread = CreateThread(
					NULL, // can't be inherted LPSECURITY_ATTRIBUTES lpThreadAttributes,
					NULL, // default SIZE_T dwStackSize,
					AudioDbgThreadProc, // LPTHREAD_START_ROUTINE lpStartAddress,
					pszLogFileName, //LPVOID lpParameter,
					0, // DWORD dwCreationFlags,
					&gAudio.Dbg.dwThreadId);//LPDWORD lpThreadId

			if (gAudio.Dbg.hThread == NULL)
			{
				rc |= AUDIO_IF_ERR_FAILED;
			}
			else
			{
				gAudio.bInitialized = true;
				DWORD dw = WaitForSingleObject(gAudio.Dbg.hStartEvent, 5000); // 2 sec max	
																				//June 20, 2007
																				// Increaseing it to 5sec, got some timeout error	

				switch(dw)
				{
				case WAIT_OBJECT_0: // normal exit
					audio_log_inf("AudioIf_init -- done");
					break;
				default:
					rc |= AUDIO_IF_ERR_TIMING;
					break;
				}
			}
		}
	}

	return rc;
}
/*****************************************************************************/
DWORD				AudioIf_destroy
/*****************************************************************************/
(
)
{
	if (!gAudio.bInitialized) return AUDIO_IF_ERR_NOT_INITIALIZED;

	unsigned long rc = AUDIO_IF_ERR_NONE;
	audio_lock();
	audio_log_inf("AudioIf_destroy -- ");

	if (gAudio.bRunning)
	{
		audio_log_err("AudioIf_destroy -- forced call to AudioIf_drv_close()");
		AudioIf_drv_close(NULL);
	}

	if (!gAudio.Dbg.bRunning)
	{
		audio_log_err("AudioIf_destroy -- already stopped");
		gAudio.bInitialized = false;
		return AUDIO_IF_ERR_ALREADY_REMOVED;
	}

	audio_tmr_start(AUDIO_TMR_DRV_THREAD);

	if (SetEvent(gAudio.Dbg.ahEvents[AUDIO_DBG_EVENT_QUIT]))
	{
		float fTimeout = 0;
		DWORD dw = WaitForSingleObject(gAudio.Dbg.hThread, 1000);
		audio_tmr_stop(AUDIO_TMR_DRV_THREAD, &fTimeout);

		switch(dw)
		{
		case WAIT_OBJECT_0:
			audio_log_inf("AudioIf_destroy -- thread stopped in %7.3f ms", fTimeout);
			break;
		case WAIT_TIMEOUT:
			audio_log_err("AudioIf_destroy -- timeout %7.3f ms", 1000);
			rc = AUDIO_IF_ERR_WARNING;
			break;
		default:
			audio_log_err("AudioIf_destroy -- unknown ret code 0x%x", dw);
			rc = AUDIO_IF_ERR_WARNING;
			break;
		}
	}
	else
	{
		rc = AUDIO_IF_ERR_FAILED;
	}

	if (gAudio.Dbg.bRunning)
	{
		Sleep(5);
	}
	CloseHandle(gAudio.Dbg.hThread);

	// flush q
	audio_dbg_poll();


	if (gAudio.Dbg.Rec.wMask)
	{
		if (gAudio.Dbg.LogQ.fdLog)
			fprintf(gAudio.Dbg.LogQ.fdLog, 
					"\nAudioDbgThreadProc -- rec q overflows %d\n", 
					gAudio.Dbg.Rec.Q.iOverflows);
		if (gAudio.Dbg.Win.wUiMode & 0x8000)
			printf("AudioDbgThreadProc -- rec q overflows %d\n", 
				gAudio.Dbg.Rec.Q.iOverflows);
	}

	if (gAudio.Dbg.LogQ.fdLog)
	{
		fprintf(gAudio.Dbg.LogQ.fdLog, 
				"\nAudioDbgThreadProc -- log q overflows %d\n", 
				gAudio.Dbg.LogQ.iOverflows);
		if (gAudio.Dbg.Win.wUiMode & 0x8000)
			printf("AudioDbgThreadProc -- log q overflows %d\n", 
				gAudio.Dbg.LogQ.iOverflows);
		fclose(gAudio.Dbg.LogQ.fdLog);
	}

	audio_unlock();
	audio_delete();
//	memset(&gAudio, 0, sizeof(gAudio));
	gAudio.bInitialized = false;

	return rc;
}

