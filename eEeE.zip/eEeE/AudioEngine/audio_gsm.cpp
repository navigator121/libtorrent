#include "audio_defs.h"
#include "audio_gsm.h"

/*****************************************************************************/
void *				audio_GSM_init
/*****************************************************************************/
(
)
{
	return gsm_create();
}
/*****************************************************************************/
void *				audio_GSM_delete
/*****************************************************************************/
(
void *pObj
)
{
	gsm_destroy((gsm)pObj);
	return NULL;
}
/*****************************************************************************/
int					audio_GSM_decode
/*****************************************************************************/
(
void *pObj,
short *psOut,
BYTE *pcIn // can be NULL -> PLC
)
{
	gsm_state *pDec = (gsm_state*)pObj;

	if (pcIn)
	{
		gsm_decode(
			pDec,
			(gsm_byte *)pcIn,
			psOut);
	}
	else
	{
		memset(psOut, 0, sizeof(short)*AUDIO_FRSZ8);
	}
	return AUDIO_FRSZ8;
}
/*****************************************************************************/
int					audio_GSM_encode
/*****************************************************************************/
(
void *pObj,
BYTE *pcOut,
short *psIn
)
{
	gsm_state * pEnc = (gsm_state *)pObj;
	gsm_encode(
			pEnc,
			psIn,
			(gsm_byte *)pcOut);

	return AUDIO_CSZ_GSM;
}
