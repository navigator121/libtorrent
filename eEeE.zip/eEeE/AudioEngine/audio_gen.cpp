
#include "audio_defs.h"
#include "audio_g711a.h"
#include "audio_g711u.h"
#include "audio_speex.h"
#include "audio_ilbc.h"
#include "audio_gsm.h"
#include "audio_g729.h"
#include "siren_if.h"

#include <stdlib.h>


Audio_tGen gAudioGen = {0};

volatile short s = 12345;

/*****************************************************************************/
static int						_my_rand
/*****************************************************************************/
(
)
{

	s = short(s*int(31821) + int(13849));
	s&= 0x7fff;
	return int(s);
}

/*****************************************************************************/
static int						_src_idx
/*****************************************************************************/
(
int iSrcId
)
{
	int idx = -1;
	for (int k = 0; k < AUDIO_IF_PARTY_MAX; k++)
	{
		if ((gAudioGen.aStream[k].bRunning) &&
			(gAudioGen.aStream[k].iSrcId == iSrcId))
		{
			idx = k;
			break;
		}
	}
	return idx;
}
/*****************************************************************************/
void					audio_gen_set_callback
/*****************************************************************************/
(
void *arg,
AudioGenRecvCallback pCallback
)
{
	gAudioGen.pCallback.arg = arg;
	gAudioGen.pCallback.fp = pCallback;
}
/*****************************************************************************/
static DWORD			_sender
/*****************************************************************************/
(
WORD	wSrcId,				// shall be one of used in AudioIf_src_add()
WORD	wPayloadType,		// extract it from RTP header
WORD	wSequenceNumber,	// sequence number
DWORD	dwTimeStamp,		// timestamp
BYTE*	pcRtpData,	// ptr to the start of RTP data
WORD	wRtpDataSz
)
{
	DWORD rc = 0;

	switch(gAudioGen.iSendMode)
	{
	case 0:
		rc = AudioIf_net_rcv(
			wSrcId,
			wPayloadType,
			wSequenceNumber,
			dwTimeStamp,
			pcRtpData,
			wRtpDataSz);
		break;
	case 1: // UDP
		if (gAudioGen.pCallback.fp)
			rc = gAudioGen.pCallback.fp(
				gAudioGen.pCallback.arg,
				wSrcId,
				wPayloadType,
				wSequenceNumber,
				dwTimeStamp,
				pcRtpData,
				wRtpDataSz);
		break;
	}
// mode = net
	// make rtp header
	// send using raw
	gAudioGen.iCnt++;
	return rc;
}
/*****************************************************************************/
static void				_try_sending
/*****************************************************************************/
(
Audio_tGenStream *pStream,
int iEncoded
)
{
	static Audio_tRtpHdr HdrSav = {0};
	static BYTE *pcCodeSav = NULL;
	if (iEncoded > 0) // CBR only
	{
		pStream->iTS += pStream->dwTsFrame;
		pStream->iCurrentFrame++;
		pStream->iEncodedTotal += iEncoded;

		if (pStream->iCurrentFrame >= pStream->iFPP)
		{
			if (pStream->bDtx)
				pStream->iDtxCnt++;

			if (pStream->iDtxCnt <= pStream->iDtxSend)
			{
	//			printf(">>%d=%d", pStream->iCurrentFrame, pStream->iFPP);
				if (((rand() < int(RAND_MAX*gAudioGen.fLost/100.0)) && (pcCodeSav == NULL))
	//				||((pStream->iSN > 1000) && (pStream->iSN < 1050))
					)
				{
					// do not send anything
				}
				else
				{
					if ((rand() < int(RAND_MAX*gAudioGen.fOOS/100.0)) && // OOS
						(pcCodeSav == NULL))
					{
						pcCodeSav = (BYTE *)AudioIf_alloc(pStream->iEncodedTotal); 
						memcpy(pcCodeSav, pStream->pcCode, pStream->iEncodedTotal);
						HdrSav.wIdx = pStream->iSrcId;
						HdrSav.dwTS = pStream->iTS; 
						HdrSav.wSN = pStream->iSN;
						HdrSav.wPT = pStream->iPT;
					}
					else
					{
	//					printf(">");
						DWORD rc = _sender(
							pStream->iSrcId, 
							pStream->iPT,
							pStream->iSN,
							pStream->iTS,
							pStream->pcCode,
							pStream->iEncodedTotal);

						if (pcCodeSav)
						{
							rc = _sender(
								HdrSav.wIdx,
								HdrSav.wPT,
								HdrSav.wSN,
								HdrSav.dwTS,
								pcCodeSav, 
								pStream->iEncodedTotal);
							pcCodeSav = (BYTE *)AudioIf_free(pcCodeSav);
						}
					}
				}
				pStream->iSN++;
			}
			else // DTX is enganged
			{
				if (pStream->iDtxCnt > pStream->iDtxSend + pStream->iDtxPause)
				{
					pStream->iDtxCnt = 0;
				}
			}
			pStream->iCurrentFrame = 0;
			pStream->iEncodedTotal = 0;
		}
	}
}
/*****************************************************************************/
void					audio_gen_process
/*****************************************************************************/
(
)
{
	int k;
	for (k = 0; k < AUDIO_IF_PARTY_MAX; k++)
	{
		Audio_tGenStream *pStream = &gAudioGen.aStream[k];
		if (pStream->bRunning)
		{
			short asFrame[AUDIO_FRSZ32]; // juts in case of Siren
			int iSz = pStream->dwTsFrame;
			if (pStream->iPT == AUDIO_IF_PT_G729A)
				iSz *= 2;

			int i = (int)fread(asFrame, sizeof(short), iSz, pStream->fd);
#if 0
			for (int n = 0; n < AUDIO_FRSZ; n++)
			{
				int x = asFrame[n] * 5;
				if (x > 32767)
					x = 32767;
				if (x < -32768)
					x = -32768;
				asFrame[n] = short(x);

			}
#endif
			if (i < iSz) // eof
			{
#ifndef _WIN32_WCE
				rewind(pStream->fd);
#else
				fseek(pStream->fd, 0, SEEK_SET);
#endif
				fread(asFrame, 1, 44, pStream->fd); // sizeof WavHdr
				pStream->iCurrentLoop++;
				if (pStream->iLoops > 0)
				{
					if (pStream->iCurrentLoop > pStream->iLoops)
					{
						audio_gen_rem_stream(pStream->iSrcId);
					}
				}
			}

			if (pStream->bRunning) // not finished yet
			{
				int iEncoded = 0;
				switch(pStream->iPT)
				{
				case AUDIO_IF_PT_G711A:
					iEncoded = audio_G711A_encode
							(
							pStream->pcCode + AUDIO_CSZ_G711*pStream->iCurrentFrame,
							asFrame
							);
					break;
				case AUDIO_IF_PT_G711U:
					iEncoded = audio_G711U_encode
							(
							pStream->pcCode + AUDIO_CSZ_G711*pStream->iCurrentFrame,
							asFrame
							);
					break;
				case AUDIO_IF_PT_SPEEX_NB:
					iEncoded = audio_speex_encode(pStream->pvEncoder,
							pStream->pcCode + AUDIO_CSZ_SPEEX_NB*pStream->iCurrentFrame,
							asFrame
							);
					break;
				case AUDIO_IF_PT_SPEEX_WB:
					iEncoded = audio_speex_encode(pStream->pvEncoder,
							pStream->pcCode + AUDIO_CSZ_SPEEX_WB*pStream->iCurrentFrame,
							asFrame
							);
					break;
				case AUDIO_IF_PT_SPEEX_UWB:
					iEncoded = audio_speex_encode(pStream->pvEncoder,
							pStream->pcCode + AUDIO_CSZ_SPEEX_UWB*pStream->iCurrentFrame,
							asFrame
							);
					break;
				case AUDIO_IF_PT_ILBC:
					iEncoded = audio_iLBC_encode
							(
							pStream->pvEncoder,
							pStream->pcCode + AUDIO_CSZ_ILBC*pStream->iCurrentFrame,
							asFrame
							);
					break;

				case AUDIO_IF_PT_GSM:
					iEncoded = audio_GSM_encode
							(
							pStream->pvEncoder,
							pStream->pcCode + AUDIO_CSZ_GSM*pStream->iCurrentFrame,
							asFrame
							);
					break;
#if AUDIO_G729
				case AUDIO_IF_PT_G729A:
					iEncoded = audio_G729_encode
							(
							pStream->pvEncoder,
							pStream->pcCode + AUDIO_CSZ_G729A*pStream->iCurrentFrame,
							asFrame
							);
					_try_sending(pStream, iEncoded);
					iEncoded = audio_G729_encode
							(
							pStream->pvEncoder,
							pStream->pcCode + AUDIO_CSZ_G729A*pStream->iCurrentFrame,
							asFrame+AUDIO_FRSZ8/2 // from
							);
					break;
#endif
				case AUDIO_IF_PT_SIREN14:
					iEncoded = siren_encode
							(
							pStream->pvEncoder,
							pStream->pcCode + AUDIO_CSZ_SIREN1424*pStream->iCurrentFrame,
							asFrame
							);
					break;
				case AUDIO_IF_PT_SIREN1432:
					iEncoded = siren_encode(pStream->pvEncoder,
							pStream->pcCode + AUDIO_CSZ_SIREN1432*pStream->iCurrentFrame,
							asFrame
							);
					break;
				case AUDIO_IF_PT_SIREN1448:
					iEncoded = siren_encode(pStream->pvEncoder,
							pStream->pcCode + AUDIO_CSZ_SIREN1448*pStream->iCurrentFrame,
							asFrame
							);
					break;
				case AUDIO_IF_PT_SIREN1416:
					iEncoded = siren_encode(pStream->pvEncoder,
							pStream->pcCode + AUDIO_CSZ_SIREN1416*pStream->iCurrentFrame,
							asFrame
							);
					break;
				default:
					// later
					break;
				}
				_try_sending(pStream, iEncoded);
			}
		}
	}
}
/*****************************************************************************/
DWORD WINAPI			AudioGenThreadProc
/*****************************************************************************/
(
LPVOID lpParam // TBD; thread priority, mm timer duration, etc
) 
{ 
	DWORD rc = AUDIO_IF_ERR_NONE;
	static int iFailed = 0;
	bool fDone = false;

	if (SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_TIME_CRITICAL))
	{
		audio_log_inf("AudioGenThreadProc -- set to priority %d", 
			THREAD_PRIORITY_TIME_CRITICAL);
	}
	else
	{
		audio_log_err("AudioGenThreadProc -- failed to set priority %d [0x%08x]",
			THREAD_PRIORITY_TIME_CRITICAL, GetLastError());
	}

#if AUDIO_DRV_USE_MM_TMR 
	gAudioGen.uMmTimerId = timeSetEvent(
		AUDIO_GEN_THREAD_TIMEOUT, 
		0, 
		(LPTIMECALLBACK )gAudioGen.ahEvents[1], 
		0, 
#ifndef _WIN32_WCE
		TIME_PERIODIC | TIME_CALLBACK_EVENT_SET | TIME_KILL_SYNCHRONOUS);
#else
		TIME_PERIODIC | TIME_CALLBACK_EVENT_SET);
#endif

	if (gAudioGen.uMmTimerId == NULL)
	{
		audio_log_war("AudioGenThreadProc -- failed to create mm timer");
	}
#endif

	audio_tmr_peek(0, &gAudioGen.fBaseTS);
	gAudioGen.fTS = gAudioGen.fBaseTS + AUDIO_FRMS*(1+gAudioGen.fSkew*1e-6F);
	gAudioGen.bRunning = true;

	for (;!fDone;)
	{
		DWORD dw = WaitForMultipleObjects(
			2, 
			gAudioGen.ahEvents, 
			FALSE, 
			AUDIO_GEN_THREAD_TIMEOUT);

		switch(dw)
		{
		case WAIT_OBJECT_0+0: // exit
			fDone = true;
			break;
		case WAIT_OBJECT_0+1: // exit
		case WAIT_TIMEOUT: // do the job
			{
				int ir = _my_rand();
				int irr= _my_rand();
				bool br = true;

				float fJitter = ir*(1.F/RAND_MAX)*gAudioGen.fJitter;

				iFailed = 0;
				gAudioGen.iEvents++;


				if      (irr < 0.02F*RAND_MAX)	fJitter *= 1.0F;
				else if (irr < 0.1F *RAND_MAX)	fJitter *= 0.3F;
				else if (irr < 0.5F *RAND_MAX)	fJitter *= 0.1F;
				else {
					fJitter = 0;
					br=false;
				}
#if 0
				// add 800 ms jump
				if ((gAudioGen.iCnt == 0) ||
					(gAudioGen.iCnt == 1500))
				{
					fJitter += 800.F;
				}
#endif
				for (int i = 0; i < 10; i++) // max 10 pkts at the time
				{
					audio_tmr_peek(0, &gAudioGen.fNow);


					//r = 0.1F/(r+.1F)-0.09F;	fTS += r*gAudioGen.fJitter;
		//			fTS += gAudioGen.fJitter/(1.f+r*gAudioGen.fJitter); // not a poisson
		//			fTS += gAudioGen.fJitter*rand()*(1.F/RAND_MAX); // not a poisson

					if (gAudioGen.fNow > gAudioGen.fTS + fJitter) // 20 ms expired, + jitter + skew
					{
						audio_gen_process();
						audio_tmr_restart(AUDIO_TMR_GEN_THREAD, NULL);

						gAudioGen.fTS += AUDIO_FRMS*(1+gAudioGen.fSkew*1e-6F);

//						if(br) audio_log_inf("AudioGenThreadProc -- jitter=%f %d %d", fJitter, ir, irr);
					}
					else
					{
						i = 10;
					}
				}
			}
			break;
		default:
			iFailed ++;
			if (iFailed > 100)
			{
				audio_log_err("AudioGenThreadProc -- failed");
				fDone = true;
			}
			break;
		}
	}
	if (gAudioGen.uMmTimerId)
		timeKillEvent(gAudioGen.uMmTimerId);

	gAudioGen.bRunning = false;
	return rc;
}

/*****************************************************************************/
DWORD					audio_gen_start
/*****************************************************************************/
(
int iSendMode
)
{
	DWORD rc = AUDIO_IF_ERR_NONE;
	audio_log_inf("audio_gen_start -- iSendMode=%d", iSendMode);

	if (!gAudioGen.bRunning)
	{
		memset(&gAudioGen, 0, (char *)&gAudioGen.pCallback - (char *)&gAudioGen);

		for (int k = 0; k < 2; k++)
		{
			gAudioGen.ahEvents[k] = CreateEvent(NULL, FALSE, FALSE, NULL);
			if (gAudioGen.ahEvents[k] == NULL)
			{
				audio_log_err("audio_gen_start -- CreateEvent %d failed", k);
				rc = AUDIO_IF_ERR_FAILED;
			}
		}

		gAudioGen.iSendMode = iSendMode;

		if (rc == AUDIO_IF_ERR_NONE)
		{

			gAudioGen.hThread = CreateThread(
				NULL, // can't be inherted LPSECURITY_ATTRIBUTES lpThreadAttributes,
				NULL, // default SIZE_T dwStackSize,
				AudioGenThreadProc, // LPTHREAD_START_ROUTINE lpStartAddress,
				NULL, //LPVOID lpParameter,
				0, // DWORD dwCreationFlags,
				&gAudioGen.dwThreadId);//LPDWORD lpThreadId

			if (gAudioGen.hThread == NULL)
			{
				audio_log_err("audio_gen_start -- CreateThread failed");
				rc = AUDIO_IF_ERR_FAILED;
			}
			else
			{
				while (!gAudioGen.bRunning)
					Sleep(10);
			}

		}
	}
	else
	{
		; // heck with it:-)))
	}
	return rc;
}
/*****************************************************************************/
DWORD					audio_gen_set_jitter
/*****************************************************************************/
(
float fLost, 
float fOOS, 
float fJitter,
float fSkew
)
{
	audio_log_inf("audio_gen_set_jitter -- fLost=%f fOOS=%f fJitter=%f fSkew=%f", 
					fLost, fOOS, fJitter, fSkew);

	gAudioGen.fLost = fLost;
	gAudioGen.fOOS = fOOS;
	gAudioGen.fJitter = fJitter;
	gAudioGen.fSkew = fSkew;
	return 0;
}

/*****************************************************************************/
DWORD					audio_gen_stop
/*****************************************************************************/
(
)
{
	DWORD rc = AUDIO_IF_ERR_NONE;


	if (!gAudioGen.bRunning)
	{
		audio_log_err("audio_gen_stop -- already stopped");
		return AUDIO_IF_ERR_ALREADY_REMOVED;
	}

	if (SetEvent(gAudioGen.ahEvents[0]))
	{
		DWORD dw = WaitForSingleObject(gAudioGen.hThread, 100);

		switch(dw)
		{
		case WAIT_OBJECT_0:
			audio_log_inf("audio_gen_stop -- thread stopped OK"); 
			break;
		case WAIT_TIMEOUT:
			audio_log_err("audio_gen_stop -- timeout");
			rc = AUDIO_IF_ERR_WARNING;
			break;
		default:
			audio_log_err("audio_gen_stop -- unknown ret code 0x%x", dw);
			rc = AUDIO_IF_ERR_WARNING;
			break;
		}
	}
	else
	{
		rc = AUDIO_IF_ERR_FAILED;
	}

	for (int k = 0; k < 2; k++)
	{
	    CloseHandle(gAudioGen.ahEvents[k]);
	}
	audio_log_inf("audio_gen_stop -- exit");

	return rc;
}
/*****************************************************************************/
DWORD				audio_gen_add_stream
/*****************************************************************************/
(
int iSrcId, 
int iPT, 
int iTS, 
int iSN, 
int iFPP, 
int iLoops, 
char *pcToken
)
{
	DWORD rc = AUDIO_IF_ERR_NONE;
	audio_log_inf("audio_gen_add_stream -- SrcId=%d PT=%d TS=%u SN=%u FPP=%d Loops=%d \"%s\"",
		iSrcId, iPT, iTS, iSN, iFPP, iLoops, pcToken);

	bool bOk = false;

	if (_src_idx(iSrcId) < 0)
	{
		// find first available slot
		int k;

		for (k = 0; k < AUDIO_IF_PARTY_MAX; k++)
		{
			if (!gAudioGen.aStream[k].bRunning)
			{
				break;
			}
		}

		if (k < AUDIO_IF_PARTY_MAX)
		{
			Audio_tGenStream *pStream = &gAudioGen.aStream[k];
			memset(pStream, 0, sizeof(Audio_tGenStream));
			pStream->iSrcId = iSrcId;
			pStream->iPT = iPT;
			pStream->iTS = iTS;
			pStream->iSN = iSN;
			pStream->iFPP = iFPP;
			pStream->dwTsFrame = AUDIO_FRSZ8;
			pStream->iAllocSz = 0;
			pStream->iLoops = iLoops;

			if (pcToken)
			{
				pStream->fd = fopen(pcToken, "rb");
			}

			if (pStream->fd != NULL)
			{
				char acFrame[44];
				fread(acFrame, 1, 44, pStream->fd); // sizeof WavHdr

				switch(iPT)
				{
				case AUDIO_IF_PT_G711A:
					pStream->iAllocSz += AUDIO_CSZ_G711*iFPP;
					pStream->pcCode = (BYTE*)AudioIf_alloc(pStream->iAllocSz);
					if (pStream->pcCode)
					{
						pStream->pvEncoder = NULL;
						bOk = true;
					}
					break;
				case AUDIO_IF_PT_G711U:
					pStream->iAllocSz += AUDIO_CSZ_G711*iFPP;
					pStream->pcCode = (BYTE*)AudioIf_alloc(pStream->iAllocSz);
					if (pStream->pcCode)
					{
						pStream->pvEncoder = NULL;
						bOk = true;
					}
					break;
				case AUDIO_IF_PT_SPEEX_NB:
					pStream->iAllocSz += AUDIO_CSZ_SPEEX_NB*iFPP;
					pStream->pcCode = (BYTE*)AudioIf_alloc(pStream->iAllocSz);
					if (pStream->pcCode)
					{
						pStream->pvEncoder = AudioIf_alloc(sizeof(Audio_tSpeex));
						if (pStream->pvEncoder)
						{
							DWORD rcc = audio_speex_encoder_init
								(
								pStream->pvEncoder, 
								AUDIO_IF_PT_SPEEX_NB
								);
							if (rcc == AUDIO_IF_ERR_NONE)
							{
								bOk = true;
							}
						}
					}
					break;
				case AUDIO_IF_PT_SPEEX_WB:
					pStream->iAllocSz += AUDIO_CSZ_SPEEX_WB*iFPP;
					pStream->pcCode = (BYTE*)AudioIf_alloc(pStream->iAllocSz);
					if (pStream->pcCode)
					{
						pStream->pvEncoder = AudioIf_alloc(sizeof(Audio_tSpeex));
						if (pStream->pvEncoder)
						{
							DWORD rcc = audio_speex_encoder_init
								(
								pStream->pvEncoder, 
								AUDIO_IF_PT_SPEEX_WB
								);
							if (rcc == AUDIO_IF_ERR_NONE)
							{
								bOk = true;
								pStream->dwTsFrame = AUDIO_FRSZ16;
							}
						}
					}
					break;
				case AUDIO_IF_PT_SPEEX_UWB:
					pStream->iAllocSz += AUDIO_CSZ_SPEEX_UWB*iFPP;
					pStream->pcCode = (BYTE*)AudioIf_alloc(pStream->iAllocSz);
					if (pStream->pcCode)
					{
						pStream->pvEncoder = AudioIf_alloc(sizeof(Audio_tSpeex));
						if (pStream->pvEncoder)
						{
							DWORD rcc = audio_speex_encoder_init
								(
								pStream->pvEncoder, 
								AUDIO_IF_PT_SPEEX_UWB
								);
							if (rcc == AUDIO_IF_ERR_NONE)
							{
								bOk = true;
								pStream->dwTsFrame = AUDIO_FRSZ32;
							}
						}
					}
					break;
				case AUDIO_IF_PT_ILBC:
					pStream->iAllocSz += AUDIO_CSZ_ILBC*iFPP;
					pStream->pcCode = (BYTE*)AudioIf_alloc(pStream->iAllocSz);
					if (pStream->pcCode)
					{
						pStream->pvEncoder = AudioIf_alloc(sizeof(iLBC_Enc_Inst_t));
						if (pStream->pvEncoder)
						{
							DWORD rcc = audio_iLBC_encoder_init
								(
								pStream->pvEncoder
								);
							if (rcc == AUDIO_IF_ERR_NONE)
							{
								bOk = true;
							}
						}
					}
					break;
				case AUDIO_IF_PT_GSM:
					pStream->iAllocSz += AUDIO_CSZ_GSM*iFPP;
					pStream->pcCode = (BYTE*)AudioIf_alloc(pStream->iAllocSz);
					if (pStream->pcCode)
					{
						pStream->pvEncoder = audio_GSM_init();
						if (pStream->pvEncoder)
						{
							bOk = true;
						}
					}
					break;
#if AUDIO_G729
				case AUDIO_IF_PT_G729A:
					pStream->iAllocSz += AUDIO_CSZ_G729A*iFPP;
					pStream->pcCode = (BYTE*)AudioIf_alloc(pStream->iAllocSz);
					if (pStream->pcCode)
					{
						pStream->pvEncoder = audio_G729_encoder_init();
						if (pStream->pvEncoder)
						{
							pStream->dwTsFrame = AUDIO_FRSZ8/2;
							bOk = true;
						}
					}
					break;
#endif
				case AUDIO_IF_PT_SIREN14:
//					audio_log_inf("audio_gen_add_stream -- siren14");
					pStream->iAllocSz += AUDIO_CSZ_SIREN1424*iFPP;
					pStream->pcCode = (BYTE*)AudioIf_alloc(pStream->iAllocSz);
					if (pStream->pcCode)
					{
						pStream->pvEncoder = AudioIf_alloc(sizeof(Siren_tEnc));
						if (pStream->pvEncoder)
						{
							siren_encoder_init(pStream->pvEncoder);
							pStream->dwTsFrame = AUDIO_FRSZ32;
							bOk = true;
						}
					}
					break;
				case AUDIO_IF_PT_SIREN1432:
					pStream->iAllocSz += AUDIO_CSZ_SIREN1432*iFPP;
					pStream->pcCode = (BYTE*)AudioIf_alloc(pStream->iAllocSz);
					if (pStream->pcCode)
					{
						pStream->pvEncoder = AudioIf_alloc(sizeof(Siren_tEnc));
						if (pStream->pvEncoder)
						{
							siren_encoder_init(pStream->pvEncoder, 640);
							pStream->dwTsFrame = AUDIO_FRSZ32;
							bOk = true;
						}
					}
					break;
				case AUDIO_IF_PT_SIREN1448:
					pStream->iAllocSz += AUDIO_CSZ_SIREN1448*iFPP;
					pStream->pcCode = (BYTE*)AudioIf_alloc(pStream->iAllocSz);
					if (pStream->pcCode)
					{
						pStream->pvEncoder = AudioIf_alloc(sizeof(Siren_tEnc));
						if (pStream->pvEncoder)
						{
							siren_encoder_init(pStream->pvEncoder, 960);
							pStream->dwTsFrame = AUDIO_FRSZ32;
							bOk = true;
						}
					}
					break;
				case AUDIO_IF_PT_SIREN1416:
					pStream->iAllocSz += AUDIO_CSZ_SIREN1416*iFPP;
					pStream->pcCode = (BYTE*)AudioIf_alloc(pStream->iAllocSz);
					if (pStream->pcCode)
					{
						pStream->pvEncoder = AudioIf_alloc(sizeof(Siren_tEnc));
						if (pStream->pvEncoder)
						{
							siren_encoder_init(pStream->pvEncoder, 320);
							pStream->dwTsFrame = AUDIO_FRSZ32;
							bOk = true;
						}
					}
					break;
				default:
					break;
	
				}

				if (bOk)
				{
					pStream->bRunning = true;
				}
				else
				{
					rc |= AUDIO_IF_ERR_FAILED;
				}
			}
			else
			{
				rc |= AUDIO_IF_ERR_FILE_IO;
			}
		}
		else
		{
			rc |= AUDIO_IF_ERR_OVERFLOW;	
		}
	}
	else
	{
		rc |= AUDIO_IF_ERR_ALREADY_EXISTS;
	}
	if (rc)
		audio_log_err("audio_gen_add_stream -- err 0x%x", rc);
	else
		audio_log_inf("audio_gen_add_stream -- done");
	return rc;
		
}
/*****************************************************************************/
DWORD						audio_gen_rem_stream
/*****************************************************************************/
(
int	iSrcIdx
)
{
	DWORD rc = AUDIO_IF_ERR_NONE;
	audio_log_inf("audio_gen_rem_stream -- SrcId=%d", iSrcIdx);

	int idx = _src_idx(iSrcIdx);
	if (idx >= 0)
	{
		Audio_tGenStream *pStream = &gAudioGen.aStream[idx];
		pStream->bRunning = false;

		if (pStream->pcCode)
			pStream->pcCode = (BYTE*)AudioIf_free(pStream->pcCode);

		switch(pStream->iPT)
		{
		case AUDIO_IF_PT_G711A:
		case AUDIO_IF_PT_G711U:
			break;
		case AUDIO_IF_PT_SPEEX_NB:
		case AUDIO_IF_PT_SPEEX_WB:
		case AUDIO_IF_PT_SPEEX_UWB:
			audio_speex_encoder_delete(pStream->pvEncoder);
			pStream->pvEncoder = AudioIf_free(pStream->pvEncoder);
			break;
		case AUDIO_IF_PT_ILBC:
			pStream->pvEncoder = AudioIf_free(pStream->pvEncoder);
			break;
		case AUDIO_IF_PT_GSM:
			pStream->pvEncoder = audio_GSM_delete(pStream->pvEncoder);
			break;
#if AUDIO_G729
		case AUDIO_IF_PT_G729A:
			pStream->pvEncoder = AudioIf_free(pStream->pvEncoder);
			break;
#endif
		case AUDIO_IF_PT_SIREN14:
		case AUDIO_IF_PT_SIREN1432:
		case AUDIO_IF_PT_SIREN1448:
		case AUDIO_IF_PT_SIREN1416:
			pStream->pvEncoder = AudioIf_free(pStream->pvEncoder);
			break;
		default:
			break;
		}
		if (pStream->fd) 
			fclose(pStream->fd);

		memset(pStream, 0, sizeof(Audio_tGenStream));
	}
	else
	{
		rc |= AUDIO_IF_ERR_ALREADY_REMOVED;
	}
	return rc;
}
/*****************************************************************************/
DWORD						audio_gen_dtx
/*****************************************************************************/
(
int	iSrcIdx,
bool bDtx,
int iDtxSend,
int iDtxPause
)
{
	DWORD rc = AUDIO_IF_ERR_NONE;
	audio_log_inf("audio_gen_dtx -- [%d] bDtx=%d iSend=%d iPause=%d", 
		iSrcIdx,
		bDtx,
		iDtxSend,
		iDtxPause);

	int idx = _src_idx(iSrcIdx);
	if (idx >= 0)
	{
		Audio_tGenStream *pStream = &gAudioGen.aStream[idx];
		pStream->bDtx = bDtx;
		pStream->iDtxSend = iDtxSend;
		pStream->iDtxPause = iDtxPause;
		pStream->iDtxCnt = 0;
	}
	else
	{
		rc |= AUDIO_IF_ERR_NOT_INITIALIZED;
	}
	return rc;
}

/////////////////////////////////////////////////////////////////////////////
//      
//                      NETWORK WRITER
//
static const DWORD dwG711 = 0;

Audio_CNetWr::Audio_CNetWr()
{
	m_pvDecoder = NULL;
	m_wPT = AUDIO_IF_PT_NONE;
	m_fd = NULL;
	memset(&m_WavHdr, 0, sizeof(m_WavHdr));
}
bool Audio_CNetWr::open(WORD wPayloadType, char *pszFileName)
{
	bool brc = false;
	audio_log_inf("Audio_CNetWr::open -- PT %d, file=\"%s\"", wPayloadType,pszFileName);
	m_fd = fopen(pszFileName, "wb");
	audio_utl_set_wav(&m_WavHdr, 8000);

	if (m_fd)
	{
		switch(wPayloadType)
		{
		case AUDIO_IF_PT_G711A:
			m_pvDecoder = (void*)&dwG711;//NULL;
			break;
		case AUDIO_IF_PT_G711U:
			m_pvDecoder = (void*)&dwG711;//NULL;
			break;
		case AUDIO_IF_PT_SPEEX_NB:
			m_pvDecoder = AudioIf_alloc(sizeof(Audio_tSpeex));
			audio_speex_decoder_init(m_pvDecoder, AUDIO_IF_PT_SPEEX_NB);
			break;
		case AUDIO_IF_PT_SPEEX_WB:
			m_pvDecoder = AudioIf_alloc(sizeof(Audio_tSpeex));
			audio_speex_decoder_init(m_pvDecoder, AUDIO_IF_PT_SPEEX_WB);
			audio_utl_set_wav(&m_WavHdr, 16000);
			break;
		case AUDIO_IF_PT_SPEEX_UWB:
			m_pvDecoder = AudioIf_alloc(sizeof(Audio_tSpeex));
			audio_speex_decoder_init(m_pvDecoder, AUDIO_IF_PT_SPEEX_UWB);
			audio_utl_set_wav(&m_WavHdr, 32000);
			break;
		case AUDIO_IF_PT_ILBC:
			m_pvDecoder = AudioIf_alloc(sizeof(iLBC_Dec_Inst_t));
			audio_iLBC_decoder_init(m_pvDecoder);
			break;
		case AUDIO_IF_PT_GSM:
			m_pvDecoder = audio_GSM_init();
			break;
#if AUDIO_G729
		case AUDIO_IF_PT_G729A:
			m_pvDecoder = audio_G729_decoder_init();
			break;
#endif
		case AUDIO_IF_PT_SIREN14:
			m_pvDecoder = AudioIf_alloc(sizeof(Siren_tDec));
			siren_decoder_init(m_pvDecoder);
			audio_utl_set_wav(&m_WavHdr, 32000);
			break;
		case AUDIO_IF_PT_SIREN1432:
			m_pvDecoder = AudioIf_alloc(sizeof(Siren_tDec));
			siren_decoder_init(m_pvDecoder, 640);
			audio_utl_set_wav(&m_WavHdr, 32000);
			break;
		case AUDIO_IF_PT_SIREN1448:
			m_pvDecoder = AudioIf_alloc(sizeof(Siren_tDec));
			siren_decoder_init(m_pvDecoder, 960);
			audio_utl_set_wav(&m_WavHdr, 32000);
			break;
		case AUDIO_IF_PT_SIREN1416:
			m_pvDecoder = AudioIf_alloc(sizeof(Siren_tDec));
			siren_decoder_init(m_pvDecoder, 320);
			audio_utl_set_wav(&m_WavHdr, 32000);
			break;
		default:
			break;
		}

		if (m_pvDecoder)
		{
			fwrite(&m_WavHdr, sizeof(m_WavHdr), 1, m_fd);
			m_wPT = wPayloadType;
			audio_log_inf("Audio_CNetWr::open -- fd=%p, dec=%p", m_fd, m_pvDecoder);
			brc = true;
		}
	}
	return brc;
}
void Audio_CNetWr::write(BYTE *pCode, WORD wDataSz)
{
	short asFrame[AUDIO_FRSZ32]; // max of what can be needed
	int iFrSz = AUDIO_FRSZ8;
	int iFrames = 1;

	switch(m_wPT)
	{
	case AUDIO_IF_PT_G711A:
		{
			iFrames = wDataSz/AUDIO_CSZ_G711;
			for (int iFrame = 0; iFrame < iFrames; iFrame++)
			{
				audio_G711A_decode(asFrame, pCode);
				fwrite(asFrame, sizeof(short), AUDIO_FRSZ8, m_fd);
				pCode += AUDIO_CSZ_G711;
			}
		}
		break;
	case AUDIO_IF_PT_G711U:
		{
			iFrames = wDataSz/AUDIO_CSZ_G711;
			for (int iFrame = 0; iFrame < iFrames; iFrame++)
			{
				audio_G711U_decode(asFrame, pCode);
				fwrite(asFrame, sizeof(short), AUDIO_FRSZ8, m_fd);
				pCode += AUDIO_CSZ_G711;
			}
		}
		break;
	case AUDIO_IF_PT_SPEEX_NB:
		{
			iFrames = wDataSz/AUDIO_CSZ_SPEEX_NB;
			for (int iFrame = 0; iFrame < iFrames; iFrame++)
			{
				audio_speex_decode(m_pvDecoder, asFrame, pCode, AUDIO_CSZ_SPEEX_NB);
				fwrite(asFrame, sizeof(short), AUDIO_FRSZ8, m_fd);
				pCode += AUDIO_CSZ_SPEEX_NB;
			}
		}
		break;
	case AUDIO_IF_PT_SPEEX_WB:
		{
			iFrames = wDataSz/AUDIO_CSZ_SPEEX_WB;
			for (int iFrame = 0; iFrame < iFrames; iFrame++)
			{
				audio_speex_decode(m_pvDecoder, asFrame, pCode, AUDIO_CSZ_SPEEX_WB);
				fwrite(asFrame, sizeof(short), AUDIO_FRSZ16, m_fd);
				pCode += AUDIO_CSZ_SPEEX_WB;
			}
			iFrSz = AUDIO_FRSZ16;
		}
		break;
	case AUDIO_IF_PT_SPEEX_UWB:
		{
			iFrames = wDataSz/AUDIO_CSZ_SPEEX_UWB;
			for (int iFrame = 0; iFrame < iFrames; iFrame++)
			{
				audio_speex_decode(m_pvDecoder, asFrame, pCode, AUDIO_CSZ_SPEEX_UWB);
				fwrite(asFrame, sizeof(short), AUDIO_FRSZ32, m_fd);
				pCode += AUDIO_CSZ_SPEEX_UWB;
			}
			iFrSz = AUDIO_FRSZ32;
		}
		break;
	case AUDIO_IF_PT_ILBC:
		{
			iFrames = wDataSz/AUDIO_CSZ_ILBC;
			for (int iFrame = 0; iFrame < iFrames; iFrame++)
			{
				audio_iLBC_decode(m_pvDecoder, asFrame, pCode);
				fwrite(asFrame, sizeof(short), AUDIO_FRSZ8, m_fd);
				pCode += AUDIO_CSZ_ILBC;
			}
		}
		break;
	case AUDIO_IF_PT_GSM:
		{
			iFrames = wDataSz/AUDIO_CSZ_GSM;
			for (int iFrame = 0; iFrame < iFrames; iFrame++)
			{
				audio_GSM_decode(m_pvDecoder, asFrame, pCode);
				fwrite(asFrame, sizeof(short), AUDIO_FRSZ8, m_fd);
				pCode += AUDIO_CSZ_GSM;
			}
		}
		break;
#if AUDIO_G729
	case AUDIO_IF_PT_G729A:
		{
			iFrames = wDataSz/AUDIO_CSZ_G729A;
			for (int iFrame = 0; iFrame < iFrames; iFrame++)
			{
				audio_G729_decode(m_pvDecoder, asFrame, pCode);
				fwrite(asFrame, sizeof(short), AUDIO_FRSZ8/2, m_fd);
				pCode += AUDIO_CSZ_G729A;
			}
			iFrSz = AUDIO_FRSZ8/2;
		}
		break;
#endif
	case AUDIO_IF_PT_SIREN14:
		{
			iFrames = wDataSz/AUDIO_CSZ_SIREN1424;
			for (int iFrame = 0; iFrame < iFrames; iFrame++)
			{
				siren_decode(m_pvDecoder, asFrame, pCode);
				fwrite(asFrame, sizeof(short), AUDIO_FRSZ32, m_fd);
				pCode += AUDIO_CSZ_SIREN1424;
			}
			iFrSz = AUDIO_FRSZ32;
		}
		break;
	case AUDIO_IF_PT_SIREN1432:
		{
			iFrames = wDataSz/AUDIO_CSZ_SIREN1432;
			for (int iFrame = 0; iFrame < iFrames; iFrame++)
			{
				siren_decode(m_pvDecoder, asFrame, pCode);
				fwrite(asFrame, sizeof(short), AUDIO_FRSZ32, m_fd);
				pCode += AUDIO_CSZ_SIREN1432;
			}
			iFrSz = AUDIO_FRSZ32;
		}
		break;
	case AUDIO_IF_PT_SIREN1448:
		{
			for (int iFrame = 0; iFrame < iFrames; iFrame++)
			{
				siren_decode(m_pvDecoder, asFrame, pCode);
				fwrite(asFrame, sizeof(short), AUDIO_FRSZ32, m_fd);
				pCode += AUDIO_CSZ_SIREN1448;
			}
			iFrSz = AUDIO_FRSZ32;
		}
	case AUDIO_IF_PT_SIREN1416:
		{
			for (int iFrame = 0; iFrame < iFrames; iFrame++)
			{
				siren_decode(m_pvDecoder, asFrame, pCode);
				fwrite(asFrame, sizeof(short), AUDIO_FRSZ32, m_fd);
				pCode += AUDIO_CSZ_SIREN1416;
			}
			iFrSz = AUDIO_FRSZ32;
		}
		break;
	}
	m_WavHdr.dwLen1 += sizeof(short) * iFrSz * iFrames;
	m_WavHdr.dwLen3 += sizeof(short) * iFrSz * iFrames;

}
bool Audio_CNetWr::active()
{
	if (m_fd && m_pvDecoder)
		return true;
	else
		return false;
}

void Audio_CNetWr::close()
{
	if (m_fd && m_pvDecoder)
	{
#ifndef _WIN32_WCE
		rewind(m_fd);
#else
		fseek(m_fd, 0, SEEK_SET);
#endif
		fwrite(&m_WavHdr, sizeof(m_WavHdr), 1, m_fd);
		fclose(m_fd);
		switch(m_wPT)
		{
			case AUDIO_IF_PT_G711A:
			case AUDIO_IF_PT_G711U:
				break;
			case AUDIO_IF_PT_SPEEX_NB:
			case AUDIO_IF_PT_SPEEX_WB:
			case AUDIO_IF_PT_SPEEX_UWB:
				audio_speex_decoder_delete(m_pvDecoder);
				m_pvDecoder = AudioIf_free(m_pvDecoder);
				break;
			case AUDIO_IF_PT_ILBC:
				m_pvDecoder = AudioIf_free(m_pvDecoder);
				break;
			case AUDIO_IF_PT_GSM:
				m_pvDecoder = audio_GSM_delete(m_pvDecoder);
				break;
#if AUDIO_G729
			case AUDIO_IF_PT_G729A:
				m_pvDecoder = AudioIf_free(m_pvDecoder);
				break;
#endif
			case AUDIO_IF_PT_SIREN14:
			case AUDIO_IF_PT_SIREN1432:
			case AUDIO_IF_PT_SIREN1448:
			case AUDIO_IF_PT_SIREN1416:
				m_pvDecoder = AudioIf_free(m_pvDecoder);
				break;
		}
	}
}