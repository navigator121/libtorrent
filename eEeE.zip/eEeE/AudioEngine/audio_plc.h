#pragma once

#include "audio_defs.h"


#define AUDIO_PLC_MAX				(120)	// ~67 Hz
//#define AUDIO_PLC_MAX				(AUDIO_FRSZ8)	// ~67 Hz
// min pitch is 60. we can not have more than 3 pitch periods in a frame (160)
#define AUDIO_PLC_MIN				(AUDIO_PLC_MAX/2)	
#define AUDIO_PLC_SSZ				(AUDIO_PLC_MAX*2+AUDIO_FRSZ8)	
#define AUDIO_PLC_RAMP				(20)	// 2.5ms
#define AUDIO_PLC_CHANGE			(5)		// max pitch change in 10ms

#define AUDIO_PLC_DIFF				(0)

enum {
	AUDIO_PLC_ST_INIT,
	AUDIO_PLC_ST_OK,
	AUDIO_PLC_ST_OOPS,
	AUDIO_PLC_ST_O_O,
	AUDIO_PLC_ST_BAD,

	AUDIO_PLC_ST_MAX
};

typedef struct {
	DWORD	dwSD;

	float	afSav					[AUDIO_PLC_SSZ]; // original 
	float	afSaf					[AUDIO_PLC_SSZ]; // filtered with b=[1 1 1 1]/4;
	float	afPredicted				[AUDIO_FRSZ8+AUDIO_PLC_RAMP*2];

	int		iState;
	int		iPitch;
	float	fPitch;

	float	fGain;
	int		iSeed;

	short	sNseSeed;
	float	fNseLast;

	float	fVadCrit;
	float	fVadNse;
	int		iVadCnt;
	DWORD	dwED;


	// scratch pad
	float	afPredErr				[AUDIO_PLC_MAX];
	float	afGain					[AUDIO_PLC_MAX];
	float	fPredErrMin;
	float	afR						[AUDIO_PLC_MAX];

#if AUDIO_PLC_DIFF
	float	afPredErrDiff			[AUDIO_PLC_CHANGE*2+1];
	float	afGainDiff				[AUDIO_PLC_CHANGE*2+1];
	int		iPitchDiff;
	float	fPitchDiff;
	float	fPitchOff;
#endif

} Audio_tPlc;

// public
void audio_plc_reset(Audio_tPlc *pPlc);
bool audio_plc_process(Audio_tPlc *pPlc, float *pfIO, bool bLost);
bool audio_plc_process(void *p, short *psIO, bool bLost);

// private
//void audio_plc_pda(Audio_tPlc *pPlc);
//void audio_plc_update(Audio_tPlc *pPlc, float *pfIO);
//void audio_plc_interpolate2(float *pfIO);
//void audio_plc_mix(Audio_tPlc *pPlc, float *pfTo, float *pfFrom);
//void audio_plc_analyze(Audio_tPlc *pPlc, float *pfIO);
//void audio_plc_zero(Audio_tPlc *pPlc, float *pfIO);
//void audio_plc_delay(Audio_tPlc *pPlc, float *pfIO);
