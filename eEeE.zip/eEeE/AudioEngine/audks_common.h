//**@@@*@@@****************************************************
//
// Microsoft Windows
// Copyright (C) Microsoft Corporation. All rights reserved.
//
//**@@@*@@@****************************************************

//
// FileName:    kssample.h
//
// Abstract:    
//      All of the necessary includes in one place
//

#pragma once
#ifndef __COMMONKS_H
#define __COMMONKS_H

#define _WIN32_WINNT 0x0501
#define WINVER 0x0501

#include <windows.h>
#include <ks.h>
#include <ksmedia.h>
#include <tchar.h>
#include <assert.h>
#include <stdio.h>

#if 0
// filter types
typedef enum {eUnknown, eAudRen, eAudCap} ETechnology;

typedef struct
{
    KSP_PIN KsPProp;
    KSMULTIPLE_ITEM KsMultiple;
} INTERSECTION;
#endif

typedef struct 
{
    KSSTREAM_HEADER Header;
    OVERLAPPED      Signal;
} AUDKS_DATA_PACKET;

extern void audio_log_inf(char *, ...);

#include "audks_tlist.h"
#include "audks_util.h"
#include "audks_irptgt.h"
#include "audks_filter.h"
#include "audks_pin.h"
#include "audks_audpin.h"


#endif //__COMMONKS_H
