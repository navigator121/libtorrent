//**@@@*@@@****************************************************
//
// Microsoft Windows
// Copyright (C) Microsoft Corporation. All rights reserved.
//
//**@@@*@@@****************************************************

//
// FileName:    filter.cpp
//
// Abstract:    
//      This is the implementation file for C++ classes that expose
//      functionality of KS filter objects
//
#define _CRT_SECURE_NO_DEPRECATE 1

#include "audks_common.h"

// ============================================================================
//
//   CKsFilter
//
//=============================================================================



////////////////////////////////////////////////////////////////////////////////
//
//  CKsFilter::CKsFilter()
//
//  Routine Description:
//      Constructor
//  
//  Arguments: 
//      Strings and more Strings!
//
//
//  Return Value:
//  
//     S_OK on success
//


CKsFilter::CKsFilter (
    LPCTSTR     pszName,
	const char *pszFriendlyName,
    HRESULT*   phr)
    : CKsIrpTarget(INVALID_HANDLE_VALUE)
{
    AUDKS_TRACE_ENTER();
    HRESULT hr = S_OK;

    if (NULL == pszName)
    {
        hr = E_INVALIDARG;
        audio_log_err("CKsFilter -- pszName cannot be NULL");
    }

	if (SUCCEEDED(hr))
    {
        hr = m_listPins.Initialize(1);
        if (FAILED(hr))
            audio_log_err("CKsFilter -- Failed to Initialize m_listPins");
    }


    if (SUCCEEDED(hr))
    {
		strncpy(m_szFriendlyName, pszFriendlyName, MAX_PATH);
        _tcsncpy(m_szFilterName, pszName, MAX_PATH);
    }
    
    AUDKS_TRACE_LEAVE_HRESULT(hr);
    *phr = hr;
    return;
}


////////////////////////////////////////////////////////////////////////////////
//
//  CKsFilter::~CKsFilter()
//
//  Routine Description:
//      CKsFilter Destructor
//  
//  Arguments: 
//      None
//
//  Return Value:
//      None
//


CKsFilter::~CKsFilter()
{
    AUDKS_TRACE_ENTER();
    HRESULT hr = S_OK;
    
    CKsPin* pPin;
    // clean pins
    while(m_listPins.RemoveHead(&pPin))
    {
        delete pPin;
    }

	SafeCloseHandle(m_handle);
    
    AUDKS_TRACE_LEAVE_HRESULT(hr);
    return;
}


////////////////////////////////////////////////////////////////////////////////
//
//  CKsFilter::Instantiate()
//
//  Routine Description:
//      Instantiates the pin 
//  
//  Arguments: 
//      None, Make sure that the object is fully initialized before calling this function  
//
//
//  Return Value:
//  
//     S_OK on success
//


HRESULT CKsFilter::Instantiate(void)
{
    AUDKS_TRACE_ENTER();
    HRESULT hr = S_OK;

    m_handle = CreateFile(
        m_szFilterName,
        GENERIC_READ | GENERIC_WRITE,
        0,
        NULL,
        OPEN_EXISTING,
        FILE_ATTRIBUTE_NORMAL | FILE_FLAG_OVERLAPPED,
        NULL);

    if (!IsValidHandle(m_handle))
    {
        hr = E_FAIL;
    }
    
    if (FAILED(hr))
    {
        DWORD dwError = GetLastError();
        audio_log_err("CKsFilter::Instantiate: CreateFile failed for device %s.  ErrorCode = 0x%08x",m_szFilterName, dwError);
    }
    
    AUDKS_TRACE_LEAVE_HRESULT(hr);
    return hr;
}


////////////////////////////////////////////////////////////////////////////////
//
//  CKsFilter::GetPinPropertySimple()
//
//  Routine Description:
//      Gets simple pin properties
//  
//  Arguments: 
//      Pin property stuff
//
//
//  Return Value:
//  
//     S_OK on success
//


HRESULT CKsFilter::GetPinPropertySimple(
    IN  ULONG   nPinId,
    IN  REFGUID guidPropertySet,
    IN  ULONG   nProperty,
    OUT PVOID   pvValue,
    OUT ULONG   cbValue)
{
    AUDKS_TRACE_ENTER();
    HRESULT hr = S_OK;

    ULONG ulReturned = 0;
    KSP_PIN ksPProp;

    ksPProp.Property.Set = guidPropertySet;
    ksPProp.Property.Id = nProperty;
    ksPProp.Property.Flags = KSPROPERTY_TYPE_GET;
    ksPProp.PinId = nPinId;
    ksPProp.Reserved = 0;

    hr = SyncIoctl(
        m_handle,
        IOCTL_KS_PROPERTY,
        &ksPProp,
        sizeof(KSP_PIN),
        pvValue,
        cbValue,
        &ulReturned);
    
    AUDKS_TRACE_LEAVE_HRESULT(hr);
    return hr;
}

////////////////////////////////////////////////////////////////////////////////
//
//  CKsFilter::GetPinPropertyMulti()
//
//  Routine Description:
//      Gets multiple pin properties
//  
//  Arguments: 
//      Pin property stuff  
//
//
//  Return Value:
//  
//     S_OK on success
//


HRESULT CKsFilter::GetPinPropertyMulti(
    IN  ULONG               nPinId,
    IN  REFGUID             guidPropertySet,
    IN  ULONG               nProperty,
    OUT PKSMULTIPLE_ITEM*   ppKsMultipleItem)
{
    AUDKS_TRACE_ENTER();
    HRESULT hr = S_OK;
    ULONG   ulReturned = 0;
    ULONG   cbMultipleItem = 0;
    KSP_PIN ksPProp;

    ksPProp.Property.Set = guidPropertySet;
    ksPProp.Property.Id = nProperty;
    ksPProp.Property.Flags = KSPROPERTY_TYPE_GET;
    ksPProp.PinId = nPinId;
    ksPProp.Reserved = 0;

    hr = SyncIoctl(
        m_handle,
        IOCTL_KS_PROPERTY,
        &ksPProp.Property,
        sizeof(KSP_PIN),
        NULL,
        0,
        &cbMultipleItem);

    if (SUCCEEDED(hr))
    {
        *ppKsMultipleItem = (PKSMULTIPLE_ITEM) new BYTE[cbMultipleItem];
        if (NULL == ppKsMultipleItem)
        {
            hr = E_OUTOFMEMORY;
        }
        else
        {
            hr = SyncIoctl(
                m_handle,
                IOCTL_KS_PROPERTY,
               &ksPProp,
               sizeof(KSP_PIN),
               (PVOID)*ppKsMultipleItem,
               cbMultipleItem,
               &ulReturned);
        }
    }
    AUDKS_TRACE_LEAVE_HRESULT(hr);
    return hr;
}



static HRESULT _classify
(
KSPIN_COMMUNICATION Communication,
KSPIN_DATAFLOW DataFlow,
bool bCapture
)
{
    HRESULT hr = E_FAIL;
    
    switch(Communication)
    {
        case KSPIN_COMMUNICATION_BOTH:
        case KSPIN_COMMUNICATION_SINK:
	        if (KSPIN_DATAFLOW_IN == DataFlow) 
			{
				if (!bCapture)
					hr = S_OK;
			}
			else
			{
				if (bCapture)
					hr = S_OK;
			}
            break;

        case KSPIN_COMMUNICATION_SOURCE:
        case KSPIN_COMMUNICATION_NONE:
        default:
            break;
    }
    
    return hr;
}

HRESULT CKsFilter::EnumeratePins
(
bool bCapture
)
{
    AUDKS_TRACE_ENTER();
    HRESULT hr = S_OK;
    ULONG   cPins = 0;

    // get the number of pins supported by SAD
    hr = 
        GetPinPropertySimple
        (  
            0,
            KSPROPSETID_Pin,
            KSPROPERTY_PIN_CTYPES,
            &cPins,
            sizeof(cPins)
        );

    if (FAILED(hr))
    {
        audio_log_err("CKsFilter::EnumeratePins -- Failed to retrieve count of pins in audio filter");
    }
    else // (SUCCEEDED(hr))
    {
        //
        // loop through the pins, looking for audio pins
        //
        audio_log_inf("CKsFilter::EnumeratePins -- %d pins in %s", cPins, m_szFriendlyName);
        for(ULONG nPinId = 0; nPinId < cPins; nPinId++)
        {
		    KSPIN_COMMUNICATION ksPinCommunication = KSPIN_COMMUNICATION_NONE;
			KSPIN_DATAFLOW ksPinDataflow = (KSPIN_DATAFLOW)0;
            CKsAudPin* pNewPin = NULL;

	        audio_log_trc("CKsFilter::EnumeratePins -- pin %d of %d on %s", nPinId, cPins, m_szFriendlyName);

            // This information is needed to create the right type of pin
            
            //
            // get COMMUNICATION ---------------
            //
            hr = GetPinPropertySimple
                ( 
                    nPinId,
                    KSPROPSETID_Pin,
                    KSPROPERTY_PIN_COMMUNICATION,
                    &ksPinCommunication,
                    sizeof(KSPIN_COMMUNICATION)
                );
            if (FAILED(hr))
            {
                audio_log_err("CKsFilter::EnumeratePins -- Failed to retrieve pin property KSPROPERTY_PIN_COMMUNICATION");
            }
			else // Get the data flow property
            {
                hr = GetPinPropertySimple
                    (             
                        nPinId,
                        KSPROPSETID_Pin,
                        KSPROPERTY_PIN_DATAFLOW,
                        &ksPinDataflow,
                        sizeof(KSPIN_DATAFLOW)
                    );
                if (FAILED(hr))
                {
                    audio_log_err("CKsFilter::EnumeratePins -- Failed to retrieve pin property KSPROPERTY_PIN_DATAFLOW");
                }
            }
            if (SUCCEEDED(hr))
			{
				hr = _classify(ksPinCommunication, ksPinDataflow, bCapture);
			}

			if (SUCCEEDED(hr))
            {
                pNewPin = new CKsAudPin(this, nPinId, &hr);

                if (NULL == pNewPin)
                {
                    audio_log_err("CKsFilter::EnumeratePins -- Failed to create audio pin");
                    hr = E_OUTOFMEMORY;
                    break;
                }
            }

            if (SUCCEEDED(hr))
            {
                if (NULL == m_listPins.AddTail(pNewPin))
                {
                    delete pNewPin;
                    audio_log_err("CKsFilter::EnumeratePins -- Unable to allocate list entry to save pin in");
                    hr = E_OUTOFMEMORY;
                    break;
                }
				else
				{
                    audio_log_inf("CKsFilter::EnumeratePins -- pin %d added", nPinId);
				}
            }
            else //if (FAILED(hr))
            {
                delete pNewPin;
            }
        }
    }

        
	if( m_listPins.IsEmpty())
    {
        audio_log_err("CKsFilter::EnumeratePins -- No valid pins found on the filter");
        hr = E_FAIL;
    }
    else
    {
        hr = S_OK;
    }

    AUDKS_TRACE_LEAVE_HRESULT(hr);
    return hr;
}

////////////////////////////////////////////////////////////////////////////////
//
//  CKsAudRenFilter::CreateRenderPin()
//
//  Routine Description:
//      Look through m_listRenderPins and find one that can do pwfx and create it
//  
//  Arguments: 
//      WAVEFORMATEX that the pin must support  
//      Flag whether or not the pin plays backed looped buffers or streamed buffers
//
//  Return Value:
//  
//     S_OK on success
//
CKsAudPin* CKsFilter::CreatePin
(
    const WAVEFORMATEX*   pwfx
)
{
    AUDKS_TRACE_ENTER();
    HRESULT hr = S_OK;
    CKsAudPin* pPin = NULL;
	LISTPOS listPosPin;

    // Try to intstantiate all the pins, one at a time
    listPosPin = m_listPins.GetHeadPosition();

    while( !pPin) 
    {
	    CKsPin *pKsPin;
		if (!m_listPins.GetNext( listPosPin, &pKsPin ))
				break;

        CKsAudPin *pKsAudPin = (CKsAudPin *)pKsPin;
        hr = pKsAudPin->SetFormat( pwfx );
        if (SUCCEEDED(hr))
        {
            hr = pKsAudPin->Instantiate();
			if (SUCCEEDED(hr))
			{
				// Save the pin in pPin
				pPin = pKsAudPin;
				
				audio_log_trc("CKsAudFilter::CreatePin -- Success! ID=%d", 
					pPin->GetId());
				break;
			}
		}
    }

	if (!pPin)
		audio_log_trc("CKsAudFilter::CreatePin -- failed");

    AUDKS_TRACE_LEAVE_HRESULT(hr);
    return pPin;
}

#include <setupapi.h>
#include <mmsystem.h>

static inline BOOL
IsEqualGUIDAligned(GUID guid1, GUID guid2)
{
    return ((*(PLONGLONG)(&guid1) == *(PLONGLONG)(&guid2)) && (*((PLONGLONG)(&guid1) + 1) == *((PLONGLONG)(&guid2) + 1)));
}

CKsFilter * audks_find_filter
(
const GUID* aguidCategories,
const int   cguidCategories,
const char*	pszFriendlyName,
const bool	bCapture,
int*		piSimilarNames		
)
{
	HDEVINFO hDevInfo = NULL;
	CKsFilter *pFilter = NULL;
	BYTE acDevInterfaceDetails[sizeof(SP_DEVICE_INTERFACE_DETAIL_DATA) + MAX_PATH * sizeof(WCHAR)];
    DWORD cbInterfaceDetails = sizeof(SP_DEVICE_INTERFACE_DETAIL_DATA) + MAX_PATH * sizeof(WCHAR);

	int iSimilar = 0;

    if (aguidCategories && !IsEqualGUIDAligned(GUID_NULL, aguidCategories[0]))
    {
        // Get a handle to the device set specified by the guid
        hDevInfo = 
            SetupDiGetClassDevs
            (
                &(aguidCategories[0]), 
                NULL, 
                NULL, 
                DIGCF_PRESENT | DIGCF_DEVICEINTERFACE
            );

        if( !CKsIrpTarget::IsValidHandle(hDevInfo) )
        {
            audio_log_inf("No devices found");
        }
        else
        {
			bool bFound = false;

            // Loop through members of the set and get details for each
            for(int iClassMember = 0; !bFound; iClassMember++)
            {
                SP_DEVICE_INTERFACE_DATA            DID;
                SP_DEVICE_INTERFACE_DATA            DIDAlias;
                SP_DEVINFO_DATA                     DevInfoData;
                SP_DEVICE_INTERFACE_DETAIL_DATA*    pDevInterfaceDetails = 
					(SP_DEVICE_INTERFACE_DETAIL_DATA*)acDevInterfaceDetails;

                DID.cbSize = sizeof(DID);
                DID.Reserved = 0;
                DIDAlias.cbSize = sizeof(DIDAlias);
                DIDAlias.Reserved = 0;

                DevInfoData.cbSize = sizeof(DevInfoData);
                DevInfoData.Reserved = 0;

                BOOL fRes = 
                    SetupDiEnumDeviceInterfaces
                    (
                        hDevInfo, 
                        NULL, 
                        &(aguidCategories[0]), 
                        iClassMember,
                        &DID
                    );

                if (!fRes)
                {
                    // This just means that we've enumerate all the devices - it's not a real error
                    break;
                }

                pDevInterfaceDetails->cbSize = sizeof(*pDevInterfaceDetails);

                fRes = 
                    SetupDiGetDeviceInterfaceDetail
                    (
                        hDevInfo, 
                        &DID, 
                        pDevInterfaceDetails, 
                        cbInterfaceDetails,
                        NULL, 
                        &DevInfoData
                    );

                if (fRes)
                {
                    // 
                    // check additional category guids which may (or may not) have been supplied
                    //
                    for(int nguidCategory = 1; nguidCategory < cguidCategories && fRes; nguidCategory++)
                    {
                        fRes = 
                            SetupDiGetDeviceInterfaceAlias
                            (
                                hDevInfo,
                                &DID,
                                &(aguidCategories[nguidCategory]),
                                &DIDAlias
                            );

                        if (!fRes)
                        {
                            audio_log_trc("Failed to get requested DeviceInterfaceAlias");
                        }

                        //
                        // Check if the this interface alias is enabled.
                        //
                        if (fRes)
                        {
                            if (!DIDAlias.Flags || (DIDAlias.Flags & SPINT_REMOVED))
                            {
                                fRes = FALSE;
                                audio_log_trc("DeviceInterfaceAlias disabled.");
                            }
                        }
                    }
				}
				if (fRes)
				{
					char acFriendlyName[MAX_PATH] = {0};

					HKEY hkey=SetupDiOpenDeviceInterfaceRegKey(
						hDevInfo,
						&DID,
						0,
//						KEY_SET_VALUE|KEY_QUERY_VALUE // does not work under Vista
						KEY_QUERY_VALUE
						);
					if (hkey!=INVALID_HANDLE_VALUE)
					{                                                       
						DWORD dwmess = sizeof(acFriendlyName);
						DWORD dwtype;
						if (ERROR_SUCCESS ==  RegQueryValueEx(
								hkey,
								TEXT("FriendlyName"),
								0,
								&dwtype,
								(LPBYTE)acFriendlyName,
								&dwmess)
								) 
						{
//								OutputDebugString(friendly_name);
//								OutputDebugString("\r\n");
						}
						RegCloseKey(hkey);
					}

					// if strings start the same for sufficient length
					if (strncmp(pszFriendlyName, acFriendlyName, strlen(pszFriendlyName)))
					{
						fRes = FALSE;
	                    audio_log_inf("audks_find_filter -- \"%s\" exists in this category", 
							acFriendlyName);

						// if this is a substring - WDM name is shorter
						if (strstr(pszFriendlyName, acFriendlyName))
						{
							iSimilar++;
						}
						else
						{
							char *pc = strtok(acFriendlyName, " ");
							// we assume WDM name starts from vendor: SoundMAX / SigmaTel / SB
							if (strstr(pszFriendlyName, acFriendlyName)) 
								iSimilar++;
						}

						if ((*piSimilarNames > 0) && (iSimilar > 0))
						{
							fRes = TRUE; // let it be.
		                    audio_log_inf("audks_find_filter -- \"%s\" = \"%s\" found for %s", 
								acFriendlyName,
								pszFriendlyName,
								bCapture? "CAPTURE":"RENDER");
						}
					}
					else
					{
	                    audio_log_inf("audks_find_filter -- \"%s\" found for %s", 
							pszFriendlyName,
							bCapture? "CAPTURE":"RENDER");
					}
				}

                if (fRes)
                {
                    HRESULT hr = S_OK;
					pFilter = new CKsFilter(
									pDevInterfaceDetails->DevicePath, 
									pszFriendlyName,
									&hr);

                    if (NULL == pFilter)
                    {
                        hr = E_OUTOFMEMORY;
                    }
                    if (SUCCEEDED(hr))
                    {
                        hr = pFilter->Instantiate();
					}
                    if (SUCCEEDED(hr))
					{
                        hr = pFilter->EnumeratePins(bCapture);
                    }
                    if (SUCCEEDED(hr))
                    {
						bFound = true;
                    }
					else
                    {
                        delete pFilter;
						pFilter = NULL;
                        audio_log_err("audks_find_filter -- Failed to create filter for %s", 
                            pszFriendlyName);
                    }
                }
            } // for

			if ((!bFound) && (iSimilar > 0))
			{
				audio_log_inf("audks_find_filter -- %d unprecise matches found", iSimilar);
			}
        }
    }

    if (CKsIrpTarget::IsValidHandle(hDevInfo))
        SetupDiDestroyDeviceInfoList(hDevInfo);

	*piSimilarNames = iSimilar;

    return pFilter;
}
