#include "audio_defs.h"


#define _SOFT_TALKER			(10*50) // 7 seconds
#define _NO_SIGNAL				(3*50) // 3 seconds

static const AudioIf_tAgcCfg AgcCfg = {
	-18.F, //	float			fTargetLevelDBFS;
	-35.F, //float			fMinEnergyDBFS;
	10.F, //float			fOverNoiseThrDB;			// must be over noise XdB to be detected
	12.F, //float			fMaxGainDB;					// positive, < 12 dB
	100.F, //float			fAdaptationSpeedOnVowelsMs;
	1000.F //float			fAdaptationSpeedOnNoiseMs;
};

/* A-weighting filter

f1=4636/(2*pi);f2=676.7/(2*pi);
[b1,a1]=butter(1, f1/4000,'high');
[b2,a2]=butter(1, f2/4000,'high');b=conv(b1,b2);a=conv(a1,a2);
[h,g]=freqz(b,a,4000,8000);
h1k=abs(h(1000));
b=b/h1k;
h=20*log10(abs(h)+eps);
h=h-h(1000);
f2=[ 20  50 100 200 400 1000];
h2=[-50 -30 -20 -11 -5   0];
semilogx(g,h,f2,h2);grid on;axis([10 4000 -50 5])
*/
static const  float _afSosAWeighting[4] = {
	// b0=b2			b1					a1					a2
	0.915691215030684F, -1.83138243006137F,-1.45946362750195F, 0.496762346822656F
};

/*****************************************************************************/
static void				_vad
/*****************************************************************************/
(
Audio_tAgc *pAgc,
float *pfSnd
)
{
	float afAW[AUDIO_FRSZ32];

	for (int k = 0; k < AUDIO_FRSZ32; k++) afAW[k] = pfSnd[k];

	audio_utl_iir2s(
		afAW, 
		pAgc->afSosAW, 
		_afSosAWeighting,
		AUDIO_FRSZ32); 

	pAgc->Last.fNrg = audio_utl_pktnrg(pfSnd, AUDIO_FRSZ32);

	if (pAgc->Last.fNrg > AUDIO_VAD_NSE_MIN-pAgc->Cfg.fExtraGain)
    {
        float fDlt = pAgc->Last.fNrg - pAgc->fVadNse;
        pAgc->fVadCrit += fDlt - AUDIO_CRIT_THR;
        if (pAgc->fVadCrit < AUDIO_CRIT_MIN)
            pAgc->fVadCrit = AUDIO_CRIT_MIN;
        if (pAgc->fVadCrit > AUDIO_CRIT_MAX)
            pAgc->fVadCrit = AUDIO_CRIT_MAX;

        if (pAgc->fVadCrit < 0)
        {
            pAgc->fVadNse += fDlt * (1/16.F);

            if (pAgc->fVadNse > AUDIO_VAD_NSE_MAX-pAgc->Cfg.fExtraGain)
                pAgc->fVadNse = AUDIO_VAD_NSE_MAX-pAgc->Cfg.fExtraGain;
            if (pAgc->fVadNse < AUDIO_VAD_NSE_MIN-pAgc->Cfg.fExtraGain)
                pAgc->fVadNse = AUDIO_VAD_NSE_MIN-pAgc->Cfg.fExtraGain;

			float fAwNrg = audio_utl_pktnrg(afAW, AUDIO_FRSZ32);

			pAgc->fAwNse += (fAwNrg - pAgc->fAwNse) * (1/16.F);
        }
        else
        {
            if (pAgc->Last.fNrg < AUDIO_VAD_NSE_MAX-pAgc->Cfg.fExtraGain) 
            {
                pAgc->fVadNse += 0.03F;
            }
        }
    }
    else
    {
        pAgc->fVadCrit -= AUDIO_CRIT_THR;
        if (pAgc->fVadCrit < AUDIO_CRIT_MIN)
            pAgc->fVadCrit = AUDIO_CRIT_MIN;

    }

	if (pAgc->Last.fNrg < AUDIO_VAD_NSE_MIN-pAgc->Cfg.fExtraGain - GAEC_DB(6) )
	{
		pAgc->iNoSignalCnt++;
		if (pAgc->iNoSignalCnt > _NO_SIGNAL) // 3 seconds
		{
			pAgc->iNoSignalCnt = _NO_SIGNAL;
		}
	}
	else
	{
		pAgc->iNoSignalCnt = 0;
	}
}
/*****************************************************************************/
static void				_zc
/*****************************************************************************/
(
Audio_tAgc *pAgc,
float *pfSnd
)
{
	int acc = 0;
	int i = 1;
	if (pfSnd[0] < 0) 
		i = 0;

	for (int k = 1; k < AUDIO_FRSZ32; k++)
	{
		int j = 1;
		if (pfSnd[k] < 0)
			j = 0;
		acc += int(i^j);
		i = j;
	}
	pAgc->Last.fZc = acc * (1.F/AUDIO_FRSZ32);

	pAgc->Last.fZcFactor = 1.0F;
	if (pAgc->Last.fZc > AUDIO_AGC_ZC_MAX)
	{
		pAgc->Last.fZcFactor = 0.1F * (pAgc->Last.fZc - AUDIO_AGC_ZC_MAX) *
			(1.F/(1.F-AUDIO_AGC_ZC_MAX));
	}
	else if (pAgc->Last.fZc > AUDIO_AGC_ZC_MIN)
	{
		pAgc->Last.fZcFactor = 1.0F - (pAgc->Last.fZc - AUDIO_AGC_ZC_MIN) * 
			(0.9F/(AUDIO_AGC_ZC_MAX - AUDIO_AGC_ZC_MIN));
	}
}
/*****************************************************************************/
static void				_peaks
/*****************************************************************************/
(
Audio_tAgc *pAgc
)
{
	if ((pAgc->Last.fNrg > pAgc->fVadNse + pAgc->Cfg.fOverNoise) &&
		(pAgc->Last.fNrg + pAgc->Cfg.fExtraGain > pAgc->Cfg.fMinNrg ) &&
		(pAgc->fVadCrit > AUDIO_CRIT_MAX*0.5F))
	{
		float fDlt = pAgc->Last.fNrg - pAgc->fPeakNrg;
		float fTau;

		if (fDlt > 0)
		{
			pAgc->iCnt++;
			if (pAgc->iCnt > 4)
				pAgc->iCnt = 4;

			fTau = pAgc->Cfg.fFastAdapt * (pAgc->iCnt * 0.25F) * pAgc->Last.fZcFactor;
		}
		else
		{
			pAgc->iCnt = 0;
			if (fDlt < -12.F)
				fDlt = -12.F;
			fTau = pAgc->Cfg.fSlowAdapt * pAgc->Last.fZcFactor;
		}

		pAgc->fPeakNrg += fDlt * fTau;

		if (pAgc->iSoftTalkerCnt > 0)
		{
			pAgc->iSoftTalkerCnt = -1;
		}
		else
		{
			pAgc->iSoftTalkerCnt--;
			if (pAgc->iSoftTalkerCnt < -20)
				pAgc->iSoftTalkerCnt = -20;
		}
	}
	else
	{
		if (pAgc->iSoftTalkerCnt >= -7)
		{
			pAgc->iSoftTalkerCnt++;
			if (pAgc->iSoftTalkerCnt > _SOFT_TALKER) // 7 seconds
			{
				pAgc->iSoftTalkerCnt = _SOFT_TALKER;
			}
		}
	}
}
/*****************************************************************************/
static void				_gain
/*****************************************************************************/
(
Audio_tAgc *pAgc
)
{
	if (pAgc->bOn)
	{
		float fDlt = pAgc->Cfg.fTargetNrg - (pAgc->fPeakNrg + pAgc->Cfg.fExtraGain);

		pAgc->fGainDb += (fDlt - pAgc->fGainDb) * pAgc->Cfg.fFastAdapt;

		if (pAgc->fGainDb > pAgc->Cfg.fMaxGain)
			pAgc->fGainDb = pAgc->Cfg.fMaxGain;

		//June 15, 2007 zion@eyeball.com
		//Add minimum gain. Usually between 0 and -20, but saw -180 when there were
		//"crack and thunder" sounds
		if (pAgc->fGainDb < -20.0f)
			pAgc->fGainDb = -20.0f;
	}
	else
	{
		pAgc->fGainDb = 0;
	}
}
/*****************************************************************************/
static void				_apply_gain
/*****************************************************************************/
(
Audio_tAgc *pAgc,
float *pfSnd
)
{
	float fGainLin = gaec_utl_exp(pAgc->fGainDb + pAgc->Cfg.fExtraGain);
	int k;

	for (k = 0; k < AUDIO_FRSZ32; k++)
	{
		float x = pfSnd[k] * fGainLin;
		if (x > 1.0f)
			x = 1.0f;
		if (x < -1.0f)
			x = -1.0f;
		pfSnd[k] = x;
	}

}
/*****************************************************************************/
static void				_cfg
/*****************************************************************************/
(
Audio_tAgc *pAgc,
float fMicExtraGainDB,
const AudioIf_tAgcCfg *pCfg
)
{
	pAgc->Cfg.fTargetNrg = pCfg->fTargetLevelDBFS;
	pAgc->Cfg.fMinNrg = pCfg->fMinEnergyDBFS;
	pAgc->Cfg.fOverNoise = pCfg->fOverNoiseThrDB;
	pAgc->Cfg.fExtraGain = fMicExtraGainDB;
	pAgc->Cfg.fMaxGain = pCfg->fMaxGainDB;
	pAgc->Cfg.fFastAdapt = 20.f/(pCfg->fAdaptationSpeedOnVowelsMs+1);
	pAgc->Cfg.fSlowAdapt = 20.f/(pCfg->fAdaptationSpeedOnNoiseMs+1);
};

/*****************************************************************************/
static void				_get_cfg
/*****************************************************************************/
(
Audio_tAgc *pAgc,
float *pfMicExtraGainDB,
AudioIf_tAgcCfg *pCfg
)
{
	pCfg->fTargetLevelDBFS = pAgc->Cfg.fTargetNrg;
	pCfg->fMinEnergyDBFS = pAgc->Cfg.fMinNrg;
	pCfg->fOverNoiseThrDB = pAgc->Cfg.fOverNoise;
	pCfg->fMaxGainDB = pAgc->Cfg.fMaxGain;
	pCfg->fAdaptationSpeedOnVowelsMs = 20.F/pAgc->Cfg.fFastAdapt - 1;
	pCfg->fAdaptationSpeedOnNoiseMs = 20.F/pAgc->Cfg.fSlowAdapt - 1;
	*pfMicExtraGainDB = pAgc->Cfg.fExtraGain;
};
/*****************************************************************************/
void					audio_agc_init
/*****************************************************************************/
(
Audio_tAgc *pAgc,
float fMicExtraGainDB,
const AudioIf_tAgcCfg *pCfg
)
{
	memset (pAgc, 0, sizeof(*pAgc));
	
	if (pCfg == NULL)
		pCfg = &AgcCfg;

	_cfg(pAgc, fMicExtraGainDB, pCfg);

	pAgc->bOn = true;
	pAgc->fGainDb = 0;
	pAgc->fVadNse = AUDIO_VAD_NSE_MAX-pAgc->Cfg.fExtraGain;
	pAgc->fAwNse  = AUDIO_VAD_NSE_MIN-pAgc->Cfg.fExtraGain;
	pAgc->fPeakNrg = pAgc->Cfg.fTargetNrg - pAgc->Cfg.fExtraGain;
}
/*****************************************************************************/
void					audio_agc_reset
/*****************************************************************************/
(
Audio_tAgc *pAgc
)
{
	float fExtraGain;
	AudioIf_tAgcCfg	Cfg = {0};

	_get_cfg(pAgc, &fExtraGain, &Cfg);
	audio_agc_init(pAgc, fExtraGain, &Cfg);
}

/*****************************************************************************/
void					audio_agc
/*****************************************************************************/
(
Audio_tAgc *pAgc,
float *pfSnd
)
{
	_zc(pAgc, pfSnd);
	_vad(pAgc, pfSnd);
	_peaks(pAgc);
	_gain(pAgc);
	_apply_gain(pAgc, pfSnd);
	audio_log_trc("audio_agc -- on %d gain %7.2f vadn=%7.2f vadc=%7.2f nrg=%7.2f",
		pAgc->fVadNse,
		pAgc->fVadCrit,
		pAgc->fPeakNrg,
		pAgc->bOn, 
		pAgc->fGainDb);
#if 0
	audio_log_inf("audio_agc -- targ=%7.2f min=%7.2f onse=%7.2f extr=%7.2f maxg=%7.2f fast=%7.2f slow=%7.2f",
		pAgc->Cfg.fTargetNrg,
		pAgc->Cfg.fMinNrg,
		pAgc->Cfg.fOverNoise,
		pAgc->Cfg.fExtraGain,
		pAgc->Cfg.fMaxGain,
		pAgc->Cfg.fFastAdapt,
		pAgc->Cfg.fSlowAdapt);
#endif


	pAgc->uAlarm = 0;
	if (pAgc->iSoftTalkerCnt >= _SOFT_TALKER)
		pAgc->uAlarm |= AUDIO_IF_ALARM_AGC_SOFT_TALKER;
	if (pAgc->iNoSignalCnt >= _NO_SIGNAL)
		pAgc->uAlarm |= AUDIO_IF_ALARM_MIC_NO_SIGNAL;

	float fNse = pAgc->fAwNse + pAgc->fGainDb + pAgc->Cfg.fExtraGain;

	if (fNse > pAgc->Cfg.fTargetNrg - 12.F)
		pAgc->uAlarm |= AUDIO_IF_ALARM_MIC_BAD_NOISE;
	else if (fNse > pAgc->Cfg.fTargetNrg - 18.F)
		pAgc->uAlarm |= AUDIO_IF_ALARM_MIC_VERY_HIGH_NOISE;
	else if (fNse > pAgc->Cfg.fTargetNrg - 24.F)
		pAgc->uAlarm |= AUDIO_IF_ALARM_MIC_HIGH_NOISE;
	else ; // it's fine
}
/*****************************************************************************/
DWORD					AudioIf_agc
/*****************************************************************************/
(
const bool bOn, 
const float fMicExtraGainDB,
const AudioIf_tAgcCfg *pCfg
)
{
	if (!gAudio.bInitialized) return AUDIO_IF_ERR_NOT_INITIALIZED;

	DWORD rc = AUDIO_IF_ERR_NONE;
	audio_lock();

	audio_log_inf("AudioIf_agc -- on/off=%d pCfg=%p", 
				bOn, pCfg);

	gAudio.Agc.bOn = bOn;
	if (pCfg)
	{
		_cfg(&gAudio.Agc, fMicExtraGainDB, pCfg);
	}

	audio_log_inf("AudioIf_agc -- done");
	audio_unlock();
	return rc;
}
/*****************************************************************************/
DWORD					AudioIf_agc
/*****************************************************************************/
(
bool *pbOn, 
float *pfMicExtraGainDB,
AudioIf_tAgcCfg *pCfg
)
{
	if (!gAudio.bInitialized) return AUDIO_IF_ERR_NOT_INITIALIZED;

	DWORD rc = AUDIO_IF_ERR_NONE;
	audio_lock();

	audio_log_inf("AudioIf_agc get -- pbOn=%p pCfg=%p", 
				pbOn, pCfg);

	if (pbOn)
		*pbOn = gAudio.Agc.bOn;

	if (pCfg)
	{
		_get_cfg(&gAudio.Agc, pfMicExtraGainDB, pCfg);
	}

	audio_log_inf("AudioIf_agc get -- done");
	audio_unlock();
	return rc;
}
