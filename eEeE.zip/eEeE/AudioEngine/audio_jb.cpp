#include "audio_defs.h"
#include "audio_g711u.h"
#include "audio_g711a.h"
#include "audio_plc.h"
#include "audio_speex.h"
#include "audio_ilbc.h"
#include "audio_gsm.h"
#include "audio_g729.h"
#include "siren_if.h"

/*****************************************************************************/
static void						_q_free
/*****************************************************************************/
(
Audio_tJbParty *pParty
) 
{
//	pParty->decoder->Reset();
	pParty->bDecoderActive = false;

	for (int k = 0; k < AUDIO_JB_QSZ; k++)
	{
		Audio_tJbNetQItem *pItem = &pParty->aItem[k];
		if (pItem->wFrsPerPkt)
		{
			pItem->pcData = (BYTE *)AudioIf_free(pItem->pcData);
			memset(pItem, 0, sizeof(*pItem));
		}
	}
	// average delay
}
/*****************************************************************************/
static void						_party_on_late
/*****************************************************************************/
(
Audio_tJbParty *pParty
)
{
	// we allow 1 of 100 pks be dropped due to being late
	if (pParty->iLateCnt < 100)
	{
		pParty->fCrit += AUDIO_CRIT_MAX/3;
	}
	else if (pParty->iLateCnt < 300)
	{
		pParty->fCrit += AUDIO_CRIT_THR;
	}
	else
	{
		pParty->fCrit += AUDIO_CRIT_THR/3;
	}
	pParty->iLateCnt = 0;
	pParty->Stts.iPktsLate++;
}
/*****************************************************************************/
static void						_party_on_overflow
/*****************************************************************************/
(
Audio_tJbParty *pParty
)
{
	_q_free(pParty);

	pParty->wFrsPerPkt = 0;
	pParty->fCrit = 0;
	pParty->wWriteIdx = pParty->wWriteIdxStart;
	pParty->wReadIdx = 0;
	pParty->iOosCnt = 0;
	pParty->iLateCnt = 0;
	pParty->wLateIdxC = AUDIO_JB_INVALID_IDX;
	pParty->wRdIdxC = AUDIO_JB_INVALID_IDX;
	pParty->wRdFrs = 0;
	pParty->Stts.iJbOverflows++;

	pParty->bRunning = false;
	audio_log_inf("audio_jb_party_on_overflow -- [%d] re-init", pParty->wIdx);
}
/*****************************************************************************/
static void						_party_on_write
/*****************************************************************************/
(
Audio_tJbParty *pParty,
short sDlt,
float fDlt
)
{
	float fAdaptationSpeed = 0.05F+0.95F/(0.3F*pParty->Stts.iPktsTotal+1.F);
	if (fDlt > AUDIO_FRMS*1.75F)
	{
		pParty->fCrit -= fAdaptationSpeed * 0.05F*AUDIO_CRIT_MAX;
	}
	else
	{
		if (fDlt < AUDIO_FRMS*0.25F)
		{
			pParty->fCrit += fAdaptationSpeed * 0.2F*AUDIO_CRIT_MAX;
		}
		else
		{
			; // ok. dead zone
		}
	}

	if (pParty->fCrit > AUDIO_CRIT_MAX)
	{
		if (sDlt < (AUDIO_JB_QSZ - 2))
		{
			pParty->wWriteIdx++; // that will affect next pkt
			audio_log_inf("audio_jb_party_on_write -- [%d] Crit %7.1f write++", pParty->wIdx, pParty->fCrit);
			pParty->iPtrAdjustments++;
		}
		else 
		{
			// we are about to overflow... should not happen
			audio_log_err("audio_jb_party_on_write -- 1: %d", sDlt);
		}
#if 0
		pParty->fCrit -= AUDIO_CRIT_MAX;
		if (pParty->fCrit < 0)
#endif
			pParty->fCrit = 0;
	}
	else
	{
		if (pParty->fCrit < -AUDIO_CRIT_MAX)
		{
			if (sDlt > 0)
			{
				pParty->wWriteIdx--; // that will affect next pkt
				pParty->iPtrAdjustments--;
				audio_log_inf("audio_jb_party_on_write -- [%d] Crit %7.1f write--", pParty->wIdx, pParty->fCrit);
				// there may be left-over packet after write--. if will be freed soon
			}
			else
			{
				// we are about to underflow... should not happen
				audio_log_err("audio_jb_party_on_write -- 2: %d", sDlt);
			}
#if 0
			pParty->fCrit += AUDIO_CRIT_MAX;
			if (pParty->fCrit > 0)
#endif
				pParty->fCrit = 0;
		}
		else
		{
			;// do nothing
		}
	}
}
/*****************************************************************************/
static bool						_party_write_SZ
/*****************************************************************************/
(
Audio_tJbParty *pParty, 
Audio_tJbNetQItem *pItem
) 
{
	bool bDropped = false;
	WORD wSz = pItem->wDataSz;
	WORD wRem = 0;

	//pParty->iBytes += wSz;
	pParty->iBytes += (wSz + AUDIO_PACKET_HEADER_SIZE);
	

	switch(pParty->wPayloadType)
	{
	case AUDIO_IF_PT_G711A:
	case AUDIO_IF_PT_G711U:
		pParty->wFrsPerPkt = wSz / AUDIO_CSZ_G711;
		wRem = wSz % AUDIO_CSZ_G711;
		break;
#if AUDIO_G729
	case AUDIO_IF_PT_G729A: // for G729 it's 10 ms frame
		pParty->wFrsPerPkt = wSz / AUDIO_CSZ_G729A;
		wRem = wSz % AUDIO_CSZ_G729A;
		break;
#endif
	case AUDIO_IF_PT_SPEEX_NB:
		pParty->wFrsPerPkt = wSz / AUDIO_CSZ_SPEEX_NB;
		wRem = wSz % AUDIO_CSZ_SPEEX_NB;
		break;
	case AUDIO_IF_PT_SPEEX_WB:
		pParty->wFrsPerPkt = wSz / AUDIO_CSZ_SPEEX_WB;
		wRem = wSz % AUDIO_CSZ_SPEEX_WB;
		break;
	case AUDIO_IF_PT_SPEEX_UWB:
		pParty->wFrsPerPkt = wSz / AUDIO_CSZ_SPEEX_UWB;
		wRem = wSz % AUDIO_CSZ_SPEEX_UWB;
		break;
	case AUDIO_IF_PT_GSM:
		pParty->wFrsPerPkt = wSz / AUDIO_CSZ_GSM;
		wRem = wSz % AUDIO_CSZ_GSM;
		break;
	case AUDIO_IF_PT_ILBC:
		pParty->wFrsPerPkt = wSz / AUDIO_CSZ_ILBC;
		wRem = wSz % AUDIO_CSZ_ILBC;
		break;
	case AUDIO_IF_PT_SIREN14:
		pParty->wFrsPerPkt = wSz / AUDIO_CSZ_SIREN1424;
		wRem = wSz % AUDIO_CSZ_SIREN1424;
		break;
	case AUDIO_IF_PT_SIREN1432:
		pParty->wFrsPerPkt = wSz / AUDIO_CSZ_SIREN1432;
		wRem = wSz % AUDIO_CSZ_SIREN1432;
		break;
	case AUDIO_IF_PT_SIREN1448:
		pParty->wFrsPerPkt = wSz / AUDIO_CSZ_SIREN1448;
		wRem = wSz % AUDIO_CSZ_SIREN1448;
		break;
	case AUDIO_IF_PT_SIREN1416:
		pParty->wFrsPerPkt = wSz / AUDIO_CSZ_SIREN1416;
		wRem = wSz % AUDIO_CSZ_SIREN1416;
		break;
	default: // shall not happen
		audio_log_err("audio_jb_party_write_SZ -- [%d] PT %d", pParty->wIdx, pParty->wPayloadType);
		pParty->wFrsPerPkt = 0;
		bDropped = true;
		break;
	}

	if (wRem != 0)
	{
		audio_log_err("audio_jb_party_write_SZ -- [%d] data sz %d", pParty->wIdx, wSz);
		pParty->Stts.iPktsDefective++;
		bDropped = true;
	}
	return bDropped;
}
/*****************************************************************************/
static bool						_party_write_SN
/*****************************************************************************/
(
Audio_tJbParty *pParty, 
Audio_tJbNetQItem *pItem
) 
{
	WORD wSnExpected = pParty->wSnLast + 1;
	WORD wSn = pItem->Hdr.wSN;
	bool bDropped = false;

	if (wSnExpected == wSn)
	{
		// Sequence number is as expected
		pParty->iOosCnt = 0;
		pParty->wSnLast = wSn;
	}
	else
	{
		short sDlt = short(wSn - wSnExpected);
		pParty->iOosCnt ++;

		if (sDlt > 0) // lost pkts
		{
			// if there are not too many lost packets...
			if (sDlt < AUDIO_JB_OOS_MAX) 
			{
				audio_log_war("audio_jb_party_write_SN -- [%d] lost %d, SN=%d", 
					pParty->wIdx, sDlt, wSn);
				pParty->Stts.iPktsLost += sDlt;
				pParty->wSnLast = wSn;
//				pParty->iOosCnt = 0;
			}
			else 
			{
				audio_log_err("audio_jb_party_write_SN -- [%d] lost %d, SN=%d", 
					pParty->wIdx, sDlt, wSn);
				// the gap is goo big
				bDropped = true;
			}
		}
		else // out of sequence or duplicated. drop for now
		{
			pParty->Stts.iPktsOutOfSequence++;
			audio_log_war("audio_jb_party_write_SN -- [%d] OOS %d, SN=%d", 
				pParty->wIdx, sDlt, wSn);
			bDropped = true;
		}
	
		if (pParty->iOosCnt >= AUDIO_JB_OOS_MAX) // restart
		{
			pParty->iOosCnt = 0;
			pParty->dwTsLast = pItem->Hdr.dwTS;
			pParty->wSnLast = wSn;
			pParty->wWriteIdx = pParty->wReadIdx + 2;
			audio_log_war("audio_jb_party_write_SN -- [%d] restart, SN=%d", 
				pParty->wIdx, wSn);
			bDropped = true;
		}
	}
	return bDropped;
}
/*****************************************************************************/
static bool						_party_write_TS
/*****************************************************************************/
(
Audio_tJbParty *pParty, 
Audio_tJbNetQItem *pItem,
bool	*pbLate
) 
{
	bool bDropped = false;
	DWORD dwTsDlt = pItem->Hdr.dwTS - pParty->dwTsLast;
	WORD wFrames = WORD((dwTsDlt + (pParty->dwTsFrame>>1)) / pParty->dwTsFrame);
	*pbLate = false;

// TODO: test FrsPerPkt and TsDlt are coherent, ...

	pParty->wWriteIdx += wFrames;

	// write idx must be ahead of read idx, 
	// but not in excess of jb q length
	short sDlt = short(pParty->wWriteIdx - pParty->wReadIdx);

	if (sDlt < 0) // it's a late pkt
	{
		audio_log_war("audio_jb_party_write_TS -- [%d] late %d, SN=%d", 
			pParty->wIdx, sDlt, pItem->Hdr.wSN);
		for (int k = 0; k < -sDlt; k++)
		{
			_party_on_late(pParty);
		}

		// write it if pkt contains more that 1 frame, and something is valid
		if ((-sDlt) > int(pParty->wFrsPerPkt))
		{
			audio_log_war("audio_jb_party_write_TS -- [%d] too late %d", 
				pParty->wIdx, sDlt);
			bDropped = true;
		}
		else
			*pbLate = true;
	}
	else if (sDlt > (AUDIO_JB_QSZ-3)) // it's an overflow
	{
		_party_on_overflow(pParty);
		bDropped = true;
	}
	else 
	{
		// normal 
	}

	pItem->fArrived = gAudio.Drv.fNow - pItem->fArrived;
	pItem->fArrived += sDlt * AUDIO_FRMS; 
	audio_hstgm_add(&pParty->Stts.JitterHistogram, pItem->fArrived);

	pParty->Stts.fDelayCurrent = pItem->fArrived;
	pParty->Stts.fDelayAverage += 0.02F * (pItem->fArrived - pParty->Stts.fDelayAverage);

	if (!bDropped)
	{
		_party_on_write(pParty, sDlt, pItem->fArrived);
		pParty->dwTsLast = pItem->Hdr.dwTS;
	}

	return bDropped;
}
/*****************************************************************************/
static void						_party_write
/*****************************************************************************/
(
Audio_tJbParty *pParty, 
Audio_tJbNetQItem *pItem
) 
{
	bool bDropped = false;
	WORD wPayloadType = pItem->Hdr.wPT;
	bool bLate = false;
	audio_log_trc("audio_jb_party_write -- PT %d SZ %d SN %d TS %d p=%p", 
		pItem->Hdr.wPT,
		pItem->wDataSz,
		pItem->Hdr.wSN,
		pItem->Hdr.dwTS,
		pItem->pcData);

	if (pParty->dwSD != AUDIO_SD)
	{
		audio_log_err("audio_jb_party_write -- [%d] in SD %x", 
			pParty->wIdx, pParty->dwSD);
		pParty->dwSD = AUDIO_SD;
	}
	if (pParty->dwED != AUDIO_ED)
	{
		audio_log_err("audio_jb_party_write -- [%d] in ED %x", 
			pParty->wIdx, pParty->dwED);
		pParty->dwED = AUDIO_ED;
	}

	audio_rec_pkt(
		AUDIO_IF_REC_JB_IN, 
		pParty->wIdx,
		&pItem->Hdr,
		pItem->pcData,
		pItem->wDataSz,
		pItem->fArrived);

	if (pParty->wPayloadType == wPayloadType)
	{
		if (pParty->bRunning)
		{
			if (!bDropped)
			{
				bDropped = _party_write_SZ(pParty, pItem);
			}
			if (!bDropped)
			{
				bDropped = _party_write_SN(pParty, pItem);
			}
			if (!bDropped)
			{
				bDropped = _party_write_TS(pParty, pItem, &bLate);
			}
		}
		else // first pkt in a call
		{
			pParty->dwTsLast = pItem->Hdr.dwTS;
			pParty->wSnLast = pItem->Hdr.wSN;
			pParty->bRunning = true;
			_party_write_SZ(pParty, pItem);
			if (!pParty->bRestart)
			{
				audio_log_inf(
					"audio_jb_party_write -- [%d] first pkt in the stream", 
					pParty->wIdx);
				
				if(0 == pParty->Stts.iPktsTotal)
				{
					audio_tmr_peek(0, &pParty->fStartedAt);
				}
			}
			else
			{
				audio_log_inf(
			"audio_jb_party_write -- [%d] DTX restart, write=%d read= %d", 
					pParty->wIdx,
					pParty->wWriteIdx,
					pParty->wReadIdx
					);
			}
		}
	}
	else
	{
		audio_log_err("audio_jb_party_write -- [%d] PT %d, expected %d", 
			pParty->wIdx, wPayloadType, pParty->wPayloadType);
		pParty->Stts.iPktsDefective++;
		bDropped = true;
	}

	if (bDropped)
	{
		pParty->Stts.iPktsDropped++;
		pItem->pcData = (BYTE *)AudioIf_free(pItem->pcData);
		audio_log_war("audio_jb_party_write -- [%d] dropped %d", 
			pParty->wIdx, pParty->Stts.iPktsDropped);
	}
	else
	{
		WORD wIdxC = pParty->wWriteIdx & (AUDIO_JB_QSZ-1);
		pItem->wFrsPerPkt = pParty->wFrsPerPkt;

		if (pParty->aItem[wIdxC].wFrsPerPkt)
		{
			// somehow it's left there
			audio_log_war("audio_jb_party_write -- [%d] leftover at %d", 
				pParty->wIdx, wIdxC);
			pParty->aItem[wIdxC].pcData = 
				(BYTE *)AudioIf_free(pParty->aItem[wIdxC].pcData);
			memset(&pParty->aItem[wIdxC], 0, sizeof(Audio_tJbNetQItem));
		}
		pParty->aItem[wIdxC] = *pItem;
		audio_log_trc("audio_jb_party_write -- [%d] written at 0x%04x", 
				pParty->wIdx, pParty->wWriteIdx);

		if (bLate)
		{
			// free an old one if it happens to be there
			if (pParty->wLateIdxC < AUDIO_JB_QSZ)
			{
				pParty->aItem[pParty->wLateIdxC].pcData = 
					(BYTE *)AudioIf_free
						(pParty->aItem[pParty->wLateIdxC].pcData);

				memset(&pParty->aItem[pParty->wLateIdxC], 
					0, 
					sizeof(Audio_tJbNetQItem));
			}
			pParty->wLateIdxC = wIdxC;
		}

		pItem->pcData = NULL;
	}


	pParty->Stts.iPktsTotal++;

	if (pParty->dwSD != AUDIO_SD)
	{
		audio_log_err("audio_jb_party_write -- [%d] out SD %x", 
			pParty->wIdx, pParty->dwSD);
		pParty->dwSD = AUDIO_SD;
	}
	if (pParty->dwED != AUDIO_ED)
	{
		audio_log_err("audio_jb_party_write -- [%d] out ED %x", 
			pParty->wIdx, pParty->dwED);
		pParty->dwED = AUDIO_ED;
	}
}
/*****************************************************************************/
static void						_party_read_find
/*****************************************************************************/
(
Audio_tJbParty *pParty
) 
{
	/* we have 3 sources:
		- decoder is still active
		- new item arrived at wReadIdx
		- a late pkt was latched
			
		if new packet is available at wReadIdx, then 
			all the rest is discarded;
		else
			if decoder is active, then 
				it goes on
			else
				if late pkt was latched, then
					use it
				else
					put wRdIdxC = (-1)
				endif
			endif
		endif

	*/	
	WORD wIdxC = pParty->wReadIdx & (AUDIO_JB_QSZ-1);
	Audio_tJbNetQItem *pItem = &pParty->aItem[wIdxC];

//	bool bDecoderActive = (pParty->wRdIdxC < AUDIO_JB_QSZ) && 
//			(pParty->aItem[pParty->wRdIdxC].wFrsPerPkt > 0);

	audio_log_trc("audio_jb_party_read_find -- [%d] at=%xh FPP=%d act=%d late=%xh", 
			pParty->wIdx, wIdxC, pItem->wFrsPerPkt, pParty->bDecoderActive, pParty->wLateIdxC);

	if (pItem->wFrsPerPkt) // not empty
	{

		if (pParty->bDecoderActive)
		{
			if (pParty->wRdIdxC < AUDIO_JB_QSZ)
			{
				pParty->aItem[pParty->wRdIdxC].pcData = 
					(BYTE *)AudioIf_free(pParty->aItem[pParty->wRdIdxC].pcData);
				memset(&pParty->aItem[pParty->wRdIdxC], 0, sizeof(Audio_tJbNetQItem));
			}
			else
				audio_log_err("audio_jb_party_read_find -- 1");

		}
		if (pParty->wLateIdxC < AUDIO_JB_QSZ) // something has been latched
		{
			pParty->aItem[pParty->wLateIdxC].pcData = 
				(BYTE *)AudioIf_free(pParty->aItem[pParty->wLateIdxC].pcData);
			memset(&pParty->aItem[pParty->wLateIdxC], 0, sizeof(Audio_tJbNetQItem));

			pParty->wLateIdxC = AUDIO_JB_INVALID_IDX;
		}
		pParty->wRdFrs = 0;
		pParty->wRdIdxC = wIdxC;
		pParty->bDecoderActive = false; // true???
	}
	else // there is nothing new
	{
		if (pParty->bDecoderActive) // we still have data to process
		{
			// something has been latched, drop it
			// by the  way, it should not happen... unless we do pWriteIdx adjustments
			if (pParty->wLateIdxC < AUDIO_JB_QSZ) 
			{
				pParty->aItem[pParty->wLateIdxC].pcData = 
					(BYTE *)AudioIf_free(pParty->aItem[pParty->wLateIdxC].pcData);
				memset(&pParty->aItem[pParty->wLateIdxC], 0, sizeof(Audio_tJbNetQItem));

				pParty->wLateIdxC = AUDIO_JB_INVALID_IDX;
			}
		}
		else // no data to process
		{
			if (pParty->wLateIdxC < AUDIO_JB_QSZ) // something has been latched
			{
				Audio_tJbNetQItem *pLateItem = &pParty->aItem[pParty->wLateIdxC];
				WORD wDlt = wIdxC - pParty->wLateIdxC;
				wDlt &= (AUDIO_JB_QSZ-1);

				if (wDlt < pLateItem->wFrsPerPkt) // use it
				{
					pParty->wRdFrs = wDlt;
					pParty->wRdIdxC = pParty->wLateIdxC;
					pParty->bDecoderActive = true;
				}
				else // too late. discard it
				{
					pLateItem->pcData = 
						(BYTE *)AudioIf_free(pLateItem->pcData);
					memset(pLateItem, 0, sizeof(Audio_tJbNetQItem));

				}
				pParty->wLateIdxC = AUDIO_JB_INVALID_IDX;
			}
			else // nothing new, no data inside codec, no late pkts
			{		
				pParty->wRdFrs = 0;
				pParty->wRdIdxC = AUDIO_JB_INVALID_IDX;
				pParty->bDecoderActive = false;
			}
		}
	}
}
/*****************************************************************************/
static void						_party_read_one
/*****************************************************************************/
(
Audio_tJbParty *pParty,
WORD wCodeSz,
short *psTo
) 
{

	BYTE *pcData = NULL;
	Audio_tJbNetQItem *pItem = NULL;

	if (pParty->wRdIdxC < AUDIO_JB_QSZ)
	{
		pItem = &pParty->aItem[pParty->wRdIdxC];

		if (pItem->wFrsPerPkt)
		{
			if (pItem->pcData)
			{
				pcData = pItem->pcData;
				pcData += wCodeSz * pParty->wRdFrs;
			}
			else
			{
				audio_log_err("audio_jb_party_read_one -- 1");
			}
		}
	}

	audio_log_trc("audio_jb_party_read_one -- [%d] idxC=0x%04x readIdx=0x%04x CodeSz=%d pcData=%p psTo=%p", 
		pParty->wIdx, pParty->wRdIdxC, pParty->wReadIdx, wCodeSz, pcData, psTo);

	audio_tmr_start(AUDIO_TMR_DEC);
	switch(pParty->wPayloadType)
	{
	case AUDIO_IF_PT_G711A:
		audio_G711A_decode(psTo, pcData);
		audio_plc_process(pParty->pvDecoder, psTo, (pcData == NULL));
		break;
	case AUDIO_IF_PT_G711U:
		audio_G711U_decode(psTo, pcData);
		audio_plc_process(pParty->pvDecoder, psTo, (pcData == NULL));
		break;
	case AUDIO_IF_PT_SPEEX_NB:
	case AUDIO_IF_PT_SPEEX_WB:
	case AUDIO_IF_PT_SPEEX_UWB:
		audio_speex_decode(pParty->pvDecoder, psTo, pcData, wCodeSz);
		break;
	case AUDIO_IF_PT_ILBC:
		audio_iLBC_decode(pParty->pvDecoder, psTo, pcData);
		break;
	case AUDIO_IF_PT_GSM:
		audio_GSM_decode(pParty->pvDecoder, psTo, pcData);
		break;
#if AUDIO_G729
	case AUDIO_IF_PT_G729A:
		audio_G729_decode(pParty->pvDecoder, psTo, pcData);
		break;
#endif
	case AUDIO_IF_PT_SIREN14:
	case AUDIO_IF_PT_SIREN1432:
	case AUDIO_IF_PT_SIREN1448:
	case AUDIO_IF_PT_SIREN1416:
		siren_decode(pParty->pvDecoder, psTo, pcData);
		break;
	default:
		audio_log_err("audio_jb_party_read_one -- PT %d ???",
			pParty->wPayloadType);
		break;
	}
	audio_tmr_stop(AUDIO_TMR_DEC);

	if (pcData != NULL) // valid RdIdxC with non-empty content
	{
		pParty->wRdFrs++;

		// are we done with this pkt ?
		if (pParty->wRdFrs >= pItem->wFrsPerPkt)
		{
			pItem->pcData = (BYTE *)AudioIf_free(pItem->pcData);
			memset(&pParty->aItem[pParty->wRdIdxC], 0, sizeof(Audio_tJbNetQItem));
			pParty->wRdFrs = 0;
			pParty->wRdIdxC = AUDIO_JB_INVALID_IDX;
			pParty->bDecoderActive = false;

		}
		else
		{
			pParty->bDecoderActive = true;
		}
	}
	else
	{
		pParty->wRdIdxC = AUDIO_JB_INVALID_IDX;
		pParty->bDecoderActive = false;
	}

//	audio_jb_party_on_read(pParty);
}
/*****************************************************************************/
static void						_party_read
/*****************************************************************************/
(
Audio_tJbParty *pParty
) 
{
	int k;

	if (pParty->dwSD != AUDIO_SD)
	{
		audio_log_err("audio_jb_party_read -- [%d] in SD %x", 
			pParty->wIdx, pParty->dwSD);
		pParty->dwSD = AUDIO_SD;
	}
	if (pParty->dwED != AUDIO_ED)
	{
		audio_log_err("audio_jb_party_read -- [%d] in ED %x", 
			pParty->wIdx, pParty->dwED);
		pParty->dwED = AUDIO_ED;
	}

	for (k = 0; k < AUDIO_FRSZ32; k++)
	{
		pParty->asOut[k] = 0;
	}

	if (pParty->bRunning)
	{
		_party_read_find(pParty);
		WORD	wUpSample = 1;

		switch(pParty->wPayloadType)
		{
		case AUDIO_IF_PT_G711A:
		case AUDIO_IF_PT_G711U:
			_party_read_one(pParty, AUDIO_CSZ_G711,pParty->asOut);
			break;
#if AUDIO_G729
		case AUDIO_IF_PT_G729A: // for G729 it's 10 ms frame
			_party_read_one(pParty,	AUDIO_CSZ_G729A, pParty->asOut);

			pParty->wReadIdx++;
			_party_read_find(pParty);
			_party_read_one(
				pParty,
				AUDIO_CSZ_G729A,
				pParty->asOut + AUDIO_FRSZ8/2);
			break;
#endif
		case AUDIO_IF_PT_SPEEX_NB:
			_party_read_one(pParty, AUDIO_CSZ_SPEEX_NB, pParty->asOut);
			break;
		case AUDIO_IF_PT_SPEEX_WB:
			_party_read_one(pParty, AUDIO_CSZ_SPEEX_WB, pParty->asOut);
			wUpSample = 3;
			break;
		case AUDIO_IF_PT_SPEEX_UWB:
			_party_read_one(pParty, AUDIO_CSZ_SPEEX_UWB, pParty->asOut);
			wUpSample = 2;
			break;
		case AUDIO_IF_PT_GSM:
			_party_read_one(pParty,	AUDIO_CSZ_GSM,	pParty->asOut);
			break;
		case AUDIO_IF_PT_ILBC:
			_party_read_one(pParty,	AUDIO_CSZ_ILBC,	pParty->asOut);
			break;
		case AUDIO_IF_PT_SIREN14:
			_party_read_one(pParty,	AUDIO_CSZ_SIREN1424, pParty->asOut);
			wUpSample = 2;
			break;
		case AUDIO_IF_PT_SIREN1432:
			_party_read_one(pParty,	AUDIO_CSZ_SIREN1432,pParty->asOut);
			wUpSample = 2;
			break;
		case AUDIO_IF_PT_SIREN1448:
			_party_read_one(pParty,	AUDIO_CSZ_SIREN1448,pParty->asOut);
			wUpSample = 2;
			break;
		case AUDIO_IF_PT_SIREN1416:
			_party_read_one(pParty,	AUDIO_CSZ_SIREN1416,pParty->asOut);
			wUpSample = 2;
			break;
		default:
			audio_log_err("audio_jb_party_read -- [%d] PT %d", pParty->wIdx, pParty->wPayloadType);
			break;

		}
		pParty->wReadIdx++;

		switch (wUpSample)
		{
		case 0: // data in floating, normalized and 32kHz
			break;
		case 1: // data in short and on 8kHz
			{
				float af[AUDIO_FRSZ8];
				audio_utl_short2float(af, pParty->asOut, AUDIO_FRSZ8);
				audio_utl_8to32(pParty->afIntSav, pParty->afOut, af);
			}
			break;
		case 2: // data in short on 32kHz
			{
				audio_utl_short2float(pParty->afOut, pParty->asOut, AUDIO_FRSZ32);
			}
			break;
		case 3: // data in short and on 16kHz
			{
				float af[AUDIO_FRSZ16];
				audio_utl_short2float(af, pParty->asOut, AUDIO_FRSZ16);
				audio_utl_16to32(pParty->afIntSav, pParty->afOut, af);
			}
			break;
		}
		audio_recf32(AUDIO_IF_REC_JB_OUT, pParty->wIdx, pParty->afOut); 

		float fNrg = 80.F+audio_utl_pktnrg(pParty->afOut, AUDIO_FRSZ32);
		if (fNrg < 0)
			fNrg = 0;

		if (fNrg > pParty->fNrg)
			pParty->fNrg = fNrg;
		else
			pParty->fNrg += (fNrg - pParty->fNrg) * 0.1F;

		float fPeak = 1e-4F;
		for (k = 0; k < AUDIO_FRSZ32; k++)
		{
			float f = fabsf(pParty->afOut[k]);
			if (fPeak < f)
				fPeak = f;
		}
#ifndef _WIN32_WCE
		fPeak = 20*log10f(fPeak);
#else
		fPeak = 20*log10l(fPeak);
#endif

		if (fPeak > pParty->fPeak)
			pParty->fPeak = fPeak;
		else
			pParty->fPeak += (fPeak - pParty->fPeak) * 0.01F;

		float fGain = gaec_utl_exp(pParty->fGainDb);
		for (k = 0; k < AUDIO_FRSZ32; k++)
		{
			pParty->afOut[k] *= fGain;
		}

		// detect is there were too long discontinuities in 
		short sDlt = short(pParty->wWriteIdx - pParty->wReadIdx);

		if (sDlt < -250) // no packets for 5 seconds
		{
			// reinitialize party
			pParty->bRunning = false;
			int iDelay = int (pParty->Stts.fDelayAverage*0.05F);
			if (iDelay < 1)
				iDelay = 1;
			if (iDelay > AUDIO_JB_QSZ/2)
				iDelay = AUDIO_JB_QSZ/2;
			pParty->wWriteIdxStart = iDelay;
			pParty->wReadIdx = 0;
			pParty->wRdFrs = 0;
			pParty->wFrsPerPkt = 0;
			pParty->wWriteIdx = pParty->wWriteIdxStart;
			pParty->dwTsLast = 0;
			pParty->wSnLast = 0;
			pParty->iOosCnt = 0;
			pParty->iLateCnt = 0;
			pParty->bDecoderActive = false;
			pParty->wLateIdxC = AUDIO_JB_INVALID_IDX;
			pParty->wRdIdxC = AUDIO_JB_INVALID_IDX;
			pParty->fCrit = 0;
			pParty->bRestart = true;

			audio_log_inf("audio_jb_party_read -- [%d] DTX detected, delay %d [%7.2f] pkts", 
				pParty->wIdx, pParty->wWriteIdxStart, pParty->Stts.fDelayAverage*0.05F);
		}
	}
	else 
	{
		 ; // nothing to do
	}


	if (pParty->dwSD != AUDIO_SD)
	{
		audio_log_err("audio_jb_party_read -- [%d] out SD %x", 
			pParty->wIdx, pParty->dwSD);
		pParty->dwSD = AUDIO_SD;
	}
	if (pParty->dwED != AUDIO_ED)
	{
		audio_log_err("audio_jb_party_read -- [%d] out ED %x", 
			pParty->wIdx, pParty->dwED);
		pParty->dwED = AUDIO_ED;
	}
}

/*****************************************************************************/
void						audio_jb_mux
/*****************************************************************************/
(
)
{
	Audio_tJb *pJb = &gAudio.Jb;
	int k;

	for (k = 0; k < AUDIO_FRSZ32; k++)
	{
		gAudio.afRcv[k] = (1.e-10F/RAND_MAX)*(rand()-RAND_MAX/2);
	}
	for (int jb = 1; jb <= AUDIO_IF_PARTY_MAX; jb++)
	{
		Audio_tJbParty *pParty = pJb->apParty[jb];
		if (pParty != NULL)
		{
			_party_read(pParty);

			if (pParty->bMixToSpk)
			{
				for (k = 0; k < AUDIO_FRSZ32; k++)
				{
					gAudio.afRcv[k] += pParty->afOut[k];
				}
			}
		}
	}

	for (k = 0; k < AUDIO_FRSZ32; k++) gAudio.afMux[k] = gAudio.afRcv[k];
	audio_recf32(AUDIO_IF_REC_JB_MIX, 0, gAudio.afRcv);
}
/*****************************************************************************/
void						audio_jb_netq_poll
/*****************************************************************************/
(
)
{
	Audio_tJbNetQ *pNetQ = &gAudio.Jb.NetQ;

//	audio_tmr_peek(0, &gAudio.Drv.fNow);

	while (pNetQ->lSz > 0)
	{
		Audio_tJbNetQItem *pItem = &pNetQ->aItem[pNetQ->iReadIdx];

		WORD wSrcId = pItem->Hdr.wIdx;
		if ((wSrcId > 0) &&
			(wSrcId <= AUDIO_IF_PARTY_MAX))
		{
			if (gAudio.Jb.apParty[wSrcId])
			{
				if (pItem->pcData)
					_party_write(gAudio.Jb.apParty[wSrcId], pItem); 
				else
					audio_log_err("audio_jb_poll -- pcData=NULL");
			}
			else
			{
				// party may have got down since pk got into NetQ
				audio_log_war("audio_jb_poll -- party not initialized");
				pItem->pcData = (BYTE *)AudioIf_free(pItem->pcData);
			}
		}
		else
		{
			// party may have got down since ...
			audio_log_war("audio_jb_poll -- bad line idx 0x%x", pItem->Hdr.wIdx);
			pItem->pcData = (BYTE *)AudioIf_free(pItem->pcData); 
		}
#ifndef _WIN32_WCE
		InterlockedDecrement(&pNetQ->lSz);
#else
		InterlockedDecrement((LPLONG)&pNetQ->lSz);
#endif

		pNetQ->iReadIdx++;
		pNetQ->iReadIdx &= (AUDIO_JB_NETQ_SZ-1);
	}
}
/*****************************************************************************/
void						audio_jb_netq_free
/*****************************************************************************/
(
)
{
	Audio_tJbNetQ *pNetQ = &gAudio.Jb.NetQ;

	for (int k = 0; k < AUDIO_JB_NETQ_SZ; k++)
	{
		Audio_tJbNetQItem *pItem = &pNetQ->aItem[k];
		if (pItem->pcData)
		{
			audio_log_war("audio_jb_netq_free -- %p", pItem->pcData);
			pItem->pcData = (BYTE *)AudioIf_free(pItem->pcData); 
		}
	}
	memset(pNetQ, 0, sizeof(*pNetQ));
}
/*****************************************************************************/
static Audio_tJbParty*			_party_create
/*****************************************************************************/
(
WORD wPayloadType, 
WORD wIdx, 
float fInitialDelayMs
)
{
	Audio_tJbParty *pParty = (Audio_tJbParty *)AudioIf_alloc(sizeof(Audio_tJbParty));
	if (pParty == NULL)
		return pParty;

	memset(pParty, 0, sizeof(Audio_tJbParty));
	pParty->wIdx = wIdx;
	pParty->wPayloadType = wPayloadType;

	if (fInitialDelayMs < 0)
		fInitialDelayMs = 0;

	switch(wPayloadType)
	{
	case AUDIO_IF_PT_G711A:
		pParty->pvDecoder = AudioIf_alloc(sizeof(Audio_tPlc));
		audio_plc_reset((Audio_tPlc*)pParty->pvDecoder);
		pParty->dwTsFrame = 160;
		pParty->wWriteIdxStart = 1 + int ((fInitialDelayMs + 19.F)*0.05F);
		break;
	case AUDIO_IF_PT_G711U:
		pParty->pvDecoder = AudioIf_alloc(sizeof(Audio_tPlc));
		audio_plc_reset((Audio_tPlc*)pParty->pvDecoder);
		pParty->dwTsFrame = 160;
		pParty->wWriteIdxStart = 1 + int ((fInitialDelayMs + 19.F)*0.05F);
		break;
	case AUDIO_IF_PT_SPEEX_NB:
		pParty->pvDecoder = AudioIf_alloc(sizeof(Audio_tSpeex));
		audio_speex_decoder_init(pParty->pvDecoder, AUDIO_IF_PT_SPEEX_NB);
		pParty->dwTsFrame = 160;
		pParty->wWriteIdxStart = 1 + int ((fInitialDelayMs + 19.F)*0.05F);
		break;
	case AUDIO_IF_PT_SPEEX_WB:
		pParty->pvDecoder = AudioIf_alloc(sizeof(Audio_tSpeex));
		audio_speex_decoder_init(pParty->pvDecoder, AUDIO_IF_PT_SPEEX_WB);
		pParty->dwTsFrame = 320;
		pParty->wWriteIdxStart = 1 + int ((fInitialDelayMs + 19.F)*0.05F);
		break;
	case AUDIO_IF_PT_SPEEX_UWB:
		pParty->pvDecoder = AudioIf_alloc(sizeof(Audio_tSpeex));
		audio_speex_decoder_init(pParty->pvDecoder, AUDIO_IF_PT_SPEEX_UWB);
		pParty->dwTsFrame = 640;
		pParty->wWriteIdxStart = 1 + int ((fInitialDelayMs + 19.F)*0.05F);
		break;
	case AUDIO_IF_PT_ILBC:
		pParty->pvDecoder = AudioIf_alloc(sizeof(iLBC_Dec_Inst_t));
		audio_iLBC_decoder_init(pParty->pvDecoder);
		pParty->dwTsFrame = 160;
		pParty->wWriteIdxStart = 1 + int ((fInitialDelayMs + 19.F)*0.05F);
		break;
	case AUDIO_IF_PT_GSM:
		pParty->pvDecoder = audio_GSM_init();
		pParty->dwTsFrame = 160;
		pParty->wWriteIdxStart = 1 + int ((fInitialDelayMs + 19.F)*0.05F);
		break;
#if AUDIO_G729
	case AUDIO_IF_PT_G729A: // for G729 it's 10 ms frame
		pParty->pvDecoder = audio_G729_decoder_init();
		pParty->dwTsFrame = 80;
		pParty->wWriteIdxStart = 1 + int ((fInitialDelayMs + 9.F)*0.10F);
		break;
#endif
	case AUDIO_IF_PT_SIREN14:
		pParty->pvDecoder = AudioIf_alloc(sizeof(Siren_tDec));
		siren_decoder_init(pParty->pvDecoder);
		pParty->dwTsFrame = 640;
		pParty->wWriteIdxStart = 1 + int ((fInitialDelayMs + 19.F)*0.05F);
		break;
	case AUDIO_IF_PT_SIREN1432:
		pParty->pvDecoder = AudioIf_alloc(sizeof(Siren_tDec));
		siren_decoder_init(pParty->pvDecoder, 640);
		pParty->dwTsFrame = 640;
		pParty->wWriteIdxStart = 1 + int ((fInitialDelayMs + 19.F)*0.05F);
		break;
	case AUDIO_IF_PT_SIREN1448:
		pParty->pvDecoder = AudioIf_alloc(sizeof(Siren_tDec));
		siren_decoder_init(pParty->pvDecoder, 960);
		pParty->dwTsFrame = 640;
		pParty->wWriteIdxStart = 1 + int ((fInitialDelayMs + 19.F)*0.05F);
		break;
	case AUDIO_IF_PT_SIREN1416:
		pParty->pvDecoder = AudioIf_alloc(sizeof(Siren_tDec));
		siren_decoder_init(pParty->pvDecoder, 320);
		pParty->dwTsFrame = 640;
		pParty->wWriteIdxStart = 1 + int ((fInitialDelayMs + 19.F)*0.05F);
		break;
	default:
		audio_log_err("audio_jb_party_create -- PT %d", wPayloadType);
		pParty = (Audio_tJbParty *)AudioIf_free(pParty);
		break;

	}

	if (pParty)
	{
		pParty->wWriteIdx = pParty->wWriteIdxStart;
		pParty->wLateIdxC = AUDIO_JB_INVALID_IDX;
		pParty->wRdIdxC = AUDIO_JB_INVALID_IDX;
		pParty->dwSD = AUDIO_SD;
		pParty->dwED = AUDIO_ED;
		audio_hstgm_init(&pParty->Stts.JitterHistogram);

		pParty->fNrg = -65;
		pParty->fPeak = -65;

	}
	return pParty;
}
/*****************************************************************************/
static Audio_tJbParty*				_party_delete
/*****************************************************************************/
(
Audio_tJbParty *pParty
)
{
	if (pParty)
	{
		float fNow;
		audio_tmr_peek(0, &fNow);
		pParty->Stts.fBitRateKbps = pParty->iBytes * 8.F / 
				(fabs(fNow - pParty->fStartedAt) + 1.e-12F);
		audio_hstgm_analyse(&pParty->Stts.JitterHistogram);

		audio_log_inf("total %d", pParty->Stts.iPktsTotal);
		audio_log_inf("lost  %d", pParty->Stts.iPktsLost);
		audio_log_inf("late  %d", pParty->Stts.iPktsLate);
		audio_log_inf("OOS   %d", pParty->Stts.iPktsOutOfSequence);
		audio_log_inf("defective %d", pParty->Stts.iPktsDefective);
		audio_log_inf("overflows %d", pParty->Stts.iJbOverflows);
		audio_log_inf("KBPS %7.2f", pParty->Stts.fBitRateKbps);
		audio_log_inf("delay avrg %f", pParty->Stts.fDelayAverage);
		audio_log_inf("pos adjusts %d", pParty->iPtrAdjustments);
		audio_log_inf("jitter min %f", pParty->Stts.JitterHistogram.fMin);
		audio_log_inf("jitter avr %f", pParty->Stts.JitterHistogram.fAvrg);
		audio_log_inf("jitter 50%% %f", pParty->Stts.JitterHistogram.f50);
		audio_log_inf("jitter 90%% %f", pParty->Stts.JitterHistogram.f90);
		audio_log_inf("jitter 99%% %f", pParty->Stts.JitterHistogram.f99);
		audio_log_inf("jitter max %f", pParty->Stts.JitterHistogram.fMax);

		for (int k = 0; k < AUDIO_JB_QSZ; k++)
		{
			if (pParty->aItem[k].pcData)
			{
				pParty->aItem[k].pcData = (BYTE*)AudioIf_free(pParty->aItem[k].pcData);
			}
		}

		switch(pParty->wPayloadType)
		{
		case AUDIO_IF_PT_G711A:
		case AUDIO_IF_PT_G711U:
			pParty->pvDecoder = AudioIf_free(pParty->pvDecoder);
			break;
		case AUDIO_IF_PT_SPEEX_NB:
		case AUDIO_IF_PT_SPEEX_WB:
		case AUDIO_IF_PT_SPEEX_UWB:
			audio_speex_decoder_delete(pParty->pvDecoder);
			pParty->pvDecoder = AudioIf_free(pParty->pvDecoder);
			break;
		case AUDIO_IF_PT_ILBC:
			pParty->pvDecoder = AudioIf_free(pParty->pvDecoder);
			break;
		case AUDIO_IF_PT_GSM:
			pParty->pvDecoder = audio_GSM_delete(pParty->pvDecoder);
			break;
#if AUDIO_G729
		case AUDIO_IF_PT_G729A: // for G729 it's 10 ms frame
			pParty->pvDecoder = AudioIf_free(pParty->pvDecoder);
			break;
#endif
		case AUDIO_IF_PT_SIREN14:
		case AUDIO_IF_PT_SIREN1432:
		case AUDIO_IF_PT_SIREN1448:
		case AUDIO_IF_PT_SIREN1416:
			pParty->pvDecoder = AudioIf_free(pParty->pvDecoder);
			break;
		default:
			break;
		}
		pParty = (Audio_tJbParty *)AudioIf_free(pParty);

	}
	return pParty;
}

/*****************************************************************************/
DWORD						AudioIf_src_add
/*****************************************************************************/
(
WORD	wSrcId, 
WORD	wPayloadType, 
float	fInitialDelayMs,
bool	bMixToSpk
)
{
	if (!gAudio.bInitialized) return AUDIO_IF_ERR_NOT_INITIALIZED;

	DWORD rc = AUDIO_IF_ERR_NONE;
	audio_lock();
	audio_log_inf("AudioIf_src_add -- SRC=%d PT=%d Dly=%f", 
				wSrcId, wPayloadType, fInitialDelayMs);

	Audio_tJb *pJb = &gAudio.Jb;

	if ((wSrcId > 0) &&
		(wSrcId <= AUDIO_IF_PARTY_MAX))
	{
		if (pJb->apParty[wSrcId] == NULL)
		{
			pJb->apParty[wSrcId] = _party_create(wPayloadType, wSrcId, fInitialDelayMs);
			
			if (pJb->apParty[wSrcId] == NULL) // this type is not supported
			{
				audio_log_err("AudioIf_src_add -- type %d not supported", 
							wPayloadType);
				rc |= AUDIO_IF_ERR_INVALID_PARAM;
			}
			else
			{
				pJb->apParty[wSrcId]->bMixToSpk = bMixToSpk;
				audio_log_inf("AudioIf_src_add -- line=%d", wSrcId);
			}
		}
		else
		{
			audio_log_err("AudioIf_src_add -- line %d already exists",
				wSrcId);
			rc |= AUDIO_IF_ERR_ALREADY_EXISTS;
		}
	}
	else
	{
		rc |= AUDIO_IF_ERR_RANGE;
	}

	if (rc)
		audio_log_err("AudioIf_src_add -- rc=0x%08x", rc);
	else
		audio_log_inf("AudioIf_src_add -- done");
	audio_unlock();

	return rc;
}
/*****************************************************************************/
DWORD						AudioIf_src_mix
/*****************************************************************************/
(
WORD	wSrcId, 
bool	bMixToSpk
)
{
	if (!gAudio.bInitialized) return AUDIO_IF_ERR_NOT_INITIALIZED;

	DWORD rc = AUDIO_IF_ERR_NONE;
	audio_lock();
	audio_log_inf("AudioIf_src_mix -- SRC=%d bMix=%d", 
				wSrcId, bMixToSpk);

	Audio_tJb *pJb = &gAudio.Jb;

	if ((wSrcId > 0) &&
		(wSrcId <= AUDIO_IF_PARTY_MAX))
	{
		if (pJb->apParty[wSrcId])
		{
			pJb->apParty[wSrcId]->bMixToSpk = bMixToSpk;
		}
		else
		{
			audio_log_err("AudioIf_src_mix -- wSRC %d does not exist",
				wSrcId);
			rc |= AUDIO_IF_ERR_NOT_INITIALIZED;
		}
	}
	else
	{
		rc |= AUDIO_IF_ERR_BAD_IDX;
	}

	if (rc)
		audio_log_err("AudioIf_src_mix -- rc=0x%08x", rc);
	else
		audio_log_inf("AudioIf_src_mix -- done");
	audio_unlock();

	return rc;
}
/*****************************************************************************/
DWORD						AudioIf_src_remove
/*****************************************************************************/
(
WORD	wSrcId
)
{
	if (!gAudio.bInitialized) return AUDIO_IF_ERR_NOT_INITIALIZED;

	DWORD rc = AUDIO_IF_ERR_NONE;
	audio_lock();
	audio_log_inf("AudioIf_src_remove -- SRC %d", 
				wSrcId);

	Audio_tJb *pJb = &gAudio.Jb;

	if ((wSrcId > 0) &&
		(wSrcId <= AUDIO_IF_PARTY_MAX))
	{
		if (pJb->apParty[wSrcId])
		{
			pJb->apParty[wSrcId] = _party_delete(pJb->apParty[wSrcId]);
			rc |= AudioIf_dst_mix_remove(wSrcId);
		}
		else
		{
			rc |= AUDIO_IF_ERR_ALREADY_REMOVED;
			audio_log_err("AudioIf_src_remove -- wSRC %d already removed",
				wSrcId);
		}
	}
	else
	{
		rc |= AUDIO_IF_ERR_BAD_IDX;
	}

	if (rc)
		audio_log_err("AudioIf_src_remove -- rc=0x%08x", rc);
	else
		audio_log_inf("AudioIf_src_remove -- done");
	audio_unlock();
	return rc;
}
/*****************************************************************************/
DWORD						AudioIf_src_remove_all
/*****************************************************************************/
(
)
{
	if (!gAudio.bInitialized) return AUDIO_IF_ERR_NOT_INITIALIZED;

	DWORD rc = AUDIO_IF_ERR_NONE;
	audio_lock();
	audio_log_inf("AudioIf_src_remove_all -- ");

	Audio_tJb *pJb = &gAudio.Jb;

	for (int wSrcId = 1; wSrcId <= AUDIO_IF_PARTY_MAX; wSrcId++)
	{
		if (pJb->apParty[wSrcId])
		{
			audio_log_inf("AudioIf_src_remove_all -- wSrcId=%d",
				wSrcId);

			rc |= AudioIf_dst_mix_remove(wSrcId);
			pJb->apParty[wSrcId] = _party_delete(pJb->apParty[wSrcId]);
		}
	}

	if (rc)
		audio_log_err("AudioIf_src_remove_all -- rc=0x%08x", rc);
	else
		audio_log_inf("AudioIf_src_remove_all -- done");
	audio_unlock();
	return rc;
}
/*****************************************************************************/
DWORD						AudioIf_net_rcv
/*****************************************************************************/
(
WORD	wSrcId, // shall be one of used in AudioIf_src_add()
WORD	wPayloadType, // extract it from RTP header
WORD	wSequenceNumber,	// sequence number
DWORD	dwTimeStamp,	// timestamp
BYTE *pcRtpData, // ptr to the start of RTP data
WORD	wRtpDataSz
)
{
	if (!gAudio.bInitialized) return AUDIO_IF_ERR_NOT_INITIALIZED;

	DWORD rc = AUDIO_IF_ERR_NONE;
	audio_lock();

	Audio_tJbNetQ *pNetQ = &gAudio.Jb.NetQ;

	if (pcRtpData == NULL)
	{
		audio_log_err("AudioIf_net_rcv -- invalid pcRtpData");
		rc |= AUDIO_IF_ERR_INVALID_PARAM;
	}

	if (wRtpDataSz == 0)
	{
		audio_log_err("AudioIf_net_rcv -- invalid wRtpDataSz");
		rc |= AUDIO_IF_ERR_INVALID_PARAM;
	}


	if (rc == AUDIO_IF_ERR_NONE)
	{
		Audio_tRtpHdr Hdr = {0};
		Hdr.wPT = wPayloadType;
		Hdr.wSN = wSequenceNumber;
		Hdr.dwTS = dwTimeStamp;
		Hdr.wIdx = wSrcId;
		float fNow;

		audio_tmr_peek(0, &fNow);

		audio_rec_pkt(
			AUDIO_IF_REC_NET_RCV, 
			0,
			&Hdr,
			pcRtpData,
			wRtpDataSz,
			fNow);

		if ((wSrcId > 0) &&
			(wSrcId <= AUDIO_IF_PARTY_MAX) &&
			(gAudio.Jb.apParty[wSrcId]))
		{
			if (pNetQ->lSz < AUDIO_JB_NETQ_SZ)
			{
				BYTE *pc = (BYTE *)AudioIf_alloc(wRtpDataSz);
				if (pc)
				{
//					audio_log_inf("AudioIf_net_rcv -- alloc of %p, pc");
#ifndef _WIN32_WCE
					LONG idx = InterlockedIncrement(&pNetQ->lWriteIdx);
#else
					LONG idx = InterlockedIncrement((LPLONG)&pNetQ->lWriteIdx);
#endif
					idx--;
					idx &= (AUDIO_JB_NETQ_SZ-1);
					Audio_tJbNetQItem *pItem = &pNetQ->aItem[idx];

					memset(pItem, 0, sizeof(*pItem));
					memcpy(pc, pcRtpData, wRtpDataSz);

					pItem->pcData = pc;//RtpData;
					pItem->Hdr = Hdr;
					pItem->wDataSz = wRtpDataSz;
					audio_tmr_peek(0, &pItem->fArrived);
#ifndef _WIN32_WCE
					InterlockedIncrement(&pNetQ->lSz);
#else
					InterlockedIncrement((LPLONG)&pNetQ->lSz);
#endif
				}
				else
				{
					audio_log_err("AudioIf_net_rcv -- alloc failed");
					rc |= AUDIO_IF_ERR_OUT_OF_MEMORY;
					pNetQ->iAllocFalied++;
				}
			}
			else
			{
				audio_log_err("AudioIf_net_rcv -- overflow");
	//			AudioIf_pkt_free(pvHandle);pvHandle= NULL;
				rc |= AUDIO_IF_ERR_OVERFLOW;
				pNetQ->iOverflows++;
			}
		}
		else
		{
			audio_log_trc("AudioIf_net_rcv -- bad SRC %d", Hdr.wIdx);
	//		AudioIf_pkt_free(pvHandle);pvHandle= NULL;
			rc |= AUDIO_IF_ERR_BAD_IDX;
			pNetQ->iBadSrcId++;
		}
	}
	audio_unlock();
	return rc;
}
/*****************************************************************************/
DWORD				AudioIf_src_volume
/*****************************************************************************/
(
WORD	wSrcId, 
float*	pfGainDB
)
{
	if (!gAudio.bInitialized) return AUDIO_IF_ERR_NOT_INITIALIZED;

	DWORD rc = AUDIO_IF_ERR_NONE;
	audio_lock();

	audio_log_inf("AudioIf_src_volume get -- wSrcId=%d p=%p", 
				wSrcId, pfGainDB);

	if (pfGainDB != NULL)
	{
		Audio_tJb *pJb = &gAudio.Jb;
		if ((wSrcId > 0) &&
			(wSrcId <= AUDIO_IF_PARTY_MAX) &&
			(pJb->apParty[wSrcId]))
		{
			Audio_tJbParty *pParty = pJb->apParty[wSrcId];
			*pfGainDB = pParty->fGainDb;
		}
		else
		{
			rc |= AUDIO_IF_ERR_NOT_INITIALIZED;
		}
	}
	else
	{
		rc |= AUDIO_IF_ERR_INVALID_PARAM;
	}

	if (rc)
		audio_log_err("AudioIf_src_volume get -- rc=0x%08x", rc);
	else
		audio_log_inf("AudioIf_src_volume get -- done");

	audio_unlock();
	return rc;
}
/*****************************************************************************/
DWORD				AudioIf_src_volume
/*****************************************************************************/
(
WORD wSrcId, 
float fGainDB
)
{
	if (!gAudio.bInitialized) return AUDIO_IF_ERR_NOT_INITIALIZED;

	DWORD rc = AUDIO_IF_ERR_NONE;
	audio_lock();

	audio_log_inf("AudioIf_src_volume -- wSrcId=%d gain=%f", 
				wSrcId, fGainDB);

	Audio_tJb *pJb = &gAudio.Jb;

	if ((wSrcId > 0) &&
		(wSrcId <= AUDIO_IF_PARTY_MAX) &&
		(pJb->apParty[wSrcId]))
	{
		Audio_tJbParty *pParty = pJb->apParty[wSrcId];
		if (fGainDB > 0)
		{
			audio_log_war("AudioIf_src_volume -- gain set to 0");
//			rc |= AUDIO_IF_ERR_WARNING;
			fGainDB = 0;
		}
		pParty->fGainDb = fGainDB;
	}
	else
	{
		rc |= AUDIO_IF_ERR_NOT_INITIALIZED;
	}

	if (rc)
		audio_log_err("AudioIf_src_volume -- rc=0x%08x", rc);
	else
		audio_log_inf("AudioIf_src_volume -- done");

	audio_unlock();
	return rc;
}
#if 0
/*****************************************************************************/
DWORD				AudioIf_src_most_active
/*****************************************************************************/
(
DWORD *pdwSrcId,
WORD   wSz
)
{
	DWORD rc = AUDIO_IF_ERR_NONE;
	audio_lock();

	audio_log_trc("AudioIf_src_most_active -- pdwSrcId=%p", 
				pdwSrcId);

	if (pdwSrcId)
	{
		DWORD adw[AUDIO_IF_PARTY_MAX];
		float af[AUDIO_IF_PARTY_MAX];

		int k;
		int srcs = 0;

		for (k = 0; k < AUDIO_IF_PARTY_MAX; k++)
		{
			if (gAudio.Jb.apParty[k])
			{
				adw[srcs] = gAudio.Jb.adwSrcId[k];
				af[srcs] = gAudio.Jb.apParty[k]->fNrg;
				srcs++;
			}
		}
		
		for (k = 0; k < wSz; k++)
		{
			float fMax = 0;
			int iMax = -1;
			for (int m = 0; m < srcs; m++)
			{
				if (fMax < af[m])
				{
					fMax = af[m];
					iMax = m;
				}
			}

			if (iMax >= 0)
			{
				audio_log_trc("-- dwSrcId 0x%x, nrg %7.2f", 
					adw[iMax], af[iMax]);

				*pdwSrcId++ = adw[iMax];
				af[iMax] = -2;
			}
			else
			{
				*pdwSrcId++ = (DWORD)(-1);
			}
		}
	}
	else
	{
		rc |= AUDIO_IF_ERR_INVALID_PARAM;
	}

	if (rc)
		audio_log_err("AudioIf_src_most_active -- rc=0x%08x", rc);
	else
		audio_log_trc("AudioIf_src_most_active -- done");

	audio_unlock();
	return rc;
}
#endif
/*****************************************************************************/
DWORD				AudioIf_src_level
/*****************************************************************************/
(
WORD	wSrcId,
float*	pfNrgDBFS		//  smoothed energy in dB Full Scale
)
{
	if (!gAudio.bInitialized) return AUDIO_IF_ERR_NOT_INITIALIZED;

	DWORD rc = AUDIO_IF_ERR_NONE;
	audio_lock();

	audio_log_trc("AudioIf_src_level -- wSrcId=%d pfNrgDBFS=%p", 
					wSrcId, pfNrgDBFS);

	if (pfNrgDBFS)
	{
		Audio_tJb *pJb = &gAudio.Jb;
		if ((wSrcId > 0) &&
			(wSrcId <= AUDIO_IF_PARTY_MAX) &&
			(pJb->apParty[wSrcId]))
		{
			Audio_tJbParty *pParty = pJb->apParty[wSrcId];
			*pfNrgDBFS = pParty->fNrg - 86.F;
		}
		else
		{
			rc |= AUDIO_IF_ERR_NOT_INITIALIZED;
		}
	}
	else
	{
		rc |= AUDIO_IF_ERR_INVALID_PARAM;
	}

	if (rc)
		audio_log_err("AudioIf_src_level -- rc=0x%08x", rc);
	else
		audio_log_trc("AudioIf_src_level -- done");

	audio_unlock();
	return rc;
}

/*****************************************************************************/
DWORD				AudioIf_src_stts_get
/*****************************************************************************/
(
WORD	wSrcId,
AudioIf_tSrcStts *pStts
)
{
	if (!gAudio.bInitialized) return AUDIO_IF_ERR_NOT_INITIALIZED;

	DWORD rc = AUDIO_IF_ERR_NONE;
	audio_lock();

	audio_log_trc("AudioIf_src_stts_get -- wSrcId=%d pStts=%p", 
				wSrcId, pStts);

	if (pStts)
	{
		Audio_tJb *pJb = &gAudio.Jb;
		if ((wSrcId > 0) &&
			(wSrcId <= AUDIO_IF_PARTY_MAX) &&
			(pJb->apParty[wSrcId]))
		{
			Audio_tJbParty *pParty = pJb->apParty[wSrcId];
			audio_hstgm_analyse(&pParty->Stts.JitterHistogram);

			float fNow;
			audio_tmr_peek(0, &fNow);
			pParty->Stts.fBitRateKbps = pParty->iBytes * 8.F / 
				(fabs(fNow - pParty->fStartedAt) + 1.e-12F);
			*pStts = pParty->Stts;
		}
		else
		{
			rc |= AUDIO_IF_ERR_NOT_INITIALIZED;
		}
	}
	else
	{
		rc |= AUDIO_IF_ERR_INVALID_PARAM;
	}

	if (rc)
		audio_log_err("AudioIf_src_stts_get -- rc=0x%08x", rc);
	else
		audio_log_trc("AudioIf_src_stts_get -- done");

	audio_unlock();
	return rc;
}


