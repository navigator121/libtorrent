#ifndef _AUDIO_G729_H_
#define _AUDIO_G729_H_

#include "g729.h"

/*****************************************************************************/
void *audio_G729_decoder_init
	(
	void
	);
void *audio_G729_encoder_init
	(
	void
	);
int audio_G729_decode
	(
	void *pDec,
	short *psOut,
	BYTE *pcIn // can be NULL -> PLC 
	);
int	audio_G729_encode
	(
	void *pEnc,
	BYTE *pcOut,
	short *psIn
	);

#endif // _AUDIO_G729_H_