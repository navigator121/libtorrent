#ifndef AUDIO_G711U_H
#define AUDIO_G711U_H

// Disabled warnings
//#pragma warning(disable:4710) // function not inlined

//#include "AudioCodecInterface.h"

void audio_G711U_decoder_init(void);
int  audio_G711U_decode(short *psOut, BYTE *pcIn);

void audio_G711U_encoder_init();
int  audio_G711U_encode(BYTE *pcOut, short *psIn);

#endif // AUDIO_G711U_H
