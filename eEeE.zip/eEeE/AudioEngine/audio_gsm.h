#ifndef _AUDIO_GSM_H_
#define _AUDIO_GSM_H_

#include "gsm.h"

/*****************************************************************************/

void *audio_GSM_init
	(
	void
	);
void* audio_GSM_delete
	(
	void *pState
	);
int audio_GSM_decode
	(
	void *pDec,
	short *psOut,
	BYTE *pcIn // can be NULL -> PLC ??? external
	);
int	audio_GSM_encode
	(
	void *pEnc,
	BYTE *pcOut,
	short *psIn
	);

#endif // _AUDIO_GSM_H_