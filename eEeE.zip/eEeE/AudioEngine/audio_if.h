#ifndef AUDIO_IF_H
#define AUDIO_IF_H

///////////////////////////////////////////////////////////////////////////////
//
//					PAYLOAD TYPES 
//
// ....standard
#define AUDIO_IF_PT_G711U					(0)
#define AUDIO_IF_PT_G711A					(8)
#define AUDIO_IF_PT_G729A					(18)
#define AUDIO_IF_PT_GSM						(3)

// ... dynamic to be mapped here
#define AUDIO_IF_PT_SPEEX_NB				(100)
#define AUDIO_IF_PT_ILBC					(99)
#define AUDIO_IF_PT_SIREN14					(110) // default rate of 24kbps
#define AUDIO_IF_PT_SIREN1432				(111) // 32kbps
#define AUDIO_IF_PT_SIREN1448				(112) // 48 kbps
#define AUDIO_IF_PT_SIREN1416				(113) // 16kbps
#define AUDIO_IF_PT_SPEEX_WB				(102) 
#define AUDIO_IF_PT_SPEEX_UWB				(103)

// ... to be implemented
#define AUDIO_IF_PT_G722					(9)
#define	AUDIO_IF_PT_SPEEX_VBR_NB			(105)
#define AUDIO_IF_PT_SPEEX_VBR_WB			(106)
#define AUDIO_IF_PT_SPEEX_VBR_UWB			(107)

#define AUDIO_IF_PT_NONE					((WORD)-1)

///////////////////////////////////////////////////////////////////////////////
//
//					ERROR CODES
//
// returned by all AudioIf_ functions.
// or-ed if multiple problems happen.
// fit into unsigned long=DWORD.
//
enum 
{
	AUDIO_IF_ERR_NONE				= 0x00000000,
	AUDIO_IF_ERR_NOT_INITIALIZED	= 0x00000002,
	AUDIO_IF_ERR_ALREADY_EXISTS		= 0x00000004,
	AUDIO_IF_ERR_ALREADY_REMOVED	= 0x00000008,
	AUDIO_IF_ERR_INVALID_PARAM		= 0x00000010, // if NULL not expected, etc
	AUDIO_IF_ERR_RANGE				= 0x00000020,
	AUDIO_IF_ERR_DRIVER_FAIL		= 0x00000040,
	AUDIO_IF_ERR_OUT_OF_MEMORY		= 0x00000080,
	AUDIO_IF_ERR_BAD_IDX			= 0x00000100,
	AUDIO_IF_ERR_OVERFLOW			= 0x00000200,
	AUDIO_IF_ERR_STATE				= 0x00000400,
	AUDIO_IF_ERR_TMR_HW_FAILURE		= 0x00000800,
	AUDIO_IF_ERR_DRV_SPK			= 0x00001000,
	AUDIO_IF_ERR_DRV_MIC			= 0x00002000,
	AUDIO_IF_ERR_TIMING				= 0x00004000,
	AUDIO_IF_ERR_MEM_CORRUPTED		= 0x00008000,
	AUDIO_IF_ERR_FILE_IO			= 0x00008000,
	AUDI0_IF_ERR_RESYNC				= 0x00010000,
	AUDI0_IF_ERR_HW_NOT_SUPPORTED	= 0x00020000,

	// the list is supposed to grow

	//additional error code, for AudioIf_drv_open()
	AUDI0_IF_ERR_DRV_OPEN_WAIT_ABANDONED	= 0x00040000,
	AUDI0_IF_ERR_DRV_OPEN_WAIT_TIMEOUT		= 0x00080000,
	AUDI0_IF_ERR_DRV_OPEN_WAIT_FAILED		= 0x00100000,
	
	AUDIO_IF_ERR_WARNING			= 0x40000000, // it's only a warning
	// general unspecified failure
	AUDIO_IF_ERR_FAILED				= 0x80000000
};

///////////////////////////////////////////////////////////////////////////////
//
//					AUDIO ENGINE INTIALIZATION AND DESTROYING 
//
//	you need to call AudioIf_init() only once, in the application start.
//	this function creates a dbg thread. CPU is very low.
//
//	you need to call AudioIf_destroy() at the very end of your application.
//	all logs will be closed, and dbg thread completed.
//
// ------------------------ defines -------------------------------------------
//
enum {
	AUDIO_IF_LOG_LEVEL_NONE, // 0
	AUDIO_IF_LOG_LEVEL_ERROR, // 1 recoverable
	AUDIO_IF_LOG_LEVEL_WARNING, // 2
	AUDIO_IF_LOG_LEVEL_INFO, // 3
	AUDIO_IF_LOG_LEVEL_TRACE,  // 4
	AUDIO_IF_LOG_LEVEL_ALWAYS // 5
};
//
// NET_RCV produces full dump of everything that comes from the network, 
// in one file
#define AUDIO_IF_REC_NET_RCV				(0x0001)	// .txt file
// JB_IN produces a set of files (one per src) with dump of pkts coming 
// from the network
// along with timing information (when it was received)
#define AUDIO_IF_REC_JB_IN					(0x0002)	// .txt
// JB_OUT produces a set of files (one per src) how that src sounds to spk
// per-stream volume will not be applied.
#define AUDIO_IF_REC_JB_OUT					(0x0004)	// .wav file
// JB_MIX - what is going forward to the spk, with per-stream volumes applied
#define AUDIO_IF_REC_JB_MIX					(0x0008)	// .wav file
// TST_GEN - if rcv was modified by test gen
#define AUDIO_IF_REC_TST_GEN				(0x0010)	// .wav
// VOL results of volume applied
#define AUDIO_IF_REC_VOL					(0x0020)	// .wav
// SPK - what is going to the spk, after AEC
#define AUDIO_IF_REC_SPK					(0x0040)	// .wav on 48 kHz
// MIC - raw pcm mic  signal captured
#define AUDIO_IF_REC_MIC					(0x0080)	// .wav on 48 kHz
// MIC_FLT - filtered mic signal
#define AUDIO_IF_REC_MIC_FLT				(0x0100)	// .wav on 8 kHz
// CNL - echo cancellation was applied
#define AUDIO_IF_REC_CNL					(0x0200)	// .wav on 8 kHz
// NLP - further echo reduction by non-linear procesing
#define AUDIO_IF_REC_NLP					(0x0400)	// .wav on 8 kHz
// NRD - noise reduction
#define AUDIO_IF_REC_NRD					(0x0800)	// .wav on 8 kHz
// AGC - automatic gain control applied
#define AUDIO_IF_REC_AGC					(0x1000)	// .wav
// ENC - produces a set of files (one per dst) with signal 
// that is going to that particular outbound stream
#define AUDIO_IF_REC_ENC					(0x2000)	// .wav
// NET_SND - a set of files with signal encoded.
#define AUDIO_IF_REC_NET_SND				(0x4000)	// .txt
//
// 
typedef void (*AudioIf_tNetSndCallback)
 (
 void *arg,
 WORD	wDstId,    // one of opened dst's.
 DWORD dwTimestamp,   // it will be incremented as required by wPayloadType
 BYTE *pcRtpData, // ptr to a static memory. you need to copy data out.
 WORD wRtpDataSz
 );
//
// ------------------------ functions -----------------------------------------
//
DWORD AudioIf_init
	(
	char *pszLogFileName = NULL,// name of log file. if it includes directories, 
								// they must exist. 
								// NULL if none, 
	int	iLogLevel = AUDIO_IF_LOG_LEVEL_NONE,
								// from AUDIO_IF_LOG_LEVEL_NONE 
								// to AUDIO_IF_LOG_LEVEL_ALL
	char *pszRecFilesDirectory = NULL, 
								// directory to save all recording files 
								// (set by wRecMask) into. 
								// NULL if none
								// file names will be audiorec_nameXX.wav or .txt
								// XX = channel no
								// name is the same as in 
								// "#define AUDIO_IF_REC_name..."
	WORD wRecMask = 0,				// valid if pszRecFilesDirectory != NULL, 
								// | of AUDIO_IF_REC_... - defined above.
								//	0xffff means - record all channels
								//	0x0000 means - no recordings
								//  
	WORD wUiMode = 0				// if not 0, Audio Monitoring Window will be open. 
								// plotting takes quite a bit of cpu.
	);
// to initialize a call back fior network send
// to remove the callback, set pCallback to NULL
DWORD AudioIf_set_net_send_callback 
	(
	void *arg,
	AudioIf_tNetSndCallback pCallback
	);
DWORD AudioIf_destroy
	(
	);
///////////////////////////////////////////////////////////////////////////////
//
//					STARTING / ENDING AUDIO
//
// prior to starting a meeting or 2-party call....
//
// ... allocate audio capture/render devices and start functionality
// of analog front end signal processing as AEC/etc.
//
// you can set one or both pszMicDeviceName and pszSpkDeviceName to NULL.
// AE will try to determine most suitable devices it self. if it can't, it fails.
// AE will fallback to lowest mode that works. 
// i.e if WDM KS does not work, it will try DirectX.
// if DirectX does not work - then AE returns failure.
// _open()  starts a tread for working with both capturing and rendering, 
// and running all AE activities. 
// 
// AEC, AGC, Denoiser will start working immediately.
// 
// It is recommended to run it on highest priority in the system.
// 
// you need to call _drv_open() before adding any incoming or outgoing streams,
// or enabling test gen.
//
// opening devices and thread creation may take up to 500 ms 
// (CPU speed and OS depending).
// 
// MAKE SURE that you instruct the user to:
//	- select proper microphone in the Windows' 
//		"VolumeControl->Options->Properties->Recording"
//	- disable all "advanced features" in the sound card as 
//		-- AGC
//		-- echo cancellation
//		-- noise reduction
//		-- 3D effects and similar EAX / ESP / whatever features.
//	- never change volume by rotating the volume knob on speakers during a call. 
//			a Slider (linked to AudioIf_volume()) must be present 
//			in your app, and it shall be used instead.
//	- similary, avoid touching system/master volume 
//		in Windows' "Volume Control" panel during a call.
//	- never use hardware mic mute. a button linked to 
//		AudioIf_mic_mute() shall be used instead.
//	- complete audio wizard ahead of making any calls 
//		and make sure that user can hear 'reference' sounds normally, 
//		as well as his/her recorded voice from mic.
//		some onboard sound have awfull leakage from power to mic input, 
//		and there is nothing that can be done in s/w what would fix it.
//		in some cases, self-powered mics (like AudioTechnika ATR-97) 
//		can help with the issue -
//		but those are more expensive and require manual switching on/off 
//		(their batteries last for 20..80 hours).
//	- avoid using different devices for microphone and speaker, 
//		especially webcams's mics. 
//		the quality will be very poor whatever we can do,
//	- advice user to update audio drivers. some older drivers, 
//		especially SoundMAX, 
//		do not support mic or support it very badly (while speakers are ok). 
//		the version of drivers for SoundMAX must be above 5.12.01.3520
//		http://forms.analog.com/Form_Pages/soundMax/soundMaxSupportFAQ.html
//
//
// ------------------------ defines -------------------------------------------
//
// must be indentical or more than windows[30]/etc def
#define AUDIO_IF_DEVICE_NAME_SZ				(80)
//
// fall-back to lower mode is high-mode fails
#define AUDIO_IF_DRV_MODE_WAVE				(0)
#define AUDIO_IF_DRV_MODE_DIRECTX			(1)
#define AUDIO_IF_DRV_MODE_WDM				(2)
#define AUDIO_IF_DRV_MODE_ASIO				(3)
//
#define AUDIO_IF_HSTGM_MAX_SZ				(200)
//
typedef struct {
	int				aiData					[AUDIO_IF_HSTGM_MAX_SZ+2];
	int				iRange;					// <= AUDIO_IF_HSTGM_MAX_SZ
	int				iTotal;
	double			dSum;
	float			fMin;
	float			fAvrg;
	float			fMax;
	float			f50;		// 50 % quantile
	float			f90;		// 90 % quantile
	float			f99;		// 99 % quantile
} AudioIf_tHstgm;

typedef struct {
	float			fClkAvrUs; // relative to performance counters clk
	float			fClkDevUs;
	float			fDelayAverage;
	AudioIf_tHstgm	JitterHistogram;
	int				iFailures;
} AudioIf_tDrvSideStts;

typedef struct {
	int				iFramesTotal;
	float			fSpkMicDelayAverageUs;
	AudioIf_tDrvSideStts SpkStts;
	AudioIf_tDrvSideStts MicStts;

} AudioIf_tDrvStts;
//
// ------------------------ functions -----------------------------------------
//
DWORD AudioIf_drv_open
	(
	char *pszMicDeviceName, 
	char *pszSpkDeviceName = NULL, 
	int iDrvMode				// the same driver mode will 
								// be used by both mic and spk
		= AUDIO_IF_DRV_MODE_WDM,	
	int iThreadPriority = 15	// 8...15
	); 
// call this function when you finish a call.
// if you switch between calls, just replace 
// all incoming and outgoing streams instead (see below).
DWORD AudioIf_drv_close
	(
	char *pszTimingFileName		// you can give a filename where to save timing stts
		= NULL
	); 
// if you need to retrieve the name of device being opened. use it
DWORD AudioIf_drv_spk_device_name_get
	(
	char *pszDeviceName
	);
DWORD AudioIf_drv_mic_device_name_get
	(
	char *pszDeviceName
	); 
// it returns the drv mode that is being used. 
// if you asked ASIO in open, but only DirectX suceeded,
// then AUDIO_IF_DRV_MODE_DIRECTX will be set to *piDrvMode.
DWORD AudioIf_drv_mode_get
	(
	int *piDrvMode
	);
// get statistics. call it before AudioIf_drv_close().
DWORD AudioIf_drv_stts_get
	(
	AudioIf_tDrvStts *pStts
	);
///////////////////////////////////////////////////////////////////////////////
//
//					CONFERENCE
//
//	conference is meeting/mixing place for parties.
//	you can create upto AUDIO_IF_CONF_MAX conferences.
//
//	theoretically, a conference can have up to AUDIO_IF_PARTY_MAX paties in it, 
//	but real size of a meeting is better to be limited to 15...20. 
//  decoding more than 20 H.264 video .... not on today's typical machines.
//	more people that are all active = lots of mess and background noise. 
//	large meetings must be managed.
//
// ------------------------ defines -------------------------------------------
//
#define AUDIO_IF_CONF_MAX					(64)	
//
// ------------------------ functions -----------------------------------------
//
DWORD AudioIf_conf_create
	(
	WORD*	pwConfId,	// conf id will be returned here. use it for further calling.
	bool	bAddHost = true // host will be moved here from any other conference
	);
DWORD AudioIf_conf_delete
	(
	WORD	wConfId,	
	bool	bDeleteAllParties = true
	);
// you should create a party before connecting it - except for host.
// host is created by AudioIf_drv_open()
DWORD AudioIf_conf_connect_party
	(
	WORD	wConfId,	
	WORD	wPartyId
	);
// NOTE: disconnecting of host from a conference is equivalent to putting it on hold
DWORD AudioIf_conf_disconnect_party
	(
	WORD	wConfId,	
	WORD	wPartyId
	);
// wConfIdMerging will be deleted after merging all its parties to wConfIdMergedTo
DWORD AudioIf_conf_merge
	(
	WORD	wConfIdMergedTo,	
	WORD	wConfIdMerging 
	);
DWORD AudioIf_conf_num_parties
	(
	WORD	wConfId,	
	WORD*	pwNumPartyIds
	);
DWORD AudioIf_conf_list_parties
	(
	WORD	wConfId,	
	WORD*	pwListPartyIds // point to caller-allocated array of wNumParties len
	);
DWORD AudioIf_conf_most_active
	(
	WORD	wConfId,	
	WORD	wNumPartiesToReport,
	WORD*	pwListPartyIds // point to caller-allocated array of wNumParties len
	);
DWORD AudioIf_conf_num
	(
	WORD*	pwNumConferences	
	);
DWORD AudioIf_conf_list
	(
	WORD*	pwListConferences	
	);

///////////////////////////////////////////////////////////////////////////////
//
//					PARTIES
//
//
// use AudioIf_src_ and AudioIf_dst_ for munite control of parties
//
// to create a listener, put wDstPayloadType=AUDIO_IF_PT_NONE
// to create a broadcasting channel, put wSrcPayloadType=AUDIO_IF_PT_NONE
// you can set both wSrcPayloadType and wDstPayloadType 
// to AUDIO_IF_PT_NONE during _create(), and update them later.
//
// ------------------------ defines -------------------------------------------
//
#define AUDIO_IF_PARTY_MAX					(64)	
#define AUDIO_IF_PARTY_HOST					(0)	
//
// ------------------------ functions -----------------------------------------
//
DWORD AudioIf_party_create
	(
	WORD*	pwPartyId,	// PartyId id will be returned here. use it for further calling.
	WORD	wSrcPayloadType,
	WORD	wDstPayloadType,
	WORD	wDstFrsPerPkt = 1,		// max = 4
	DWORD	dwDstTimestamp = 0,		// to start with
	float	fInitialDelayMs = 25.0F
	);
DWORD AudioIf_party_delete
	(
	WORD	wPartyId
	);
DWORD AudioIf_num_parties
	(
	WORD*	pwNumParties
	);
DWORD AudioIf_list_parties
	(
	WORD*	pwPartyIds,
	WORD*	pwConfIds	// those parties belong to
	);

///////////////////////////////////////////////////////////////////////////////
//
//					INCOMING STREAMS
//
// you can add up to AUDIO_IF_PARTY_MAX sources.
// they all will be mixed to spk.
// wSrcId shall be the same as used in AudioIf_net_rcv().
//
//
// ------------------------ defines -------------------------------------------
//
typedef struct {
	int				iPktsTotal;
	int				iPktsLost;
	int				iPktsLate;
	int				iPktsDropped;
	int				iPktsOutOfSequence;
	int				iPktsDuplicated;
	int				iPktsDefective;
	int				iJbOverflows;
	float			fDelayAverage;
	float			fDelayCurrent;
	float			fBitRateKbps;
	AudioIf_tHstgm	JitterHistogram;
} AudioIf_tSrcStts;
//
// ------------------------ functions -----------------------------------------
//
DWORD AudioIf_src_add
	(
	WORD	wSrcId,				// 1..AUDIO_IF_PARTY_MAX
	WORD	wPayloadType,		// one of AUDIO_IF_PT_
	float	fInitialDelayMs = 25.0F,
	bool	bMixToSpk = true
	);
DWORD AudioIf_src_remove // also remove it from mixer map (for dst)
	(
	WORD	wSrcId
	);
DWORD AudioIf_src_remove_all
	(
	void
	);
// to serve putting conference on hold, you may disable mixing 
// certain Srcs towards the speaker (to be re-enabled later)
// that does NOT influence how they are mixed into dst
DWORD AudioIf_src_mix
	(
	WORD	wSrcId, 
	bool	bMIxToSpk = true
	);
// you can set volume for each incoming stream.
// =0 -> no alterations 
// <0 -> attenuation
// there are repercussions for positive gain from AEC perspective, and, 
// typically, only attenuation is used in practice, so 
// any positive gain will capped down to 0.
DWORD AudioIf_src_volume
	(
	WORD	wSrcId, 
	float	fGainDB = 0.F
	);
DWORD AudioIf_src_volume
	(
	WORD	wSrcId, 
	float*	pfGainDB
	);
// sorts all active dwSrcId according to their activity
// pdwSrcId must point to an array of wSz size 
// if wSz < active srcs, the reminder is filled with (-1)
#if 0
DWORD AudioIf_src_most_active
	(
	WORD *pwSrcId,
	WORD wSz = 1				// report only wSz most active
	);
#endif
DWORD AudioIf_src_level
	(
	WORD	wSrcId,
	float*	pfNrgDBFS		//  smoothed energy in dB Full Scale
	);

DWORD AudioIf_src_stts_get
	(
	WORD	wSrcId,
	AudioIf_tSrcStts *pStts
	);
//
// this function shall be invoked when an RPT pkt arrives from net.
// you extract most of params from the RTP header. 
//
// pcRtpData shall point to the start of a RtpPayload, i.e. after the header. 
// AE copies the data in.
//
DWORD AudioIf_net_rcv
	(
	WORD	wSrcId,				// shall be one of used in AudioIf_src_add()
	WORD	wPayloadType,		// extract it from RTP header
	WORD	wSequenceNumber,	// sequence number
	DWORD	dwTimeStamp,		// timestamp
	BYTE*	pcRtpData,	// ptr to the start of RTP data
	WORD	wRtpDataSz
	);
///////////////////////////////////////////////////////////////////////////////
//
//					OUTGOING STREAMS
//
//  if you want to create and outbound stream, call AudioIf_dst_add();
//  you can create up to AUDIO_IF_PARTY_MAX outbound streams.
//
//  you need to make sure that at any moment of time all dwDstId are unique.
//  1 =< dwDstId <= AUDIO_IF_PARTY_MAX;
//  (provide unique dwDstId for each invocation of 
//	AudioIf_dst_add() not followed by AudioIf_dst_remove());
//  
//   by default (for client) you mix micropone signal.
// 
//
// ------------------------ defines -------------------------------------------
//
typedef struct {
	int				iPktsTotal;
	int				iBytesTotal;
	float			fInactivityPercent;
} AudioIf_tDstStts; 
//
// ------------------------ functions -----------------------------------------
//
DWORD AudioIf_dst_add
	(
	WORD	wDstId,				// 1...AUDIO_IF_PARTY_MAX
	WORD	wPayloadType, 
	DWORD	dwTimestamp = 0,		// to start with
	WORD	wFrsPerPkt = 1,		// max = 4
	bool	bMixMic = true
	);
DWORD AudioIf_dst_remove
	(
	WORD	wDstId
	);
DWORD AudioIf_dst_remove_all
	(
	void
	);
DWORD AudioIf_dst_stts_get
	(
	WORD	wDstId,
	AudioIf_tDstStts *pStts
	);

///////////////////////////////////////////////////////////////////////////////
//
//					MIXING INCOMING STREAMS INTO OUTGOING STREAMS
//
// the following functions govern over how incoming streams are mixed into outgoing streams
// if you are using a usual 2 party call, you do not need to bother.
//
// this is a generic function. full control can be executed.
//
// ------------------------ defines -------------------------------------------
// ------------------------ functions -----------------------------------------
// if (wSz == -1) changes are concerned with mic only.
DWORD AudioIf_dst_mix
	(
	WORD	wDstId,				// for this dst...
	bool	bMixMic = true,		// you can mix microphone..
	WORD	wSz = 0,				// and iSz number of incoming streams
	WORD*	pwMixSrcIds = NULL	// the volumes will be same as 
								// set by AudioIf_src_volume_set()
	);
DWORD AudioIf_dst_mix_get
	(
	WORD	wDstId,
	WORD*	pwSz,
	WORD*	pwMixSrcIds
	);

// when you take one of parties out, then specify it's SrcId in this call.
// this function will remove this src from all dst's where it was listed before
// this function is called automatically when you call AudioIf_src_remove();
DWORD AudioIf_dst_mix_remove 
	(
	WORD	wSrcId				// of incoming stream
	);
///////////////////////////////////////////////////////////////////////////////
//
//					SPECIAL PURPOSE SIGNAL GENERATOR
//
// with this one, you can:
//	- generate white/pink noise, sine waves, etc towards speaker
//	- generate DTMF tones towards network 
//		-- set iMode to AUDIO_IF_TEST_GEN_MODE_INBAND_DTMF
//		-- give the string of digits in pszFileName.
//		-- and they will be pulsed out with proper timing.
//		-- DO NOT try inband dialing when dst payload is CELP or LPC (except G.728).
//	- record micrpohone
//	- play back a .wav PCM file
//	- record a call in "stereo". left channel will be a mix of src, and right will be mic.
//
// see AUDIO_IF_TEST_GEN_MODE_.... for mode info.
//
//
// ------------------------ defines -------------------------------------------
//
enum {
	AUDIO_IF_TEST_GEN_MODE_OFF,				// 0 stop everything

	// one of - to speaker (RCV side)
	AUDIO_IF_TEST_GEN_MODE_WHITE_NOISE,		// 1 on -20 dbFS
	AUDIO_IF_TEST_GEN_MODE_BROWN_NOISE,		// 2 on -20 dbFS
	AUDIO_IF_TEST_GEN_MODE_1000HZ,			// 3 on -20 dbFS
	AUDIO_IF_TEST_GEN_MODE_FREQ_SWEEP,		// 4 on -20 dbFS	

	// support inband dialing (SND side)
	// 40ms of silence, dtmf for 80 ms, 40 ms of silence
	// SND output level is fixed at -8 dBFS per freq as per ITU-T Q.23
	// RCV is "echoed" at -12 dB, as from sidetone
	// dtmf replaces any other signal
	AUDIO_IF_TEST_GEN_MODE_INBAND_DTMF,		// 5

	// microphone path recording.
	AUDIO_IF_TEST_GEN_MODE_PLAY_ONCE,		// 6
	AUDIO_IF_TEST_GEN_MODE_PLAY_LOOP,		// 7
	AUDIO_IF_TEST_GEN_MODE_PAUSE,			// 8
	AUDIO_IF_TEST_GEN_MODE_CONTINUE,		// 9
	AUDIO_IF_TEST_GEN_MODE_RECORD,			// 10
	AUDIO_IF_TEST_GEN_MODE_STOP,			// 11

	// record call - to be done in parallel with everything else. 
	// state is not reported in mode_get();
	AUDIO_IF_TEST_GEN_MODE_RECORD_CALL_START,		// 12
	AUDIO_IF_TEST_GEN_MODE_RECORD_CALL_PAUSE,		// 13
	AUDIO_IF_TEST_GEN_MODE_RECORD_CALL_CONTINUE,	// 14
	AUDIO_IF_TEST_GEN_MODE_RECORD_CALL_STOP,		// 15

	AUDIO_IF_TEST_GEN_MODE_SND_1000HZ,			// 16, 3 on -20 dbFS

	AUDIO_IF_TEST_GEN_MODE_MAX
};
//
// ------------------------ functions -----------------------------------------
//
DWORD AudioIf_test_gen
	(
	int iMode = AUDIO_IF_TEST_GEN_MODE_OFF, 
	char *pszFileName = NULL	
						// record-to or play-from filename, 
						// or DTMF dialing string, "0...9*#"
	);
DWORD AudioIf_test_gen
	(
	int *piMode
	);
///////////////////////////////////////////////////////////////////////////////
//
//					VOLUME and MIC MUTE
//
// these functions provide software equivalent of 
// hardware mic mute and spk volume. 
// they are safe to use - that means there 
// will be no negative impact on AEC performance.
//
// ------------------------ defines -------------------------------------------
// ------------------------ functions -----------------------------------------
DWORD AudioIf_volume
	(
	float fVolumeDB = 0.F	// will be capped at +12 dB
	);
DWORD AudioIf_volume
	(
	float *pfVolumeDB
	);
DWORD AudioIf_mic_mute
	(
	const bool bMute = true
	);
DWORD AudioIf_mic_mute
	(
	bool *pbMuted
	);
DWORD AudioIf_mic_level // before AGC
	(
	float *pfNrgDBFS		//  smoothed energy in dB Full Scale
	);
///////////////////////////////////////////////////////////////////////////////
//
//					AGC 
//
// on by default.
//
// unless you understand what is going on, do not call those functions.
//
// if you are using hardware-based echo control devices from ClearOne/Polycom,
// disable AEC/AGC/Denoiser. these hardware devices have everything of their own, 
// and tandeming will hurt. 
//
//
// ------------------------ defines -------------------------------------------
//
typedef struct {
	float			fTargetLevelDBFS;
	float			fMinEnergyDBFS;
	float			fOverNoiseThrDB;			// must be over noise XdB to be detected
	float			fMaxGainDB;					// positive, < 12 dB
	float			fAdaptationSpeedOnVowelsMs;
	float			fAdaptationSpeedOnNoiseMs;
} AudioIf_tAgcCfg;
//
// ------------------------ functions -----------------------------------------
//
DWORD AudioIf_agc
	(
	const bool bOn, 
	const float fMicExtraGainDB = 0,
	const AudioIf_tAgcCfg *pCfg // default if NULL
		= (AudioIf_tAgcCfg *)NULL 
	);
DWORD AudioIf_agc
	(
	bool *pbOn, // can be NULL
	float *pfMicExtraGainDB = NULL,
	AudioIf_tAgcCfg *pCfg		// where to put it
		= (AudioIf_tAgcCfg *)NULL
	);

///////////////////////////////////////////////////////////////////////////////
//
//					AEC
//
// on by default.
//
// unless you understand what is going on, do not call those functions.
//
// if you are using hardware-based echo control devices from ClearOne/Polycom,
// disable AEC/AGC/Denoiser. these hardware devices have everything of their own, 
// and tandeming will hurt. 
//
// quality up - CPU is up too
//
// ------------------------ defines -------------------------------------------
//
enum {
	AUDIO_IF_AEC_MODE_LQ,	// low quality
	AUDIO_IF_AEC_MODE_MQ,	// mid quality = default		
	AUDIO_IF_AEC_MODE_HQ,	// highest quality 

	AUDIO_IF_AEC_MODE_MAX
};

typedef struct {
	int 			iAecMode;
	float			fWorstErlDB;
    float			fTCLstDB;
    float			fTCLdtDB;
	float			fSpkNonLinear1PercentDBFS;	// thr when spk becomes nonlinear.
} AudioIf_tAecCfg;
//
// ------------------------ functions -----------------------------------------
//
DWORD AudioIf_aec
	(
	const bool bOn, 
	const AudioIf_tAecCfg *pCfg // default if NULL
		= (AudioIf_tAecCfg *)NULL
	);
DWORD AudioIf_aec
	(
	bool *pbOn, // can be NULL
	AudioIf_tAecCfg *pCfg		// where to put it
		= (AudioIf_tAecCfg *)NULL
	);
///////////////////////////////////////////////////////////////////////////////
//
//					DENOISER 
//
// on by default.
//
// unless you understand what is going on, do not call those functions.
//
// if you are using hardware-based echo control devices from ClearOne/Polycom,
// disable AEC/AGC/Denoiser. these hardware devices have everything of their own, 
// and tandeming will hurt. 
//
// ------------------------ defines -------------------------------------------
// ------------------------ functions -----------------------------------------
DWORD AudioIf_denoiser			// if AEC is off, Denoiser will be OFF.
	(
	const bool bOn, 
	const float fStrength = 1.0F // from 1 to 5. the more, the stronger.
	);
DWORD AudioIf_denoiser
	(
	bool *pbOn, 
	float *pfStrength			// where to put it
	);

///////////////////////////////////////////////////////////////////////////////
//
//					CPU USAGE STATISTICS
//
// ------------------------ defines -------------------------------------------
typedef struct {
	AudioIf_tHstgm	Decoding;
	AudioIf_tHstgm	Aec;
	AudioIf_tHstgm	Encoding;
	AudioIf_tHstgm	SignalProcessingTotal;
	float			fDrvThreadUserModePercentage;
	float			fDrvThreadKernelModePercentage;
	float			fDbgThreadUserModePercentage;
	float			fDbgThreadKernelModePercentage;
} AudioIf_tCpuStts;
//
// ------------------------ functions -----------------------------------------
//
// 
DWORD	AudioIf_cpu_stts_get
	(
	AudioIf_tCpuStts *pStts
	);

///////////////////////////////////////////////////////////////////////////////
//
//					CALLBACKS you MUST provide
//
// 
// ------------------------ defines -------------------------------------------
// ------------------------ functions -----------------------------------------
void* AudioIf_alloc				// returns NULL if failed
	(
	int iSz
	); 
void* AudioIf_free				// shall always return NULL 
	(
	void *pv
	); 

///////////////////////////////////////////////////////////////////////////////
//
//                  ALARMS
//
// audio alarm indications are provided to re-direct blame 
// on low audio quality "somewhere else", 
// i.e. on network problems, soundcard, mic, spk, configuration, room noise, etc.
//
// they mean: " yes, we acknowledge that the audio is not great at the moment. 
// it's because of ... blah-blah-blah".
//
// we can't warrant that there will no false alarms, or that we
// issue alarm when we have to - (we may miss it)... 
// we just do our best guess on audio conditions, and hope to improve in next versions.
//
///////////////////////////////////////////////////////////////////////////////

// some minor problems with network rcv. 
// pkt loss/late > 1% and/or jitter buffer delay > 50ms
// MOS loss is > 0.33
#define AUDIO_IF_ALARM_POOR_NETWORK			(0x0001) 
// more serius problems with network rcv. 
// pkt loss/late > 5% and/or jitter buffer delay > 80ms
// MOS loss is > 1.0
#define AUDIO_IF_ALARM_BAD_NETWORK			(0x0002)
// very serius problems with network rcv. 
// pkt loss/late > 15% and/or jitter buffer delay > 100ms, etc
// MOS loss is > 2.0
#define AUDIO_IF_ALARM_NO_NETWORK			(0x0003)

// some minor problems with sound card 
// a re-sync has been required.
#define AUDIO_IF_ALARM_POOR_SOUND			(0x0004)
// some more problems with sound card 
// too many re-syncs happened in last minute(s),
// the delay through audio driver grew up to be > 50 ms
#define AUDIO_IF_ALARM_BAD_SOUND			(0x0008)
// very serious problems with sound card. 
// generally, someting is wrong with sound card.
// running audio wizard/diagnostic is advised.
#define AUDIO_IF_ALARM_NO_SOUND				(0x000c)

// the mic signal has been clipped few times
#define AUDIO_IF_ALARM_MIC_CLIPPING			(0x0010)
// the mic signal has been clipped many times recently
#define AUDIO_IF_ALARM_MIC_SATURATED		(0x0020)
// the mic signal is being clipped all the time
// either mic sensitivity is wrong, or...
#define AUDIO_IF_ALARM_MIC_OVERFLOWN		(0x0030)

// AEC is experencing some troubles.
// far-end may hear echo.
// speaker may be non-linear, or companding the signal (Bose companion II, etc)
// sound card may implement AGC/AEC/NRD in hardware, etc
#define AUDIO_IF_ALARM_AEC					(0x0040)
// AEC is experencing troubles becuase speaker echo saturates mic
// re-run audio wizard.
#define AUDIO_IF_ALARM_AEC_COUPLING			(0x0080)

// the noise floor is somewhat high.
// mic sensitivity may be too high, room may be too noisy
// we can't do a good job on noise reduction.
// far end may complain on excessive noise
#define AUDIO_IF_ALARM_MIC_HIGH_NOISE		(0x0100)
// the noise floor is really high.
// we can't deal with it to user satisfaction.
// far end will defintely complain on excessive noise
#define AUDIO_IF_ALARM_MIC_VERY_HIGH_NOISE	(0x0200)
// the noise floor is well beyond system's ability to cope with it.
// far end will complain on both excessive noise and poor inteligibility
#define AUDIO_IF_ALARM_MIC_BAD_NOISE		(0x0300)

// the signal on mic is a way too low.
// has mic been muted in h/w???
#define AUDIO_IF_ALARM_MIC_NO_SIGNAL		(0x0400)
// AGC is uncapable to bring mic signal to nominal level
// is mic placed right??? sensitvity correct???
#define AUDIO_IF_ALARM_AGC_SOFT_TALKER		(0x0800)


#if 0 
///////////////////////////////////////////////////////////////////////////////
//
//					TO BE IMPLEMENTED
//
///////////////////////////////////////////////////////////////////////////////
//
//					AUDIO ENVIRONMENT SETUP 
//
// those functions are privided to ensure that user can return 
// to the same volume settings that have been used in AudioWizard
//
// preferably, you should 
//		-- call AudioIf_env_get() before every call, preserve it as "user".
//		-- call AudioIf_env_set() with known good config (from AudioWizard)
//		-- call AudioIf_drv_open() and proceed with the call
//		-- call AudioIf_drv_close() when the call ends
//		-- call AudioIf_env_set() to revert the preserved "user" environment.
//
// this functions are not parts of AudioIf_drv_open() because the scenarios of
// usage and preserving audio environment are too many.
// users may switch beween calls, invoke AudioWizard while in the call, etc.
// we are not in control of this logic, and therefore leave it 
// for you to decide when and why to call these fucntions.
//
// ------------------------ defines -------------------------------------------
//
typedef struct {
	int				iMasterVolume;
	int				iWaveVolume;
	int				iMicVolume;
	bool			bMicBoost;
	bool			bAlternateMic; // if present
	bool			bMicFedback;
} AudioIf_tEnvCfg;
//
// ------------------------ functions -----------------------------------------
//
DWORD AudioIf_env_get
	(
	AudioIf_tEnvCfg *pEnv
	);
DWORD AudioIf_env_set
	(
	AudioIf_tEnvCfg *pEnv
	);
#define AUDIO_IF_EQ_FREQS					(30)


///////////////////////////////////////////////////////////////////////////////
//
//					AUDIO CONFIGRATION
//
//
///////////////////////////////////////////////////////////////////////////////
// max number of parties in a meeting
// these will be used throughout audio processing
// for headset and
typedef struct {
	float			fNoiseMinDBFS;				// min level of noise
	float			fNoiseDefaultDBFS;			// level of noise to start with
	float			fNoiseMaxDBFS;				// max level of noise
	bool			bFilterBelow80Hz;
	int				iPreEmphasis;				// 0...3 dB per octave
	bool			bFilter60HzHarmonics;
} AudioIf_tAudioCfg;

typedef struct {
	// driver config
	char			aszMicName				[AUDIO_IF_DEVICE_NAME_SZ];
	char			aszSpkName				[AUDIO_IF_DEVICE_NAME_SZ];
	int				iDrvMode;

	// processing config
	// test gen mode is assumed to be NONE
	AudioIf_tAudioCfg	Audio;
	float			fVolumeDB;
	float			afSpkEqGainsDB			[AUDIO_IF_EQ_FREQS];
	bool			bDeHowling;
	float			fDeHowlingFreqShiftHz;
	AudioIf_tAecCfg Aec;
	bool			bNoiseReduction;
	float			fNoiseReducionStrength;
	AudioIf_tAgcCfg Agc;
	float			afMicEqGainsDB			[AUDIO_IF_EQ_FREQS];
	bool			bMicMute;
	bool			bDTX;					// false by default

	// misc
	WORD			wUiMode;
	WORD			wRecordingMode;
	char			aszRecFilesDirectory	[MAX_PATH];
	int				iLogLevel;
	char			aszLogFileName			[MAX_PATH];

} AudioIf_tCfg;




typedef struct {
	float			fERLworstDB;
	float			fERLWeightedDB;
	float			fERLEWeightedDB;
	float			fTCLWeightedDB;
	float			fRcvNoiseDBFS;
	float			fSndNoiseDBFS;
	float			fEchoDelayMs;
	int				iRcvActiveFrames;
	int				iSndActiveFrames;
	int				iDtFrames;
	int				iTotalFrames;
} AudioIf_tAecStts;

DWORD AudioIf_drv_warm_reset(); // behavior TBD
DWORD AudioIf_drv_reset(); // also resets everything
DWORD AudioIf_cfg_set(AudioIf_tAudioCfg *pCfg);
DWORD AudioIf_cfg_get(AudioIf_tAudioCfg *pCfg);
	// mos is estimated with e-model, over TBD last seconds. 
DWORD AudioIf_src_mos_get(WORD wPartyId, 
		float *pMOS, // returns negative number if unsuficient data
		float fBulkDelayMs = 0.F); // over the network and at far-end.
DWORD AudioIf_spk_eq_set(float *pfGains);
DWORD AudioIf_spk_eq_get(float *pfGains);
DWORD AudioIf_de_howling_set(bool bOn);
DWORD AudioIf_de_howling_get(bool *pbOn);
DWORD AudioIf_aec_stts_get(AudioIf_tAecStts *pMode, bool bClearOnRead = false);
DWORD AudioIf_mic_eq_set(float *pfGains);
DWORD AudioIf_mic_eq_get(float *pfGains);
DWORD AudioIf_dtx_mode_set(bool bOn = true);	// set by default.
DWORD AudioIf_dtx_mode_get(	bool *pbOn);
DWORD AudioIf_dst_quality_set(WORD wPartyId, void *pvData, // whatever structure
		int iDataSz); // the structure size
DWORD AudioIf_dst_quality_get(WORD wPartyId, void *pvData, int *piDataSz);
DWORD AudioIf_dst_stts_get(WORD wPartyId, AudioIf_tNsStts *pStts);
	// returns current alarm mask. 
	// it can be converted into a call back that fires on change only
DWORD AudioIf_alarm(unsigned long *pulAlarm, unsigned long *pulAlarmMask);
DWORD AudioIf_ui_mode(unsigned int uUiMask); // magic values
DWORD AudioIf_recording_mode(unsigned int iMask, char *pszFilename);
DWORD AudioIf_log_mode(int iLevel, char *pszFilename);
#endif

#endif