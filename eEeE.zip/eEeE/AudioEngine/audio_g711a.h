#ifndef AUDIO_G711A_H
#define AUDIO_G711A_H

// Disabled warnings
//#pragma warning(disable:4710) // function not inlined

#include "audio_defs.h"
void audio_G711A_decoder_init();
int  audio_G711A_decode(short *psTo, BYTE *pcFrom);
void audio_G711A_encoder_init();
int  audio_G711A_encode(BYTE *pcTo, short *psFrom);


#endif // AUDIO_G711U_H
