#include "audio_defs.h"

// -----------------------------------------------------------------------------
static WORD		_list_parties // excluding host
// -----------------------------------------------------------------------------
(
WORD wConfId, 
WORD *awListPartyIds
)
{
	WORD cnt = 0;
	Audio_tConf *pConf = &gAudio.Conf;
	for (int k = 1; k <= AUDIO_IF_PARTY_MAX; k++)
	{	
		if (pConf->aParty[k].wConfId == wConfId)
		{
			*awListPartyIds++ = k;
			cnt++;
		}
	}
	return cnt;
}

// -----------------------------------------------------------------------------
DWORD					AudioIf_conf_create
// -----------------------------------------------------------------------------
(
WORD*	pwConfId,	// conf id will be returned here. use it for further calling.
bool	bAddHost // host will be moved into here from any other conference
)
{
	if (!gAudio.bInitialized) return AUDIO_IF_ERR_NOT_INITIALIZED;

	DWORD rc = AUDIO_IF_ERR_NONE;
	audio_lock();

	audio_log_inf("AudioIf_conf_create -- pwConfId=%p bAddHost=%d", 
				pwConfId, bAddHost);

	Audio_tConf *pConf = &gAudio.Conf;

	if (pwConfId == NULL)
	{
		rc |= AUDIO_IF_ERR_INVALID_PARAM;
	}
	else 
	{
		int wConfId;
		bool bFound = false;
		if ((*pwConfId != 0) && 
			(*pwConfId <= AUDIO_IF_CONF_MAX) &&
			(!pConf->aConf[*pwConfId].bActive))
		{
			bFound = true;
		}
		wConfId = *pwConfId;

		// find first available slot
		if (!bFound)
		{
			for (wConfId = 1; wConfId <= AUDIO_IF_CONF_MAX; wConfId++)
			{
				if (!pConf->aConf[wConfId].bActive)
				{
					*pwConfId = wConfId;
					bFound = true;
					break;
				}
			}
		}
		if (bFound)
		{
			pConf->aConf[wConfId].bActive = true;
			if (bAddHost)
			{
				if (pConf->aParty[AUDIO_IF_PARTY_HOST].wConfId)
				{
					rc |= AudioIf_conf_disconnect_party(
							pConf->aParty[AUDIO_IF_PARTY_HOST].wConfId, 
							AUDIO_IF_PARTY_HOST);
				}
				rc |= AudioIf_conf_connect_party(wConfId, AUDIO_IF_PARTY_HOST);
			}
		}
		else // internal error
		{
			rc |= AUDIO_IF_ERR_OUT_OF_MEMORY;
		}
	}

	if (rc)
		audio_log_err("AudioIf_conf_create -- rc=0x%08x", rc);
	else
		audio_log_inf("AudioIf_conf_create -- done");

	audio_unlock();
	return rc;

}
// -----------------------------------------------------------------------------
DWORD					AudioIf_conf_delete
// -----------------------------------------------------------------------------
(
WORD	wConfId,	
bool	bDeleteAllParties
)
{
	if (!gAudio.bInitialized) return AUDIO_IF_ERR_NOT_INITIALIZED;

	DWORD rc = AUDIO_IF_ERR_NONE;
	audio_lock();

	audio_log_inf("AudioIf_conf_delete -- wConfId=%d bDeleteAllParties=%d", 
				wConfId, bDeleteAllParties);

	Audio_tConf *pConf = &gAudio.Conf;

	if ((wConfId > AUDIO_IF_CONF_MAX) ||
		(wConfId == 0))
		rc |= AUDIO_IF_ERR_INVALID_PARAM;

	if ((rc == AUDIO_IF_ERR_NONE) && 
		(!pConf->aConf[wConfId].bActive))
		rc |= AUDIO_IF_ERR_ALREADY_REMOVED;

	if (rc == AUDIO_IF_ERR_NONE)
	{
		for (int k = 0; k <= AUDIO_IF_PARTY_MAX; k++) // including host
		{
			if (pConf->aParty[k].wConfId == wConfId)
			{
				rc |= AudioIf_conf_disconnect_party(wConfId, k);
				if (bDeleteAllParties && (k > 0))
					rc |= AudioIf_party_delete(k);
			}
		}
		pConf->aConf[wConfId].bActive = false;

	}

	if (rc)
		audio_log_err("AudioIf_conf_delete -- rc=0x%08x", rc);
	else
		audio_log_inf("AudioIf_conf_delete -- done");

	audio_unlock();
	return rc;
}
// -----------------------------------------------------------------------------
DWORD					AudioIf_conf_connect_party
// -----------------------------------------------------------------------------
(
WORD	wConfId,	
WORD	wPartyId
)
{
	if (!gAudio.bInitialized) return AUDIO_IF_ERR_NOT_INITIALIZED;

	DWORD rc = AUDIO_IF_ERR_NONE;
	audio_lock();

	audio_log_inf("AudioIf_conf_connect_party -- wConfId=%d wPartyId=%d", 
				wConfId, wPartyId);

	Audio_tConf *pConf = &gAudio.Conf;

	if ((wConfId > AUDIO_IF_CONF_MAX) ||
		(wConfId == 0) ||
		(wPartyId > AUDIO_IF_PARTY_MAX) ||
		(!pConf->aConf[wConfId].bActive) ||
		(!pConf->aParty[wPartyId].bActive))
	{
		rc |= AUDIO_IF_ERR_INVALID_PARAM;
	}
	else // all params are valid
	{
		if (pConf->aParty[wPartyId].wConfId == wConfId)
		{
			// it's already here
			audio_log_inf("AudioIf_conf_connect_party -- already here");
		}
		else
		{
			// first, if this party has been in any other conference,
			// take it from there
			if (pConf->aParty[wPartyId].wConfId)
			{
				AudioIf_conf_disconnect_party(
					pConf->aParty[wPartyId].wConfId, wPartyId);
			}
			// now, connect it to this conference
			// our actions are different for host and a tributary 
			if (wPartyId == AUDIO_IF_PARTY_HOST)
			{
				for (int k = 1; k <= AUDIO_IF_PARTY_MAX; k++)
				{
					if (pConf->aParty[k].wConfId == wConfId)
					{
						rc |= AudioIf_src_mix(k, true);
						rc |= AudioIf_dst_mix(k, true, (WORD)-1, NULL);
					}
				}
			}
			else
			{
				WORD awPartyIds[AUDIO_IF_PARTY_MAX];
				WORD wNumPartyIds = _list_parties(wConfId, awPartyIds);
				bool bHost = 
					(pConf->aParty[AUDIO_IF_PARTY_HOST].wConfId == wConfId);

				// add all others to this party id
				rc |= AudioIf_dst_mix(
						wPartyId, 
						bHost,
						wNumPartyIds,
						awPartyIds);
				rc |= AudioIf_src_mix(wPartyId, bHost);

				// add this party id to all others
				for (int k = 0; k < wNumPartyIds; k++)
				{
					WORD awMixMap[AUDIO_IF_PARTY_MAX];
					WORD wMixSz = 0;
					rc |= AudioIf_dst_mix_get(
						awPartyIds[k], 
						&wMixSz,
						awMixMap);
					awMixMap[wMixSz] = wPartyId;
					wMixSz++;
					rc |= AudioIf_dst_mix(
						awPartyIds[k], 
						bHost,
						wMixSz,
						awMixMap);
				}
			}
			audio_net_snd_mix_log();
		}
	}

	if (rc == AUDIO_IF_ERR_NONE)
	{
		pConf->aParty[wPartyId].wConfId = wConfId;
	}

	if (rc)
		audio_log_err("AudioIf_conf_connect_party -- rc=0x%08x", rc);
	else
		audio_log_inf("AudioIf_conf_connect_party -- done");

	audio_unlock();
	return rc;
}
// NOTE: disconnecting of host from a conference is equivalent to putting it on hold
// -----------------------------------------------------------------------------
DWORD				AudioIf_conf_disconnect_party
// -----------------------------------------------------------------------------
(
WORD	wConfId,	
WORD	wPartyId
)
{
	if (!gAudio.bInitialized) return AUDIO_IF_ERR_NOT_INITIALIZED;

	DWORD rc = AUDIO_IF_ERR_NONE;
	audio_lock();

	audio_log_inf("AudioIf_conf_disconnect_party -- wConfId=%d wPartyId=%d", 
				wConfId, wPartyId);

	Audio_tConf *pConf = &gAudio.Conf;

	if ((wConfId > AUDIO_IF_CONF_MAX) ||
		(wConfId == 0) ||
		(wPartyId > AUDIO_IF_PARTY_MAX))
		rc |= AUDIO_IF_ERR_INVALID_PARAM;

	if (rc == AUDIO_IF_ERR_NONE)
		if ((!pConf->aConf[wConfId].bActive) ||
			(!pConf->aParty[wPartyId].bActive) ||
			(pConf->aParty[wPartyId].wConfId != wConfId))
			rc |= AUDIO_IF_ERR_ALREADY_REMOVED;

	if (rc == AUDIO_IF_ERR_NONE)
	{
		if (wPartyId == AUDIO_IF_PARTY_HOST)
		{
			for (int k = 1; k <= AUDIO_IF_PARTY_MAX; k++)
			{
				if (pConf->aParty[k].wConfId == wConfId)
				{
					rc |= AudioIf_src_mix(k, false);
					rc |= AudioIf_dst_mix(k, false, (WORD)-1, NULL);
				}
			}
		}
		else // a tributary
		{
			// do not mix mic to this party, 
			// and zero list of other paries to be mixed for this one
			rc |= AudioIf_dst_mix(wPartyId, false, 0, NULL);
			// do not mix this party to spk
			rc |= AudioIf_src_mix(wPartyId, false);
			// remove this party from all other parties
			rc |= AudioIf_dst_mix_remove(wPartyId);
		}
		pConf->aParty[wPartyId].wConfId = 0;

		audio_net_snd_mix_log();
	}

	if (rc)
		audio_log_err("AudioIf_conf_disconnect_party -- rc=0x%08x", rc);
	else
		audio_log_inf("AudioIf_conf_disconnect_party -- done");

	audio_unlock();
	return rc;

}
// wConfIdMerging will be deleted after merging all its parties to wConfIdMergedTo
// -----------------------------------------------------------------------------
DWORD					AudioIf_conf_merge
// -----------------------------------------------------------------------------
(
WORD	wConfIdMergedTo,	
WORD	wConfIdMerging 
)
{
	if (!gAudio.bInitialized) return AUDIO_IF_ERR_NOT_INITIALIZED;

	DWORD rc = AUDIO_IF_ERR_NONE;
	audio_lock();

	audio_log_inf("AudioIf_conf_merge -- wConfIdMergedTo=%d wConfIdMerging=%d", 
				wConfIdMergedTo, wConfIdMerging);

	Audio_tConf *pConf = &gAudio.Conf;

	if ((wConfIdMergedTo > AUDIO_IF_CONF_MAX) ||
		(wConfIdMergedTo == 0) ||
		(wConfIdMerging > AUDIO_IF_CONF_MAX) ||
		(wConfIdMerging == 0) ||
		(!pConf->aConf[wConfIdMergedTo].bActive) ||
		(!pConf->aConf[wConfIdMerging].bActive))
	{
		rc |= AUDIO_IF_ERR_INVALID_PARAM;
	}
	else
	{
		for (int k = 0; k <= AUDIO_IF_PARTY_MAX; k++) // including host
		{
			if (pConf->aParty[k].wConfId == wConfIdMerging)
			{
				rc |= AudioIf_conf_connect_party(wConfIdMergedTo, k);
			}
		}
		rc |= AudioIf_conf_delete(wConfIdMerging);
	}

	if (rc)
		audio_log_err("AudioIf_conf_merge -- rc=0x%08x", rc);
	else
		audio_log_inf("AudioIf_conf_merge -- done");

	audio_unlock();
	return rc;
}
// -----------------------------------------------------------------------------
DWORD				AudioIf_conf_num_parties
// -----------------------------------------------------------------------------
(
WORD	wConfId,	
WORD*	pwNumPartyIds
)
{
	if (!gAudio.bInitialized) return AUDIO_IF_ERR_NOT_INITIALIZED;

	DWORD rc = AUDIO_IF_ERR_NONE;
	audio_lock();

	audio_log_inf("AudioIf_conf_num_parties -- wConfId=%d pwNumPartyIds=%p", 
				wConfId, pwNumPartyIds);

	Audio_tConf *pConf = &gAudio.Conf;

	if ((!pwNumPartyIds) ||
		(wConfId == 0) ||
		(wConfId > AUDIO_IF_CONF_MAX))
	{
		rc |= AUDIO_IF_ERR_INVALID_PARAM;
	}
	else
	{
		WORD wNumPartyIds = 0;
		for (int k = 0; k <= AUDIO_IF_PARTY_MAX; k++) // including host
		{
			if (pConf->aParty[k].wConfId == wConfId)
				wNumPartyIds++;
		}
		*pwNumPartyIds = wNumPartyIds;
	}

	if (rc)
		audio_log_err("AudioIf_conf_num_parties -- rc=0x%08x", rc);
	else
		audio_log_inf("AudioIf_conf_num_parties -- done");

	audio_unlock();
	return rc;
}
// -----------------------------------------------------------------------------
DWORD				AudioIf_conf_list_parties
// -----------------------------------------------------------------------------
(
WORD	wConfId,	
WORD*	pwListPartyIds // point to caller-allocated array of wNumParties len
)
{
	if (!gAudio.bInitialized) return AUDIO_IF_ERR_NOT_INITIALIZED;

	DWORD rc = AUDIO_IF_ERR_NONE;
	audio_lock();

	audio_log_inf("AudioIf_conf_list_parties -- wConfId= %d pwListPartyIds=%p", 
				wConfId, pwListPartyIds);

	Audio_tConf *pConf = &gAudio.Conf;

	if ((!pwListPartyIds) ||
		(wConfId == 0) ||
		(wConfId > AUDIO_IF_CONF_MAX))
	{
		rc |= AUDIO_IF_ERR_INVALID_PARAM;
	}
	else
	{
		int iParties = 0; 
		for (int k = 0; k <= AUDIO_IF_PARTY_MAX; k++) // including host
		{
			if (pConf->aParty[k].wConfId == wConfId)
			{
				*pwListPartyIds++ = k;
				iParties++;
			}
		}
	}
	if (rc)
		audio_log_err("AudioIf_conf_list_parties -- rc=0x%08x", rc);
	else
		audio_log_inf("AudioIf_conf_list_parties -- done");

	audio_unlock();
	return rc;
}
// -----------------------------------------------------------------------------
DWORD				AudioIf_conf_most_active
// -----------------------------------------------------------------------------
(
WORD	wConfId,	
WORD	wNumPartiesToReport, // set to AUDIO_IF_PARTY_MAX to report all
WORD*	pwListPartyIds // point to caller-allocated array of wNumParties len
)
{
	if (!gAudio.bInitialized) return AUDIO_IF_ERR_NOT_INITIALIZED;

	DWORD rc = AUDIO_IF_ERR_NONE;
	audio_lock();

	audio_log_trc("AudioIf_conf_most_active -- wConfId=%d "
		"wNumPartiesToReport=%d pwListPartyIds=%p", 
				wConfId, wNumPartiesToReport, pwListPartyIds);

	Audio_tConf *pConf = &gAudio.Conf;

	if ((!pwListPartyIds) ||
		(wConfId == 0) ||
		(wConfId > AUDIO_IF_CONF_MAX) ||
		(wNumPartiesToReport == 0))
	{
		rc |= AUDIO_IF_ERR_INVALID_PARAM;
	}
	else
	{
		WORD  aw[AUDIO_IF_PARTY_MAX+1];
		float af[AUDIO_IF_PARTY_MAX+1];

		int k;
		int srcs = 0;

		for (k = 1; k <= AUDIO_IF_PARTY_MAX; k++)
		{
			if (pConf->aParty[k].wConfId == wConfId)
			{
				aw[srcs] = k;
				AudioIf_src_level(k, &af[srcs]);// = gAudio.Jb.apParty[k]->fNrg;
				srcs++;
			}
		}
		if (pConf->aParty[AUDIO_IF_PARTY_HOST].wConfId == wConfId)
		{
			aw[srcs] = 0;
			AudioIf_mic_level(&af[srcs]);// = gAudio.Nrg.fMicS;
			srcs++;
		}
		
		for (k = 0; k < wNumPartiesToReport; k++)
		{
			float fMax = 0;
			int iMax = -100;
			for (int m = 0; m < srcs; m++)
			{
				if (fMax < af[m])
				{
					fMax = af[m];
					iMax = m;
				}
			}

			if (iMax >= 0)
			{
				audio_log_trc("-- dwSrcId %d, nrg %7.2f", 
					aw[iMax], af[iMax]);

				*pwListPartyIds++ = aw[iMax];
				af[iMax] = -200;
			}
			else
			{
				*pwListPartyIds++ = ((WORD)(-1));
			}
		}
	}

	if (rc)
		audio_log_err("AudioIf_conf_most_active -- rc=0x%08x", rc);
	else
		audio_log_trc("AudioIf_conf_most_active -- done");

	audio_unlock();
	return rc;
}

// -----------------------------------------------------------------------------
DWORD				AudioIf_conf_num
// -----------------------------------------------------------------------------
(
WORD*	pwNumConferences	
)
{
	if (!gAudio.bInitialized) return AUDIO_IF_ERR_NOT_INITIALIZED;

	DWORD rc = AUDIO_IF_ERR_NONE;
	audio_lock();

	audio_log_inf("AudioIf_conf_num -- pwNumConferences=%p", 
				pwNumConferences);

	Audio_tConf *pConf = &gAudio.Conf;
	if (pwNumConferences)
	{
		int cnt = 0;
		for (int k = 1; k <= AUDIO_IF_CONF_MAX; k++)
		{
			if (pConf->aConf[k].bActive)
				cnt++;
		}
		*pwNumConferences = cnt;
	}
	else
	{
		rc |= AUDIO_IF_ERR_INVALID_PARAM;
	}

	if (rc)
		audio_log_err("AudioIf_conf_num -- rc=0x%08x", rc);
	else
		audio_log_inf("AudioIf_conf_num -- done");

	audio_unlock();
	return rc;
}
// -----------------------------------------------------------------------------
DWORD				AudioIf_conf_list
// -----------------------------------------------------------------------------
(
WORD*	pwListConferences	
)
{
	if (!gAudio.bInitialized) return AUDIO_IF_ERR_NOT_INITIALIZED;

	DWORD rc = AUDIO_IF_ERR_NONE;
	audio_lock();

	audio_log_inf("AudioIf_conf_list -- pwListConferences=%p", 
				pwListConferences);

	if (pwListConferences)
	{
		Audio_tConf *pConf = &gAudio.Conf;

		for (int k = 1; k <= AUDIO_IF_CONF_MAX ; k++)
		{
			if (pConf->aConf[k].bActive)
			{
				*pwListConferences++ = k;
			}
		}
	}
	else
	{
		rc |= AUDIO_IF_ERR_INVALID_PARAM;
	}
	if (rc)
		audio_log_err("AudioIf_conf_list -- rc=0x%08x", rc);
	else
		audio_log_inf("AudioIf_conf_list -- done");

	audio_unlock();
	return rc;
}
// -----------------------------------------------------------------------------
DWORD				AudioIf_party_create
// -----------------------------------------------------------------------------
(
WORD*	pwPartyId,	// PartyId id will be returned here. use it for further calling.
WORD	wSrcPayloadType,
WORD	wDstPayloadType,
WORD	wDstFrsPerPkt,		// max = 4
DWORD	dwDstTimestamp,		// to start with
float	fInitialDelayMs
)
{
	if (!gAudio.bInitialized) return AUDIO_IF_ERR_NOT_INITIALIZED;

	DWORD rc = AUDIO_IF_ERR_NONE;
	audio_lock();

	audio_log_inf("AudioIf_party_create -- pwPartyId=%p wSrcPayloadType=%d "
		"wDstPayloadType=%d wDstFrsPerPkt=%d " 
		"dwDstTimestamp=%d fInitialDelayMs=%f", 
		pwPartyId, wSrcPayloadType, wDstPayloadType, wDstFrsPerPkt, 
		dwDstTimestamp, fInitialDelayMs);

	Audio_tConf *pConf = &gAudio.Conf;

	if (pwPartyId)
	{
		bool bFound = false;
		if ((*pwPartyId > 0) &&
			(*pwPartyId <= AUDIO_IF_PARTY_MAX) &&
			(!pConf->aParty[*pwPartyId].bActive))
		{
			bFound = true;// found. do not change it
		}
		else
		{
			for (int k = 1; k <= AUDIO_IF_PARTY_MAX; k++)
			{
				if (!pConf->aParty[k].bActive)
				{
					*pwPartyId = k;
					bFound = true;
					break;
				}
			}
		}

		if (bFound)
		{
			if (wSrcPayloadType != AUDIO_IF_PT_NONE)
			{
				rc |= AudioIf_src_add(*pwPartyId, 
					wSrcPayloadType, fInitialDelayMs, false);
			}

			if (wDstPayloadType != AUDIO_IF_PT_NONE)
				rc |= AudioIf_dst_add(*pwPartyId, wDstPayloadType, 
					dwDstTimestamp, wDstFrsPerPkt, false);

			if (rc == AUDIO_IF_ERR_NONE)
			{
				pConf->aParty[*pwPartyId].bActive = true;
			}
		}
		else
		{
			rc |= AUDIO_IF_ERR_OUT_OF_MEMORY;
		}
	}
	else
	{
		rc |= AUDIO_IF_ERR_INVALID_PARAM;
	}

	if (rc)
		audio_log_err("AudioIf_party_create -- rc=0x%08x", rc);
	else
		audio_log_inf("AudioIf_party_create -- done");

	audio_unlock();
	return rc;

}
// -----------------------------------------------------------------------------
DWORD				AudioIf_party_delete
// -----------------------------------------------------------------------------
(
WORD	wPartyId
)
{
	if (!gAudio.bInitialized) return AUDIO_IF_ERR_NOT_INITIALIZED;

	DWORD rc = AUDIO_IF_ERR_NONE;
	audio_lock();

	audio_log_inf("AudioIf_party_delete -- wPartyId=%d", 
				wPartyId);

	Audio_tConf *pConf = &gAudio.Conf;

	if ((wPartyId == 0) ||
		(wPartyId > AUDIO_IF_PARTY_MAX) ||
		(!pConf->aParty[wPartyId].bActive))
	{
		rc |= AUDIO_IF_ERR_INVALID_PARAM;
	}
	else
	{
		if (pConf->aParty[wPartyId].wConfId) // connected
		{
			rc |= AudioIf_conf_disconnect_party
				(pConf->aParty[wPartyId].wConfId, wPartyId);
		}
		rc |= AudioIf_dst_mix_remove(wPartyId);
		rc |= AudioIf_src_remove(wPartyId);
		rc |= AudioIf_dst_remove(wPartyId);
		pConf->aParty[wPartyId].bActive = false;
	}

	if (rc)
		audio_log_err("AudioIf_party_delete -- rc=0x%08x", rc);
	else
		audio_log_inf("AudioIf_party_delete -- done");

	audio_unlock();
	return rc;
}
// -----------------------------------------------------------------------------
DWORD				AudioIf_num_parties
// -----------------------------------------------------------------------------
(
WORD*	pwNumParties
)
{
	if (!gAudio.bInitialized) return AUDIO_IF_ERR_NOT_INITIALIZED;

	DWORD rc = AUDIO_IF_ERR_NONE;
	audio_lock();

	audio_log_inf("AudioIf_num_parties -- pwNumParties=%p", 
				pwNumParties);

	if (pwNumParties)
	{
		Audio_tConf *pConf = &gAudio.Conf;
		WORD cnt = 0; 
		for (int k = 0; k <= AUDIO_IF_PARTY_MAX; k++)
		{	
			if (pConf->aParty[k].bActive)
				cnt++;
		}
		audio_log_inf("-- %d active parties", cnt);
		*pwNumParties = cnt;
	}
	else
	{
		rc |= AUDIO_IF_ERR_INVALID_PARAM;
	}

	if (rc)
		audio_log_err("AudioIf_num_parties -- rc=0x%08x", rc);
	else
		audio_log_inf("AudioIf_num_parties -- done");

	audio_unlock();
	return rc;
}
// -----------------------------------------------------------------------------
DWORD				AudioIf_list_parties
// -----------------------------------------------------------------------------
(
WORD*	pwPartyIds,
WORD*	pwConfIds	// those parties belong to
)
{
	if (!gAudio.bInitialized) return AUDIO_IF_ERR_NOT_INITIALIZED;

	DWORD rc = AUDIO_IF_ERR_NONE;
	audio_lock();

	audio_log_inf("AudioIf_list_parties -- pwConfIds=%p pwConfIds=%p", 
				pwPartyIds, pwConfIds);

	if (pwPartyIds && pwConfIds)
	{
		Audio_tConf *pConf = &gAudio.Conf;

		for (int k = 0; k <= AUDIO_IF_PARTY_MAX; k++)
		{	
			if (pConf->aParty[k].bActive)
			{
				audio_log_inf("-- party=%d in conf=%d", k, 
					pConf->aParty[k].wConfId);
				*pwPartyIds++ = k;
				*pwConfIds++ = pConf->aParty[k].wConfId;
			}
		}
	}
	else
	{
		rc |= AUDIO_IF_ERR_INVALID_PARAM;
	}

	if (rc)
		audio_log_err("AudioIf_list_parties -- rc=0x%08x", rc);
	else
		audio_log_inf("AudioIf_list_parties -- done");

	audio_unlock();
	return rc;
}
