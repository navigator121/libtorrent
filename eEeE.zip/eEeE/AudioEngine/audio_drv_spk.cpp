
#include "audio_defs.h"

static short _asSine1k[AUDIO_DRV_SPK_BLK_SZ/2];


// see also; timeSetEvent , timeGetDevCaps , 
/*****************************************************************************/
DWORD					audio_drv_spk_init
/*****************************************************************************/
(
char *pszDeviceName
)
{
	unsigned long rc = AUDIO_IF_ERR_NONE;
	Audio_tDrvSpk *pSpk = &gAudio.Drv.Spk;
	HRESULT hr;

#if 1
	for (int k = 0; k < AUDIO_DRV_SPK_BLK_SZ/2; k++)
	{
		_asSine1k[k] = int(1000.F*sin((2*AUDIO_PI*k*1000.)/AUDIO_DRV_FS));
	}
#endif

	pSpk->iMode = AUDIO_DRV_SPK_MODE_NONE;
	hr = DirectSoundCreate8(NULL, // default playback device
			&pSpk->pDs, 
			NULL);
	if (hr == DS_OK)
	{
		DSCAPS DsCaps;
		DsCaps.dwSize = sizeof(DsCaps);
		hr = pSpk->pDs->GetCaps(&DsCaps);
		if (hr == DS_OK)
		{
			audio_log_inf("audio_drv_spk_init -- caps for %s", pszDeviceName);
			audio_log_inf("flags 0x%x", DsCaps.dwFlags);
			audio_log_inf("flag DSCAPS_CERTIFIED  0x%x", DsCaps.dwFlags&DSCAPS_CERTIFIED);
			audio_log_inf("flag DSCAPS_CONTINUOUSRATE   0x%x", DsCaps.dwFlags&DSCAPS_CONTINUOUSRATE );
			audio_log_inf("flag DSCAPS_EMULDRIVER  0x%x", DsCaps.dwFlags&DSCAPS_EMULDRIVER);
			audio_log_inf("flag DSCAPS_PRIMARY16BIT   0x%x", DsCaps.dwFlags&DSCAPS_PRIMARY16BIT );
			audio_log_inf("flag DSCAPS_PRIMARY8BIT   0x%x", DsCaps.dwFlags&DSCAPS_PRIMARY8BIT );
			audio_log_inf("flag DSCAPS_PRIMARYMONO   0x%x", DsCaps.dwFlags&DSCAPS_CERTIFIED);
			audio_log_inf("flag DSCAPS_PRIMARYSTEREO   0x%x", DsCaps.dwFlags&DSCAPS_PRIMARYSTEREO  );
			audio_log_inf("flag DSCAPS_SECONDARY16BIT   0x%x", DsCaps.dwFlags&DSCAPS_SECONDARY16BIT );
			audio_log_inf("flag DSCAPS_SECONDARY8BIT    0x%x", DsCaps.dwFlags&DSCAPS_SECONDARY8BIT  );
			audio_log_inf("flag DSCAPS_SECONDARYMONO    0x%x", DsCaps.dwFlags&DSCAPS_SECONDARYMONO  );
			audio_log_inf("flag DSCAPS_SECONDARYSTEREO    0x%x", DsCaps.dwFlags&DSCAPS_SECONDARYSTEREO  );
			audio_log_inf("dwMinSecondarySampleRate %d", DsCaps.dwMinSecondarySampleRate);
			audio_log_inf("dwMaxSecondarySampleRate %d", DsCaps.dwMaxSecondarySampleRate);
			audio_log_inf("dwTotalHwMemBytes %d", DsCaps.dwTotalHwMemBytes);
			audio_log_inf("dwFreeHwMemBytes %d", DsCaps.dwFreeHwMemBytes);
			audio_log_inf("dwUnlockTransferRateHwBuffers %d", DsCaps.dwUnlockTransferRateHwBuffers);
			audio_log_inf("dwMaxContigFreeHwMemBytes %d", DsCaps.dwMaxContigFreeHwMemBytes);
			audio_log_inf("dwPlayCpuOverheadSwBuffers %d", DsCaps.dwPlayCpuOverheadSwBuffers);
		}
		else
		{
			audio_log_war("audio_drv_spk_init -- GetCaps %s failed with 0x%x", pszDeviceName, hr);
		}

		DWORD dw;
		hr = pSpk->pDs->GetSpeakerConfig(&dw);
		if (hr == DS_OK)
		{
			switch(dw)
			{
			case DSSPEAKER_5POINT1: audio_log_inf("spk cfg: 5.1");break;
			case DSSPEAKER_DIRECTOUT: audio_log_inf("spk cfg: direct out");break;
			case DSSPEAKER_HEADPHONE:  audio_log_inf("spk cfg: headphone");break;
			case DSSPEAKER_MONO: audio_log_inf("spk cfg: mono");break;
			case DSSPEAKER_QUAD: audio_log_inf("spk cfg: quad");break;
			case DSSPEAKER_STEREO: audio_log_inf("spk cfg: stereo");break;
			case DSSPEAKER_STEREO | DSSPEAKER_GEOMETRY_WIDE: 
				audio_log_inf("spk cfg: stereo wide");break;
			case DSSPEAKER_STEREO | DSSPEAKER_GEOMETRY_NARROW: 
				audio_log_inf("spk cfg: stereo narrow");break;
			case DSSPEAKER_STEREO | DSSPEAKER_GEOMETRY_MIN: 
				audio_log_inf("spk cfg: stereo min");break;
			case DSSPEAKER_STEREO | DSSPEAKER_GEOMETRY_MAX: 
				audio_log_inf("spk cfg: stereo max");break;
//			case DSSPEAKER_SURROUND: audio_log_inf("spk cfg: surround");break;
			case DSSPEAKER_7POINT1: audio_log_inf("spk cfg: 7.1");break;
			default: audio_log_inf("spk cfg: other 0x%x", dw);break;
			}
//			m_dwSavedSpkCfg = dw;
//			m_bSpkCfgSaved = true;
			// setup mono ???
		}
		else
		{
			audio_log_war("audio_drv_spk_init -- GetSpeakerConfig failed with 0x%x", hr);
//			m_bSpkCfgSaved = false;
		}

		HWND hWnd = GetForegroundWindow();
		if (hWnd == NULL)
		{
			hWnd = GetDesktopWindow();
		}

		hr = pSpk->pDs->SetCooperativeLevel(hWnd, DSSCL_PRIORITY);
		if (hr == DS_OK)
		{
			audio_log_inf("audio_drv_spk_init -- priority mode");
			pSpk->iMode = AUDIO_DRV_SPK_MODE_PRIORITY;
		}
		else
		{
			audio_log_war("audio_drv_spk_init -- priority mode failed with 0x%x", hr);
			hr = pSpk->pDs->SetCooperativeLevel(hWnd, DSSCL_NORMAL);
			if (hr == DS_OK)
			{
				audio_log_inf("audio_drv_spk_init -- normal mode");
				pSpk->iMode = AUDIO_DRV_SPK_MODE_NORMAL;
			}
			else
			{
				audio_log_err("audio_drv_spk_init -- normal mode failed with 0x%x", hr);
				pSpk->iMode = AUDIO_DRV_SPK_MODE_FAILED;
				rc |= AUDIO_IF_ERR_DRV_SPK | AUDIO_IF_ERR_FAILED;
			}
		}

		if (rc == AUDIO_IF_ERR_NONE)
		{
			DSBUFFERDESC BufDesc;
			WAVEFORMATEX BufFmt;


			// 80ms, mono, 16 bits
			memset(&BufFmt, 0, sizeof(BufFmt));
			BufFmt.wFormatTag = WAVE_FORMAT_PCM;//it was 1 originally
			BufFmt.nChannels = 1;
			BufFmt.nSamplesPerSec = AUDIO_DRV_FS;
			BufFmt.wBitsPerSample = 16;
			BufFmt.nAvgBytesPerSec = (BufFmt.wBitsPerSample >> 3) * BufFmt.nChannels * BufFmt.nSamplesPerSec;
			BufFmt.nBlockAlign = (BufFmt.wBitsPerSample >> 3) * BufFmt.nChannels;
			BufFmt.cbSize = 0;

			memset(&BufDesc, 0, sizeof(BufDesc));
			BufDesc.dwSize = sizeof(BufDesc);
			BufDesc.dwFlags =	DSBCAPS_GLOBALFOCUS|
	//							DSBCAPS_CTRLPOSITIONNOTIFY|
	//							DSBCAPS_LOCDEFER |
	//							DSBCAPS_STATIC|
								0;

			BufDesc.dwBufferBytes = AUDIO_DRV_SPK_BUF_SZ;
			BufDesc.dwReserved = 0;
			BufDesc.lpwfxFormat = &BufFmt;
			BufDesc.guid3DAlgorithm = GUID_NULL;

			hr =  pSpk->pDs->CreateSoundBuffer(&BufDesc, &pSpk->pDsBuf, NULL);
			if (hr != DS_OK)
			{
				audio_log_err("audio_drv_spk_init -- buff create failed with 0x%x", hr);
				rc |= AUDIO_IF_ERR_DRV_SPK | AUDIO_IF_ERR_FAILED;
			}
		}
	}
	else
	{
		audio_log_err("audio_drv_spk_init -- create failed with hr = 0x%x", hr);
		rc |= AUDIO_IF_ERR_DRV_SPK | AUDIO_IF_ERR_FAILED;

	}
	pSpk->dwED = AUDIO_ED;
	pSpk->dwSD = AUDIO_SD;
	return rc;
}
/*****************************************************************************/
DWORD					audio_drv_spk_start
/*****************************************************************************/
(
)
{
	unsigned long rc = AUDIO_IF_ERR_NONE;
	Audio_tDrvSpk *pSpk = &gAudio.Drv.Spk;
	HRESULT hr;
	void *pv1;
	DWORD dwSz1;

	hr = pSpk->pDsBuf->Lock( 0, // from
					AUDIO_DRV_SPK_BLK_SZ*AUDIO_DRV_SPK_PRIME, // sz
					&pv1, &dwSz1,
					NULL, NULL,
					0);//DSBLOCK_ENTIREBUFFER);
	if (hr == DS_OK)
	{
		char *pc1 = (char*)pv1;
		for (int k = 0; k < AUDIO_DRV_SPK_BLKS; k++, pc1 += AUDIO_DRV_SPK_BLK_SZ)
		{
//					memcpy(pc1, _asSine1k, AUDIO_DRV_SPK_BLK_SZ);
			memset(pc1, 0, AUDIO_DRV_SPK_BLK_SZ);
		}
		hr = pSpk->pDsBuf->Unlock(pv1, AUDIO_DRV_SPK_BLK_SZ*AUDIO_DRV_SPK_PRIME, NULL, 0);
		pSpk->dwWriteOffset = AUDIO_DRV_SPK_BLK_SZ*AUDIO_DRV_SPK_PRIME;
		pSpk->dwReadOffset = 0;
		pSpk->iLookAhead = AUDIO_DRV_SPK_PRIME;


		if (hr == DS_OK)
		{
			hr = pSpk->pDsBuf->SetCurrentPosition(0);

			hr = pSpk->pDsBuf->Play(0, 0, DSBPLAY_LOOPING);
			if (hr != DS_OK)
				audio_log_err("audio_drv_spk_start -- play failed with 0x%x", hr);
			else
				audio_log_inf("audio_drv_spk_start -- started");

//			DWORD dwROffset = 123;
//			DWORD dwWOffset = 456;
//			m_pDsBuf->GetCurrentPosition(&dwROffset, &dwWOffset);
//			audio_log_inf("AudioDrvSpk::spk_init -- r %d, w %d", dwROffset, dwWOffset);

		}
		else
		{
			audio_log_err("audio_drv_spk_start -- unlock failed with 0x%x", hr);
			rc |= AUDIO_IF_ERR_DRV_SPK | AUDIO_IF_ERR_FAILED;
		}
	}
	else
	{
		audio_log_err("audio_drv_spk_init -- lock failed with 0x%x", hr);
		rc |= AUDIO_IF_ERR_DRV_SPK | AUDIO_IF_ERR_FAILED;
	}
	return rc;
}
/*****************************************************************************/
DWORD					audio_drv_spk_poll
/*****************************************************************************/
(
bool *pbOutOfSinc,
bool *pbDelayAdded
)
{
	Audio_tDrvSpk *pSpk = &gAudio.Drv.Spk;
	DWORD rc = AUDIO_IF_ERR_NONE;
	DWORD dwWriteOffset;
	HRESULT hr;

	*pbOutOfSinc = false;
	*pbDelayAdded = false;

	// events can be seriosly late, and we may need to fill more than one blk
	if ((pSpk->dwED != AUDIO_ED) || (pSpk->dwSD != AUDIO_SD))
	{
		audio_log_err("audio_drv_spk_poll -- in mem corupted");
		return AUDIO_IF_ERR_MEM_CORRUPTED;
	}

	for (;;)
	{
		audio_tmr_start(AUDIO_TMR_SPK_POLL);
		// dwWriteOffset : where we can write from
		hr = pSpk->pDsBuf->GetCurrentPosition(NULL, &dwWriteOffset);
		if (hr == DS_OK)
		{
			int iDlt = 0;
			// m_dwWriteOffset must be ahead of dwWriteOffset by a blk or two
			// what if we are not allowed to write where we need to ???
			if (dwWriteOffset > pSpk->dwWriteOffset)
			{
				// check if it is a wrap-around
				iDlt = (AUDIO_DRV_SPK_BUF_SZ - dwWriteOffset)+pSpk->dwWriteOffset;
				if (iDlt > AUDIO_DRV_SPK_BUF_SZ/2)
				{
					audio_hstgm_add(&gAudio.TmrCtrl.aTmr[AUDIO_TMR_SPK_OVERRUN].Hstgm, 
						(AUDIO_DRV_SPK_BUF_SZ-iDlt) /(2.e-3F*AUDIO_DRV_FS));

					*pbOutOfSinc = true;

					pSpk->fCrit += AUDIO_CRIT_MAX/3;

					audio_log_err("audio_drv_spk_poll -- overrun: %d ahead of %d, crit %7.3f", 
						dwWriteOffset, pSpk->dwWriteOffset, pSpk->fCrit);

					if (pSpk->fCrit > AUDIO_CRIT_MAX)
					{
						if (pSpk->iLookAhead < AUDIO_DRV_SPK_BLKS/2)
						{
							// add delay
							pSpk->dwWriteOffset += AUDIO_DRV_SPK_BLK_SZ;
							if (pSpk->dwWriteOffset >= AUDIO_DRV_SPK_BUF_SZ)
							{
								pSpk->dwWriteOffset -= AUDIO_DRV_SPK_BUF_SZ;
							}
							pSpk->fCrit = 0.F;
							audio_log_war("audio_drv_spk_poll -- adding bulk delay"); 

							*pbDelayAdded = true;
							pSpk->iLookAhead++;
						}
						else
						{
							audio_log_err("audio_drv_spk_poll -- unable to add bulk delay, already %d blks", pSpk->iLookAhead); 
						}
					}
					// TODO: reset all
				}
			}

			// see if a blk was read - and we can write a next block
			if (dwWriteOffset > pSpk->dwReadOffset)
			{
				iDlt = dwWriteOffset - pSpk->dwReadOffset;
			}
			else if (dwWriteOffset < pSpk->dwReadOffset) // wrap-around
			{
				iDlt = (AUDIO_DRV_SPK_BUF_SZ - pSpk->dwReadOffset)+dwWriteOffset;
			}
			else // ==
			{
				iDlt = 0;
			}

			if (iDlt > AUDIO_DRV_SPK_BLK_SZ)
			{
				void *pv1;
				DWORD dwSz1;
				hr = pSpk->pDsBuf->Lock(pSpk->dwWriteOffset, 
								AUDIO_DRV_SPK_BLK_SZ, // sz
								&pv1, &dwSz1,
								NULL, NULL,
								0);
				if (hr == DS_OK)
				{
					if (dwSz1 < AUDIO_DRV_SPK_BLK_SZ)
						audio_log_err("audio_drv_spk_poll -- size: %d < %d", dwSz1, AUDIO_DRV_SPK_BLK_SZ);
#if 0
					memcpy(pv1, _asSine1k, AUDIO_DRV_SPK_BLK_SZ);
#else
					if (pSpk->iQSz > 0)
					{
						memcpy(pv1, 
							&pSpk->asQ[pSpk->iQReadIdx*AUDIO_DRV_SPK_BLK_SZ/sizeof(short)],
							AUDIO_DRV_SPK_BLK_SZ);
						pSpk->iQReadIdx++;
						pSpk->iQReadIdx &= (AUDIO_DRV_SPK_QSZ-1);
						pSpk->iQSz--;
					}
					else
					{
						audio_log_err("audio_drv_spk_poll -- q starvation");
						memcpy(pv1, _asSine1k, AUDIO_DRV_SPK_BLK_SZ);
						*pbOutOfSinc = true;

						// TODO: reset AEC
					}
#endif

					hr = pSpk->pDsBuf->Unlock(pv1, AUDIO_DRV_SPK_BLK_SZ, NULL, 0);
					if (hr == DS_OK)
					{
						pSpk->dwReadOffset += AUDIO_DRV_SPK_BLK_SZ;
						if (pSpk->dwReadOffset >= AUDIO_DRV_SPK_BUF_SZ)
						{
							pSpk->dwReadOffset -= AUDIO_DRV_SPK_BUF_SZ;
						}
						pSpk->dwWriteOffset += AUDIO_DRV_SPK_BLK_SZ;
						if (pSpk->dwWriteOffset >= AUDIO_DRV_SPK_BUF_SZ)
						{
							pSpk->dwWriteOffset -= AUDIO_DRV_SPK_BUF_SZ;
						}
						audio_tmr_restart(AUDIO_TMR_SPK_BLK, NULL);

						// we allow 1 spike per minute, i.e. 3 per 3 minutes
						pSpk->fCrit -= AUDIO_CRIT_MAX/(100.0F*60.F*3.F);
						if (pSpk->fCrit < 0)
							pSpk->fCrit = 0;
					}
					else
					{
						audio_log_err("audio_drv_spk_poll -- unlock failed with 0x%x", hr);
						break;
					}
				}
				else
				{
					audio_log_err("audio_drv_spk_poll -- lock failed with 0x%x", hr);
					break;
				}
			}
			else //if (iDlt == 0)
			{
				audio_tmr_stop(AUDIO_TMR_SPK_POLL, NULL);
				break; // there is nothing to do
			}
		}
		else
		{
			audio_log_err("audio_drv_spk_poll -- get pos failed with 0x%x", hr);
			break;
		}
		audio_tmr_stop(AUDIO_TMR_SPK_POLL, NULL);
	}
	if (hr != DS_OK)
	{
		audio_tmr_stop(AUDIO_TMR_SPK_POLL, NULL);
		rc |= AUDIO_IF_ERR_DRV_SPK | AUDIO_IF_ERR_FAILED;
		*pbOutOfSinc = true;

	}
	if ((pSpk->dwED != AUDIO_ED) || (pSpk->dwSD != AUDIO_SD))
	{
		audio_log_err("audio_drv_spk_poll -- out mem corupted"); 
		rc = AUDIO_IF_ERR_MEM_CORRUPTED;
	}

	return rc;
}

//	DSBLOCK_FROMWRITECURSOR
/*****************************************************************************/
DWORD					audio_drv_spk_stop
/*****************************************************************************/
(
)
{
	gAudio.Drv.Spk.pDsBuf->Stop();
	gAudio.Drv.Spk.pDsBuf->Release();
	return AUDIO_IF_ERR_NONE;
}
