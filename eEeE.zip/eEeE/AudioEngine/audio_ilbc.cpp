#include "audio_defs.h"
#include "audio_ilbc.h"

/*****************************************************************************/
DWORD				audio_iLBC_decoder_init
/*****************************************************************************/
(
void *pObj
)
{
	iLBC_Dec_Inst_t *pDec = (iLBC_Dec_Inst_t*)pObj;
	initDecode(pDec, 20, 1); // 20 ms frame, enhancement on
	return 0;
}
/*****************************************************************************/
DWORD				audio_iLBC_encoder_init
/*****************************************************************************/
(
void *pObj
)
{
	iLBC_Enc_Inst_t *pEnc = (iLBC_Enc_Inst_t*)pObj;
	initEncode(pEnc, 20);
	return 0;
}
/*****************************************************************************/
int					audio_iLBC_decode
/*****************************************************************************/
(
void *pObj,
short *psOut,
BYTE *pcIn // can be NULL -> PLC
)
{
	iLBC_Dec_Inst_t *pDec = (iLBC_Dec_Inst_t*)pObj;
	float af[AUDIO_FRSZ8];

	if (pcIn)
	{
		iLBC_decode(af, pcIn, pDec, 1);
	}
	else
	{
		BYTE ac[AUDIO_CSZ_ILBC];
		memset(ac, 0, sizeof(ac));
		iLBC_decode(af, ac, pDec, 0);
	}
	for (int k = 0; k < AUDIO_FRSZ8; k++)
	{
		int i = int(af[k]);
		if (i > 32767)
			i = 32767;
		if (i < -32768)
			i = -32768;
		psOut[k] = short(i);
	}
	return AUDIO_FRSZ8;
}
/*****************************************************************************/
int					audio_iLBC_encode
/*****************************************************************************/
(
void *pObj,
BYTE *pcOut,
short *psIn
)
{
	iLBC_Enc_Inst_t *pEnc = (iLBC_Enc_Inst_t*)pObj;
	float af[AUDIO_FRSZ8];
	for (int k = 0; k < AUDIO_FRSZ8; k++)
	{
		af[k] = psIn[k];
	}

	iLBC_encode(pcOut,af, pEnc);
	return AUDIO_CSZ_ILBC;
}
#if 0
short initDecode(                   /* (o) Number of decoded
                                              samples */
       iLBC_Dec_Inst_t *iLBCdec_inst,  /* (i/o) Decoder instance */
       int mode,                       /* (i) frame size mode */
       int use_enhancer                /* (i) 1 to use enhancer
                                              0 to run without
                                                enhancer */
												){return 0;}

 void iLBC_decode(
       float *decblock,            /* (o) decoded signal block */
       BYTE *bytes,           /* (i) encoded signal bits */
       iLBC_Dec_Inst_t *iLBCdec_inst,  /* (i/o) the decoder state
                                                structure */
       int mode                    /* (i) 0: bad packet, PLC,
                                              1: normal */


											  ){}
short initEncode(                   /* (o) Number of bytes
                                              encoded */
       iLBC_Enc_Inst_t *iLBCenc_inst,  /* (i/o) Encoder instance */
       int mode                    /* (i) frame size mode */
	   ){return 0;}

void iLBC_encode(

       BYTE *bytes,           /* (o) encoded data bits iLBC */
       float *block,                   /* (o) speech vector to
                                              encode */
       iLBC_Enc_Inst_t *iLBCenc_inst   /* (i/o) the general encoder
                                              state */
											  ){}
#endif
