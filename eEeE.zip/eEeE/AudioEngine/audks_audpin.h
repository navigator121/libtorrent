//**@@@*@@@****************************************************
//
// Microsoft Windows
// Copyright (C) Microsoft Corporation. All rights reserved.
//
//**@@@*@@@****************************************************

//
// FileName:    audpin.h
//
// Abstract:    
//      This is the header file for C++ classes that expose
//      functionality of KS pins that support PCM audio formats
//

#pragma once
#ifndef __KSAUDPIN_H
#define __KSAUDPIN_H

// Forward Declarations
class CKsAudFilter;

////////////////////////////////////////////////////////////////////////////////
//
//  class CKsAudPin
//
//  Class Description:
//      This is the base class for an Audio pin.
//
//
//

class CKsAudPin : public CKsPin
{
public:
    // constructor
    CKsAudPin(CKsFilter* pFilter, ULONG nId, HRESULT *phr);

    // destructor
    virtual ~CKsAudPin(void);

    // Various other methods
    HRESULT SetFormat(const WAVEFORMATEX* pwfx);

    HRESULT GetPosition(KSAUDIO_POSITION* Pos);
	bool	Classify(bool bcapture);


protected:

private:
    HRESULT         Init(void);


    WAVEFORMATEX*               m_pWaveFormatEx;
    KSDATAFORMAT_WAVEFORMATEX*  m_pksDataFormatWfx; // Just a reference into m_pksPinCreate
};


#endif //__KSAUDPIN_H
