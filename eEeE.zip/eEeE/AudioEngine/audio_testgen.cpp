#include "audio_defs.h"
#include "audio_g711u.h"
enum {
	_DTMF_1,
	_DTMF_2,
	_DTMF_3,
	_DTMF_4,
	_DTMF_5,
	_DTMF_6,
	_DTMF_7,
	_DTMF_8,
	_DTMF_9,
	_DTMF_STAR,
	_DTMF_0,
	_DTMF_POUND,

	_DTMF_MAX
};

/*****************************************************************************/
static void				_nse
/*****************************************************************************/
(
short *psSeed,
float *psTo,
float fLevel
)
{
	fLevel *= (1.72F / 32768.F);
	short seed = *psSeed;

    for (int k = 0; k < AUDIO_FRSZ32; k++)
    {
        long ac0 = seed * 31821L;
        ac0 += 13849;
        seed = (short)ac0;

		float f = seed * fLevel;
		if (f > 1.0F)
			f = 1.0F;
		if (f < -1.0F)
			f = -1.0F;
		*psTo++ = f;
    }
	*psSeed = seed;
}
/*****************************************************************************/
static void				_lpf
/*****************************************************************************/
(
float *pfSav,
float *pfIo
)
{
	float sav = *pfSav;
	for (int k = 0; k < AUDIO_FRSZ32; k++)
	{
		sav = 0.9F * sav + 0.3F * pfIo[k];
		pfIo[k] = sav;
	}
	*pfSav = sav;
}
/*****************************************************************************/
static void				_sine
/*****************************************************************************/
(
float *pfPhase, /// 0...1 -> 0... 2pi
float fFreq,
float fAmplitude,
float *pfIo // at 0dBm
)
{
	float fPhase = *pfPhase;
#ifndef _WIN32_WCE
	float c  = cosf (fPhase * 2*AUDIO_PI);
	float s  = sinf (fPhase * 2*AUDIO_PI);
	float dc = cosf (fFreq * 2*AUDIO_PI);
	float ds = sinf (fFreq * 2*AUDIO_PI);
#else
	float c  = (float) cosl (fPhase * 2*AUDIO_PI);
	float s  = (float) sinl (fPhase * 2*AUDIO_PI);
	float dc = (float) cosl (fFreq * 2*AUDIO_PI);
	float ds = (float) sinl (fFreq * 2*AUDIO_PI);
#endif
	for (int k = 0; k < AUDIO_FRSZ32; k++)
	{
		float c1 = c * dc - s * ds;
		float s1 = c * ds + s * dc;
		pfIo[k] += s1 * fAmplitude;
		c = c1;
		s = s1;
	}
	
	fPhase += fFreq * AUDIO_FRSZ32;
	fPhase -= floorf(fPhase);
	*pfPhase = fPhase;
}

static const float _afFreq1[] = {
	697.F/AUDIO_FS32,
	697.F/AUDIO_FS32,
	697.F/AUDIO_FS32,
	770.F/AUDIO_FS32,
	770.F/AUDIO_FS32,
	770.F/AUDIO_FS32,
	852.F/AUDIO_FS32,
	852.F/AUDIO_FS32,
	852.F/AUDIO_FS32,
	941.F/AUDIO_FS32,
	941.F/AUDIO_FS32,
	941.F/AUDIO_FS32
};
static const float _afFreq2[] = {
	1209.F/AUDIO_FS32,
	1336.F/AUDIO_FS32,
	1477.F/AUDIO_FS32,
	1209.F/AUDIO_FS32,
	1336.F/AUDIO_FS32,
	1477.F/AUDIO_FS32,
	1209.F/AUDIO_FS32,
	1336.F/AUDIO_FS32,
	1477.F/AUDIO_FS32,
	1209.F/AUDIO_FS32,
	1336.F/AUDIO_FS32,
	1477.F/AUDIO_FS32
};

/*****************************************************************************/
void					audio_tg_dtmf
/*****************************************************************************/
(
Audio_tTestGenDtmf *pDtmf
)
{
	if (pDtmf->iQSz > 0)
	{
		for (int k = 0; k < AUDIO_FRSZ32; k++) pDtmf->afFrame[k] = 0.F;

		switch(pDtmf->wFrameCnt)
		{
		case 0:
			{
				WORD wDigit = pDtmf->awQDigits[pDtmf->wQIdxRead];
				pDtmf->fPhase1 = 0;
				pDtmf->fPhase2 = 0;
				pDtmf->fFreq1 = _afFreq1[wDigit];
				pDtmf->fFreq2 = _afFreq2[wDigit];
				break;
			}
		case 1:
		case 6:
		case 7:
			break;
		case 2:
		case 3:
		case 4:
		case 5:
			_sine(&pDtmf->fPhase1, pDtmf->fFreq1, 0.3976F*.7F, pDtmf->afFrame); // -5 dBm
			_sine(&pDtmf->fPhase2, pDtmf->fFreq2, 0.4212F*.7F, pDtmf->afFrame); // -4.5 dBm
			// if last, window it to 0
			break;
		}

		// a digit got executed
		pDtmf->wFrameCnt++;
		if (pDtmf->wFrameCnt == 8)
		{
			pDtmf->wQIdxRead++;
			pDtmf->wQIdxRead &= AUDIO_TEST_GEN_DTMF_QSZ-1;
			pDtmf->wFrameCnt = 0;
			pDtmf->iQSz--;
		}
	}
}
/*****************************************************************************/
DWORD					audio_tg_dtmf_add
/*****************************************************************************/
(
Audio_tTestGenDtmf *pDtmf,
char *pszDialingString
)
{
	DWORD rc = AUDIO_IF_ERR_NONE;
	if (pszDialingString)
	{
		while (*pszDialingString)
		{
			char c = *pszDialingString;
			WORD wDigit = _DTMF_MAX;
			switch(c)
			{
			case '0': wDigit = _DTMF_0;break;
			case '1': wDigit = _DTMF_1;break;
			case '2': wDigit = _DTMF_2;break;
			case '3': wDigit = _DTMF_3;break;
			case '4': wDigit = _DTMF_4;break;
			case '5': wDigit = _DTMF_5;break;
			case '6': wDigit = _DTMF_6;break;
			case '7': wDigit = _DTMF_7;break;
			case '8': wDigit = _DTMF_8;break;
			case '9': wDigit = _DTMF_9;break;
			case '*': wDigit = _DTMF_STAR;break;
			case '#': wDigit = _DTMF_POUND;break;
			}
			if (wDigit != _DTMF_MAX)
			{
				if (pDtmf->iQSz < AUDIO_TEST_GEN_DTMF_QSZ-1)
				{
					pDtmf->awQDigits[pDtmf->wQIdxWrite] = wDigit;
					pDtmf->wQIdxWrite ++;
					pDtmf->wQIdxWrite &= (AUDIO_TEST_GEN_DTMF_QSZ-1);
					pDtmf->iQSz++;
				}
				else
				{
					audio_log_err("audio_tg_dtmf_add -- dtmf q overflow"); // lose it
					rc |= AUDIO_IF_ERR_OVERFLOW;
					break;
				}
			}
			else
			{
				audio_log_err("audio_tg_dtmf_add -- invalid digit %c", c); // lose it
				rc |= AUDIO_IF_ERR_RANGE;
			}
			pszDialingString++;
		}
	}
	else
	{
		rc |= AUDIO_IF_ERR_INVALID_PARAM;
	}
	return rc;
}
/*****************************************************************************/
void					audio_tg_dtmf_stop
/*****************************************************************************/
(
Audio_tTestGenDtmf *pDtmf
)
{
	memset(pDtmf, 0, sizeof(*pDtmf));
}
/*****************************************************************************/
void					audio_tg_player
/*****************************************************************************/
(
Audio_tTestGen *pTg,
bool bRcvSide
)
{
	short as[AUDIO_FRSZ32];

	if (pTg->Player.fd && (!pTg->Player.bPause))
	{
		if (bRcvSide) // RCV side
		{
			if (pTg->Player.bPlay) 
			{
				int read = (int)fread(as, sizeof(short), AUDIO_FRSZ32, pTg->Player.fd);
				if (read != AUDIO_FRSZ32)
				{
					if (pTg->Player.bLoop)
					{
#ifndef _WIN32_WCE
						rewind(pTg->Player.fd);
#else
						fseek(pTg->Player.fd, 0, SEEK_SET);
#endif
						fread(&pTg->Player.WavHdr, sizeof(pTg->Player.WavHdr), 1, pTg->Player.fd);
						fread(as, sizeof(short), AUDIO_FRSZ32, pTg->Player.fd);
					}
					else // playing finished
					{
						fclose(pTg->Player.fd);
						memset(&pTg->Player, 0, sizeof(pTg->Player));
					}
				}
				if (pTg->Player.fd) // still active
					audio_utl_short2float(gAudio.afRcv, as);
			}
		}
		else  // SND side 
		{
			if (!pTg->Player.bPlay)// file is open, but not playing - i.e. recording
			{
				audio_utl_float2short(as, gAudio.afSnd);
				int written = (int)fwrite(as, sizeof(short), AUDIO_FRSZ32, pTg->Player.fd);
				pTg->Player.WavHdr.dwLen1 += sizeof(short)*written;
				pTg->Player.WavHdr.dwLen3 += sizeof(short)*written;
			}
		}
	}
}
/*****************************************************************************/
void					audio_tg_common
/*****************************************************************************/
(
Audio_tTestGen *pTg,
float *pfTo
)
{
	int k;

	switch(pTg->iMode)
	{
	case AUDIO_IF_TEST_GEN_MODE_WHITE_NOISE:
		for (k = 0; k < AUDIO_FRSZ32; k++) pfTo[k] = 0;
		_nse(&pTg->sSeed, pfTo, 0.1F);
		break;
	case AUDIO_IF_TEST_GEN_MODE_BROWN_NOISE:
		for (k = 0; k < AUDIO_FRSZ32; k++) pfTo[k] = 0;
		_nse(&pTg->sSeed, pfTo, 0.1F);
		_lpf(&pTg->fLpSav, pfTo);
		break;
	case AUDIO_IF_TEST_GEN_MODE_1000HZ:
		for (k = 0; k < AUDIO_FRSZ32; k++) pfTo[k] = 0;
		_sine(&pTg->fPhase, 1000.F/AUDIO_FS32, 0.1F, pfTo); // -5 dBm
		break;
	case AUDIO_IF_TEST_GEN_MODE_FREQ_SWEEP:
		for (k = 0; k < AUDIO_FRSZ32; k++) pfTo[k] = 0;
		pTg->fFreq *= 1.01F;
		if (pTg->fFreq < 0.45F)
		{
			_sine(&pTg->fPhase, pTg->fFreq, 0.1F, pfTo); // -5 dBm
		}
		else
		{
			// put silence
			if (pTg->fFreq > 0.5F) // loop back
				pTg->fFreq = 62.5F/AUDIO_FS32;
		}
		break;
	}
}
/*****************************************************************************/
void					audio_tg_player_stop
/*****************************************************************************/
(
Audio_tTestGen *pTg
)
{
	if (pTg->Player.fd)
	{
		if (!pTg->Player.bPlay) // record
		{
#ifndef _WIN32_WCE
			rewind(pTg->Player.fd);
#else
			fseek(pTg->Player.fd, 0, SEEK_SET);
#endif
			fwrite(&pTg->Player.WavHdr, sizeof(pTg->Player.WavHdr), 1, pTg->Player.fd);
		}
		fclose(pTg->Player.fd);
		pTg->Player.fd = NULL;
	}
}
/*****************************************************************************/
void					audio_tg_record_call
/*****************************************************************************/
(
Audio_tTestGen *pTg
)
{
	if (pTg->RecordCall.fd && 
		(!pTg->RecordCall.bPause))
	{
		float afOut32[AUDIO_FRSZ32];
		float afOut8[AUDIO_FRSZ8];
		short asOut8[AUDIO_FRSZ8];
		BYTE acOut8[AUDIO_FRSZ8];

		for (int k = 0; k < AUDIO_FRSZ32; k++)
		{
			afOut32[k] = gAudio.afMux[k] + gAudio.afSnd[k];
		}
		audio_utl_32to8(pTg->RecordCall.afDcmSav, afOut8, afOut32);
		audio_utl_float2short(asOut8, afOut8, AUDIO_FRSZ8);
		audio_G711U_encode(acOut8, asOut8);

		fwrite(acOut8, sizeof(char), AUDIO_FRSZ8, pTg->RecordCall.fd);
		pTg->RecordCall.WavHdr.dwLen1 += AUDIO_FRSZ8;
		pTg->RecordCall.WavHdr.dwLen3 += AUDIO_FRSZ8;
	}
}
/*****************************************************************************/
void					audio_test_gen_rcv
/*****************************************************************************/
(
)
{
	Audio_tTestGen *pTg = &gAudio.Tg;
	int k;

	audio_tg_common(pTg, gAudio.afRcv);
	audio_tg_player(pTg, true);
	if (pTg->Dtmf.iQSz)
	{
		audio_tg_dtmf(&pTg->Dtmf);

		// sidetone to be heard back
		for (k = 0; k < AUDIO_FRSZ32; k++) 
		{
			gAudio.afRcv[k] = pTg->Dtmf.afFrame[k]*0.25F;
		}
	}
}
/*****************************************************************************/
void					audio_test_gen_snd
/*****************************************************************************/
(
)
{
	Audio_tTestGen *pTg = &gAudio.Tg;
	int k;

	audio_tg_player(pTg, false);
	if (pTg->Dtmf.iQSz)
	{
		// on nominal level
		for (k = 0; k < AUDIO_FRSZ32; k++) 
		{
			gAudio.afSnd[k] = pTg->Dtmf.afFrame[k];
		}
	}
	if (pTg->iMode == AUDIO_IF_TEST_GEN_MODE_SND_1000HZ)
	{
		for (k = 0; k < AUDIO_FRSZ32; k++) gAudio.afSnd[k] = 0;
		_sine(&pTg->fPhase, 1000.F/AUDIO_FS32, 0.1F, gAudio.afSnd); 
	}
	audio_tg_record_call(pTg);
}
/*****************************************************************************/
DWORD					AudioIf_test_gen
/*****************************************************************************/
(
int iMode, 
char *pszFileName
)
{
	if (!gAudio.bInitialized) return AUDIO_IF_ERR_NOT_INITIALIZED;

	DWORD rc = AUDIO_IF_ERR_NONE;
	audio_lock();
	audio_log_inf("AudioIf_test_gen -- mode=%d file %s", 
		iMode, pszFileName);

	Audio_tTestGen *pTg = &gAudio.Tg;

	switch(iMode)
	{
	case AUDIO_IF_TEST_GEN_MODE_OFF:
		// stop everything
		audio_tg_player_stop(pTg);
		audio_tg_dtmf_stop(&pTg->Dtmf);
		pTg->iMode = iMode;
		break;

	// one of
	case AUDIO_IF_TEST_GEN_MODE_WHITE_NOISE: // -20 dBFS
	case AUDIO_IF_TEST_GEN_MODE_BROWN_NOISE: // -20 dBFS
		pTg->iMode = iMode;
		break;
	case AUDIO_IF_TEST_GEN_MODE_1000HZ:		// -12 dBFS
	case AUDIO_IF_TEST_GEN_MODE_SND_1000HZ:
		pTg->fFreq = 1000.F/AUDIO_FS32;
		pTg->fPhase = 0.F;
		pTg->iMode = iMode;
		break;
	case AUDIO_IF_TEST_GEN_MODE_FREQ_SWEEP:		// -12 dBFS
		pTg->fFreq = 62.5F/AUDIO_FS32;
		pTg->fPhase = 0.F;
		pTg->iMode = iMode;
		break;

	// 40ms of silence, dtmf for 80 ms, 40 ms of silence
	// SND output level is fixed at -10 dBFS per freq
	// RCV is "echoed" at -25 dBFS
	case AUDIO_IF_TEST_GEN_MODE_INBAND_DTMF: 
		rc |= audio_tg_dtmf_add(&pTg->Dtmf, pszFileName);
		pTg->iMode = iMode;
		break;

	case AUDIO_IF_TEST_GEN_MODE_PLAY_ONCE:
	case AUDIO_IF_TEST_GEN_MODE_PLAY_LOOP:
		if (pTg->Player.fd) // already open
		{
			if (!pTg->Player.bPlay) // it was recording
			{
#ifndef _WIN32_WCE
				rewind(pTg->Player.fd);
#else
				fseek(pTg->Player.fd, 0, SEEK_SET);
#endif
				fwrite(&pTg->Player.WavHdr, sizeof(pTg->Player.WavHdr), 1, pTg->Player.fd);
			}
			fclose(pTg->Player.fd);
			pTg->Player.fd = NULL;
		}
		pTg->Player.fd = fopen(pszFileName, "rb");
		if (pTg->Player.fd)
		{
			pTg->Player.bPlay = true;
			pTg->Player.bPause = false;
			pTg->Player.bLoop = (iMode == AUDIO_IF_TEST_GEN_MODE_PLAY_LOOP);
			pTg->iMode = iMode;
		}
		else
		{
			rc |= AUDIO_IF_ERR_FILE_IO;
		}
		break;
	case AUDIO_IF_TEST_GEN_MODE_PAUSE:
		pTg->Player.bPause = true;
		pTg->iMode = iMode;
		break;
	case AUDIO_IF_TEST_GEN_MODE_CONTINUE:
		pTg->Player.bPause = false;
		if (pTg->Player.bPlay)
		{
			if (pTg->Player.bLoop)
				pTg->iMode = AUDIO_IF_TEST_GEN_MODE_PLAY_LOOP;
			else
				pTg->iMode = AUDIO_IF_TEST_GEN_MODE_PLAY_ONCE;
		}
		else
			pTg->iMode = AUDIO_IF_TEST_GEN_MODE_RECORD;
		break;
	case AUDIO_IF_TEST_GEN_MODE_RECORD:
		if (pTg->Player.fd)
			fclose(pTg->Player.fd);
		pTg->Player.fd = fopen(pszFileName, "wb");
		if (pTg->Player.fd)
		{
			pTg->Player.bPlay = false;
			pTg->Player.bPause = false;
			audio_utl_set_wav(&pTg->Player.WavHdr);
			fwrite(&pTg->Player.WavHdr, sizeof(pTg->Player.WavHdr), 1, pTg->Player.fd);
			pTg->iMode = iMode;
		}
		else
		{
			rc |= AUDIO_IF_ERR_FILE_IO;
		}
		break;
	case AUDIO_IF_TEST_GEN_MODE_STOP:
		audio_tg_player_stop(pTg);
		pTg->iMode = AUDIO_IF_TEST_GEN_MODE_OFF;
		break;

	case AUDIO_IF_TEST_GEN_MODE_RECORD_CALL_START:
		pTg->RecordCall.fd = fopen(pszFileName, "wb");
		if (pTg->RecordCall.fd)
		{
			audio_utl_set_wav(&pTg->RecordCall.WavHdr, AUDIO_FS8);
			pTg->RecordCall.WavHdr.dwLen2 = 16; // chunk data sz
			pTg->RecordCall.WavHdr.wMode  = 7; // u-law
			pTg->RecordCall.WavHdr.wNumber = 1; // of channels
			pTg->RecordCall.WavHdr.dwFs = 8000;
			pTg->RecordCall.WavHdr.dwBps = 8000;
			pTg->RecordCall.WavHdr.wBytes = 1; // block align
			pTg->RecordCall.WavHdr.wBits = 8;

			fwrite(&pTg->RecordCall.WavHdr, sizeof(pTg->RecordCall.WavHdr),1, pTg->RecordCall.fd);
			pTg->RecordCall.bPause = false;
		}
		else
		{
			rc |= AUDIO_IF_ERR_FILE_IO;
		}
		break;
	case AUDIO_IF_TEST_GEN_MODE_RECORD_CALL_PAUSE:
		pTg->RecordCall.bPause = true;
		break;
	case AUDIO_IF_TEST_GEN_MODE_RECORD_CALL_CONTINUE:
		pTg->RecordCall.bPause = false;
		break;
	case AUDIO_IF_TEST_GEN_MODE_RECORD_CALL_STOP:
		if (pTg->RecordCall.fd)
		{
#ifndef _WIN32_WCE
			rewind(pTg->RecordCall.fd);
#else
			fseek(pTg->RecordCall.fd, 0, SEEK_SET);
#endif
			fwrite(&pTg->RecordCall.WavHdr, sizeof(pTg->RecordCall.WavHdr),1, pTg->RecordCall.fd);
			fclose(pTg->RecordCall.fd);
			pTg->RecordCall.fd = NULL;
		}
		else
		{
			rc |= AUDIO_IF_ERR_FILE_IO;
		}
		break;
	default:
		rc |= AUDIO_IF_ERR_INVALID_PARAM;
		break;
	}

	if (rc)
		audio_log_err("AudioIf_test_gen -- rc=0x%08x", rc);
	else
		audio_log_inf("AudioIf_test_gen -- done");
	audio_unlock();
	return rc;
}
/*****************************************************************************/
DWORD				AudioIf_test_gen
/*****************************************************************************/
(
int *piMode
)
{
	if (!gAudio.bInitialized) return AUDIO_IF_ERR_NOT_INITIALIZED;

	DWORD rc = AUDIO_IF_ERR_NONE;
	audio_lock();
	audio_log_inf("AudioIf_test_gen get -- p=%p", piMode);

	Audio_tTestGen *pTg = &gAudio.Tg;
	if (piMode)
	{
		*piMode = pTg->iMode;
	}
	else
	{
		rc |= AUDIO_IF_ERR_INVALID_PARAM;
	}

	if (rc)
		audio_log_err("AudioIf_test_gen get -- rc=0x%08x", rc);
	else
		audio_log_inf("AudioIf_test_gen get -- done");
	audio_unlock();
	return rc;
}