#include "audio_defs.h"
#include "audio_g711a.h"

#define	BIAS		 (0x84)		// Bias for linear code. 
#define CLIP         (8159)

#define SIGN_BIT     (0x80)
#define QUANT_MASK   (0xf)
#define NSEGS        (8)
#define SEG_SHIFT    (4)
#define SEG_MASK     (0x70)


static short G711ADecodeTable[256];

// ---------------------------------------------------------------------------
// Member functions
// ---------------------------------------------------------------------------


/*
 * alaw2pcm() - Convert an A-law value to 16-bit linear PCM
 *
 */
#if 0
int alaw2pcm(int	a_val)		
{
	int		t;      /* changed from "short" *drago* */
	int		seg;    /* changed from "short" *drago* */

	a_val ^= 0x55;

	t = (a_val & QUANT_MASK) << 4;
	seg = ((unsigned)a_val & SEG_MASK) >> SEG_SHIFT;
	switch (seg) {
	case 0:
		t += 8;
		break;
	case 1:
		t += 0x108;
		break;
	default:
		t += 0x108;
		t <<= seg - 1;
	}
	return ((a_val & SIGN_BIT) ? t : -t);
}
#else
static short alaw2pcm(BYTE	a_val)		
{
	a_val ^= 0x55;
	bool positive = (a_val & SIGN_BIT) ? true: false;

	short t = ((a_val & QUANT_MASK) << 4);
	BYTE seg = (a_val & SEG_MASK) >> SEG_SHIFT;
	switch (seg) {
	case 0:
		t += 8;
		break;
	case 1:
		t += 0x108;
		break;
	default:
		t += 0x108;
		t <<= (seg - 1);
	}
	return (positive) ? t : -t;
}
#endif


void audio_G711A_decoder_init()
{
	for (int	 c = 0; c < 256; c++) {
		G711ADecodeTable[c] = alaw2pcm((BYTE)c);
	}
}

int audio_G711A_decode(short *psOut, BYTE *pcIn)
{
	if (pcIn)
	{
		for (int k = 0; k < AUDIO_FRSZ8; k++)
		{
			*(psOut++) = G711ADecodeTable[*(pcIn++)];
		}
	}
	else
	{
		for (int k = 0; k < AUDIO_FRSZ8; k++)
		{
			*psOut++ = 0;
		}
	}
	return (AUDIO_FRSZ8);
}



// ---------------------------------------------------------------------------
// Member functions
// ---------------------------------------------------------------------------


static const int seg_aend[8] = {0x1F, 0x3F, 0x7F, 0xFF, 0x1FF, 0x3FF, 0x7FF, 0xFFF};

static BYTE G711AEncodeTable[1+65536/8];

static BYTE search( int val, const int *table, BYTE size)
{
	BYTE	i;		/* changed from "short" *drago* */

	for (i = 0; i < size; i++) {
		if (val <= *table++)
			return (i);
	}
	return (size);
}

/*
 * pcm2alaw() - Convert a 16-bit linear PCM value to 8-bit A-law
 *
 */
static BYTE pcm2alaw(short	pcm_val)        /* 2's complement (16-bit range) */
{
	BYTE		seg;
	BYTE		aval;
	bool    positive = true;

//	pcm_val = pcm_val >> 3;

	if (pcm_val < 0) 
	{
		positive = false;
		pcm_val = (-pcm_val);// - 1;
	}

	/* Convert the scaled magnitude to segment number. */
	seg = search(pcm_val, seg_aend, 8);

	/* Combine the sign, segment, and quantization bits. */

	if (seg >= 8)		/* out of range, return maximum value. */
	{
		aval = 0x7f;
	}
	else 
	{
		aval = seg << SEG_SHIFT;
		if (seg < 2)
			aval |= (pcm_val >> 1) & QUANT_MASK;
		else
			aval |= (pcm_val >> seg) & QUANT_MASK;
	}

	aval |= (positive) ? SIGN_BIT : 0;
	aval ^= 0x55;

	return aval;
}






void audio_G711A_encoder_init()
{
	for (short i = -4096; i < 4096; i++ ) {
		G711AEncodeTable[i+4096] = pcm2alaw(i);
	}
}

int audio_G711A_encode(BYTE *pcTo, short *psFrom)
{
	for (int k = 0; k < AUDIO_FRSZ8; k++)
	{
		register short sample = *(psFrom++);
		sample >>= 3;
		*(pcTo++) = G711AEncodeTable[sample+4096];
	}

	return AUDIO_FRSZ8;
}
