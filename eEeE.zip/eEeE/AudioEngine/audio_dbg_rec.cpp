#include "audio_defs.h"

static char *_apcName[] = 
{
	"audiorec_0_net_rcv",
	"audiorec_1_jb_in",
	"audiorec_2_jb_out",
	"audiorec_3_jb_mix",
	"audiorec_4_tst_rcv",
	"audiorec_5_volume",
	"audiorec_6_spk",
	"audiorec_7_mic",
	"audiorec_8_mic_flt",
	"audiorec_9_cancel",
	"audiorec_A_NLP",
	"audiorec_B_denoise",
	"audiorec_C_AGC",
	"audiorec_D_encoder",
	"audiorec_E_net_snd",
	"audiorec_F_16"
};



/* ------------------------------------------------------------------- */
void						audio_rec_pkt
/* ------------------------------------------------------------------- */
(
WORD	wPt,
WORD	wStream,
Audio_tRtpHdr*	pHdr,
BYTE *pcData,
WORD	wDataSz,
float	fArrived
)
{
	Audio_tDbgRec	*pRec  = &gAudio.Dbg.Rec;
	Audio_tDbgRecQ	*pRecQ = &gAudio.Dbg.Rec.Q;

	if (pRec->wMask & wPt)
	{
		if (pRecQ->lSz < AUDIO_DBG_RECQ_SZ-1)
		{
			int idx = pRecQ->lWriteIdx;
			pRecQ->aItem[idx].wType = AUDIO_DBG_REC_PKT;
			pRecQ->aItem[idx].wPt = wPt;
			pRecQ->aItem[idx].wStream = wStream;
			pRecQ->aItem[idx].iFrameNo = gAudio.Drv.iFrameNo;
			for (int k = 0; k < wDataSz; k++)
			{
				pRecQ->aItem[idx].u.Pkt.acData[k] = pcData[k]; 
			}
			pRecQ->aItem[idx].u.Pkt.Hdr = *pHdr; 
			pRecQ->aItem[idx].u.Pkt.wDataSz = wDataSz; 
			pRecQ->aItem[idx].u.Pkt.fArrived = fArrived; 

			pRecQ->lWriteIdx++;
			pRecQ->lWriteIdx &= (AUDIO_DBG_RECQ_SZ-1);
#ifndef _WIN32_WCE
			InterlockedIncrement(&pRecQ->lSz);
#else	
			InterlockedIncrement((LPLONG)&pRecQ->lSz);
#endif
			if (pRecQ->lSz > AUDIO_DBG_RECQ_SZ/2)
				SetEvent(gAudio.Dbg.ahEvents[AUDIO_DBG_EVENT_ACTION]);
		}
		else
			pRecQ->iOverflows++;
	}
	else
	{
		// we do not record this point
	}
}
/*****************************************************************************/
void					audio_rec_handle_pkt
/*****************************************************************************/
(
Audio_tDbgRec	*pRec, 
Audio_tDbgRecQItem *pItem
) 
{
	WORD wPt = pItem->wPt;
	WORD wStream = pItem->wStream;
	WORD wIdx = 0;

	if (wPt == 0) return; // shall not happen

	while (((1<<wIdx) & wPt) == 0) wIdx++;

	FILE *fd = pRec->aafd[wIdx][wStream];
	// if first pkt
	if (fd == NULL)
	{
		char acName[MAX_PATH];
		if (gAudio.Dbg.acRecFilesDirectory[0])
		{
			sprintf(acName, "%s%s%02d.txt", 
				gAudio.Dbg.acRecFilesDirectory,
				_apcName[wIdx], wStream);
			fd = fopen(acName, "w");
			if (fd)
			{
				audio_log_trc("audio_rec_handle_pkt -- \"%s\" open", acName);
				fprintf(fd, "%% frame Idx PT TimeStamp SeqNo ArrivedAt(s) DataSz Payload-Bytes   ");
				for (int k = 5; k < 160; k++)
				{
					fprintf(fd, "%02x ",k);
				}
				fprintf(fd, "\n");
			}
		}
		else 
		{
			; // rec disabled
		}
	}

	if (fd != NULL)
	{
#if 0
		fprintf(fd, "Frame %d\n", pItem->iFrameNo);
		fprintf(fd, "Idx %d\n", pItem->u.Pkt.Hdr.wIdx);
		fprintf(fd, "Payload %d\n", pItem->u.Pkt.Hdr.wPT);
		fprintf(fd, "TS %d\n", pItem->u.Pkt.Hdr.dwTS);
		fprintf(fd, "SN %d\n", pItem->u.Pkt.Hdr.wSN);
		fprintf(fd, "Arrived %f\n", pItem->u.Pkt.fArrived);
		fprintf(fd, "Data sz %d\n", pItem->u.Pkt.wDataSz);
#else
		fprintf(fd, "%7u %2u %2u %9u %5u %12.6f %4u  %% ", 
			pItem->iFrameNo,
			pItem->u.Pkt.Hdr.wIdx,
			pItem->u.Pkt.Hdr.wPT,
			pItem->u.Pkt.Hdr.dwTS,
			pItem->u.Pkt.Hdr.wSN,
			pItem->u.Pkt.fArrived*1e-3f,
			pItem->u.Pkt.wDataSz);
#endif
		for (int k = 0; k < pItem->u.Pkt.wDataSz; k++)
		{
			fprintf(fd, "%02x ",pItem->u.Pkt.acData[k]);
		}
		fprintf(fd, "\n");
		pRec->aafd[wIdx][wStream] = fd;
	}
}
/* ------------------------------------------------------------------- */
static void                audio_rec_pcm
/* ------------------------------------------------------------------- */
(
WORD	wType,
WORD	wPt,
WORD	wStream,
short*	psData,
WORD	wDataSz
)
{
	Audio_tDbgRec	*pRec  = &gAudio.Dbg.Rec;
	Audio_tDbgRecQ	*pRecQ = &gAudio.Dbg.Rec.Q;

	if (pRec->wMask & wPt)
	{
		if (pRecQ->lSz < AUDIO_DBG_RECQ_SZ-1)
		{
			int idx = pRecQ->lWriteIdx;
			pRecQ->aItem[idx].wType = wType;
			pRecQ->aItem[idx].wPt = wPt;
			pRecQ->aItem[idx].wStream = wStream;
			pRecQ->aItem[idx].iFrameNo = gAudio.Drv.iFrameNo;
			pRecQ->aItem[idx].u.Pcm.wDataSz = wDataSz;
			for (int k = 0; k < wDataSz; k++)
			{
				pRecQ->aItem[idx].u.Pcm.asData[k] = psData[k]; 
			}
			pRecQ->lWriteIdx++;
			pRecQ->lWriteIdx &= (AUDIO_DBG_RECQ_SZ-1);
#ifndef _WIN32_WCE
			InterlockedIncrement(&pRecQ->lSz);
#else
			InterlockedIncrement((LPLONG)&pRecQ->lSz);
#endif
			if (pRecQ->lSz > AUDIO_DBG_RECQ_SZ/2)
				SetEvent(gAudio.Dbg.ahEvents[AUDIO_DBG_EVENT_ACTION]);
		}
		else
			pRecQ->iOverflows++;
	}
	else
	{
		// we do not record this point
	}
}
/* ------------------------------------------------------------------- */
void						audio_recf8
/* ------------------------------------------------------------------- */
(
WORD	wPt,
WORD	wStream,
float   *pfData
)
{
	short asData[AUDIO_FRSZ8];
	audio_utl_float2short(asData, pfData, AUDIO_FRSZ8); 
	audio_rec_pcm(AUDIO_DBG_REC_PCM8, wPt, wStream, asData, AUDIO_FRSZ8);
}
/* ------------------------------------------------------------------- */
void						audio_recf32
/* ------------------------------------------------------------------- */
(
WORD	wPt,
WORD	wStream,
float   *pfData
)
{
	short asData[AUDIO_FRSZ32];
	audio_utl_float2short(asData, pfData, AUDIO_FRSZ32); 
	audio_rec_pcm(AUDIO_DBG_REC_PCM32, wPt, wStream, asData, AUDIO_FRSZ32);
}

/* ------------------------------------------------------------------- */
void						audio_recs8
/* ------------------------------------------------------------------- */
(
WORD	wPt,
WORD	wStream,
short   *psData
)
{
	audio_rec_pcm(AUDIO_DBG_REC_PCM8, wPt, wStream, psData, AUDIO_FRSZ8);
}
/* ------------------------------------------------------------------- */
void						audio_recf48
/* ------------------------------------------------------------------- */
(
WORD	wPt,
WORD	wStream,
float   *pfData
)
{
	short asData[AUDIO_FRSZ48];
	audio_utl_float2short(asData, pfData, AUDIO_FRSZ48); 
	audio_rec_pcm(AUDIO_DBG_REC_PCM48, wPt, wStream, asData, AUDIO_FRSZ48);
}
/* ------------------------------------------------------------------- */
void						audio_recs48
/* ------------------------------------------------------------------- */
(
WORD	wPt,
WORD	wStream,
short   *psData
)
{
	audio_rec_pcm(AUDIO_DBG_REC_PCM48, wPt, wStream, psData, AUDIO_FRSZ48);
}
/*****************************************************************************/
void					audio_rec_handle_pcm
/*****************************************************************************/
(
Audio_tDbgRec	*pRec, 
Audio_tDbgRecQItem *pItem,
DWORD dwFs
) 
{
	WORD wPt = pItem->wPt;
	WORD wStream = pItem->wStream;
	WORD wIdx = 0;

	if (wPt == 0) return; // shall not happen

	while (((1<<wIdx) & wPt) == 0) wIdx++;

	FILE *fd = pRec->aafd[wIdx][wStream];
	// if first pkt
	if (fd == NULL)
	{
		Audio_tWavHdr Hdr;
		char acName[MAX_PATH];
		if (gAudio.Dbg.acRecFilesDirectory[0])
		{
			sprintf(acName, "%s%s%02d.wav", 
				gAudio.Dbg.acRecFilesDirectory,
				_apcName[wIdx], wStream);
			fd = fopen(acName, "wb");
			audio_log_trc("audio_rec_handle_pcm -- \"%s\" open", acName);
			if (fd)
			{
				audio_utl_set_wav(&Hdr, dwFs);
				fwrite(&Hdr, sizeof(Hdr), 1, fd);
				pRec->aadwSz[wIdx][wStream] = 0;
				pRec->aadwFs[wIdx][wStream] = dwFs;
			}
		}
		else
		{
			; // rec disabled
		}
	}

	if (fd != NULL)
	{
		fwrite(pItem->u.Pcm.asData, sizeof(WORD), pItem->u.Pcm.wDataSz, fd);
		pRec->aadwSz[wIdx][wStream] += pItem->u.Pcm.wDataSz*sizeof(short); 
		pRec->aafd[wIdx][wStream] = fd;
	}
}
/*****************************************************************************/
void					audio_dbg_poll_rec
/*****************************************************************************/
(
) 
{
	Audio_tDbgRec	*pRec = &gAudio.Dbg.Rec;
	Audio_tDbgRecQ	*pRecQ = &gAudio.Dbg.Rec.Q;

	if (pRec->wMask) // if anything is enabled
	{
		while (pRecQ->lSz > 0)
		{
//			audio_log_trc("audio_dbg_poll_rec -- sz=%d", pRecQ->lSz);
			Audio_tDbgRecQItem *pItem = &pRecQ->aItem[pRecQ->iReadIdx];
			switch(pItem->wType)
			{
			case AUDIO_DBG_REC_PKT:
				audio_rec_handle_pkt(pRec, pItem);
				break;
			case AUDIO_DBG_REC_PCM8:
				audio_rec_handle_pcm(pRec, pItem, 8000);
				break;
			case AUDIO_DBG_REC_PCM32:
				audio_rec_handle_pcm(pRec, pItem, 32000);
				break;
			case AUDIO_DBG_REC_PCM48:
				audio_rec_handle_pcm(pRec, pItem, 48000);
				break;
			}
//			pHdr->ulLen1 += pRecQ->aItem[pRecQ->iReadIdx].wSz*sizeof(short);
//			pHdr->ulLen3 += pRecQ->aItem[pRecQ->iReadIdx].wSz*sizeof(short);

			pRecQ->iReadIdx++;
			pRecQ->iReadIdx &= (AUDIO_DBG_RECQ_SZ-1);

#ifndef _WIN32_WCE
			InterlockedDecrement(&pRecQ->lSz);
#else
			InterlockedDecrement((LPLONG)&pRecQ->lSz);
#endif
		}
	}
}
/*****************************************************************************/
int					audio_rec_close_pkt
/*****************************************************************************/
(
WORD wMask
)
{
	Audio_tDbgRec	*pRec = &gAudio.Dbg.Rec;
	int k = 0;
	if (pRec->wMask & wMask)
	{
		WORD wIdx = 0;
		while (((1<<wIdx) & wMask) == 0) wIdx++;

		for (WORD wStream = 0; wStream <= AUDIO_IF_PARTY_MAX; wStream++)
		{
			if (pRec->aafd[wIdx][wStream])
			{
				fclose(pRec->aafd[wIdx][wStream]);
				pRec->aafd[wIdx][wStream] = NULL;
				k++;
			}
		}
	}
	return k;
}
/*****************************************************************************/
int					audio_rec_close_pcm
/*****************************************************************************/
(
WORD wMask
)
{
	Audio_tDbgRec	*pRec = &gAudio.Dbg.Rec;
	int k = 0;
	if (pRec->wMask & wMask)
	{
		WORD wIdx = 0;
		while (((1<<wIdx) & wMask) == 0) wIdx++;

		for (WORD wStream = 0; wStream <= AUDIO_IF_PARTY_MAX; wStream++)
		{
			FILE *fd = pRec->aafd[wIdx][wStream];
			if (fd)
			{
#ifndef _WIN32_WCE
				rewind(fd);
#else
				fseek(fd, 0, SEEK_SET); //seek to start of the file.
#endif
				Audio_tWavHdr Hdr;
				audio_utl_set_wav(&Hdr, pRec->aadwFs[wIdx][wStream]);
				Hdr.dwLen1 += pRec->aadwSz[wIdx][wStream];
				Hdr.dwLen3 += pRec->aadwSz[wIdx][wStream];
				fwrite(&Hdr, sizeof(Hdr), 1, fd);
				fclose(fd);
				pRec->aafd[wIdx][wStream] = NULL;
				k++;
			}
		}
	}
	return k;
}
/*****************************************************************************/
void					audio_rec_close
/*****************************************************************************/
(
)
{
	int kpcm = 0; 
	int kpkt = 0; 
	audio_log_inf("audio_rec_close -- start closing all recordings");

	kpkt += audio_rec_close_pkt(AUDIO_IF_REC_NET_RCV);
	kpkt += audio_rec_close_pkt(AUDIO_IF_REC_JB_IN);
	kpcm += audio_rec_close_pcm(AUDIO_IF_REC_JB_OUT);
	kpcm += audio_rec_close_pcm(AUDIO_IF_REC_JB_MIX);
	kpcm += audio_rec_close_pcm(AUDIO_IF_REC_TST_GEN);
	kpcm += audio_rec_close_pcm(AUDIO_IF_REC_VOL);
	kpcm += audio_rec_close_pcm(AUDIO_IF_REC_SPK);
	kpcm += audio_rec_close_pcm(AUDIO_IF_REC_MIC);
	kpcm += audio_rec_close_pcm(AUDIO_IF_REC_MIC_FLT);
	kpcm += audio_rec_close_pcm(AUDIO_IF_REC_CNL);
	kpcm += audio_rec_close_pcm(AUDIO_IF_REC_NLP);
	kpcm += audio_rec_close_pcm(AUDIO_IF_REC_NRD);
	kpcm += audio_rec_close_pcm(AUDIO_IF_REC_AGC);
	kpcm += audio_rec_close_pcm(AUDIO_IF_REC_ENC);
	kpkt += audio_rec_close_pkt(AUDIO_IF_REC_NET_SND);

	audio_log_inf("audio_rec_close -- %d .txt and %d .wav files closed", kpkt, kpcm);
}
