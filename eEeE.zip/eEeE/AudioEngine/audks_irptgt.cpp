//**@@@*@@@****************************************************
//
// Microsoft Windows
// Copyright (C) Microsoft Corporation. All rights reserved.
//
//**@@@*@@@****************************************************

//
// FileName:    irptgt.cpp
//
// Abstract:    
//      This is the implementation file for the C++ base class which abstracts
//      common functionality in CKsFilter and CKsPin classes
//

#include "audks_common.h"

// String's for logging.  These match up with the enumerations in kssample.h
LPCSTR gpstrKsTechnology[] = {"Unknown","PCM Audio Render","PCM Audio Capture"};

////////////////////////////////////////////////////////////////////////////////
//
//  CKsIrpTarget::CKsIrpTarget()
//
//  Routine Description:
//
//      CKsIrpTarget Constructor.  
//  
//  Arguments:
//  
//      None
//  
//  Return Value:
//  
//     None
//  



CKsIrpTarget::CKsIrpTarget(HANDLE handle) 
    : m_handle(handle)
{ 
    AUDKS_TRACE_ENTER();

    ZeroMemory(&m_overlapped,sizeof(m_overlapped));
    m_overlapped.hEvent = CreateEvent(NULL,FALSE,FALSE,NULL);
    if (!m_overlapped.hEvent)
    {
        audio_log_err("CKsIrpTarget::SyncIoctl CreateEvent failed");
    }
    else
    {
        // Flag the event by setting the low-order bit so we
        // don't get completion port notifications.
        // Really! - see the description of the lpOverlapped parameter in
        // the docs for GetQueuedCompletionStatus
        m_overlapped.hEvent = (HANDLE)((DWORD_PTR)m_overlapped.hEvent | 0x1);
    }
    AUDKS_TRACE_LEAVE();
    return; 
}

CKsIrpTarget::~CKsIrpTarget
(
) 
{
    CloseHandle(m_overlapped.hEvent);
}

////////////////////////////////////////////////////////////////////////////////
//
//  CKsIrpTarget::CKsIrpTarget()
//
//  Routine Description:
//
//      CKsIrpTarget Constructor.  
//  
//  Arguments:
//  
//      None
//  
//  Return Value:
//  
//     None
//  



HANDLE CKsIrpTarget::GetHandle()
{ 
    AUDKS_TRACE_ENTER();
    
    AUDKS_TRACE_LEAVE();
    return m_handle; 
}

////////////////////////////////////////////////////////////////////////////////
//
//  CKsIrpTarget::IsValidHandle()
//
//  Routine Description:
//
//      Quick and Dirty check to see if the handle is good.  Only checks against
//      a small number of known bad values.
//  
//  Arguments:
//  
//      HANDLE 
//  
//  Return Value:
//  
//      Returns TRUE unless the handle is NULL or INVALID_HANDLE_VALUE
//



BOOL CKsIrpTarget::IsValidHandle(HANDLE handle)
{
    AUDKS_TRACE_ENTER();
    BOOL bRet;

    bRet = !((handle == NULL) || (handle == INVALID_HANDLE_VALUE));

    AUDKS_TRACE_LEAVE();
    return bRet;
}

////////////////////////////////////////////////////////////////////////////////
//
//  CKsIrpTarget::SafeCloseHandle()
//
//  Routine Description:
//
//      Safely closes a file handle
//  
//  Arguments:
//  
//      HANDLE 
//  
//  Return Value:
//  
//     None
//


BOOL CKsIrpTarget::SafeCloseHandle(HANDLE &handle)
{
    AUDKS_TRACE_ENTER();
    BOOL bRet;
    bRet = TRUE;

    if (IsValidHandle(handle))
    {
        bRet = CloseHandle(handle);
        handle = INVALID_HANDLE_VALUE;
    }

    AUDKS_TRACE_LEAVE();
    return bRet;
}


////////////////////////////////////////////////////////////////////////////////
//
//  CKsIrpTarget::Close()
//
//  Routine Description:
//
//      Close the Irp Target
//  
//  Arguments:
//  
//      None 
//  
//  Return Value:
//  
//     None
//


BOOL CKsIrpTarget::Close()
{
    AUDKS_TRACE_ENTER();
    BOOL bRet = TRUE;
    
    bRet = SafeCloseHandle(m_handle);
    
    AUDKS_TRACE_LEAVE();
    return bRet;
}
////////////////////////////////////////////////////////////////////////////////
//
//  CKsIrpTarget::xxx()
//
//  Routine Description:
//
//      SyncIoctl
//  
//  Arguments:
//  
//      IN  HANDLE  handle -- The file handle to send the IOCTL to
//      IN  ULONG   ulIoctl -- The IOCTL to send
//      IN  PVOID   pvInBuffer -- Pointer to the input buffer
//      IN  ULONG   cbInBuffer -- Size in bytes of the input buffer
//      OUT PVOID   pvOutBuffer -- Pointer to the output buffer
//      OUT ULONG   cbOutBuffer -- Size in bytes of the output buffer
//      OUT PULONG  pulBytesReturned -- The number of bytes written to the
//          output buffer.
//  
//  Return Value:
//  
//     S_OK on success
//



HRESULT CKsIrpTarget::SyncIoctl(
        IN  HANDLE  handle,
        IN  ULONG   ulIoctl,
        IN  PVOID   pvInBuffer,
        IN  ULONG   cbInBuffer,
        OUT PVOID   pvOutBuffer,
        OUT ULONG   cbOutBuffer,
        OUT PULONG  pulBytesReturned)
{
    AUDKS_TRACE_ENTER();
    HRESULT hr = S_OK;
    OVERLAPPED overlapped;
        BOOL fRes = TRUE;
        ULONG ulBytesReturned;

    if (!IsValidHandle(handle))
    {
        hr = E_FAIL;
        audio_log_err("CKsIrpTarget::SyncIoctl Invalid Handle");
    }
    
    if (!pulBytesReturned)
    {
        pulBytesReturned = &ulBytesReturned;
    }

    if (SUCCEEDED(hr))
    {
        ZeroMemory(&overlapped,sizeof(overlapped));
        overlapped.hEvent = CreateEvent(NULL,FALSE,FALSE,NULL);
        if (!overlapped.hEvent)
        {
            hr = E_OUTOFMEMORY;
            audio_log_trc("CKsIrpTarget::SyncIoctl CreateEvent failed");
        }
        else
        {
            // Flag the event by setting the low-order bit so we
            // don't get completion port notifications.
            // Really! - see the description of the lpOverlapped parameter in
            // the docs for GetQueuedCompletionStatus
            overlapped.hEvent = (HANDLE)((DWORD_PTR)overlapped.hEvent | 0x1);
        }
    }

    if (SUCCEEDED(hr))
    {
        fRes = DeviceIoControl(handle, ulIoctl, pvInBuffer, cbInBuffer, pvOutBuffer, cbOutBuffer, pulBytesReturned, &overlapped);
        if (!fRes)
        {

            DWORD dwError = GetLastError();
            if (ERROR_IO_PENDING == dwError)
            {
                DWORD dwWait;
                // Wait for completion
                dwWait = ::WaitForSingleObject(overlapped.hEvent,INFINITE);
                assert(WAIT_OBJECT_0 == dwWait);
                if (dwWait != WAIT_OBJECT_0)
                {
                    hr = E_FAIL;
                    audio_log_err("CKsIrpTarget::SyncIoctl WaitForSingleObject failed dwWait:0x%08x",dwWait);
                }
            }
            else if (((ERROR_INSUFFICIENT_BUFFER == dwError) || (ERROR_MORE_DATA == dwError)) &&
                (IOCTL_KS_PROPERTY == ulIoctl) &&
                (cbOutBuffer == 0))
            {
                hr = S_OK;
                fRes = TRUE;
            }
            else
            {
                audio_log_err("CKsIrpTarget::SyncIoctl dwErr:0x%08x",dwError);
                hr = E_FAIL;
            }
        }
        if (!fRes) *pulBytesReturned = 0;
        SafeCloseHandle(overlapped.hEvent);
    }
    
    AUDKS_TRACE_LEAVE_HRESULT(hr);
    return hr;
}

////////////////////////////////////////////////////////////////////////////////
//
//  CKsIrpTarget::PropertySetSupport()
//
//  Routine Description:
//      Query to see if a property set is supported
//  
//  Arguments:
//      The GUID of the property set 
//  
//  Return Value:
//  
//      S_OK if the Property set is supported
//      S_FALSE if the property set is unsupported
//


HRESULT CKsIrpTarget::PropertySetSupport(
    IN  REFGUID  guidPropertySet)
{
    AUDKS_TRACE_ENTER();
    HRESULT hr = S_OK;

    ULONG ulReturned;
    KSPROPERTY ksProperty;

    ZeroMemory(&ksProperty,sizeof(ksProperty));

    ksProperty.Set = guidPropertySet;
    ksProperty.Id = 0;
    ksProperty.Flags = KSPROPERTY_TYPE_SETSUPPORT;

    hr = SyncIoctl(
        m_handle, 
        IOCTL_KS_PROPERTY, 
        &ksProperty, 
        sizeof(ksProperty), 
        NULL, 
        0, 
        &ulReturned);
    
    AUDKS_TRACE_LEAVE_HRESULT(hr);
    return hr;
}

////////////////////////////////////////////////////////////////////////////////
//
//  CKsIrpTarget::PropertyBasicSupport()
//
//  Routine Description:
//      Get the basic support information for this KSPROPERTY
//  
//  Arguments:
//      guidPropetySet -- The guid of the property set
//      nProperty   -- The property in the property set
//      pdwSupport -- The support information for the property
//  
//  Return Value:
//  
//     S_OK on success
//


HRESULT CKsIrpTarget::PropertyBasicSupport(
    IN  REFGUID guidPropertySet,
    IN  ULONG   nProperty,
    OUT PDWORD  pdwSupport
)
{
    AUDKS_TRACE_ENTER();
    HRESULT hr = S_OK;

    ULONG ulReturned;
    KSPROPERTY ksProperty;

    ZeroMemory(&ksProperty,sizeof(ksProperty));

    ksProperty.Set = guidPropertySet;
    ksProperty.Id = nProperty;
    ksProperty.Flags = KSPROPERTY_TYPE_BASICSUPPORT;

    hr = SyncIoctl(
            m_handle,
            IOCTL_KS_PROPERTY,
            &ksProperty,
            sizeof(ksProperty),
            pdwSupport,
            sizeof(DWORD),
            &ulReturned);
    
    AUDKS_TRACE_LEAVE_HRESULT(hr);
    return hr;
}

////////////////////////////////////////////////////////////////////////////////
//
//  CKsIrpTarget::GetPropertySimple()
//
//  Routine Description:
//      Gets a simple property;
//  
//  Arguments:
//      All the stuff for a property call
//  
//  Return Value:
//     S_OK on success
//


HRESULT CKsIrpTarget::GetPropertySimple(
    IN          REFGUID guidPropertySet,
    IN          ULONG   nProperty,
    OUT         PVOID   pvValue,
    OUT         ULONG   cbValue,
    OPTIONAL IN PVOID   pvInstance,
    OPTIONAL IN ULONG   cbInstance)
{
    AUDKS_TRACE_ENTER();
    HRESULT hr = S_OK;
    ULONG ulReturned = 0;
    PKSPROPERTY pKsProperty = NULL;
    ULONG cbProperty = 0;

    cbProperty = sizeof(KSPROPERTY) + cbInstance;
    pKsProperty = (PKSPROPERTY)new BYTE[cbProperty];
    if (NULL == pKsProperty)
    {
        hr = E_OUTOFMEMORY;
    }

    if (SUCCEEDED(hr))
    {
        ZeroMemory(pKsProperty,sizeof(*pKsProperty));
        pKsProperty->Set = guidPropertySet;
        pKsProperty->Id = nProperty;
        pKsProperty->Flags = KSPROPERTY_TYPE_GET;

        if (pvInstance)
        {
            CopyMemory(reinterpret_cast<BYTE*>(pKsProperty) + sizeof(KSPROPERTY),pvInstance,cbInstance);
        }

        hr = SyncIoctl(
                m_handle,
                IOCTL_KS_PROPERTY,
                pKsProperty,
                cbProperty,
                pvValue,
                cbValue,
                &ulReturned);
    }    

    //cleanup memory
    delete[] (BYTE*)pKsProperty;
    pKsProperty = NULL;
    
    AUDKS_TRACE_LEAVE_HRESULT(hr);
    return hr;
}

HRESULT CKsIrpTarget::GetPropertySimpleFast // get position only
	(
    IN          REFGUID guidPropertySet,
    IN          ULONG   nProperty,
    OUT         PVOID   pvValue,
    OUT         ULONG   cbValue
	)
{
    HRESULT hr = S_OK;
    ULONG ulReturned = 0;
    KSPROPERTY KsProperty;
    PKSPROPERTY pKsProperty = &KsProperty;
    ULONG cbProperty = sizeof(KsProperty);

    ZeroMemory(pKsProperty,sizeof(*pKsProperty));
    pKsProperty->Set = guidPropertySet;
    pKsProperty->Id = nProperty;
    pKsProperty->Flags = KSPROPERTY_TYPE_GET;

    BOOL fRes = DeviceIoControl(
					m_handle, 
					IOCTL_KS_PROPERTY, 
					pKsProperty, 
					sizeof(KsProperty), 
					pvValue, 
					cbValue, 
					&ulReturned, 
					&m_overlapped); // not used, actually
    if (!fRes)
    {
        DWORD dwError = GetLastError();
        if (ERROR_IO_PENDING == dwError)
        {
            DWORD dwWait = ::WaitForSingleObject(m_overlapped.hEvent,INFINITE);
            if (dwWait != WAIT_OBJECT_0)
            {
                hr = E_FAIL;
                audio_log_err("CKsIrpTarget::GetPropertySimpleFast WaitForSingleObject failed dwWait:0x%08x",dwWait);
            }
//			printf(".");
        }
        else
        {
            audio_log_err("CKsIrpTarget::GetPropertySimpleFast dwErr:0x%08x",dwError);
            hr = E_FAIL;
        }
    }
//    if (!fRes) ulReturned = 0;
    return hr;
}


////////////////////////////////////////////////////////////////////////////////
//
//  CKsIrpTarget::GetPropertyMulti()
//
//  Routine Description:
//      MultipleItem request.  The function allocates memory for the 
//      caller.  It is the caller's responsiblity to free this memory
//  
//  Arguments:
//  
//      HANDLE 
//  
//  Return Value:
//  
//     S_OK on success
//


HRESULT CKsIrpTarget::GetPropertyMulti(
    IN  REFGUID             guidPropertySet,
    IN  ULONG               nProperty,
    OUT PKSMULTIPLE_ITEM*   ppKsMultipleItem)
{
    AUDKS_TRACE_ENTER();
    HRESULT hr = S_OK;

    ULONG cbMultipleItem = 0;
    ULONG ulReturned = 0;
    KSPROPERTY ksProperty;

    ZeroMemory(&ksProperty, sizeof(ksProperty));
    ksProperty.Set = guidPropertySet;
    ksProperty.Id = nProperty;
    ksProperty.Flags = KSPROPERTY_TYPE_GET;

    hr = SyncIoctl(
            m_handle,
            IOCTL_KS_PROPERTY,
            &ksProperty,
            sizeof(KSPROPERTY),
            NULL,
            0,
            &cbMultipleItem);
    if (SUCCEEDED(hr) && cbMultipleItem)
    {
        *ppKsMultipleItem = (PKSMULTIPLE_ITEM) new BYTE[cbMultipleItem];
        if (NULL == *ppKsMultipleItem)
        {
            hr = E_OUTOFMEMORY;
        }
    }

    if (SUCCEEDED(hr) && cbMultipleItem)
    {
        hr = SyncIoctl(
                m_handle,
                IOCTL_KS_PROPERTY,
                &ksProperty,
                sizeof(ksProperty),
                reinterpret_cast<VOID*>(*ppKsMultipleItem),
                cbMultipleItem,
                &ulReturned);
    }
    
    AUDKS_TRACE_LEAVE_HRESULT(hr);
    return hr;
}


////////////////////////////////////////////////////////////////////////////////
//
//  CKsIrpTarget::GetPropertyMulti()
//
//  Routine Description:
//      MultipleItem request for when the input is not a property
//      The function allocates memory for the 
//      caller.  It is the caller's responsiblity to free this memory
//  
//  Arguments:
//  
//      HANDLE 
//  
//  Return Value:
//  
//     S_OK on success
//


HRESULT CKsIrpTarget::GetPropertyMulti(
    IN  REFGUID             guidPropertySet,
    IN  ULONG               nProperty,
    IN  PVOID               pvData,
    IN  ULONG               cbData,
    OUT PKSMULTIPLE_ITEM*   ppKsMultipleItem)
{
    AUDKS_TRACE_ENTER();
    HRESULT hr = S_OK;

    ULONG cbMultipleItem = 0;
    ULONG ulReturned = 0;
    KSPROPERTY ksProperty;

    ZeroMemory(&ksProperty, sizeof(ksProperty));
    ksProperty.Set = guidPropertySet;
    ksProperty.Id = nProperty;
    ksProperty.Flags = KSPROPERTY_TYPE_GET;

    hr = SyncIoctl(
            m_handle,
            IOCTL_KS_PROPERTY,
            &ksProperty,
            sizeof(KSPROPERTY),
            NULL,
            0,
            &cbMultipleItem);
    if (SUCCEEDED(hr) && cbMultipleItem)
    {
        *ppKsMultipleItem = (PKSMULTIPLE_ITEM) new BYTE[cbMultipleItem];
        if (NULL == *ppKsMultipleItem)
        {
            hr = E_OUTOFMEMORY;
        }
    }

    if (SUCCEEDED(hr) && cbMultipleItem)
    {
        hr = SyncIoctl(
                m_handle,
                IOCTL_KS_PROPERTY,
                (PKSPROPERTY) pvData,
                cbData,
                reinterpret_cast<VOID*>(*ppKsMultipleItem),
                cbMultipleItem,
                &ulReturned);
    }
    
    AUDKS_TRACE_LEAVE_HRESULT(hr);
    return hr;
}



////////////////////////////////////////////////////////////////////////////////
//
//  CKsIrpTarget::SetPropertySimple()
//
//  Routine Description:
//
//      Set the value of a simple (non-multi) property
//  
//  Arguments:
//  
//      HANDLE 
//  
//  Return Value:
//  
//     S_OK on success
//


HRESULT CKsIrpTarget::SetPropertySimple(
    IN          REFGUID guidPropertySet,
    IN          ULONG   nProperty,
    OUT         PVOID   pvValue,
    OUT         ULONG   cbValue,
    OPTIONAL IN PVOID   pvInstance,
    OPTIONAL IN ULONG   cbInstance)
{
    AUDKS_TRACE_ENTER();
    HRESULT hr = S_OK;
    ULONG       ulReturned  = 0;
    PKSPROPERTY pksProperty = NULL;
    ULONG       cbProperty  = 0;

    cbProperty = sizeof(KSPROPERTY) + cbInstance;
    pksProperty = (PKSPROPERTY)new BYTE[cbProperty];
    if (NULL == pksProperty)
    {
        hr = E_OUTOFMEMORY;
    }

    if (SUCCEEDED(hr))
    {
        pksProperty->Set    = guidPropertySet; 
        pksProperty->Id     = nProperty;       
        pksProperty->Flags  = KSPROPERTY_TYPE_SET;

        if (pvInstance)
        {
            memcpy((PBYTE)pksProperty + sizeof(KSPROPERTY), pvInstance, cbInstance);
        }

        hr = SyncIoctl(
                m_handle,
                IOCTL_KS_PROPERTY,
                pksProperty,
                cbProperty,
                pvValue,
                cbValue,
                &ulReturned);
    }

    //cleanup memory
    delete[] (BYTE*)pksProperty;
    pksProperty = NULL;

    AUDKS_TRACE_LEAVE_HRESULT(hr);
    return hr;
}

////////////////////////////////////////////////////////////////////////////////
//
//  CKsIrpTarget::SetPropertyMulti()
//
//  Routine Description:
//
//      Blah Blah Blah
//  
//  Arguments:
//  
//      HANDLE 
//  
//  Return Value:
//  
//     S_OK on success
//


HRESULT CKsIrpTarget::SetPropertyMulti(
    IN  REFGUID             guidPropertySet,
    IN  ULONG               nProperty,
    OUT PKSMULTIPLE_ITEM*   ppKsMultipleItem)
{
    AUDKS_TRACE_ENTER();
    HRESULT hr = S_OK;
    ULONG       cbMultipleItem = 0;
    ULONG       ulReturned = 0;
    KSPROPERTY  ksProperty;

    ksProperty.Set    = guidPropertySet; 
    ksProperty.Id     = nProperty;       
    ksProperty.Flags  = KSPROPERTY_TYPE_SET;

    hr = SyncIoctl(
            m_handle,
            IOCTL_KS_PROPERTY,
            &ksProperty,
            sizeof(KSPROPERTY),
            NULL,
            0,
            &cbMultipleItem);

    if (SUCCEEDED(hr))
    {
        *ppKsMultipleItem = (PKSMULTIPLE_ITEM)LocalAlloc(LPTR, cbMultipleItem);
        
        hr = SyncIoctl (
                m_handle,
                IOCTL_KS_PROPERTY,
                &ksProperty,
                sizeof(KSPROPERTY),
                (PVOID)*ppKsMultipleItem,
                cbMultipleItem,
                &ulReturned);
    }

    AUDKS_TRACE_LEAVE_HRESULT(hr);
    return hr;
}


