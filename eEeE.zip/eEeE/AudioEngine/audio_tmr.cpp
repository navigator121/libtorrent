#define  AUDIO_DRV_TMR_C
#include "audio_defs.h"

/*****************************************************************************/
unsigned long				audio_tmr_init
/*****************************************************************************/
(
Audio_tTmrCtrl *pTmrCtrl
)
{
	unsigned long rc = AUDIO_IF_ERR_NONE;
	__int64 llTmp;

	memset(pTmrCtrl, 0, sizeof(*pTmrCtrl));
	
	BOOL bRC = QueryPerformanceFrequency((LARGE_INTEGER*)&llTmp);
	if (bRC && (llTmp != 0))
	{
		pTmrCtrl->llFreq = llTmp;
		pTmrCtrl->fInvFreq = float(1.0e3/double(llTmp));
		bRC = QueryPerformanceCounter((LARGE_INTEGER *)&pTmrCtrl->aTmr[0].llBase);
		if (bRC)
		{
			pTmrCtrl->aTmr[0].bRunning = true;
			for (int k = 0; k < AUDIO_TMR_MAX; k++)
			{
				rc |= audio_hstgm_init(&pTmrCtrl->aTmr[k].Hstgm, AUDIO_IF_HSTGM_MAX_SZ);
			}
			pTmrCtrl->bInitialized = true;
		SYSTEMTIME Time;
		GetLocalTime(&Time);
		audio_log_inf("audio_tmr_init -- started at %d/%d/%d %d\"%d'%d.%d, F0=%10.3f MHz",
			Time.wMonth,
			Time.wDay,
			Time.wYear,
			Time.wHour,
			Time.wMinute,
			Time.wSecond,
			Time.wMilliseconds,
			llTmp*1e-6);
		}
		else
		{
			rc = AUDIO_IF_ERR_TMR_HW_FAILURE;
		}
	}
	else
	{
		rc = AUDIO_IF_ERR_TMR_HW_FAILURE;
	}
	if (rc != AUDIO_IF_ERR_NONE)
		audio_log_err("audio_tmr_init -- failed with 0x%x",rc);

	return rc;
}
/*****************************************************************************/
unsigned long			audio_tmr_reset
/*****************************************************************************/
(
int iTmrId
)
{
	Audio_tTmr *pTmr = &gAudio.TmrCtrl.aTmr[iTmrId];
	memset(pTmr, 0, sizeof(*pTmr));
	return audio_hstgm_init(&pTmr->Hstgm, AUDIO_IF_HSTGM_MAX_SZ);
}
/*****************************************************************************/
unsigned long			audio_tmr_start
/*****************************************************************************/
(
int iTmrId
)
{
	unsigned long rc = AUDIO_IF_ERR_NONE;

	if (gAudio.TmrCtrl.bInitialized)
	{
		if ((iTmrId > 0) &&	(iTmrId < AUDIO_TMR_MAX))
		{
			Audio_tTmr *pTmr = &gAudio.TmrCtrl.aTmr[iTmrId];
			if (!pTmr->bRunning)
			{
				if (QueryPerformanceCounter((LARGE_INTEGER*)&pTmr->llBase))
				{
					pTmr->bRunning = true;
				}
				else
				{
					rc = AUDIO_IF_ERR_TMR_HW_FAILURE;
				}
			}
			else
			{
				rc = AUDIO_IF_ERR_STATE;
			}
		}
		else
		{
			rc = AUDIO_IF_ERR_RANGE;
		}
	}
	else
	{
		rc = AUDIO_IF_ERR_NOT_INITIALIZED;
	}
	if (rc != AUDIO_IF_ERR_NONE)
		audio_log_err("audio_tmr_start [%s] -- failed with 0x%x",aTmrName[iTmrId], rc);

	return rc;
}
/*****************************************************************************/
unsigned long			audio_tmr_stop
/*****************************************************************************/
(
int iTmrId,
float *pfTimeout
)
{
	unsigned long rc = AUDIO_IF_ERR_NONE;

	if (pfTimeout)
		*pfTimeout = 0;

	if (gAudio.TmrCtrl.bInitialized)
	{
		if ((iTmrId > 0) &&	(iTmrId < AUDIO_TMR_MAX))
		{
			Audio_tTmr *pTmr = &gAudio.TmrCtrl.aTmr[iTmrId];
			if (pTmr->bRunning)
			{
				__int64 llTmp;
				if (QueryPerformanceCounter((LARGE_INTEGER*)&llTmp))
				{
					__int64 llDlt = llTmp - pTmr->llBase;
					pTmr->fLast = float(double(llDlt) * gAudio.TmrCtrl.fInvFreq);
					audio_hstgm_add(&pTmr->Hstgm, pTmr->fLast);
					if (pfTimeout)
						*pfTimeout = pTmr->fLast;
					pTmr->bRunning = false;
				}
				else
				{
					rc = AUDIO_IF_ERR_TMR_HW_FAILURE;
				}
			}
			else
			{
				rc = AUDIO_IF_ERR_STATE;
			}
		}
		else
		{
			rc = AUDIO_IF_ERR_RANGE;
		}
	}
	else
	{
		rc = AUDIO_IF_ERR_NOT_INITIALIZED;
	}
	if (rc != AUDIO_IF_ERR_NONE)
		audio_log_err("audio_tmr_stop [%s] -- failed with 0x%x",aTmrName[iTmrId], rc);

	return rc;
}
/*****************************************************************************/
unsigned long			audio_tmr_restart
/*****************************************************************************/
(
int iTmrId,
float *pfTimeout
)
{
	unsigned long rc = AUDIO_IF_ERR_NONE;

	if (pfTimeout)
		*pfTimeout = 0;

	if (gAudio.TmrCtrl.bInitialized)
	{
		if ((iTmrId > 0) &&	(iTmrId < AUDIO_TMR_MAX))
		{
			Audio_tTmr *pTmr = &gAudio.TmrCtrl.aTmr[iTmrId];
			__int64 llTmp;
			if (QueryPerformanceCounter((LARGE_INTEGER*)&llTmp))
			{
				if (pTmr->bRunning)
				{
					__int64 llDlt = llTmp - pTmr->llBase;
					pTmr->fLast = float(double(llDlt) * gAudio.TmrCtrl.fInvFreq);
					audio_hstgm_add(&pTmr->Hstgm, pTmr->fLast);
					if (pfTimeout)
						*pfTimeout = pTmr->fLast;
				}
				pTmr->bRunning = true;
				pTmr->llBase = llTmp;
			}
			else
			{
				rc = AUDIO_IF_ERR_TMR_HW_FAILURE;
			}
		}
		else
		{
			rc = AUDIO_IF_ERR_RANGE;
		}
	}
	else
	{
		rc = AUDIO_IF_ERR_NOT_INITIALIZED;
	}
	if (rc != AUDIO_IF_ERR_NONE)
		audio_log_err("audio_tmr_restart [%s] -- failed with 0x%x",aTmrName[iTmrId], rc);
	return rc;
}
/*****************************************************************************/
unsigned long			audio_tmr_peek
/*****************************************************************************/
(
int iTmrId,
float *pfTimeout
)
{
	unsigned long rc = AUDIO_IF_ERR_NONE;
	*pfTimeout = 0;

	if (gAudio.TmrCtrl.bInitialized)
	{
		if ((iTmrId >= 0) && (iTmrId < AUDIO_TMR_MAX))
		{
			Audio_tTmr *pTmr = &gAudio.TmrCtrl.aTmr[iTmrId];
			__int64 llTmp;
			if (QueryPerformanceCounter((LARGE_INTEGER*)&llTmp))
			{
				if (pTmr->bRunning)
				{
					__int64 llDlt = llTmp - pTmr->llBase;
					float fDlt = float(double(llDlt) * gAudio.TmrCtrl.fInvFreq);
					*pfTimeout = fDlt;
				}
				else
				{
//					rc = AUDIO_IF_ERR_STATE | AUDIO_IF_ERR_WARNING;
					*pfTimeout = pTmr->fLast;
				}
			}
			else
			{
				rc = AUDIO_IF_ERR_TMR_HW_FAILURE;
			}
		}
		else
		{
			rc = AUDIO_IF_ERR_RANGE;
		}
	}
	else
	{
		rc = AUDIO_IF_ERR_NOT_INITIALIZED;
		*pfTimeout = -42;
	}
	return rc;
}
#include <stdio.h>
/*****************************************************************************/
DWORD					audio_tmr_dump
/*****************************************************************************/
(
char *pszFileName
)
{
	DWORD rc = AUDIO_IF_ERR_NONE;

	FILE *fd = fopen(pszFileName,"w");
	if (fd)
	{
		int k;
		int ms;
		fprintf(fd, "no TmrName average minimum maximum quant50 quant90 quant99    total_called ");
		for (ms = -1; ms < AUDIO_IF_HSTGM_MAX_SZ+1; ms++)
		{
			fprintf(fd, "%7d ", ms);
		}
		fprintf(fd, "\n");
			
		for (k = 0; k < AUDIO_TMR_MAX; k++)
		{
			audio_hstgm_analyse(&gAudio.TmrCtrl.aTmr[k].Hstgm);
			fprintf(fd, "%02d %7s %7.3f %7.3f %7.3f %7.3f %7.3f %7.3f %15d ",
				k,
				aTmrName[k],
				gAudio.TmrCtrl.aTmr[k].Hstgm.fAvrg,
				gAudio.TmrCtrl.aTmr[k].Hstgm.fMin,
				gAudio.TmrCtrl.aTmr[k].Hstgm.fMax,
				gAudio.TmrCtrl.aTmr[k].Hstgm.f50,
				gAudio.TmrCtrl.aTmr[k].Hstgm.f90,
				gAudio.TmrCtrl.aTmr[k].Hstgm.f99,
				gAudio.TmrCtrl.aTmr[k].Hstgm.iTotal);

			for (int ms = 0; ms < gAudio.TmrCtrl.aTmr[k].Hstgm.iRange; ms++)
			{
				fprintf(fd, "%7d ", gAudio.TmrCtrl.aTmr[k].Hstgm.aiData[ms]);
			}
			fprintf(fd, "\n");
		}
		fclose(fd);
	}
	else
	{
		rc = AUDIO_IF_ERR_FAILED;
	}
	return rc;
}
