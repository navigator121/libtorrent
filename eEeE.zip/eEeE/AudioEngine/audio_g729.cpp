#include "audio_defs.h"
#include "audio_g729.h"


/*****************************************************************************/
void *				audio_G729_decoder_init
/*****************************************************************************/
(
)
{
	int iSz = g729_decoder_sz();
	void *pv = AudioIf_alloc(iSz);
	g729_decoder_init(pv);
	return pv;
}
/*****************************************************************************/
void *				audio_G729_encoder_init
/*****************************************************************************/
(
void
)
{
	int iSz = g729_encoder_sz();
	void *pv = AudioIf_alloc(iSz);
	g729_encoder_init(pv);
	return pv;
}
/*****************************************************************************/
int					audio_G729_decode
/*****************************************************************************/
(
void *pvDec,
short *psOut,
BYTE *pcIn // can be NULL -> PLC 
)
{
	return g729_decode(pvDec, psOut, pcIn);
}
/*****************************************************************************/
int					audio_G729_encode
/*****************************************************************************/
(
void *pvEnc,
BYTE *pcOut,
short *psIn
)
{
	return g729_encode(pvEnc, pcOut, psIn);
}
