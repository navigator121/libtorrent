
#include "audio_defs.h"
#include "audio_g711u.h"

#define	BIAS		 (0x84)		// Bias for linear code. 
#define CLIP         (8159)

#define SIGN_BIT     (0x80)
#define QUANT_MASK   (0xf)
#define NSEGS        (8)
#define SEG_SHIFT    (4)
#define SEG_MASK     (0x70)

static short G711DecodeTable[256];

// ---------------------------------------------------------------------------
// Member functions
// ---------------------------------------------------------------------------

/*
 * ulaw2pcm() - Convert a u-law value to 16-bit linear PCM
 *
 */
#if 0
int ulaw2pcm( int	u_val)
{
	int t;

	/* Complement to obtain normal u-law value. */
	u_val = ~u_val;

	/*
	 * Extract and bias the quantization bits. Then
	 * shift up by the segment number and subtract out the bias.
	 */
	t = ((u_val & QUANT_MASK) << 3) + BIAS;
	t <<= (u_val & SEG_MASK) >> SEG_SHIFT;

	return ((u_val & SIGN_BIT) ? (BIAS - t) : (t - BIAS));
}
#else
static short ulaw2pcm(BYTE	u_val)
{
	int t;

	/* Complement to obtain normal u-law value. */
	u_val = ~u_val;
	bool   usign = (u_val & SIGN_BIT) ? true:false;
	short  useg  = (u_val & SEG_MASK) >> SEG_SHIFT;
	short  ustep = (u_val & QUANT_MASK);

	t = ((2*ustep+33) << useg) - 33;
	if (!usign)t=-t;
	t <<=2;
	return t;
}
#endif
void audio_G711U_decoder_init()
{
	for (int i = 0; i < 256; i++) {
		G711DecodeTable[i] = ulaw2pcm((BYTE)i);
	}
}

int audio_G711U_decode(short *psOut, BYTE *pcIn)
{
	if (pcIn == NULL)
	{
		// TODO: PLC
		for (int k = 0; k < AUDIO_FRSZ8; k++)
		{
			psOut[k] = 0;
		}
	}
	else
	{
		for (int k = 0; k < AUDIO_FRSZ8; k++)
		{
			register int sample = *pcIn;
			*psOut = G711DecodeTable[sample];
			psOut++; 
			pcIn++;
		}
	}
	return AUDIO_FRSZ8;
}

// ---------------------------------------------------------------------------
// Member functions
// ---------------------------------------------------------------------------

static const int seg_uend[8] = {0x3F, 0x7F, 0xFF, 0x1FF, 0x3FF, 0x7FF, 0xFFF, 0x1FFF};
static BYTE G711EncodeTable[1+65536/4];

static BYTE search( int val, const int *table, BYTE size)
{
	BYTE	i;		/* changed from "short" *drago* */

	for (i = 0; i < size; i++) {
		if (val <= *table++)
			return (i);
	}
	return (size);
}


static BYTE pcm2ulaw( short	pcm_val)	// 2's complement (16-bit range) 
{
	bool sign = true;


	// Get the sign and the magnitude of the value. 
//	pcm_val >>= 2;
	if (pcm_val < 0) {
		pcm_val = -pcm_val;
		sign = false;
	}

//    if ( pcm_val > CLIP ) pcm_val = CLIP;		// clip the magnitude 

	pcm_val += 33;

	// Convert the scaled magnitude to segment number. 
	BYTE seg = search(pcm_val, seg_uend, 8);
	BYTE uval = (pcm_val >> (seg+1)) & 0xf;
	if (seg >= 8)
	{
		uval = 0xf;
		seg = 7;
	}

	 // Combine the sign, segment, quantization bits;
	 // and complement the code word.

	uval |= seg << 4;
	uval |= (sign) ? SIGN_BIT:0;
	uval = ~uval;

	return uval;
}




void audio_G711U_encoder_init()
{
	for (short i = -8192; i < 8192; i++ ) 
	{
		G711EncodeTable[i+8192] = pcm2ulaw(i);
	}
}

int audio_G711U_encode(BYTE *pcOut, short *psIn)
{
	register BYTE *pTab = G711EncodeTable;//+8192;

	for (int k = 0; k < AUDIO_FRSZ8; k++)
	{
		register short sample = *psIn;
		sample >>= 2;
		*pcOut = *(pTab + 8192 + sample);
		psIn++;
		pcOut++;
	}
	return AUDIO_FRSZ8;
}


