#include "audio_defs.h"
#include "audio_g711u.h"
#include "audio_g711a.h"
#include "audio_speex.h"
#include "audio_ilbc.h"
#include "audio_gsm.h"
#include "audio_g729.h"
#include "siren_if.h"


/*****************************************************************************/
static void						_party_encode
/*****************************************************************************/
(
Audio_tNsParty *pParty,
float *pfFrame
) 
{
	float afFrame[AUDIO_FRSZ16];
	int iEncoded = 0;


	if (pParty->pcCode)
	{
		BYTE *pcTo = pParty->pcCode + pParty->wCodedFrSz * pParty->wFrs;

		audio_tmr_start(AUDIO_TMR_ENC);
		switch(pParty->wPayloadType)
		{
		case AUDIO_IF_PT_G711A:
			audio_utl_32to8(pParty->afDcmSav, afFrame, pfFrame);
			audio_utl_float2short(pParty->asFrame, afFrame, AUDIO_FRSZ8);
			iEncoded = audio_G711A_encode(pcTo, pParty->asFrame);
			break;
		case AUDIO_IF_PT_G711U:
			audio_utl_32to8(pParty->afDcmSav, afFrame, pfFrame);
			audio_utl_float2short(pParty->asFrame, afFrame, AUDIO_FRSZ8);
			iEncoded = audio_G711U_encode(pcTo, pParty->asFrame);
			break;
		case AUDIO_IF_PT_SPEEX_NB:
			audio_utl_32to8(pParty->afDcmSav, afFrame, pfFrame);
			audio_utl_float2short(pParty->asFrame, afFrame, AUDIO_FRSZ8);
			iEncoded = audio_speex_encode(pParty->pvEncoder, pcTo, pParty->asFrame);
			break;
		case AUDIO_IF_PT_SPEEX_WB:
			audio_utl_32to16(pParty->afDcmSav, afFrame, pfFrame);
			audio_utl_float2short(pParty->asFrame, afFrame, AUDIO_FRSZ16);
			iEncoded = audio_speex_encode(pParty->pvEncoder, pcTo, pParty->asFrame);
			break;
		case AUDIO_IF_PT_SPEEX_UWB:
			audio_utl_float2short(pParty->asFrame, pfFrame, AUDIO_FRSZ32);
			iEncoded = audio_speex_encode(pParty->pvEncoder, pcTo, pParty->asFrame);
			break;
		case AUDIO_IF_PT_ILBC:
			audio_utl_32to8(pParty->afDcmSav, afFrame, pfFrame);
			audio_utl_float2short(pParty->asFrame, afFrame, AUDIO_FRSZ8);
			iEncoded = audio_iLBC_encode(pParty->pvEncoder, pcTo, pParty->asFrame);
			break;
		case AUDIO_IF_PT_GSM:
			audio_utl_32to8(pParty->afDcmSav, afFrame, pfFrame);
			audio_utl_float2short(pParty->asFrame, afFrame, AUDIO_FRSZ8);
			iEncoded = audio_GSM_encode(pParty->pvEncoder, pcTo, pParty->asFrame);
			break;
#if AUDIO_G729
		case AUDIO_IF_PT_G729A: // for G729 it's 10 ms frame
			audio_utl_32to8(pParty->afDcmSav, afFrame, pfFrame);
			audio_utl_float2short(pParty->asFrame, afFrame, AUDIO_FRSZ8);
			iEncoded += audio_G729_encode(pParty->pvEncoder, pcTo, pParty->asFrame);
			iEncoded += audio_G729_encode(pParty->pvEncoder, pcTo+AUDIO_CSZ_G729A,pParty->asFrame+AUDIO_FRSZ8/2);
			break;
#endif
		case AUDIO_IF_PT_SIREN14:
		case AUDIO_IF_PT_SIREN1432:
		case AUDIO_IF_PT_SIREN1448:
		case AUDIO_IF_PT_SIREN1416:
			audio_utl_float2short(pParty->asFrame, pfFrame, AUDIO_FRSZ32);
			iEncoded = siren_encode(pParty->pvEncoder, pcTo, pParty->asFrame);
			break;
		default:
			audio_log_err("audio_ns_party_encode -- [%d] PT %d", pParty->wIdx, pParty->wPayloadType);
			break;

		}
		audio_tmr_stop(AUDIO_TMR_ENC);
		pParty->iEncoded += iEncoded;
	}
	pParty->wFrs++;
}

/*****************************************************************************/
static void						_party_send
/*****************************************************************************/
(
Audio_tNsParty *pParty,
float *pfFrame
) 
{
	if (pParty->dwSD != AUDIO_SD)
	{
		audio_log_err("audio_party_send -- [%d] in SD %x", 
			pParty->wIdx, pParty->dwSD);
		pParty->dwSD = AUDIO_SD;
	}
	if (pParty->dwED != AUDIO_ED)
	{
		audio_log_err("audio_party_send -- [%d] in ED %x", 
			pParty->wIdx, pParty->dwED);
		pParty->dwED = AUDIO_ED;
	}

	_party_encode(pParty, pfFrame);

	if (pParty->wFrs >= pParty->wFrsPerPkt)
	{
		if (pParty->pcCode)
		{
			Audio_tRtpHdr Hdr; 
			memset(&Hdr, 0, sizeof(Hdr));
			Hdr.dwTS = pParty->dwTS; 
			Hdr.wPT = pParty->wPayloadType;
#if 0
			audio_log_trc("audio_party_send -- idx=%d PT=%d SZ=%d TS=%d",
				pParty->dwIdx,
				Hdr->wPT,
				pParty->iEncoded,
				pParty->dwTS);
#endif
		audio_rec_pkt(
			AUDIO_IF_REC_NET_SND, 
			pParty->wIdx,
			&Hdr,
			(BYTE *)pParty->pcCode,
			pParty->wCodedFrSz,
			gAudio.Drv.fNow);


			if (gAudio.pNetSendCallback)
				(*gAudio.pNetSendCallback)(gAudio.pNetSendThis, pParty->wIdx, pParty->dwTS, pParty->pcCode, pParty->iEncoded);

//			else
//				AudioIf_net_snd(pParty->wIdx, pParty->dwTS, pParty->pcCode, pParty->iEncoded);

		}

		memset(pParty->pcCode, 0, pParty->wCodedFrSz*pParty->wFrsPerPkt);

		pParty->Stts.iPktsTotal++;
		pParty->Stts.iBytesTotal += pParty->iEncoded;
		pParty->dwTS += pParty->dwTsFrame * pParty->wFrsPerPkt;
		pParty->iEncoded = 0;

		pParty->wFrs = 0;
	}
	if (pParty->dwSD != AUDIO_SD)
	{
		audio_log_err("audio_party_send -- [%d] out SD %x", 
			pParty->wIdx, pParty->dwSD);
		pParty->dwSD = AUDIO_SD;
	}
	if (pParty->dwED != AUDIO_ED)
	{
		audio_log_err("audio_party_send -- [%d] out ED %x", 
			pParty->wIdx, pParty->dwED);
		pParty->dwED = AUDIO_ED;
	}
}
/*****************************************************************************/
void				audio_net_snd
/*****************************************************************************/
(
)
{
	Audio_tNs *pNs = &gAudio.Ns;
	Audio_tJb *pJb = &gAudio.Jb;

	float afFrame[AUDIO_FRSZ32];
	int k;

	// cross-connect mux
	for (int ns = 1; ns <= AUDIO_IF_PARTY_MAX; ns++)
	{
		if (pNs->apParty[ns])
		{
			Audio_tNsParty *pNsParty = pNs->apParty[ns];
			int iParties = 0;

			for (k = 0; k < AUDIO_FRSZ32; k++)
			{
				afFrame[k] = 0;
			}

			if ((!gAudio.bMicMuted) && pNsParty->bMixMic)
			{
				for (k = 0; k < AUDIO_FRSZ32; k++)
				{
					afFrame[k] = gAudio.afSnd[k];
				}
				iParties++;
			}
			// mix all what is indicated in the adwMixSrcIds list
			for (int jb = 1; jb <= AUDIO_IF_PARTY_MAX; jb++)
			{
				if (pJb->apParty[jb] != NULL)
				{
					bool bFound = false;
					for (k = 0; (k < pNsParty->iMixSz) && !bFound; k++)
					{
						if (pNsParty->awMixSrcIds[k] == jb)
						{
							bFound = true;
						}
					}
					if (bFound)
					{
						for (k = 0; k < AUDIO_FRSZ32; k++)
						{
							afFrame[k] += pJb->apParty[jb]->afOut[k];
						}
						iParties++;
					}
				}
			}

			if (iParties)
			{

				audio_recf32(AUDIO_IF_REC_ENC, pNsParty->wIdx, afFrame);

				float fNrg = 80+audio_utl_pktnrg(afFrame, AUDIO_FRSZ32);
				if (fNrg < 0)
					fNrg = 0;

				if (fNrg > pNsParty->fNrg)
					pNsParty->fNrg = fNrg;
				else
					pNsParty->fNrg += (fNrg - pNsParty->fNrg) * 0.1F;

				float fPeak = 1e-4F;
				for (k = 0; k < AUDIO_FRSZ32; k++)
				{
					float f = fabsf(afFrame[k]);
					if (fPeak < f)
						fPeak = f;
				}
#ifndef _WIN32_WCE
				fPeak = 20*log10f(fPeak);
#else
				fPeak = 20*log10l(fPeak);
#endif

				if (fPeak > pNsParty->fPeak)
					pNsParty->fPeak = fPeak;
				else
					pNsParty->fPeak += (fPeak - pNsParty->fPeak) * 0.01F;

				_party_send(pNsParty, afFrame);
			}
			else 
			{
				;// there is nothing to send
			}
		}
	}
}
/*****************************************************************************/
static Audio_tNsParty*			_party_create
/*****************************************************************************/
(
WORD	wIdx,
WORD	wPayloadType, 
DWORD	dwTS, // to start with
WORD	wFrsPerPkt
)
{
	Audio_tNsParty *pParty = (Audio_tNsParty *)AudioIf_alloc(sizeof(Audio_tNsParty));
	memset(pParty, 0, sizeof(Audio_tNsParty));

	pParty->wIdx = wIdx;
	pParty->wPayloadType = wPayloadType;
	pParty->dwTS = dwTS;
	pParty->dwTsFrame = AUDIO_FRSZ8;
	pParty->fNrg = 0;
	pParty->fPeak = -65;
	pParty->dwSD = AUDIO_SD;
	pParty->dwED = AUDIO_ED;

	bool fOk = false;


	switch(wPayloadType)
	{
	case AUDIO_IF_PT_G711A:
	case AUDIO_IF_PT_G711U:
		//pDecoder = G711_Decoder
		pParty->wCodedFrSz = AUDIO_CSZ_G711;
		if (wFrsPerPkt > 4)
		{
			audio_log_war("audio_ns_party_create -- FFP was %d, limited at 4", wFrsPerPkt);
			wFrsPerPkt = 4;
		}
		pParty->wFrsPerPkt = wFrsPerPkt;
		pParty->pcCode = (BYTE*)AudioIf_alloc(AUDIO_CSZ_G711*wFrsPerPkt);
		pParty->pvEncoder= NULL;
		if (pParty->pcCode)
		{
			fOk = true; // ok
		}
		else
		{
			audio_log_err("audio_ns_party_create -- pcCode alloc failed");
		}
		break;
	case AUDIO_IF_PT_SPEEX_NB:
		pParty->wCodedFrSz = AUDIO_CSZ_SPEEX_NB;
		if (wFrsPerPkt > 4)
		{
			audio_log_war("audio_ns_party_create -- FFP was %d, limited at 4", wFrsPerPkt);
			wFrsPerPkt = 4;
		}
		pParty->wFrsPerPkt = wFrsPerPkt;
		pParty->pcCode = (BYTE*)AudioIf_alloc(AUDIO_CSZ_SPEEX_NB*wFrsPerPkt);
		if (pParty->pcCode)
		{
			pParty->pvEncoder = AudioIf_alloc(sizeof(Audio_tSpeex));
			if (pParty->pvEncoder)
			{
				audio_speex_encoder_init(pParty->pvEncoder, AUDIO_IF_PT_SPEEX_NB);
				fOk = true;
			}
			else
			{
				audio_log_err("audio_ns_party_create -- pvEncoder alloc failed");
				pParty->pcCode = (BYTE*)AudioIf_free(pParty->pcCode);
			}
		}
		else
		{
			audio_log_err("audio_ns_party_create -- pcCode alloc failed");
		}
		break;
	case AUDIO_IF_PT_SPEEX_WB:
		pParty->wCodedFrSz = AUDIO_CSZ_SPEEX_WB;
		pParty->dwTsFrame = AUDIO_FRSZ16;
		if (wFrsPerPkt > 4)
		{
			audio_log_war("audio_ns_party_create -- FFP was %d, limited at 4", wFrsPerPkt);
			wFrsPerPkt = 4;
		}
		pParty->wFrsPerPkt = wFrsPerPkt;
		pParty->pcCode = (BYTE*)AudioIf_alloc(AUDIO_CSZ_SPEEX_WB*wFrsPerPkt);
		if (pParty->pcCode)
		{
			pParty->pvEncoder = AudioIf_alloc(sizeof(Audio_tSpeex));
			if (pParty->pvEncoder)
			{
				audio_speex_encoder_init(pParty->pvEncoder, AUDIO_IF_PT_SPEEX_WB);
				fOk = true;
			}
			else
			{
				audio_log_err("audio_ns_party_create -- pvEncoder alloc failed");
				pParty->pcCode = (BYTE*)AudioIf_free(pParty->pcCode);
			}
		}
		else
		{
			audio_log_err("audio_ns_party_create -- pcCode alloc failed");
		}
		break;
	case AUDIO_IF_PT_SPEEX_UWB:
		pParty->wCodedFrSz = AUDIO_CSZ_SPEEX_UWB;
		pParty->dwTsFrame = AUDIO_FRSZ32;
		if (wFrsPerPkt > 4)
		{
			audio_log_war("audio_ns_party_create -- FFP was %d, limited at 4", wFrsPerPkt);
			wFrsPerPkt = 4;
		}
		pParty->wFrsPerPkt = wFrsPerPkt;
		pParty->pcCode = (BYTE*)AudioIf_alloc(AUDIO_CSZ_SPEEX_UWB*wFrsPerPkt);
		if (pParty->pcCode)
		{
			pParty->pvEncoder = AudioIf_alloc(sizeof(Audio_tSpeex));
			if (pParty->pvEncoder)
			{
				audio_speex_encoder_init(pParty->pvEncoder, AUDIO_IF_PT_SPEEX_UWB);
				fOk = true;
			}
			else
			{
				audio_log_err("audio_ns_party_create -- pvEncoder alloc failed");
				pParty->pcCode = (BYTE*)AudioIf_free(pParty->pcCode);
			}
		}
		else
		{
			audio_log_err("audio_ns_party_create -- pcCode alloc failed");
		}
		break;

	case AUDIO_IF_PT_ILBC:
		pParty->wCodedFrSz = AUDIO_CSZ_ILBC;
		if (wFrsPerPkt > 4)
		{
			audio_log_war("audio_ns_party_create -- FFP was %d, limited at 4", wFrsPerPkt);
			wFrsPerPkt = 4;
		}
		pParty->wFrsPerPkt = wFrsPerPkt;
		pParty->pcCode = (BYTE*)AudioIf_alloc(AUDIO_CSZ_ILBC*wFrsPerPkt);
		if (pParty->pcCode)
		{
			pParty->pvEncoder = AudioIf_alloc(sizeof(iLBC_Enc_Inst_t));
			if (pParty->pvEncoder)
			{
				audio_iLBC_encoder_init(pParty->pvEncoder);
				fOk = true;
			}
			else
			{
				audio_log_err("audio_ns_party_create -- pvEncoder alloc failed");
				pParty->pcCode = (BYTE*)AudioIf_free(pParty->pcCode);
			}
		}
		else
		{
			audio_log_err("audio_ns_party_create -- pcCode alloc failed");
		}
		break;
	case AUDIO_IF_PT_GSM:
		pParty->wCodedFrSz = AUDIO_CSZ_GSM;
		if (wFrsPerPkt > 4)
		{
			audio_log_war("audio_ns_party_create -- FFP was %d, limited at 4", wFrsPerPkt);
			wFrsPerPkt = 4;
		}
		pParty->wFrsPerPkt = wFrsPerPkt;
		pParty->pcCode = (BYTE*)AudioIf_alloc(AUDIO_CSZ_GSM*wFrsPerPkt);
		if (pParty->pcCode)
		{
			pParty->pvEncoder = audio_GSM_init();
			if (pParty->pvEncoder)
			{
				fOk = true;
			}
			else
			{
				audio_log_err("audio_ns_party_create -- pvEncoder alloc failed");
				pParty->pcCode = (BYTE*)AudioIf_free(pParty->pcCode);
			}
		}
		else
		{
			audio_log_err("audio_ns_party_create -- pcCode alloc failed");
		}
		break;
#if AUDIO_G729
	case AUDIO_IF_PT_G729A: // for G729 it's 10 ms frame
		pParty->wCodedFrSz = AUDIO_CSZ_G729A*2;
		if (wFrsPerPkt > 4)
		{
			audio_log_war("audio_ns_party_create -- FFP was %d, limited at 4", wFrsPerPkt);
			wFrsPerPkt = 4;
		}
		pParty->wFrsPerPkt = wFrsPerPkt;
		pParty->pcCode = (BYTE*)AudioIf_alloc(AUDIO_CSZ_G729A*2*wFrsPerPkt);
		if (pParty->pcCode)
		{
			pParty->pvEncoder = audio_G729_encoder_init();
			if (pParty->pvEncoder)
			{
				fOk = true;
			}
			else
			{
				audio_log_err("audio_ns_party_create -- pvEncoder alloc failed");
				pParty->pcCode = (BYTE*)AudioIf_free(pParty->pcCode);
			}
		}
		else
		{
			audio_log_err("audio_ns_party_create -- pcCode alloc failed");
		}
		break;
#endif
	case AUDIO_IF_PT_SIREN14:
		pParty->wCodedFrSz = AUDIO_CSZ_SIREN1424;
		pParty->dwTsFrame = AUDIO_FRSZ32;
		if (wFrsPerPkt > 2)
		{
			audio_log_war("audio_ns_party_create -- FFP was %d, limited at 2", wFrsPerPkt);
			wFrsPerPkt = 2;
		}
		pParty->wFrsPerPkt = wFrsPerPkt;
		pParty->pcCode = (BYTE*)AudioIf_alloc(AUDIO_CSZ_SIREN1424*wFrsPerPkt);
		if (pParty->pcCode)
		{
			pParty->pvEncoder = AudioIf_alloc(sizeof(Siren_tEnc));
			if (pParty->pvEncoder)
			{
				siren_encoder_init(pParty->pvEncoder);
				fOk = true;
			}
			else
			{
				audio_log_err("audio_ns_party_create -- pvEncoder alloc failed");
				pParty->pcCode = (BYTE*)AudioIf_free(pParty->pcCode);
			}
		}
		else
		{
			audio_log_err("audio_ns_party_create -- pcCode alloc failed");
		}
		break;
	case AUDIO_IF_PT_SIREN1432:
		pParty->wCodedFrSz = AUDIO_CSZ_SIREN1432;
		pParty->dwTsFrame = AUDIO_FRSZ32;
		if (wFrsPerPkt > 2)
		{
			audio_log_war("audio_ns_party_create -- FFP was %d, limited at 2", wFrsPerPkt);
			wFrsPerPkt = 2;
		}
		pParty->wFrsPerPkt = wFrsPerPkt;
		pParty->pcCode = (BYTE*)AudioIf_alloc(AUDIO_CSZ_SIREN1432*wFrsPerPkt);
		if (pParty->pcCode)
		{
			pParty->pvEncoder = AudioIf_alloc(sizeof(Siren_tEnc));
			if (pParty->pvEncoder)
			{
				siren_encoder_init(pParty->pvEncoder, 640);
				fOk = true;
			}
			else
			{
				audio_log_err("audio_ns_party_create -- pvEncoder alloc failed");
				pParty->pcCode = (BYTE*)AudioIf_free(pParty->pcCode);
			}
		}
		else
		{
			audio_log_err("audio_ns_party_create -- pcCode alloc failed");
		}
		break;
	case AUDIO_IF_PT_SIREN1448:
		pParty->wCodedFrSz = AUDIO_CSZ_SIREN1448;
		pParty->dwTsFrame = AUDIO_FRSZ32;
		if (wFrsPerPkt > 2)
		{
			audio_log_war("audio_ns_party_create -- FFP was %d, limited at 2", wFrsPerPkt);
			wFrsPerPkt = 2;
		}
		pParty->wFrsPerPkt = wFrsPerPkt;
		pParty->pcCode = (BYTE*)AudioIf_alloc(AUDIO_CSZ_SIREN1448*wFrsPerPkt);
		if (pParty->pcCode)
		{
			pParty->pvEncoder = AudioIf_alloc(sizeof(Siren_tEnc));
			if (pParty->pvEncoder)
			{
				siren_encoder_init(pParty->pvEncoder, 960);
				fOk = true;
			}
			else
			{
				audio_log_err("audio_ns_party_create -- pvEncoder alloc failed");
				pParty->pcCode = (BYTE*)AudioIf_free(pParty->pcCode);
			}
		}
		else
		{
			audio_log_err("audio_ns_party_create -- pcCode alloc failed");
		}
		break;
	case AUDIO_IF_PT_SIREN1416:
		pParty->wCodedFrSz = AUDIO_CSZ_SIREN1416;
		pParty->dwTsFrame = AUDIO_FRSZ32;
		if (wFrsPerPkt > 2)
		{
			audio_log_war("audio_ns_party_create -- FFP was %d, limited at 2", wFrsPerPkt);
			wFrsPerPkt = 2;
		}
		pParty->wFrsPerPkt = wFrsPerPkt;
		pParty->pcCode = (BYTE*)AudioIf_alloc(AUDIO_CSZ_SIREN1416*wFrsPerPkt);
		if (pParty->pcCode)
		{
			pParty->pvEncoder = AudioIf_alloc(sizeof(Siren_tEnc));
			if (pParty->pvEncoder)
			{
				siren_encoder_init(pParty->pvEncoder, 320);
				fOk = true;
			}
			else
			{
				audio_log_err("audio_ns_party_create -- pvEncoder alloc failed");
				pParty->pcCode = (BYTE*)AudioIf_free(pParty->pcCode);
			}
		}
		else
		{
			audio_log_err("audio_ns_party_create -- pcCode alloc failed");
		}
		break;
	default:
		audio_log_err("audio_ns_party_create -- PT %d", wPayloadType);
		break;

	}
	if (!fOk)
	{
		pParty = (Audio_tNsParty *)AudioIf_free(pParty);
	}
	else
	{
		memset(pParty->pcCode, 0, pParty->wCodedFrSz*pParty->wFrsPerPkt);
	}
	return pParty;
}
/*****************************************************************************/
static void					_party_delete
/*****************************************************************************/
(
Audio_tNsParty *pParty
)
{
	if (pParty)
	{
		switch(pParty->wPayloadType)
		{
		case AUDIO_IF_PT_G711A:
		case AUDIO_IF_PT_G711U:
			break;
		case AUDIO_IF_PT_SPEEX_NB:
		case AUDIO_IF_PT_SPEEX_WB:
		case AUDIO_IF_PT_SPEEX_UWB:
			audio_speex_encoder_delete(pParty->pvEncoder);
			pParty->pvEncoder = AudioIf_free(pParty->pvEncoder);
			break;
		case AUDIO_IF_PT_ILBC:
			pParty->pvEncoder = AudioIf_free(pParty->pvEncoder);
			break;
		case AUDIO_IF_PT_GSM:
			pParty->pvEncoder = audio_GSM_delete(pParty->pvEncoder);
			break;
#if AUDIO_G729
		case AUDIO_IF_PT_G729A: // for G729 it's 10 ms frame
			pParty->pvEncoder = AudioIf_free(pParty->pvEncoder);
			break;
#endif
		case AUDIO_IF_PT_SIREN14:
		case AUDIO_IF_PT_SIREN1432:
		case AUDIO_IF_PT_SIREN1448:
		case AUDIO_IF_PT_SIREN1416:
			pParty->pvEncoder = AudioIf_free(pParty->pvEncoder);
			break;
		default:
			break;
		}
		
		audio_log_inf("Pkts total %d", pParty->Stts.iPktsTotal);
		audio_log_inf("bytes total %d", pParty->Stts.iBytesTotal);
		audio_log_inf("inactivity %f", pParty->Stts.fInactivityPercent);

		pParty->pcCode = (BYTE*)AudioIf_free (pParty->pcCode);
		pParty = (Audio_tNsParty *)AudioIf_free(pParty);
	}
}

/*****************************************************************************/
DWORD				AudioIf_dst_add
/*****************************************************************************/
(
WORD  wDstId, 
WORD  wPayloadType, 
DWORD dwTimestamp, // to start with
WORD  wFrsPerPkt,
bool  bMixMic
)
{
	if (!gAudio.bInitialized) return AUDIO_IF_ERR_NOT_INITIALIZED;

	DWORD rc = AUDIO_IF_ERR_NONE;
	audio_lock();
	audio_log_inf(
		"AudioIf_dst_add -- idx %d PT %d TS %d FPP %d", 
		wDstId, wPayloadType, dwTimestamp, wFrsPerPkt);
	
	if (wFrsPerPkt < 1)
	{
		audio_log_war("AudioIf_dst_add -- FPP set to 1");
		wFrsPerPkt = 1;
	}

	Audio_tNs *pNs = &gAudio.Ns;

	if ((wDstId > 0) &&
		(wDstId <= AUDIO_IF_PARTY_MAX))
	{
		if (pNs->apParty[wDstId] == NULL)
		{
			pNs->apParty[wDstId] = _party_create(
				wDstId,
				wPayloadType, 
				dwTimestamp, 
				wFrsPerPkt);

			if (pNs->apParty[wDstId]) 
			{
				pNs->apParty[wDstId]->bMixMic = bMixMic;
			}
			else // this type is not supported
			{
				audio_log_err("AudioIf_dst_add -- type %d not supported", 
							wPayloadType);
				rc |= AUDIO_IF_ERR_INVALID_PARAM;
			}
		}
		else
		{
			audio_log_err("AudioIf_dst_add -- idx %d already exists",
				wDstId);
			rc |= AUDIO_IF_ERR_ALREADY_EXISTS;
		}
	}
	else
	{
		audio_log_err("AudioIf_dst_add -- wrong idx %d", wDstId);
		rc |= AUDIO_IF_ERR_RANGE;	
	}

	if (rc)
		audio_log_err("AudioIf_dst_add -- rc=0x%08x", rc);
	else
		audio_log_inf("AudioIf_dst_add -- done");
	audio_unlock();
	return rc;
		
}
/*****************************************************************************/
DWORD						AudioIf_dst_mix
/*****************************************************************************/
(
WORD wDstId,
bool bMixMic,
WORD wSz,
WORD *pwMixSrcIds
)
{
	if (!gAudio.bInitialized) return AUDIO_IF_ERR_NOT_INITIALIZED;

	DWORD rc = AUDIO_IF_ERR_NONE;
	int k;

	audio_lock();
	audio_log_inf("AudioIf_dst_mix -- dwDstId=%d mic=%d iSz=%d", wDstId, bMixMic, wSz);
	if (pwMixSrcIds)
		for (k = 0; k < wSz; k++)
			audio_log_inf("-- k=%d SrcId=%d", k, pwMixSrcIds[k]);

	Audio_tNs *pNs = &gAudio.Ns;

	if ((wDstId > 0) && 
		(wDstId <= AUDIO_IF_PARTY_MAX)) 
	{
		Audio_tNsParty *pParty = pNs->apParty[wDstId];
		if (pParty)
		{
			pParty->bMixMic = bMixMic;
			if (wSz == ((WORD)-1))
			{
			}
			else
			{
				if (wSz == 0)
				{
					pParty->iMixSz = 0;
				}
				else
				{
					if ((wSz <= AUDIO_IF_PARTY_MAX) &&
						(pwMixSrcIds))
					{
						pParty->iMixSz = wSz;
						for (k = 0; k < wSz; k++)
						{
							pParty->awMixSrcIds[k] = pwMixSrcIds[k];
						}
					}
					else
					{
						audio_log_err("AudioIf_dst_mix -- wrong sz or ptr");
						rc |= AUDIO_IF_ERR_INVALID_PARAM;
					}
				}
			}
		}
		else
		{
			audio_log_err("AudioIf_dst_mix -- channel %d not initialized",
				wDstId);
			rc |= AUDIO_IF_ERR_NOT_INITIALIZED;
		}
	}
	else
	{
		audio_log_err("AudioIf_dst_mix -- wrong idx");
		rc |= AUDIO_IF_ERR_BAD_IDX;
	}

//	audio_net_snd_mix_log();

	if (rc)
		audio_log_err("AudioIf_dst_mix -- rc=0x%08x", rc);
	else
		audio_log_inf("AudioIf_dst_mix -- done");
	audio_unlock();
	return rc;
}
/*****************************************************************************/
DWORD						AudioIf_dst_mix_get
/*****************************************************************************/
(
WORD	wDstId,
WORD*	pwSz,
WORD*	pwMixSrcIds
)
{
	if (!gAudio.bInitialized) return AUDIO_IF_ERR_NOT_INITIALIZED;

	DWORD rc = AUDIO_IF_ERR_NONE;
	int k;

	audio_lock();
	audio_log_inf("AudioIf_dst_mix_get -- wDstId=%d pwSz=%p pwMixSrcIds=%p", wDstId, pwSz, pwMixSrcIds);

	Audio_tNs *pNs = &gAudio.Ns;

	if ((wDstId > 0) &&
		(wDstId <= AUDIO_IF_PARTY_MAX))
	{
		Audio_tNsParty *pParty = pNs->apParty[wDstId];
		if (pParty)
		{
			*pwSz = pParty->iMixSz;

			if ((*pwSz > 0) && pwMixSrcIds)
			{
				for (k = 0; k < *pwSz; k++)
				{
					pwMixSrcIds[k] = pParty->awMixSrcIds[k];
				}
			}
		}
		else
		{
			audio_log_err("AudioIf_dst_mix_get -- channel %d not initialized",
				wDstId);
			rc |= AUDIO_IF_ERR_NOT_INITIALIZED;
		}
	}
	else
	{
		audio_log_err("AudioIf_dst_mix_get -- wrong idx or wSz");
		rc |= AUDIO_IF_ERR_INVALID_PARAM;
	}

	if (rc)
		audio_log_err("AudioIf_dst_mix_get -- rc=0x%08x", rc);
	else
		audio_log_inf("AudioIf_dst_mix_get -- done");
	audio_unlock();
	return rc;
}
/*****************************************************************************/
DWORD						AudioIf_dst_mix_remove
/*****************************************************************************/
(
WORD wSrcId
)
{
	if (!gAudio.bInitialized) return AUDIO_IF_ERR_NOT_INITIALIZED;

	DWORD rc = AUDIO_IF_ERR_NONE;
	int k;

	audio_lock();
	audio_log_inf("AudioIf_dst_mix_remove -- idx=%d", wSrcId);

	Audio_tNs *pNs = &gAudio.Ns;

	for (k = 1; k <= AUDIO_IF_PARTY_MAX; k++)
	{
		Audio_tNsParty *pParty = pNs->apParty[k];

		if (pParty && (pParty->iMixSz > 0))
		{
			int i;
			for (i = 0; i < pParty->iMixSz; i++)
			{
				if (pParty->awMixSrcIds[i] == wSrcId)
				{
					// found
					break;
				}
			}

			if (i < pParty->iMixSz)
			{
				audio_log_inf("AudioIf_dst_mix_remove -- SRC=%d removed from %d", 
					wSrcId, k);

				for (int n = i; n < pParty->iMixSz-1; n++)
				{
					pParty->awMixSrcIds[n] = 
						pParty->awMixSrcIds[n+1];
				}
				pParty->iMixSz--;
			}
		}
	}

//	audio_net_snd_mix_log();

	if (rc)
		audio_log_err("AudioIf_dst_mix_remove -- rc=0x%08x", rc);
	else
		audio_log_inf("AudioIf_dst_mix_remove -- done");
	audio_unlock();
	return rc;
}
/*****************************************************************************/
DWORD						AudioIf_dst_remove
/*****************************************************************************/
(
WORD wIdx
)
{
	if (!gAudio.bInitialized) return AUDIO_IF_ERR_NOT_INITIALIZED;

	DWORD rc = AUDIO_IF_ERR_NONE;
	audio_lock();
	audio_log_inf("AudioIf_dst_remove -- idx %d", wIdx);

	Audio_tNs *pNs = &gAudio.Ns;

	if ((wIdx > 0) &&
		(wIdx <= AUDIO_IF_PARTY_MAX))
	{
		if (pNs->apParty[wIdx])
		{
			_party_delete(pNs->apParty[wIdx]);
			pNs->apParty[wIdx] = NULL;
		}
		else
		{
			audio_log_err("AudioIf_dst_remove -- idx %d already removed",
				wIdx);
			rc |= AUDIO_IF_ERR_INVALID_PARAM;
		}
	}
	else
	{
		audio_log_err("AudioIf_dst_remove -- wrong idx %d",
			wIdx);
		rc |= AUDIO_IF_ERR_RANGE;
	}
	

	if (rc)
		audio_log_err("AudioIf_dst_remove -- rc=0x%08x", rc);
	else
		audio_log_inf("AudioIf_dst_remove -- done");
	audio_unlock();
	return rc;
}
/*****************************************************************************/
DWORD						AudioIf_dst_remove_all
/*****************************************************************************/
(
)
{
	if (!gAudio.bInitialized) return AUDIO_IF_ERR_NOT_INITIALIZED;

	DWORD rc = AUDIO_IF_ERR_NONE;
	audio_lock();
	audio_log_inf("AudioIf_dst_remove_all -- "); 

	Audio_tNs *pNs = &gAudio.Ns;

	for (DWORD wIdx = 1; wIdx <= AUDIO_IF_PARTY_MAX; wIdx++)
	{
		if (pNs->apParty[wIdx])
		{
			audio_log_inf("AudioIf_dst_remove_all -- idx=%d",	wIdx);
			_party_delete(pNs->apParty[wIdx]);
			pNs->apParty[wIdx] = NULL;
		}
	}

	if (rc)
		audio_log_err("AudioIf_dst_remove_all -- rc=0x%08x", rc);
	else
		audio_log_inf("AudioIf_dst_remove_all -- done");
	audio_unlock();
	return rc;
}
/*****************************************************************************/
DWORD						AudioIf_dst_stts_get
/*****************************************************************************/
(
WORD wDstId,
AudioIf_tDstStts *pStts
)
{
	if (!gAudio.bInitialized) return AUDIO_IF_ERR_NOT_INITIALIZED;

	DWORD rc = AUDIO_IF_ERR_NONE;
	audio_lock();
	audio_log_trc("AudioIf_dst_stts_get -- idx %d", wDstId); 

	Audio_tNs *pNs = &gAudio.Ns;

	if (pStts)
	{
		if (pNs->apParty[wDstId])
		{
			*pStts = pNs->apParty[wDstId]->Stts;
		}
		else
		{
			rc |= AUDIO_IF_ERR_NOT_INITIALIZED;
		}
	}
	else
	{
		rc |= AUDIO_IF_ERR_INVALID_PARAM;
	}

	if (rc)
		audio_log_err("AudioIf_dst_stts_get -- rc=0x%08x", rc);
	else
		audio_log_trc("AudioIf_dst_stts_get -- done");
	audio_unlock();
	return rc;
}
/*****************************************************************************/
void						audio_net_snd_mix_log
/*****************************************************************************/
(
)
{
	if (!gAudio.bInitialized) return;
	Audio_tNs *pNs = &gAudio.Ns;
	Audio_tJb *pJb = &gAudio.Jb;
	char ac[AUDIO_IF_PARTY_MAX+1];
	int k, i;

	for (i = 0; i < AUDIO_IF_PARTY_MAX; i++)
	{
		ac[i] = '0'+i%10;
	}
	ac[AUDIO_IF_PARTY_MAX] = 0;
	audio_log_inf("-- party XX: %s", ac);

	ac[0] = ' ';
	for (k = 1; k < AUDIO_IF_PARTY_MAX; k++)
	{
		ac[k] = ' ';
		Audio_tJbParty *pParty = pJb->apParty[k];
		if (pParty != NULL)
		{
			if (pParty->bMixToSpk)
			{
				ac[k] = 'X';
			}
		}
	}
	ac[AUDIO_IF_PARTY_MAX] = 0;
	audio_log_inf("-- party 00: %s", ac);

	for (k = 1; k <= AUDIO_IF_PARTY_MAX; k++)
	{
		Audio_tNsParty *pParty = pNs->apParty[k];

		if (pParty) 
		{
			for (i = 0; i < AUDIO_IF_PARTY_MAX; i++)
			{
				ac[i] = ' ';
			}
			ac[AUDIO_IF_PARTY_MAX] = 0;
			if (pParty->bMixMic)
				ac[0] = 'X';
			for (i = 0; i < pParty->iMixSz; i++)
			{
				int x = pParty->awMixSrcIds[i];
				if (x < AUDIO_IF_PARTY_MAX)
				{
					ac[pParty->awMixSrcIds[i]] ='X';
				}
				else
				{
					audio_log_err("-- invalid mix=%d for party %02d", x, k);
				}
			}
			audio_log_inf("-- party %02d: %s", k, ac);
		}
	}
}

/*****************************************************************************/
DWORD						AudioIf_set_net_send_callback 
/*****************************************************************************/
(
void *pThis,
AudioIf_tNetSndCallback pCallback
)
{
	if (!gAudio.bInitialized) return AUDIO_IF_ERR_NOT_INITIALIZED;

	DWORD rc = AUDIO_IF_ERR_NONE;
	audio_lock();
	audio_log_inf("AudioIf_set_net_send_callback -- pThis=%p, pCallback=0x%08x", pThis, pCallback); 

	gAudio.pNetSendThis = pThis;
	gAudio.pNetSendCallback = pCallback;

	if (rc)
		audio_log_err("AudioIf_set_net_send_callback -- rc=0x%08x", rc);
	else
		audio_log_inf("AudioIf_set_net_send_callback -- done");
	audio_unlock();
	return rc;
}
