#include "audio_defs.h"
#include "gaeci.h"
#include <tchar.h>

static const TCHAR __szTitle[] = _T("Audio Engine Monitor");			// The title bar text
static const TCHAR __szWindowClass[] = _T("Audio dbg Window Class");	// The title bar text
// 16 basic colors

#define BLACK		0x00
#define DARKGRAY	0x15
#define LIGHTGRAY	0x2a
#define WHITE		0x3f

#define RED			0x02
#define LIGHTRED	0x03

#define GREEN		0x08
#define LIGHTGREEN	0x0c

#define BLUE		0x20
#define LIGHTBLUE	0x30

#define BROWN		0x0a
#define YELLOW		0x0f

#define CYAN		0x28
#define LIGHTCYAN	0x3c

#define MAGENTA		0x11
#define LIGHTMAGENTA 0x33

#define CM 255

#define XTD				120
#define XT0				0
#define XT1				(XT0+XTD*1)
#define XT2				(XT0+XTD*2)
#define XT3				(XT0+XTD*3)
#define XT4				(XT0+XTD*4)
#define XT5				(XT0+XTD*5)
#define XT6				(XT0+XTD*6)
#define XT7				(XT0+XTD*7)
#define XTM				(XT0+XTD*8)


#define XNRGB			(30)
#define XNRGM			(XNRGB+5*1000/AUDIO_FRMS)

#define XBAND			(XNRGM+15)
#define XADFE			(XNRGM+30)

#define HMIN			(-80.F)
#define HMAX			(+6.F)

#define NRGMAX			(+6.0F)
#define NRGMIN			(-90.0F)
#define YDB				(2.F)

#define YADFE			(+20)
#define HG				(+20)

#define YGNRG			(YADFE + 282)
#define YTRC			(int(YGNRG-NRGMAX*YDB))
#define YBNRG			(int(YGNRG-NRGMIN*YDB))



#define YTD				20
#define YT0				(YGNRG+210)
#define YT1				(YT0+YTD*1)
#define YT2				(YT0+YTD*2)
#define YT3				(YT0+YTD*3)
#define YT4				(YT0+YTD*4)
#define YTM				(YT0+YTD*5)


static void text_out   (int x, int y, int ColorIdx, char *pTxt);
static void val_out    (int x, int y, int ColorIdx, char *pFmt, ...);
static void set_color  (int idx);
static void cline      (int x, int y, int xTo, int yTo, int PenIdx);
static void line       (int x, int y, int xTo, int yTo);
static void bar        (int xl, int yt, int xr, int yb);
static void pixel      (int x, int y, int color);

/* ------------------------------------------------------------------- */
static void                text_out
/* ------------------------------------------------------------------- */
(
int x, 
int y, 
int ColorIdx, 
char *pTxt
) 
{
	Audio_tDbgWin *pWin = &gAudio.Dbg.Win;

	if (ColorIdx < AUDIO_DBG_WIN_COLORS)
	{
		SetTextColor(pWin->hDc, pWin->aColor[ColorIdx]);
		TextOut(pWin->hDc, x, y, pTxt, (int)strlen(pTxt));
	}
}

/* ------------------------------------------------------------------- */
static void                val_out
/* ------------------------------------------------------------------- */
(
int x, 
int y, 
int ColorIdx, 
char *pFmt, ...
)
{
	Audio_tDbgWin *pWin = &gAudio.Dbg.Win;
	char  aBuff[MAX_PATH];
	va_list  argPtr;                  /* Argument list pointer        */

    va_start(argPtr, pFmt );         /* Initialize va_ functions     */
	_vsnprintf(aBuff, MAX_PATH, pFmt, argPtr);
	va_end( argPtr );                 /* Close va_ functions          */

	if (ColorIdx < AUDIO_DBG_WIN_COLORS)
	{
		SetTextColor(pWin->hDc, pWin->aColor[ColorIdx]);
	}
	else ; // leave color as is
	TextOut(pWin->hDc, x, y, aBuff, (int)strlen(aBuff));
}


/* ------------------------------------------------------------------- */
static void                    set_color
/* ------------------------------------------------------------------- */
(
int idx
)
{
	Audio_tDbgWin *pWin = &gAudio.Dbg.Win;
	if (idx < AUDIO_DBG_WIN_PENS)
	{
		SelectObject(pWin->hDc, pWin->ahPen[idx]);
		SetTextColor(pWin->hDc, pWin->aColor[idx]);
	}
}

/* ------------------------------------------------------------------- */
static void                    cline
/* ------------------------------------------------------------------- */
(
int xFrom, 
int yFrom, 
int xTo, 
int yTo, 
int PenIdx
)
{
	Audio_tDbgWin *pWin = &gAudio.Dbg.Win;
	POINT prev;
	if (PenIdx < AUDIO_DBG_WIN_PENS)
	{
		SelectObject(pWin->hDc, pWin->ahPen[PenIdx]);
	}
	MoveToEx(pWin->hDc, xFrom, yFrom, &prev);
	LineTo(pWin->hDc, xTo, yTo);
}

/* ------------------------------------------------------------------- */
static void                    line
/* ------------------------------------------------------------------- */
(
int xFrom, 
int yFrom, 
int xTo, 
int yTo
)
{
	Audio_tDbgWin *pWin = &gAudio.Dbg.Win;
	POINT prev;
	MoveToEx(pWin->hDc, xFrom, yFrom, &prev);
	LineTo(pWin->hDc, xTo, yTo);
}

/* ------------------------------------------------------------------- */
static void                    pixel
/* ------------------------------------------------------------------- */
(
int x,
int y,
int clr
)
{
	Audio_tDbgWin *pWin = &gAudio.Dbg.Win;
    SetPixel(pWin->hDc, x, y, RGB(((clr & 0x03)>>0)*(CM/3), 
                                ((clr & 0x0c)>>2)*(CM/3), 
				                ((clr & 0x30)>>4)*(CM/3)));
}

/* ------------------------------------------------------------------- */
static void                    bar
/* ------------------------------------------------------------------- */
(
int xl, 
int yt, 
int xr, 
int yb
)
{
	Audio_tDbgWin *pWin = &gAudio.Dbg.Win;
	RECT rect;
	SetRect(&rect, xl,yt,xr,yb);
	FillRect(pWin->hDc, &rect, pWin->hBlackBrush);
}
/* ------------------------------------------------------------------- */
static void                     plt_nrg
/* ------------------------------------------------------------------- */
(
int x,
int *py, 
float ynew, 
int color
)
{
	int y;
    if (ynew < NRGMIN) ynew = NRGMIN;
    if (ynew > NRGMAX) ynew = NRGMAX;
	y = int(ynew*YDB);
	cline(x, YGNRG-*py, x+1, YGNRG-y , color);
	*py = y;
}
/* ------------------------------------------------------------------- */
static void                     plth
/* ------------------------------------------------------------------- */
(
int x,
int *py, 
float ynew, 
int color
)
{
	int y;
    if (ynew < HMIN) ynew = HMIN;
    if (ynew > HMAX) ynew = HMAX;
	y = int(ynew*YDB);
	cline(x, HG-*py, x+1, HG-y , color);
	*py = y;
}
/* ------------------------------------------------------------------- */
static void                    trc
/* ------------------------------------------------------------------- */
(
int x,
int y, 
int color
)
{
	cline(x-1, YTRC-5-y*4, x, YTRC-5-y*4, color);
	cline(x-1, YTRC-6-y*4, x, YTRC-6-y*4, color);
}
/* ------------------------------------------------------------------- */
static void                    trc1
/* ------------------------------------------------------------------- */
(
int x,
int y, 
int color
)
{
	cline(x-1, YTRC-5-y*4, x, YTRC-5-y*4, color);
}
/* ------------------------------------------------------------------- */
static void                    trc2
/* ------------------------------------------------------------------- */
(
int x,
int y, 
int color
)
{
	cline(x-1, YTRC-6-y*4, x, YTRC-6-y*4, color);
}
/* ------------------------------------------------------------------- */
static void                    trc3
/* ------------------------------------------------------------------- */
(
int x,
int y, 
int color
)
{
	cline(x-1, YTRC-7-y*4, x, YTRC-7-y*4, color);
}

/*****************************************************************************/
static void					nrg_plot_init
/*****************************************************************************/
(
) 
{
	int k;
	int ymax = int(YGNRG-NRGMAX*YDB);
	int ymin = int(YGNRG-NRGMIN*YDB);

	cline(XNRGB, ymax, 
		  XNRGB, ymin, LIGHTGRAY);
	cline(XNRGM, ymax, 
		  XNRGM, ymin, LIGHTGRAY);

	cline(XNRGB, ymax, 
		  XNRGM, ymax, LIGHTGRAY);
	cline(XNRGB, ymin, 
		  XNRGM, ymin, LIGHTGRAY);

	for (k = 0; k < 10; k++)
	{
		cline(XNRGB, int(YGNRG+k*10*YDB), 
			  XNRGM, int(YGNRG+k*10*YDB), DARKGRAY);
		val_out(0, int(YGNRG+k*10*YDB-7), YELLOW, "%3d", -k*10);
	}
	cline(XNRGB, YGNRG, 
		  XNRGM, YGNRG, WHITE);

	for (k = 0; k < 9; k++)
	{
		cline(XNRGB, int(HG+k*10*YDB), 
			  XNRGM, int(HG+k*10*YDB), DARKGRAY);
		val_out(0, int(HG+k*10*YDB-7), YELLOW, "%3d", -k*10);
	}
	cline(XNRGB, HG, 
		  XNRGM, HG, WHITE);

	for (k = 0; k < 5; k++)
	{
		cline(XNRGB+k*1000/AUDIO_FRMS, ymin, 
			  XNRGB+k*1000/AUDIO_FRMS, ymin+4, WHITE);
		val_out(XNRGB+k*1000/AUDIO_FRMS-4, ymin+5, 
			YELLOW, "%1d", k);
	}

}
#define		_ABLKS		(4)
static float       _aafAdfEn   [GAEC_BANDS+1][GAEC_ADF_SZ-_ABLKS];
static float       _aafAdsEn   [GAEC_BANDS+1][GAEC_ADF_SZ-_ABLKS];

static float       _aafAhfEn   [GAEC_BANDS+1][GAEC_HP_ADF_SZ-_ABLKS];
static float       _aafAhsEn   [GAEC_BANDS+1][GAEC_HP_ADF_SZ-_ABLKS];

/*-------------------------------------------------------------------------*/
static void                        gaec_adf_energy
/*-------------------------------------------------------------------------*/
(
GAEC_tDb *pDb
)
{
    int band;

    for (band = 0; band < GAEC_BANDS+1; band++)
    {
        int idx;

        for (idx = 0; idx < GAEC_ADF_SZ-_ABLKS; idx++)
        {
            float ac0 = 0;
            int blk;
            for (blk = 0; blk < _ABLKS; blk++)
            {
                float x = pDb->aafAdf[band][idx+blk];
                ac0 += x * x;
                if ((band != 0) && (band != GAEC_BANDS))
                {
                    x = pDb->aafAdf[band+GAEC_BANDS][idx+blk];
                    ac0 += x * x;
                }
            }
            _aafAdfEn[band][idx] = gaec_utl_en2log(ac0);
        }
    }
}
/*-------------------------------------------------------------------------*/
static void                        gaec_ads_energy
/*-------------------------------------------------------------------------*/
(
GAEC_tDb *pDb
)
{
    int band;

    for (band = 0; band < GAEC_BANDS+1; band++)
    {
        int idx;

        for (idx = 0; idx < GAEC_ADF_SZ-_ABLKS; idx++)
        {
            float ac0 = 0;
            int blk;
            for (blk = 0; blk < _ABLKS; blk++)
            {
                float x = pDb->aafAds[band][idx+blk];
                ac0 += x * x;
                if ((band != 0) && (band != GAEC_BANDS))
                {
                    x = pDb->aafAds[band+GAEC_BANDS][idx+blk];
                    ac0 += x * x;
                }
            }
            _aafAdsEn[band][idx] = gaec_utl_en2log(ac0);
        }
    }
}
/*-------------------------------------------------------------------------*/
static void                        gaec_ahf_energy
/*-------------------------------------------------------------------------*/
(
GAEC_tHpDb *pDb
)
{
    int band;

    for (band = 0; band < GAEC_BANDS+1; band++)
    {
        int idx;

        for (idx = 0; idx < GAEC_HP_ADF_SZ-_ABLKS; idx++)
        {
            float ac0 = 0;
            int blk;
            for (blk = 0; blk < _ABLKS; blk++)
            {
                float x = pDb->aafAdf[band][idx+blk];
                ac0 += x * x;
                if ((band != 0) && (band != GAEC_BANDS))
                {
                    x = pDb->aafAdf[band+GAEC_BANDS][idx+blk];
                    ac0 += x * x;
                }
            }
            _aafAhfEn[band][idx] = gaec_utl_en2log(ac0);
        }
    }
}
/*-------------------------------------------------------------------------*/
static void                        gaec_ahs_energy
/*-------------------------------------------------------------------------*/
(
GAEC_tHpDb *pDb
)
{
    int band;

    for (band = 0; band < GAEC_BANDS+1; band++)
    {
        int idx;

        for (idx = 0; idx < GAEC_HP_ADF_SZ-_ABLKS; idx++)
        {
            float ac0 = 0;
            int blk;
            for (blk = 0; blk < _ABLKS; blk++)
            {
                float x = pDb->aafAds[band][idx+blk];
                ac0 += x * x;
                if ((band != 0) && (band != GAEC_BANDS))
                {
                    x = pDb->aafAds[band+GAEC_BANDS][idx+blk];
                    ac0 += x * x;
                }
            }
            _aafAhsEn[band][idx] = gaec_utl_en2log(ac0);
        }
    }
}

/* ------------------------------------------------------------------- */
static void					plot_data
/* ------------------------------------------------------------------- */
(
int x0,
int y0,
float *pfData,
int iSz, 
int iAmp,
int color = WHITE
)
{
	float fMax = 0;
	int k;

	for (k = 0; k < iSz; k++)
	{
		float z = fabs(pfData[k]);
		if (fMax < z)
			fMax = z;
	}
	if (fMax > GAEC_EPS)
	{
		bar(x0, y0-iAmp, x0+iSz, y0+iAmp);
        set_color(DARKGRAY);
		line(x0, y0, x0+iSz, y0);
		line(x0, y0-iAmp, x0+iSz, y0-iAmp);
		line(x0, y0+iAmp, x0+iSz, y0+iAmp);

		set_color(color);
		fMax = iAmp/fMax;
		for (k = 0; k < iSz; k++)
		{
			int i = int(pfData[k] * fMax);
			line(x0+k, y0, x0+k, y0-i);
		}
	}
}

static int _PlotUdata = 0;
static const int _aiPlotUdataColor[7] = {
	LIGHTMAGENTA,
	LIGHTBLUE,
	LIGHTCYAN,
	LIGHTGREEN,
	YELLOW,
	LIGHTRED,
	WHITE
};
/* ------------------------------------------------------------------- */
static void					plot_udata
/* ------------------------------------------------------------------- */
(
int x0,
int y0,
int *piData, // positive
int iSz, 
int iAmp,
float fLate,
float fLost,
float fDelayCurrent,
float fDelayAv
)
{
	int iMax = 0;
	int k;

	if (_PlotUdata == 0)
	{
		bar(x0, y0, x0+iAmp+20, y0+iSz);
        set_color(DARKGRAY);
		line(x0,      y0, x0,      y0+iSz);
		line(x0+iAmp, y0, x0+iAmp, y0+iSz);

		for (k = 0; k < iSz+1; k+=20)
			line(x0, y0+k, x0+iAmp, y0+k);
	}

	_PlotUdata++;

	for (k = 0; k < iSz; k++)
	{
		int z = abs(piData[k]);
		if (iMax < z)
			iMax = z;
	}
	if (iMax > 0)
	{
		set_color(_aiPlotUdataColor[_PlotUdata%7]);
		float fMax = iAmp/float(iMax);
		int i0 = int(piData[0] * fMax);
		for (k = 1; k < iSz; k++)
		{
			int i = int(piData[k] * fMax);
			line(x0+i0, y0+k-1, x0+i, y0+k);
			i0 = i;
		}
		if (fDelayCurrent < 0)
			fDelayCurrent = 0;

		line(x0+(iAmp*3)/4, y0+int(fDelayCurrent),  
			 x0+(iAmp*1)/4, y0+int(fDelayCurrent));

		line(x0 + iAmp+1 + _PlotUdata * 2, y0+int(fDelayAv),  
			 x0 + iAmp+5 + _PlotUdata * 2, y0+int(fDelayAv));

		line(x0 + iAmp+3 + _PlotUdata * 2, y0, 
			 x0 + iAmp+3 + _PlotUdata * 2, y0-int(fLate*100*20));

		line(x0 + iAmp+3 + _PlotUdata * 2, y0+iSz,                    
			 x0 + iAmp+3 + _PlotUdata * 2, y0+iSz-int(fLost*100*20));
//        val_out(x0+iSz-70, y0-iAmp, color,"%5d", iMax);
	}
}

/* ------------------------------------------------------------------- */
static void					plot_vu
/* ------------------------------------------------------------------- */
(
int x0,
int y0,
float fNrg,
float fPeak
)
{
	x0 += _PlotUdata * 4;
	y0 += int(65*YDB);

	bar(x0-2,y0-int((6+65)*YDB),
		x0+2,y0);

	line(x0-2,y0-int((6+65)*YDB),
		 x0-2,y0);

	fNrg += 65-80;

	if (fNrg < 1)
	{
		fNrg = 1;
	}

	if (fNrg > 20) // -45 dBm
	{
		cline(
			x0, y0,
			x0, y0-int(20*YDB), GREEN);

		if (fNrg > 35) // -30 dBm
		{
			cline(
				x0, y0-int(35*YDB),
				x0, y0-int(20*YDB), LIGHTGREEN);

			if (fNrg > 59) // -6 dBm
			{
				cline(
					x0, y0-int(59*YDB),
					x0, y0-int(35*YDB), YELLOW);

				if (fNrg > 71) // +6 dBm
				{
					fNrg = 71;

					cline(
						x0, y0-int(71*YDB),
						x0, y0-int(59*YDB), LIGHTRED);

				}
				else // < +6
				{
					cline(
						x0, y0-int(fNrg*YDB),
						x0, y0-int(  59*YDB), LIGHTRED);
				}
			}
			else // < -6
			{
				cline(
					x0, y0-int(fNrg*YDB),
					x0, y0-int(  35*YDB), YELLOW);
			}
		}
		else // < -30
		{
			cline(
				x0, y0-int(fNrg*YDB),
				x0, y0-int(  20*YDB), LIGHTGREEN);
		}
	}
	else // < -45
	{
		cline(
			x0, y0-int(fNrg*YDB),
			x0, y0, GREEN);
	}

	fPeak += 6;
	int color = BLACK;

	if (fPeak > -6)
	{
		if (fPeak > 6)
			fPeak = 6;
		color = LIGHTRED;
	}
	else if (fPeak > -30)
	{
		color = YELLOW;
	}
	else if (fPeak > -45)
	{
		color = LIGHTGREEN;
	}
	else 
	{
		if (fPeak < -64)
			fPeak = -64;
		color = GREEN;
	}
	cline(
		x0-2, y0-int((fPeak+65)*YDB),
		x0+2, y0-int((fPeak+65)*YDB), color);
}

const static int __aiColor[GAEC_BANDS+1] = { 
    LIGHTBLUE, LIGHTMAGENTA, 
    RED, LIGHTRED, 
    BROWN, YELLOW, 
    GREEN, LIGHTGREEN, 
    CYAN, LIGHTCYAN,

    LIGHTBLUE, LIGHTMAGENTA, 
    RED, LIGHTRED, 
    BROWN, YELLOW, 
    GREEN, LIGHTGREEN, 
    CYAN, LIGHTCYAN,

	BLUE
}; 

/* ------------------------------------------------------------------- */
void						plot_bands
/* ------------------------------------------------------------------- */
(
int x0, 
int y0, 
float *pfBands, 
float fMin, 
float fMax,
char *pszName = NULL
)
{
	int k;
	int imax = int(fMax*YDB);
	int imin = int(fMin*YDB);

	bar(x0-1,		           y0-imax, 
		x0+2*(GAEC_BANDS+1)+1, y0-imin);

	for (k = int((fMin-9.9F)/10)*10; k < int((fMax+9.9F)/10)*10; k += 10)
	{
		int color = DARKGRAY;
		if ( k == 0 )
			color = WHITE;
		cline(x0-3,                  y0-int(k*YDB),
			  x0+2*(GAEC_BANDS+1)+3, y0-int(k*YDB), color);
	}

	for (k = 0; k < GAEC_BANDS+1; k++)
	{
		int i = int((pfBands[k])*YDB);
		if (i > imax)
			i = imax;
		if (i < imin)
			i = imin;

		cline(x0 + 2*k, y0, 		
			  x0 + 2*k, y0-i, __aiColor[k]);
	}
	if (pszName)
		text_out(x0, y0-imin, LIGHTGRAY, pszName);
}

/* ------------------------------------------------------------------- */
void                        plot_adf_energy
/* ------------------------------------------------------------------- */
(
int x0, 
int y0,
float aafData[][GAEC_ADF_SZ-_ABLKS],
float aafDataHp[][GAEC_HP_ADF_SZ-_ABLKS],
const int *piColor
)
{
    int k;
    int band;
    bar(x0, y0, x0+GAEC_ADF_SZ-_ABLKS, int(y0+80*YDB));

    set_color(DARKGRAY);
    for (k = 0; k < 9; k++)
    {
        int y = int(y0+YDB*k*10);
        line(x0, y, x0+GAEC_ADF_SZ-_ABLKS, y);
        val_out(XADFE-20, y-9, DARKGRAY,"%3d", 10-k*10);

    }

    for (band = 0; band < GAEC_BANDS+1; band++)
    {
        set_color(piColor[band]);
        for (k = 0; k < GAEC_ADF_SZ-_ABLKS-1; k++)
        {
            int x1 = int(YDB*(aafData[band][k]-10));
            int x2 = int(YDB*(aafData[band][k+1]-10));
            if (x1 < int(-YDB*80))
                x1 = int(-YDB*80);
            if (x2 < int(-YDB*80))
                x2 = int(-YDB*80);

            line(x0+k, y0-x1, x0+k+1, y0-x2);
		}
        for (k = 0; k < GAEC_HP_ADF_SZ-_ABLKS-1; k++)
        {
            int x1 = int(YDB*(aafDataHp[band][k]-10));
            int x2 = int(YDB*(aafDataHp[band][k+1]-10));
            if (x1 < int(-YDB*80))
                x1 = int(-YDB*80);
            if (x2 < int(-YDB*80))
                x2 = int(-YDB*80);

            line(x0+GAEC_ADF_SZ-_ABLKS-k,   y0+int(YDB*80)+x1, 
				 x0+GAEC_ADF_SZ-_ABLKS-k-1, y0+int(YDB*80)+x2);
        }
    }
}

/* ------------------------------------------------------------------- */
static float                   _band_avrg
/* ------------------------------------------------------------------- */
(
float *pf
)
{
	float f = 0;
	for (int k = 0; k < GAEC_BANDS+1; k++)
	{
		f += pf[k];
	}
	f *= 1.F/(GAEC_BANDS+1);
	return f;
}
/*****************************************************************************/
void					audio_dbg_plot
/*****************************************************************************/
(
) 
{
	Audio_tTmr *pTmr = gAudio.TmrCtrl.aTmr;
	GAEC_tSc *pSc = &gAudio.Aec.AecLL.Sc;
	GAEC_tDb *pDb = &gAudio.Aec.AecLL.Db;

	bar(XT0, YT0, XTM, YT0+YTD);
    {
		val_out(XT0, YT0, LIGHTGREEN,	"Frame  %d",	gAudio.Drv.iFrameNo);
        val_out(XT1, YT0, YELLOW,		"Time %7.2fs",	gAudio.Drv.iFrameNo*0.02);
		val_out(XT2, YT0, RED,			"CPU %7.2f%%",	100.*pTmr[AUDIO_TMR_PROCESS].fLast*0.05);
		val_out(XT3, YT0, WHITE,		"AGC %7.2f",	gAudio.Agc.fGainDb);
		val_out(XT4, YT0, WHITE,		"ERLE %7.2f",	pDb->fErleAv);
		val_out(XT5, YT0, WHITE,		"ERL %7.2f",	pDb->fErlAv);
//		val_out(XT6, YT0, WHITE,		"AM %d",		pDb->uAdfMode);
		val_out(XT6, YT0, CYAN,			"RcvDly %d",	pDb->iRcvDelay);
//		val_out(XT6, YT0, CYAN,			"AgcOn %d",		gAudio.Agc.bOn);

    }
	bar(XT0, YT1, XTM, YT1+YTD);
    {
		AudioIf_tHstgm *pH = &pTmr[AUDIO_TMR_MIC_JITTER].Hstgm;
		audio_hstgm_analyse(pH);
		val_out(XT0, YT1, BROWN,		"GenCnt %d",	gAudioGen.iCnt);
		val_out(XT1, YT1, YELLOW,		"GenEvt %d",	gAudioGen.iEvents);
		val_out(XT2, YT1, BROWN,		"GenNow %7.2f",	gAudioGen.fNow);
		val_out(XT3, YT1, WHITE,		"GenTS  %7.2f",	gAudioGen.fTS);
//		val_out(XT0, YT1, BROWN,		"Min %7.2f",	pH->fMin);
//		val_out(XT1, YT1, YELLOW,		"Avrg %7.2f",	pH->fAvrg);
//		val_out(XT2, YT1, BROWN,		"Max %7.2f",	pH->fMax);
//		val_out(XT3, YT1, WHITE,		"AdfAdd %d",	pDb->iAdsMaxAdded);

//		val_out(XT5, YT1, GREEN,		"ErleLH2 %7.1f", gAudio.Aec.HpLH.afErleAv[2]);
//		val_out(XT6, YT1, LIGHTGREEN,	"E3 %7.1f", gAudio.Aec.HpLH.afErleAv[3]);
		val_out(XT5, YT1, LIGHTBLUE,	"RcvHL %7.1f",	gAudio.Aec.SwHL.fAttRcv);
		val_out(XT6, YT1, LIGHTRED,		"S %7.1f",		gAudio.Aec.SwHL.fAttSnd);
    }
	bar(XT0, YT2, XTM, YT2+YTD);
    {
		AudioIf_tHstgm *pH = &pTmr[AUDIO_TMR_MIC_BLK].Hstgm;
		audio_hstgm_analyse(pH);
		val_out(XT0, YT2, RED,			"Min %7.2f",	pH->fMin);
		val_out(XT1, YT2, LIGHTRED,		"Avrg %8.4f",	pH->fAvrg);
		val_out(XT2, YT2, RED,			"Max %7.2f",	pH->fMax);
		val_out(XT3, YT2, LIGHTGRAY,	"AwNse %7.1f",	gAudio.Agc.fAwNse);
		val_out(XT4, YT2, WHITE,		"Alm %xH",		gAudio.Alarm.uAlarm);

		val_out(XT5, YT2, LIGHTBLUE,	"RcvHH %7.1f",	gAudio.Aec.SwHH.fAttRcv);
		val_out(XT6, YT2, LIGHTRED,		"S %7.1f",		gAudio.Aec.SwHH.fAttSnd);

    }
	bar(XT0, YT3, XTM, YT3+YTD);
    {
		AudioIf_tHstgm *pH = &pTmr[AUDIO_TMR_SPK_BLK].Hstgm;
		audio_hstgm_analyse(pH);
		val_out(XT0, YT3, BLUE,			"Min %7.2f",	pH->fMin);
		val_out(XT1, YT3, LIGHTBLUE,	"Avrg %8.4f",	pH->fAvrg);
//		val_out(XT2, YT3, BLUE,			"Max %7.2f",	pH->fMax);
		val_out(XT2, YT3, CYAN,			"AdfC %d",		pDb->iAdfCnt);
		val_out(XT3, YT3, CYAN,			"SS5 %7.2f",	pSc->afSSC[5]);

		val_out(XT4, YT3, WHITE,		"epc %7.2f",	pDb->fEpcCrit);
		val_out(XT5, YT3, WHITE,		"St %7.2f",		pDb->Cfg.fTCLst);
		val_out(XT6, YT3, WHITE,		"Dt %7.2f",		pDb->Cfg.fTCLdt);
    }
	{
		static int __aiLine[9];
		int x = gAudio.Dbg.Win.x;
		float af[GAEC_BANDS+1];

		if (x < XNRGB)
			x = XNRGB;

		int k, color;

		bar(x+1, int(HG-HMAX*YDB+1), x+5, int(YGNRG-NRGMIN*YDB-1));
		cline(x+4, int(HG-HMAX*YDB+1), x+4, int(YGNRG-NRGMIN*YDB-1), RED);

        color = (pSc->uAdapt) ? GREEN: BLACK;
		trc2(x, 1, color);

	    switch(pDb->uAdfMode){
		    case 0:	color = YELLOW; break;
		    case 1:	color = LIGHTGREEN; break;
		    case 2:	color = LIGHTMAGENTA; break;
		    case 3:	color = LIGHTRED; break;
		    case 4:	color = LIGHTCYAN; break;
		    case 5:	color = LIGHTBLUE; break;
		    default: color = BLACK; break;
		}
		trc(x, 2, color);
        color = (pDb->uIsDT) ? YELLOW: BLACK;
		trc(x, 3, color);

		trc1(x, 5, DARKGRAY);

        for (int band = 0; band < GAEC_BANDS+1; band++)
        {
            color = (pDb->afDtCrit[band] > 0.0) ? __aiColor[band]:BLACK;
    		trc1(x, 6+band, color);
            color = (pDb->afErlCrit[band] > 0.0) ? __aiColor[band]:BLACK;
    		trc2(x, 6+band, color);
//            color = (pDb->afVadErrCrit[band] > 0.0) ? __aiColor[band]:BLACK;
//    		trc3(x, 6+band, color);
        }
        trc1(x, 6+GAEC_BANDS+1, DARKGRAY);

		static bool bNrgPlotInit = false;
		if (!bNrgPlotInit)
		{
			nrg_plot_init();
			bNrgPlotInit = true;
		}

		for (k = 0; k < 9; k++)
			plt_nrg(x, __aiLine+k, -k*10.F, DARKGRAY);

		{
			static int i = 0;
			plt_nrg(x, &i, -pSc->fErle, BROWN);
		}
		{
			static int i = 0;
			if (x & 1)
				plt_nrg(x, &i, -pDb->fErleAv, YELLOW);
		}
		{
			static int i = 0;
			plt_nrg(x, &i, -pSc->fErl, GREEN);
		}
		{
			static int i = 0;
			if (x & 1)
				plt_nrg(x, &i, -pDb->fErlAv, LIGHTGREEN);
		}
		{
			static int i = 0;
			plt_nrg(x, &i, gAudio.Nrg.fNetRcv, BLUE);
		}
		{
			static int i = 0;
			plt_nrg(x, &i, gAudio.Nrg.fVol, CYAN);
		}
		{
			static int i = 0;
			plt_nrg(x, &i, gAudio.Nrg.fSpk, LIGHTBLUE);
		}
		{
			static int i = 0;
			plt_nrg(x, &i, gAudio.Nrg.fMic, RED);
		}
		{
			static int i = 0;
			plt_nrg(x, &i, gaec_utl_pkt_energy(gAudio.Aec.AecLL.afCnl), LIGHTCYAN);
		}
		{
			static int i = 0;
			plt_nrg(x, &i, gaec_utl_pkt_energy(gAudio.Aec.AecLL.afNlp), YELLOW);
		}
		{
			static int i = 0;
			if (x&1)
				plt_nrg(x, &i, pDb->fExpectedErrEn, LIGHTMAGENTA);
		}
		{
			static int i = 0;
			plt_nrg(x, &i, gAudio.Nrg.fAec, MAGENTA);
		}
		{
			static int i = 0;
			plt_nrg(x, &i, gAudio.Nrg.fAgc, BROWN);
		}
		{
			static int i = 0;
			plt_nrg(x, &i, gAudio.Agc.fGainDb-30, GREEN);
		}
		{
			static int i = 0;
			plt_nrg(x, &i, gAudio.Nrg.fNetSnd, LIGHTRED);
		}
		{
//			static int i = 0;
//			plt_nrg(x, &i, 10*log10f(pSc->Epc.fEpcXc), WHITE);
		}

////////////////////////////
		for (k = 0; k < 9; k++)
			plth(x, __aiLine+k, -k*10.F, DARKGRAY);

#if 0
		{
			static int i = 0;
			plth(x, &i, -pDb->fDtCrit, WHITE);
		}
		{
			static int i = 0;
			plth(x, &i, -20-pDb->fEpcCrit, WHITE);
		}
		{
			static int i = 0;
			plth(x, &i, -60+pSc->Epc.fEpcXc*20, LIGHTRED);
		}
		{
			static int ai[GAEC_BANDS+1] = {0};
			for (k = 0; k < GAEC_BANDS+1; k++)
			{
				plth(x, &ai[k], -pDb->afDtCrit[k], __aiColor[k]);
			}
		}
#if 0
		{
			static int ai[GAEC_BANDS+1] = {0};
			for (k = 0; k < GAEC_BANDS+1; k++)
			{
				plth(__x, &ai[k], -30-pSc->afAttRin[k], __aiColor[k]);
//				plth(__x, &ai[k], -30-pDb->afErleAv[k], __aiColor[k]);
			}
		}
		{
			static int ai[GAEC_BANDS+1] = {0};
			for (k = 0; k < GAEC_BANDS+1; k++)
			{
				plth(__x, &ai[k], -80+pSc->afAttErr[k], __aiColor[k]);
			}
		}
#endif
#else
		GAEC_tHpDb *pHpDb = &gAudio.Aec.HpLH;
		GAEC_tHpSc *pHpSc = &gAudio.Aec.HpSc;

		{
			static int i = 0;
			plth(x, &i, gaec_utl_pkt_energy(pHpDb->afTbuf), BLUE);
		}
		{
			static int i = 0;
			plth(x, &i, gaec_utl_pkt_energy(gAudio.Aec.Rcv.afLH), LIGHTBLUE);
		}
		{
			static int i = 0;
			plth(x, &i, gaec_utl_pkt_energy(pHpDb->afSbuf), RED);
		}
		{
			static int i = 0;
			plth(x, &i, gaec_utl_pkt_energy(gAudio.Aec.Snd.afLH), LIGHTRED);
		}
		{
			static int i = 0;
			if (x&1)
				plth(x, &i, _band_avrg(pHpDb->afVadErrNse), RED);
		}
		{
			static int i = 0;
			if (!(x&1))
				plth(x, &i, _band_avrg(pHpDb->afVadRinNse), BLUE);
		}
		{
			static int i = 0;
			if (!(x&1))
				plth(x, &i, -_band_avrg(pHpDb->afErleAv), YELLOW);
		}
		{
			static int i = 0;
			if (x&1)
				plth(x, &i, -_band_avrg(pHpDb->afErlAv), LIGHTGREEN);
		}
		{
			static int i = 0;
			plth(x, &i, -_band_avrg(pHpSc->afErl), LIGHTGREEN);
		}
		{
			static int i = 0;
			plth(x, &i, -_band_avrg(pHpSc->afErle), YELLOW);
		}
		{
			static int i = 0;
//			plth(x, &i, _band_avrg(pHpSc->afRoutNrg), CYAN);
		}
		{
			static int i = 0;
//			plth(x, &i, _band_avrg(pHpSc->afErrNrg), LIGHTCYAN);
		}
		{
			static int i = 0;
			plth(x, &i, _band_avrg(pHpDb->afExpectedErrNrg), LIGHTMAGENTA);
		}

		{
			static int i = 0;
			plth(x, &i, gAudio.Aec.SwHL.fRcvNrg, LIGHTCYAN);
		}
		{
			static int i = 0;
			plth(x, &i, gAudio.Aec.SwHL.fSndNrg, YELLOW);
		}
		{
			static int i = 0;
			plth(x, &i, gAudio.Aec.SwHH.fRcvNrg, CYAN);
		}
		{
			static int i = 0;
			plth(x, &i, gAudio.Aec.SwHH.fSndNrg, BROWN);
		}
#if 0
		{
			static int i = 0;
			plth(x, &i, -20+20*log10(gAudio.Aec.SwHL.fNrCoef), LIGHTCYAN);
		}
#endif
		{
			static int i = 0;
			plth(x, &i, -21+gAudio.Aec.SwHL.fAttRcv, LIGHTBLUE);
		}
		{
			static int i = 0;
			plth(x, &i, -19+gAudio.Aec.SwHL.fAttSnd, LIGHTRED);
		}
		{
			static int i = 0;
			plth(x, &i, -31+gAudio.Aec.SwHH.fAttRcv, BLUE);
		}
		{
			static int i = 0;
			plth(x, &i, -29+gAudio.Aec.SwHH.fAttSnd, RED);
		}

#endif

		if ((x & 0xf) == 0)
		{
			gaec_adf_energy(pDb);
			gaec_ads_energy(pDb);
			gaec_ahf_energy(&gAudio.Aec.HpLH);
			gaec_ahs_energy(&gAudio.Aec.HpLH);
			plot_adf_energy(XADFE,             YADFE, _aafAdsEn, _aafAhsEn, __aiColor);
			plot_adf_energy(XADFE+GAEC_ADF_SZ, YADFE, _aafAdfEn, _aafAhfEn, __aiColor);
		}
#if 0
		plot_data(XADFE,                  YADFE, 
			pSc->Epc.afEpcRcv, GAEC_EPC_MAXD, 20, BLUE);
		plot_data(XADFE+GAEC_EPC_MAXD+10, YADFE, 
			pSc->Epc.afEpcSnd, GAEC_EPC_MAXD, 20, RED);

		plot_data(XADFE,                  YADFE+45, 
			pDb->afEpcRcvNse, GAEC_EPC_MAXD, 20, BLUE);
		plot_data(XADFE+GAEC_EPC_MAXD+10, YADFE+45, 
			pDb->afEpcSndNse, GAEC_EPC_MAXD, 20, RED);

		plot_data(XADFE,                  YADFE+90, 
			pSc->Epc.afEpcRcvNorm, GAEC_EPC_MAXD, 20, LIGHTBLUE);
		plot_data(XADFE+GAEC_EPC_MAXD+10, YADFE+90, 
			pSc->Epc.afEpcSndNorm, GAEC_EPC_MAXD, 20, LIGHTRED);
#endif
//		for (k = 0; k < GAEC_BANDS+1; k++)  af[k] = -20*log10f(pDb->afNrCoef[k]);
		plot_bands(XBAND+  0, YBNRG-int(YDB*  0), pSc->afAttErr, -2, 42, "AttS");
		for (k = 0; k < GAEC_BANDS+1; k++) af[k] = gAudio.Aec.HpSc.afAttErr[GAEC_BANDS-k];
		plot_bands(XBAND+ 45, YBNRG-int(YDB* 0), af,            -2, 42,"LH");

		plot_bands(XBAND+  0, YBNRG-int(YDB* 50), pSc->afAttRin, -2, 42,"AttR");
		for (k = 0; k < GAEC_BANDS+1; k++) af[k] = gAudio.Aec.HpSc.afAttRin[GAEC_BANDS-k];
		plot_bands(XBAND+ 45, YBNRG-int(YDB* 50), af,            -2, 42,"LH");

		plot_bands(XBAND+100, YBNRG-int(YDB*  0), pDb->afErleAv, -2, 42,"ErleAv");
		for (k = 0; k < GAEC_BANDS+1; k++) af[k] = gAudio.Aec.HpLH.afErleAv[GAEC_BANDS-k];
		plot_bands(XBAND+145, YBNRG-int(YDB*  0), af,            -2, 42,"LH");

		plot_bands(XBAND+100, YBNRG-int(YDB* 60), pDb->afAdfErl, -12, 62,"adf");
		for (k = 0; k < GAEC_BANDS+1; k++) af[k] = gAudio.Aec.HpLH.afAdfErl[GAEC_BANDS-k];
		plot_bands(XBAND+145, YBNRG-int(YDB* 60), af,            -12, 62,"LH");

		plot_bands(XBAND+200, YBNRG-int(YDB* 60), pDb->afErlAv,  -12, 62,"ErlAv");
		for (k = 0; k < GAEC_BANDS+1; k++) af[k] = gAudio.Aec.HpLH.afErlAv[GAEC_BANDS-k];
		plot_bands(XBAND+245, YBNRG-int(YDB* 60), af,            -12, 62,"LH");

		for (k = 0; k < GAEC_BANDS+1; k++) af[k] = pDb->afVadRinNse[k]+90;
		plot_bands(XBAND+200, YBNRG-int(YDB* 0), af,             -2, 38,"Nse");
		for (k = 0; k < GAEC_BANDS+1; k++) af[k] = gAudio.Aec.HpLH.afVadErrNse[GAEC_BANDS-k]+90;
		plot_bands(XBAND+245, YBNRG-int(YDB* 0), af,             -2, 38,"LH");

#if 0
		for (k = 0; k < GAEC_BANDS+1; k++)
			af[k] = pDb->afErleAv[k]+pDb->afErlAv[k];
		plot_bands(XBAND+120, YBNRG, af, -2, 52,"tcl");

		for (k = 0; k < GAEC_BANDS+1; k++)
			af[k] = pDb->afExpectedErrEn[k]+60;
		plot_bands(XBAND+180, YBNRG, af, -2, 52,"exp");
		plot_bands(XBAND+  0, YBNRG-int(YDB*50), pSc->afErl,    -12, 40,"erl");
#endif

//		for (k = 0; k < GAEC_BANDS+1; k++)
//			af[k] = pDb->afVadErrNse[k]+60;
//		plot_bands(XBAND+180, YBNRG-int(YDB*50), af,            -12, 40,"nse");


		
		for (k = 0; k < GAEC_BANDS+1; k++) af[k] = pSc->afRinEn[k]+90;
		plot_bands(XBAND+400, YBNRG-int(YDB*0), af, -2, 96,"Rin");
		for (k = 0; k < GAEC_BANDS+1; k++) af[k] = gAudio.Aec.HpSc.afRinNrg[GAEC_BANDS-k]+90;
		plot_bands(XBAND+445, YBNRG-int(YDB*0), af, -2, 96,"LH");


//		for (k = 0; k < GAEC_BANDS+1; k++) af[k] = pSc->afErrEn[k]+90;
		for (k = 0; k < GAEC_BANDS+1; k++) af[k] = pSc->afSoutNrg[k]+90;
		plot_bands(XBAND+300, YBNRG-int(YDB*0), af, -2, 96,"Sout");
//		for (k = 0; k < GAEC_BANDS+1; k++) af[k] = gAudio.Aec.HpSc.afErrNrg[GAEC_BANDS-k]+90;
		for (k = 0; k < GAEC_BANDS+1; k++) af[k] = gAudio.Aec.HpSc.afNlpNrg[GAEC_BANDS-k]+90;
		plot_bands(XBAND+345, YBNRG-int(YDB*0), af, -2, 96,"LH");

#if 1
		_PlotUdata = 0;
		for (int idx = 0; idx < AUDIO_IF_PARTY_MAX; idx++)
		{
			audio_lock();

			Audio_tJbParty *pParty = gAudio.Jb.apParty[idx];
			if (pParty 
	//			&& gAudio.Jb.apParty[idx]->bRunning
				)
			{
				plot_udata(
					XADFE+GAEC_ADF_SZ*2, 
					YADFE, 
					&pParty->Stts.JitterHistogram.aiData[0],	
					AUDIO_IF_HSTGM_MAX_SZ,
					60,
					pParty->Stts.iPktsLate / (pParty->Stts.iPktsTotal+0.1F),
					pParty->Stts.iPktsLost / (pParty->Stts.iPktsTotal+0.1F),
					pParty->Stts.fDelayCurrent,
					pParty->Stts.fDelayAverage
					);
				plot_vu(XADFE+GAEC_ADF_SZ*2+120,
						YADFE,
						pParty->fNrg,
						pParty->fPeak);

			}
			audio_unlock();

			audio_lock();
			Audio_tNsParty *pNsParty = gAudio.Ns.apParty[idx];
			if (pNsParty)
			{
				set_color(_aiPlotUdataColor[_PlotUdata%7]);
				plot_vu(XADFE+GAEC_ADF_SZ*2+120,
						YADFE+int(75*YDB),
						pNsParty->fNrg,
						pNsParty->fPeak);
			}
			audio_unlock();
		}
#endif
		x++;
		if (x > XNRGM)
			x = XNRGB;
		gAudio.Dbg.Win.x = x;
	}
}
/* ------------------------------------------------------------------- */
static LRESULT CALLBACK                audio_dbg_Wnd_proc
/* ------------------------------------------------------------------- */
(
HWND hWnd, 
UINT message, 
WPARAM wParam, 
LPARAM lParam
)
{
	switch (message) 
	{
		case WM_COMMAND:
        {
			return DefWindowProc(hWnd, message, wParam, lParam);
			break;
        }
		case WM_PAINT:
        {
        	PAINTSTRUCT ps;

			HDC hdc = BeginPaint(hWnd, &ps);
			EndPaint(hWnd, &ps);
			break;
        }
		case WM_DESTROY:
        {
			audio_dbg_delete_win(hWnd);
			break;
        }
		default:
        {
			return DefWindowProc(hWnd, message, wParam, lParam);
        }
   }
   return 0;
}

/*****************************************************************************/
bool					audio_dbg_open_win
/*****************************************************************************/
(
) 
{
	bool brc = false;
	WNDCLASSEX wcex;
	LOGBRUSH lb;
	Audio_tDbgWin *pWin = &gAudio.Dbg.Win;

	pWin->hInstance = GetModuleHandle(NULL);

   // Initialize global strings
//	LoadString(hInstance, IDS_APP_TITLE, __szTitle, MAX_LOADSTRING);
//	LoadString(hInstance, IDC_SIM, __szWindowClass, MAX_LOADSTRING);

	if (pWin->hBlackBrush == NULL)
		pWin->hBlackBrush = CreateSolidBrush(RGB(0,0,0)); // deleted by system ??

	wcex.cbSize = sizeof(WNDCLASSEX); 

	wcex.style			= CS_OWNDC;
	wcex.lpfnWndProc	= (WNDPROC)audio_dbg_Wnd_proc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= pWin->hInstance;
	wcex.hIcon			= NULL;
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW); // default one
	wcex.hbrBackground	= pWin->hBlackBrush; // deleted by system
	wcex.lpszMenuName	= NULL; // no menu
	wcex.lpszClassName	= __szWindowClass;
	wcex.hIconSm		= NULL;

	if (!RegisterClassEx(&wcex))
	{ 
		audio_log_err("AudioDbgWin -- RegisterClassEx failed");
		return false;
	}

	pWin->hWnd = CreateWindow(
		__szWindowClass, // 
		__szTitle, 
		WS_OVERLAPPEDWINDOW, // style
		20,//CW_USEDEFAULT,	// h pos
		20,//0,				// v pos
		800,//CW_USEDEFAULT,	// h size
		560,				// v size
		NULL,			// parent
		NULL,			// menu
		pWin->hInstance,		// app
		NULL);			// data


    if (pWin->hWnd)
    {
		pWin->hDc = GetDC(pWin->hWnd); 

	// create pens and colors

		lb.lbStyle = BS_SOLID; 
		lb.lbHatch = 0;
		for (int k = 0; k < AUDIO_DBG_WIN_COLORS; k++)
		{
			pWin->aColor[k] = RGB(
					((k & 0x03)>>0)*(CM/3), 
					((k & 0x0c)>>2)*(CM/3), 
					((k & 0x30)>>4)*(CM/3));

			lb.lbColor = pWin->aColor[k]; 

			pWin->ahPen[k] = ExtCreatePen(
					PS_COSMETIC | PS_SOLID, // style
					1, // width
					&lb, 
					0, 
					NULL); 
			
		}
		pWin->hSysPen = SelectObject(pWin->hDc, pWin->ahPen[0]);
		SetBkColor(pWin->hDc, RGB(0,0,0));

		brc = true;
	}
	return brc;

}
/* ------------------------------------------------------------------- */
void					audio_dbg_win_activate
/* ------------------------------------------------------------------- */
(
bool bOn
)
{
	Audio_tDbgWin *pWin = &gAudio.Dbg.Win;
	if (pWin->bCreated)
	{
		if (bOn)
		{
			pWin->x = 0;
			ShowWindow(pWin->hWnd, SW_SHOWNORMAL);
			UpdateWindow(pWin->hWnd);
		}
		else
		{
			ShowWindow(pWin->hWnd, SW_HIDE);
		}
		pWin->bActive = bOn;
	}
}
/* ------------------------------------------------------------------- */
void                    audio_dbg_delete_win
/* ------------------------------------------------------------------- */
(
HWND hWnd
)
{
	Audio_tDbgWin *pWin = &gAudio.Dbg.Win;

	if (pWin->bCreated)
	{
		if (pWin->hSysPen)
			SelectObject(pWin->hDc, pWin->hSysPen);

		if (pWin->bActive)
			audio_dbg_win_activate(false);

		for (int k = 0; k < AUDIO_DBG_WIN_COLORS; k++)
		{
			DeleteObject(pWin->ahPen[k]);
		}
	//	DeleteObject(SIM_hBlackBrush);
		ReleaseDC(hWnd, pWin->hDc);

		pWin->bCreated = false;
	}
}
