#include "audio_defs.h"
#include "audio_speex.h"

/*****************************************************************************/
DWORD				audio_speex_decoder_init
/*****************************************************************************/
(
void *pObj,
WORD wMode
)
{
	unsigned long rc = AUDIO_IF_ERR_NONE;
	Audio_tSpeex *pDec = (Audio_tSpeex *)pObj;
	int tmp = 0;

	memset(pDec, 0, sizeof(Audio_tSpeex));
	pDec->wMode = wMode;

	switch (wMode)
	{
	case AUDIO_IF_PT_SPEEX_NB: 
		pDec->pState = speex_decoder_init(&speex_nb_mode);
		tmp = 0;
		speex_decoder_ctl(pDec->pState, SPEEX_SET_ENH, &tmp);
		break;
	case AUDIO_IF_PT_SPEEX_WB:
		pDec->pState = speex_decoder_init(&speex_wb_mode);
		tmp = 1;
		speex_decoder_ctl(pDec->pState, SPEEX_SET_ENH, &tmp);
		break;
	case AUDIO_IF_PT_SPEEX_UWB:
		pDec->pState = speex_decoder_init(&speex_uwb_mode);
		tmp = 1;
		speex_decoder_ctl(pDec->pState, SPEEX_SET_ENH, &tmp);
		break;
	default:
		pDec->wMode = 0;
		break;
	}
	speex_bits_init(&pDec->Bits);

	if ((pDec->pState == NULL) || 
		(pDec->wMode == 0))
	{
		audio_log_err("audio_speex_encoder_init -- failed");
		rc = AUDIO_IF_ERR_FAILED;
	}
	return rc;
}
/*****************************************************************************/
DWORD				audio_speex_encoder_init
/*****************************************************************************/
(
void *pObj,
WORD wMode
)
{
	unsigned long rc = AUDIO_IF_ERR_NONE;
	Audio_tSpeex *pEnc = (Audio_tSpeex *)pObj;
	int iParam = 0;

	memset(pEnc, 0, sizeof(Audio_tSpeex));

	pEnc->wMode = wMode;

	switch (wMode)
	{
	case AUDIO_IF_PT_SPEEX_NB: 
		pEnc->pState = speex_encoder_init(&speex_nb_mode);
		iParam = 8; // 4
		speex_encoder_ctl(pEnc->pState,SPEEX_SET_QUALITY,&iParam);
//		iParam = 10;
//		speex_encoder_ctl(state,SPEEX_SET_COMPLEXITY,&iParam);
		break;
	case AUDIO_IF_PT_SPEEX_VBR_NB:
		pEnc->pState = speex_encoder_init(&speex_nb_mode);
		iParam = 4; 
		speex_encoder_ctl(pEnc->pState,SPEEX_SET_QUALITY,&iParam);
		iParam = 1;
		speex_encoder_ctl(pEnc->pState,SPEEX_SET_VBR,&iParam);
		iParam = 4;
		speex_encoder_ctl(pEnc->pState,SPEEX_SET_VBR_QUALITY,&iParam);
		iParam = 10;
		speex_encoder_ctl(pEnc->pState,SPEEX_SET_COMPLEXITY,&iParam);
		break;
	case AUDIO_IF_PT_SPEEX_WB:
	case AUDIO_IF_PT_SPEEX_VBR_WB:
		pEnc->pState = speex_encoder_init(&speex_wb_mode);
//		iParam = 5;
//		speex_encoder_ctl(pEnc->pState,SPEEX_SET_QUALITY,&iParam);
		if (wMode == AUDIO_IF_PT_SPEEX_VBR_WB)
		{
			iParam = 1;
			speex_encoder_ctl(pEnc->pState,SPEEX_SET_VBR,&iParam);
			iParam = 5;
			speex_encoder_ctl(pEnc->pState,SPEEX_SET_VBR_QUALITY,&iParam);
		}
//		iParam = 10;
//		speex_encoder_ctl(pEnc->pState,SPEEX_SET_COMPLEXITY,&iParam);
		break;
	case AUDIO_IF_PT_SPEEX_UWB: 
	case AUDIO_IF_PT_SPEEX_VBR_UWB: 
		pEnc->pState = speex_encoder_init(&speex_uwb_mode);
//		iParam = 5;
//		speex_encoder_ctl(pEnc->pState,SPEEX_SET_QUALITY,&iParam);
		if (wMode == AUDIO_IF_PT_SPEEX_VBR_UWB)
		{
			iParam = 1;
			speex_encoder_ctl(pEnc->pState,SPEEX_SET_VBR,&iParam);
			iParam = 4;
			speex_encoder_ctl(pEnc->pState,SPEEX_SET_VBR_QUALITY,&iParam);
		}
//		iParam = 8;
//		speex_encoder_ctl(pEnc->pState,SPEEX_SET_COMPLEXITY,&iParam);
		break;
	default:
		audio_log_err("audio_speex_encoder_init -- bad mode %d", wMode);
		rc |= AUDIO_IF_ERR_RANGE;
		pEnc->wMode = 0;
		break;
	}
	speex_bits_init(&pEnc->Bits);

	if (pEnc->pState == NULL)
	{
		audio_log_err("audio_speex_encoder_init -- failed");
		rc |= AUDIO_IF_ERR_FAILED;
	}
	return rc;
}
/*****************************************************************************/
int				  audio_speex_decode
/*****************************************************************************/
(
void *pObj,
short *psOut,
BYTE *pcIn, // can be NULL
int  iSz
)
{
	audio_log_trc("audio_speex_decode -- pObj=%p psOut=%p pcIn=%p iSz=%d",
		pObj,psOut,pcIn,iSz);

	Audio_tSpeex *pDec = (Audio_tSpeex *)pObj;
	float af[AUDIO_FRSZ32];
	int iDataSz = 0;
	int k;

	switch (pDec->wMode)
	{
	case AUDIO_IF_PT_SPEEX_NB: 
		iDataSz = 1;
		break;		
	case AUDIO_IF_PT_SPEEX_WB: 
		iDataSz = 2;
		break;		
	case AUDIO_IF_PT_SPEEX_UWB: 
		iDataSz = 4;
		break;		
	default:
		audio_log_err("audio_speex_decode -- unknown mode %d", pDec->wMode);
		break;
	}
	if (iDataSz)
	{
		/* do actual decoding of block */
		if (pcIn)
		{
//				speex_bits_reset(&pDec->Bits);
			speex_bits_read_from(&pDec->Bits, (char*)pcIn, iSz);
			speex_decode(pDec->pState, &pDec->Bits, af);
//				audio_log_trc("speex_decode");
			pDec->iLostCnt = 0;
		}
		else
		{
			pDec->iLostCnt++;

			if (pDec->iLostCnt < 3)
			{
				speex_decode(pDec->pState, NULL, af);
			}
			else
			{
				pDec->iLostCnt = 3;
				for (k = 0; k < AUDIO_FRSZ8 * iDataSz; k++)
				{
					af[k] = 0;
				}
			}
		}
		for (k = 0; k < AUDIO_FRSZ8 * iDataSz; k++)
		{
			int i = int(af[k]);
			if (i > 32767)
				i = 32767;
			if (i < -32768)
				i = -32768;
			psOut[k] = short(i);
		}
	}
	return AUDIO_FRSZ8 * iDataSz;
}
/*****************************************************************************/
int					audio_speex_encode
/*****************************************************************************/
(
void *pObj,
BYTE *pcOut,
short *psIn
)
{
	Audio_tSpeex *pEnc = (Audio_tSpeex *)pObj;
	float af[AUDIO_FRSZ32];
	int iEncoded = 0;
	int iDataSz = 0;
	int iCodeSz = 0;

	switch (pEnc->wMode)
	{
	case AUDIO_IF_PT_SPEEX_NB: 
		iDataSz = 1;
		iCodeSz = AUDIO_CSZ_SPEEX_NB;
		break;
	case AUDIO_IF_PT_SPEEX_WB: 
		iDataSz = 2;
		iCodeSz = AUDIO_CSZ_SPEEX_WB;
		break;
	case AUDIO_IF_PT_SPEEX_UWB: 
		iDataSz = 4;
		iCodeSz = AUDIO_CSZ_SPEEX_UWB;
		break;
	default:
		audio_log_err("audio_speex_encode -- unknown mode %d", pEnc->wMode);
		break;
	}

	if (iDataSz)
	{
		for (int k = 0; k < AUDIO_FRSZ8 * iDataSz; k++)
		{
			af[k] = psIn[k];
		}
		speex_bits_reset(&pEnc->Bits);
		speex_encode(pEnc->pState, af, &pEnc->Bits);

		iEncoded = speex_bits_write(&pEnc->Bits, (char*)pcOut, iCodeSz);
	}
	return iEncoded;
}
/*****************************************************************************/
void				audio_speex_decoder_delete
/*****************************************************************************/
(
void *pObj
)
{
	Audio_tSpeex *pDec = (Audio_tSpeex *)pObj;
	speex_bits_destroy(&pDec->Bits);
	speex_decoder_destroy(pDec->pState);
}
/*****************************************************************************/
void				audio_speex_encoder_delete
/*****************************************************************************/
(
void *pObj
)
{
	Audio_tSpeex *pEnc = (Audio_tSpeex *)pObj;
	speex_bits_destroy(&pEnc->Bits);
	speex_encoder_destroy(pEnc->pState);
}


