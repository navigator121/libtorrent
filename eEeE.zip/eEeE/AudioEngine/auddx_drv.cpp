#include "audio_defs.h"

DWORD auddx_spk_init(char *);
DWORD auddx_spk_start(void);
DWORD auddx_spk_poll(bool *pbOutOfSinc,bool *pbDelayAdded);
DWORD auddx_spk_stop(void);

DWORD auddx_mic_init(char *);
DWORD auddx_mic_start(void);
DWORD auddx_mic_poll(void);
DWORD auddx_mic_stop(void);

/*****************************************************************************/
DWORD					auddx_init
/*****************************************************************************/
(
)
{
	DWORD rc = AUDIO_IF_ERR_NONE;
	rc |= auddx_mic_init(gAudio.Drv.acMicDeviceName);
	rc |= auddx_spk_init(gAudio.Drv.acSpkDeviceName);
	return rc;
}
/*****************************************************************************/
DWORD					auddx_start
/*****************************************************************************/
(
)
{
	return auddx_mic_start();
}
/*****************************************************************************/
DWORD					auddx_poll
/*****************************************************************************/
(
int iEventNo
)
{
	DWORD rc = AUDIO_IF_ERR_NONE;
	Audio_tDrvDxMic *pMic = &gAudio.Drv.Dx.Mic;
	Audio_tDrvDxSpk *pSpk = &gAudio.Drv.Dx.Spk;

	rc |= auddx_mic_poll();
	if (pMic->iBlksRead > 0)
	{
		// we can run audio processing
		pMic->iBlksRead--;

		if (gAudio.Drv.iFrameNo == 0)
			rc |= auddx_spk_start();

		gAudio.Drv.iFrameNo++;
	
		audio_tmr_start(AUDIO_TMR_PROCESS);
		short *pSpkData = audio_process(pMic->asData);
		audio_tmr_stop(AUDIO_TMR_PROCESS, NULL);

		// just copy data into spk
		if (pSpk->iQSz < (AUDIO_DRV_SPK_QSZ - 2))
		{
			memcpy(&pSpk->asQ[pSpk->iQWriteIdx*AUDIO_DRV_SPK_BLK_SZ/sizeof(short)],
					pSpkData,//		pMic->asData,
				   AUDIO_DRV_MIC_BLK_SZ);
			pSpk->iQWriteIdx += 2;
			pSpk->iQWriteIdx &= (AUDIO_DRV_SPK_QSZ-1);
			pSpk->iQSz += 2;
		}
		else
		{
			audio_log_err("audio_drv_poll -- spk q overflow");
			audio_resync();
		}

		// kick dbg thread
		SetEvent(gAudio.Dbg.ahEvents[1]);
	}
	// push spk data out

	rc |= auddx_spk_poll(&gAudio.Drv.bOutOfSinc, &gAudio.Drv.bDelayAdded);

	return rc;
}
/*****************************************************************************/
DWORD					auddx_stop
/*****************************************************************************/
(
)
{
	auddx_spk_stop();
	auddx_mic_stop();

	return AUDIO_IF_ERR_NONE;
}
