#include "audio_defs.h"

typedef struct {
	int iChannels;
	DWORD dwMask;
} _tDesc;

/* ------------------------------------------------------------------- */

static const _tDesc _DescSpk[] = {
//	{1, KSAUDIO_SPEAKER_MONO},
	{2, KSAUDIO_SPEAKER_STEREO},
	{4, KSAUDIO_SPEAKER_QUAD},
	{6, KSAUDIO_SPEAKER_5POINT1},
	{8, KSAUDIO_SPEAKER_7POINT1},
	{0, 0}
};

static const GUID  aguidEnumCatsSpk[] = { 
		STATIC_KSCATEGORY_AUDIO, 
		STATIC_KSCATEGORY_RENDER 
};

/* ------------------------------------------------------------------- */

static const _tDesc _DescMic[] = {
	{1,	KSAUDIO_SPEAKER_MONO}, // hope these will suffice - spk for mic:-)))
	{2, KSAUDIO_SPEAKER_STEREO},
	{0, 0}
};

static const GUID  aguidEnumCatsMic[] = { 
		STATIC_KSCATEGORY_AUDIO, 
		STATIC_KSCATEGORY_CAPTURE 
};



/* ------------------------------------------------------------------- */
static int				audks_open_ms
/* ------------------------------------------------------------------- */
(
Audio_tDrvKsMs *pMs,
char *pszName,
const GUID * pGuidCat,
const int  iGuids,
const _tDesc *pDesc,
const bool bCapture
)
{
    HRESULT hr = S_OK;
	int iChannels = 0;
	bool bOpen = false;
	int  iSimilarNames = 0;

	pMs->pFilter = audks_find_filter( pGuidCat, iGuids, pszName, bCapture, &iSimilarNames);
	if (!pMs->pFilter)
	{
		if (iSimilarNames > 0)
			pMs->pFilter = audks_find_filter( pGuidCat, iGuids, pszName, bCapture, &iSimilarNames);
	}

	if (pMs->pFilter)
	{

//		audio_log_inf("audks_spk_open ------------------------- trying %s", 
//			pMs->pFilter->m_szFriendlyName);

		// let's try to open it with some channels
		for (int idx = 0; pDesc[idx].iChannels > 0; idx++)
		{
			iChannels = pDesc[idx].iChannels;
			audio_log_inf("audks_open_ms -- trying %d channels, format ex", iChannels);

			WAVEFORMATEXTENSIBLE wfx;
			wfx.Format.wFormatTag = WAVE_FORMAT_EXTENSIBLE;
			wfx.Format.nChannels = iChannels;
			wfx.Format.nSamplesPerSec = 48000;
			wfx.Format.nBlockAlign = wfx.Format.nChannels*2;
			wfx.Format.nAvgBytesPerSec = wfx.Format.nSamplesPerSec * wfx.Format.nBlockAlign;
			wfx.Format.wBitsPerSample = 16;
			wfx.Format.cbSize = sizeof(WAVEFORMATEXTENSIBLE)-sizeof(WAVEFORMATEX);
			wfx.Samples.wValidBitsPerSample = 16;
			wfx.SubFormat = KSDATAFORMAT_SUBTYPE_PCM;
			wfx.dwChannelMask = pDesc[idx].dwMask;

			pMs->pPin = pMs->pFilter->CreatePin(&wfx.Format);

			if (!pMs->pPin)
			{
				audio_log_inf("audks_open_ms -- trying %d channels, format pcm", iChannels);

				// driver can't handle WAVEFORMATEXTENSIBLE, so fall back to
				// WAVEFORMATEX format descriptor and try again
				wfx.Format.wFormatTag = WAVE_FORMAT_PCM;
				// set unused members to zero
				wfx.Format.cbSize = 0;
				wfx.Samples.wValidBitsPerSample = 0;
				wfx.dwChannelMask = 0;
				wfx.SubFormat = GUID_NULL;

				pMs->pPin = pMs->pFilter->CreatePin(&wfx.Format);
			}

			if (pMs->pPin)
			{
				audio_log_inf("audks_open_ms -- found \"%s\" pin [ID=%d] with %d channels", 
					pMs->pPin->Name(), 
					pMs->pPin->GetId(),
					iChannels);
				
				bOpen = true;
				break;
			}
		}
	}

	if (!bOpen)
	{
		audio_log_err("audks_open_ms -- failed");
		iChannels = 0;
	}
	else
		audio_log_inf("audks_open_ms\n");

	return iChannels;
}
/* ------------------------------------------------------------------- */
static void				_spk_pkts_init
/* ------------------------------------------------------------------- */
(
int		iChannels,
HANDLE *ph
)
{
	Audio_tDrvKsSpk *pSpk = &gAudio.Drv.Ks.Spk;

	memset(pSpk->aasBuf, 0, sizeof(pSpk->aasBuf));
	for (int i = 0; i < AUDIO_DRV_SPK_BLKS; i++)
	{
        pSpk->aPkt[i].Header.Size = sizeof(KSSTREAM_HEADER);
		pSpk->aPkt[i].Header.Data = (BYTE*)&pSpk->aasBuf[i][0];
        pSpk->aPkt[i].Header.FrameExtent = AUDIO_DRV_SPK_BLK_SZ*iChannels;
		// if we were capturing, we would init this to 0
        pSpk->aPkt[i].Header.DataUsed = pSpk->aPkt[i].Header.FrameExtent;
        pSpk->aPkt[i].Header.PresentationTime.Numerator = 1;
        pSpk->aPkt[i].Header.PresentationTime.Denominator = 1;
		pSpk->aPkt[i].Signal.hEvent = ph[i];

	}
}
/* ------------------------------------------------------------------- */
static void				_mic_pkts_init
/* ------------------------------------------------------------------- */
(
int		iChannels,
HANDLE *ph
)
{
	Audio_tDrvKsMic *pMic = &gAudio.Drv.Ks.Mic;

	memset(pMic->aasBuf, 0, sizeof(pMic->aasBuf));

	for (int i = 0; i < AUDIO_DRV_MIC_BLKS; i++)
	{
        pMic->aPkt[i].Header.Size = sizeof(KSSTREAM_HEADER);
		pMic->aPkt[i].Header.Data = (BYTE*)&pMic->aasBuf[i][0];
        pMic->aPkt[i].Header.FrameExtent = AUDIO_DRV_MIC_BLK_SZ*iChannels;
		// if we were capturing, we would init this to 0
        pMic->aPkt[i].Header.DataUsed = 0;
        pMic->aPkt[i].Header.PresentationTime.Numerator = 1;
        pMic->aPkt[i].Header.PresentationTime.Denominator = 1;
		pMic->aPkt[i].Signal.hEvent = ph[i];

	}
}

/*****************************************************************************/
DWORD					audks_init	
/*****************************************************************************/
(
) 
{
	DWORD rc = AUDIO_IF_ERR_NONE;
	Audio_tDrv *pDrv = &gAudio.Drv;
	Audio_tDrvKsSpk *pSpk = &pDrv->Ks.Spk;
	Audio_tDrvKsMic *pMic = &pDrv->Ks.Mic;

	pMic->dwED = AUDIO_ED;
	pMic->dwSD = AUDIO_SD;
	bool bOk = true; 


	if (!pMic->bOpen)
	{
		pMic->iChannels = audks_open_ms(&pMic->Ms, 
			pDrv->acMicDeviceName,
			aguidEnumCatsMic, 2,
			_DescMic,
			true);
		if (pMic->iChannels > 0)
			pMic->bOpen = true;
	}
	bOk &= pMic->bOpen;
	
	pSpk->dwED = AUDIO_ED;
	pSpk->dwSD = AUDIO_SD;

	if (!pSpk->bOpen)
	{
		pSpk->iChannels = audks_open_ms(&pSpk->Ms, 
			pDrv->acSpkDeviceName,
			aguidEnumCatsSpk, 2,
			_DescSpk,
			false);
		if (pSpk->iChannels > 0)
			pSpk->bOpen = true;
	}
	bOk &= pSpk->bOpen;

	if(bOk)
	{
		_spk_pkts_init(pDrv->Ks.Spk.iChannels, pDrv->ahEvents + 2);
		_mic_pkts_init(pDrv->Ks.Mic.iChannels, 
			pDrv->ahEvents + 2 + AUDIO_DRV_SPK_EVENTS);
	}

	if (!bOk)
		rc |= AUDIO_IF_ERR_FAILED;
	return rc;
}

/* ------------------------------------------------------------------- */
static bool				audks_spk_write
/* ------------------------------------------------------------------- */
(
)
{
	Audio_tDrvKsSpk *pSpk = &gAudio.Drv.Ks.Spk;
	AUDKS_DATA_PACKET *pPkt = &pSpk->aPkt[pSpk->idx];

	bool b = false;
	if (pSpk->bOpen)
	{
		if(pSpk->Ms.pPin)
		{
			HRESULT hr = pSpk->Ms.pPin->WriteData(&pPkt->Header, &pPkt->Signal);
			if (SUCCEEDED(hr))
			{
				pSpk->idx++;
				pSpk->idx &= (AUDIO_DRV_SPK_BLKS-1);
				pSpk->dwlWriteOffset += 
					AUDIO_DRV_SPK_BLK_SZ*pSpk->iChannels;

				b = true;
			}
			else
				audio_log_err("audks_spk_write");

		}
	}
	return b;
}
/* ------------------------------------------------------------------- */
static bool				audks_mic_read
/* ------------------------------------------------------------------- */
(
)
{
	Audio_tDrvKsMic *pMic = &gAudio.Drv.Ks.Mic;
	AUDKS_DATA_PACKET *pPkt = &pMic->aPkt[pMic->iPutIdx];

	bool b = false;
	if (pMic->bOpen)
	{
		if(pMic->Ms.pPin)
		{

//			if (pMic->asPktState[pMic->iPutIdx] == _ST_FAILED)
//				audks_mic_read(); // retry
			if (pMic->asPktState[pMic->iPutIdx] > 0)
			{
				audio_log_trc("audks_mic_read -- resubmit %d [%lld] ???",
					pMic->iPutIdx, pMic->dwlReadOffset);

				// first time only
				if (pMic->asPktState[pMic->iPutIdx] == 1)
					pMic->sPktState++;

				pMic->asPktState[pMic->iPutIdx] ++;
			}
			else
			{
				pPkt->Header.DataUsed = 0;
				HRESULT hr = pMic->Ms.pPin->ReadData(&pPkt->Header, &pPkt->Signal);
				if (SUCCEEDED(hr))
				{
					pMic->asPktState[pMic->iPutIdx] = 1;
					pMic->iPutIdx++;
					pMic->iPutIdx &= (AUDIO_DRV_MIC_BLKS-1);
					b = true;
				}
				else
				{
//					pMic->asPktState[pMic->iPutIdx] = _ST_FAILED;
					audio_log_err("audks_mic_read - failed");
				}
			}
		}
	}
	return b;
}
/*****************************************************************************/
DWORD					audks_start	
/*****************************************************************************/
(
) 
{
	DWORD rc = AUDIO_IF_ERR_NONE;
	Audio_tDrvKsSpk *pSpk = &gAudio.Drv.Ks.Spk;
	Audio_tDrvKsMic *pMic = &gAudio.Drv.Ks.Mic;

	bool bOk = false;
	int k;

	if (pMic->bOpen)
	{
		if(pMic->Ms.pPin)
		{
			if (SUCCEEDED(pMic->Ms.pPin->SetState(KSSTATE_RUN)))
			{
				// we give all the buffers to mic - it will not increase delay
				bOk = true;
				for (k = 0; k < AUDIO_DRV_MIC_BLKS; k++)
				{
					bOk &= audks_mic_read();
					if (k == 0)
					{
						audio_tmr_peek(AUDIO_TMR_BASE, &pMic->fStartTime);
						pMic->fTime = 0;
					}
				}
			}
		}
	}

	if (pSpk->bOpen)
	{
		if(pSpk->Ms.pPin)
		{
			if (SUCCEEDED(pSpk->Ms.pPin->SetState(KSSTATE_RUN)))
			{
				bOk &= true;
				// and prime spk
				for (k = 0; k < AUDIO_DRV_SPK_PRIME; k++)
				{
					bOk &= audks_spk_write();
				}
			}
		}
	}

	if (!bOk)
		rc = AUDIO_IF_ERR_FAILED;
	else
		gAudio.Drv.iFrameNo++;

	return rc;
}
/*****************************************************************************/
bool					audks_mic_poll
/*****************************************************************************/
(
DWORD *pdwRC
)
{
	Audio_tDrvKsMic *pMic = &gAudio.Drv.Ks.Mic;
	KSAUDIO_POSITION Pos = {0};
	bool bRead = false;

	if ((!pMic->bOpen) || (!pMic->Ms.pPin))
		return bRead;

//	return rc;

	if ((pMic->dwED != AUDIO_ED) || (pMic->dwSD != AUDIO_SD))
	{
		audio_log_err("audks_mic_poll -- in mem corupted"); 
		*pdwRC |= AUDIO_IF_ERR_MEM_CORRUPTED;
	}

	audio_tmr_start(AUDIO_TMR_MIC_POLL);

	HRESULT hr = pMic->Ms.pPin->GetPosition(&Pos);

	// Pos.PlayOffset -> captured signal
	// Pos.WriteOffset -> till what point we are allowed to read
	if (SUCCEEDED(hr))
	{
//		__int64 iDlt = Pos.PlayOffset - pMic->dwlReadOffset;
		__int64 iDlt = Pos.WriteOffset - pMic->dwlReadOffset;
		// see if a blk was written into by a drv - so we can read a next block
		int iMargin = AUDIO_DRV_MIC_BLK_SZ*pMic->iChannels;
#if 0
		int iMarginEx = iMargin;
		if (0 == strncmp("Sound Blaster Audigy", gAudio.Drv.acMicDeviceName,20))
			iMarginEx += iMargin>>1;
		if (0 == strncmp("SigmaTel Audio", gAudio.Drv.acMicDeviceName,14))
			iMarginEx += iMargin>>1;
		if (0 == strncmp("C-Media Wave Device", gAudio.Drv.acMicDeviceName,19))
			iMarginEx += iMargin;

		if (iDlt > iMarginEx)
#else
		if (iDlt > iMargin)
#endif
		{
#if 1
		audio_log_trc("audks_mic_poll -- play:%d read:%d dlt:%d mar:%d", 
				int(Pos.PlayOffset),
				int(pMic->dwlReadOffset),
				int(iDlt),
				iMargin);
#endif
			short *pData = &pMic->aasBuf[pMic->iGetIdx][0];
			if (pMic->iChannels == 1)
			{
				for (int k = 0; k < AUDIO_FRSZ48; k++)
				{
					pMic->asData[k] = pData[k];
				}
			}
			else // 2 channels
			{
				for (int k = 0; k < AUDIO_FRSZ48; k++)
				{
					int x = pData[2*k+0];
					x += pData[2*k+1];
					x += 1;
					x >>= 1;
					if (x > 32767)
						x = 32767;
					if (x < -32768)
						x = -32768;
					pMic->asData[k] = x;
				}
			}
			bRead = true;
			pMic->iGetIdx ++;
			pMic->iGetIdx &= (AUDIO_DRV_MIC_BLKS-1);
			pMic->dwlReadOffset += iMargin;


			// resubmit read pkt back
			audks_mic_read();
			audio_tmr_restart(AUDIO_TMR_MIC_BLK, NULL);

			// recover mic timing and collect jitter stts
			float fTime = gAudio.Drv.fNow - pMic->fStartTime;
			pMic->fTime += 20.F;
			float fDlt = fTime - pMic->fTime;

			if (fDlt > 0)
				pMic->fTime += AUDIO_DRV_MIC_PTAU * fDlt;
			else
				pMic->fTime += AUDIO_DRV_MIC_NTAU * fDlt;

			audio_hstgm_add(
					&gAudio.TmrCtrl.aTmr[AUDIO_TMR_MIC_JITTER].Hstgm, 
					fDlt);
		}
		else //if (iDlt < sz)
		{
			; // nothing to do - yet
		}
	}
	else
	{
		audio_log_err("audks_mic_poll -- get pos failed with 0x%x", hr);
		*pdwRC |= AUDIO_IF_ERR_DRIVER_FAIL;
	}
	audio_tmr_stop(AUDIO_TMR_MIC_POLL, NULL);


	if ((pMic->dwED != AUDIO_ED) || (pMic->dwSD != AUDIO_SD))
	{
		audio_log_err("audks_mic_poll -- out mem corupted"); 
		*pdwRC |= AUDIO_IF_ERR_MEM_CORRUPTED;
	}

	return bRead;
}
/*****************************************************************************/
DWORD					audks_spk_poll
/*****************************************************************************/
(
bool *pbOutOfSinc,
bool *pbDelayAdded
)
{
	Audio_tDrvKsSpk *pSpk = &gAudio.Drv.Ks.Spk;
	DWORD rc = AUDIO_IF_ERR_NONE;
	HRESULT hr;

	if ((!pSpk->bOpen) || (!pSpk->Ms.pPin))
		return AUDIO_IF_ERR_FAILED;

	*pbOutOfSinc = false;
	*pbDelayAdded = false;

	// events can be seriosly late, and we may need to fill more than one blk
	if ((pSpk->dwED != AUDIO_ED) || (pSpk->dwSD != AUDIO_SD))
	{
		audio_log_err("audks_spk_poll -- in mem corupted");
		return AUDIO_IF_ERR_MEM_CORRUPTED;
	}

	audio_tmr_start(AUDIO_TMR_SPK_POLL);
	for (;;)
	{
		// dwWriteOffset : where we can write from
		KSAUDIO_POSITION Pos = {0};
		hr = pSpk->Ms.pPin->GetPosition(&Pos);
		if (SUCCEEDED(hr))
		{
			audio_log_trc("audks_spk_poll -- play=%lld write=%lld", 
				Pos.PlayOffset, Pos.WriteOffset);

			// Pos.PlayOffset = what actually has been played
			__int64 iDlt = pSpk->dwlWriteOffset - Pos.PlayOffset; 
			// dwWriteOffset must be ahead of Pos.PlayOffset by a few ms
			int iMargin = (AUDIO_DRV_SPK_BLK_SZ*pSpk->iChannels)>>2;
			if (iDlt < iMargin)
			{
				audio_hstgm_add(&gAudio.TmrCtrl.aTmr[AUDIO_TMR_SPK_OVERRUN].Hstgm, 
						iDlt /(2.e-3F*AUDIO_DRV_FS*pSpk->iChannels));

				*pbOutOfSinc = true;

				if (iDlt < 0)
					pSpk->fCrit += (AUDIO_CRIT_MAX/3);
				else
					pSpk->fCrit += (AUDIO_CRIT_MAX/3) * (iMargin-int(iDlt))/float(iMargin);

				audio_log_err("audks_spk_poll -- overrun: %lld [%lld %lld], crit %7.3f", 
					iDlt, pSpk->dwlWriteOffset, Pos.PlayOffset, pSpk->fCrit);

				if (pSpk->fCrit > AUDIO_CRIT_MAX)
				{
					if (pSpk->iLookAhead < AUDIO_DRV_SPK_BLKS/2)
					{
						audks_spk_write();

						iDlt += AUDIO_DRV_SPK_BLK_SZ*pSpk->iChannels;

						pSpk->fCrit = 0.F;
						audio_log_war("audks_spk_poll -- adding bulk delay"); 
						*pbDelayAdded = true;
						pSpk->iLookAhead++;
					}
					else
					{
						audio_log_err("audks_spk_poll -- unable to add bulk delay, already %d blks", pSpk->iLookAhead); 
					}
				}
			}

			if (pSpk->iQSz > 0)
			{
				int idx = pSpk->iQReadIdx*AUDIO_DRV_SPK_BLK_SZ/sizeof(short);
				short *psFrom = &pSpk->asQ[idx];
				short *psTo = &pSpk->aasBuf[pSpk->idx][0];
				for (int k = 0; k < AUDIO_DRV_SPK_BLK_SZ; k++)
				{
					short x = *psFrom++;
					for (int chan = 0; chan < pSpk->iChannels; chan++)
					{
						*psTo++ = x;
					}
				}
				pSpk->iQReadIdx++;
				pSpk->iQReadIdx &= (AUDIO_DRV_SPK_QSZ-1);
				pSpk->iQSz--;

				audks_spk_write();

				audio_tmr_restart(AUDIO_TMR_SPK_BLK, NULL);

				// we allow 1 spike per minute, i.e. 3 per 3 minutes
				pSpk->fCrit -= AUDIO_CRIT_MAX/(100.0F*60.F*3.F);
				if (pSpk->fCrit < 0)
					pSpk->fCrit = 0;
			}
			else
			{
				break; // there is nothing to do
			}
		}
		else
		{
			audio_log_err("audks_spk_poll -- get pos failed with 0x%x", hr);
			break;
		}
	}
	audio_tmr_stop(AUDIO_TMR_SPK_POLL, NULL);

	if ((pSpk->dwED != AUDIO_ED) || (pSpk->dwSD != AUDIO_SD))
	{
		audio_log_err("audks_spk_poll -- out mem corupted"); 
		rc = AUDIO_IF_ERR_MEM_CORRUPTED;
	}

	return rc;
}

/*****************************************************************************/
DWORD					audks_poll	
/*****************************************************************************/
(
int iEvent
) 
{
	DWORD rc = AUDIO_IF_ERR_NONE;
	Audio_tDrvKsSpk *pSpk = &gAudio.Drv.Ks.Spk;
	Audio_tDrvKsMic *pMic = &gAudio.Drv.Ks.Mic;

	iEvent -= AUDIO_DRV_SPK_EVENTS + 2;
	if (iEvent >= 0) // mic event arrived
	{
		pMic->asPktState[iEvent] = 0;
	}

	if (pMic->sPktState > 0)
	{
		audio_log_trc("audks_poll --  %d resubmitting...", pMic->sPktState);
		if (audks_mic_read())
		{
			audio_log_trc("audks_poll --  ... done");
			pMic->sPktState--;
		}
		else
		{
			audio_log_trc("audks_poll --  ... failed");
		}
	}

	for (;!rc;)
	{
		if (audks_mic_poll(&rc))
		{
			// we can run audio processing
			gAudio.Drv.iFrameNo++;
	
			audio_tmr_start(AUDIO_TMR_PROCESS);
			short *pSpkData = audio_process(pMic->asData);
			audio_tmr_stop(AUDIO_TMR_PROCESS, NULL);

			// just copy data into spk
			if (pSpk->iQSz < (AUDIO_DRV_SPK_QSZ - 2))
			{
				memcpy(&pSpk->asQ[pSpk->iQWriteIdx*AUDIO_DRV_SPK_BLK_SZ/sizeof(short)],
						pSpkData,//		pMic->asData,
						AUDIO_DRV_MIC_BLK_SZ);
				pSpk->iQWriteIdx += 2;
				pSpk->iQWriteIdx &= (AUDIO_DRV_SPK_QSZ-1);
				pSpk->iQSz += 2;
			}
			else
			{
				audio_log_err("audks_poll -- spk q overflow");
				audio_resync();
			}

			// kick dbg thread
			SetEvent(gAudio.Dbg.ahEvents[1]);
		}
		else
		{
			break;
		}
	}
	// push spk data out

	rc |= audks_spk_poll(&gAudio.Drv.bOutOfSinc, &gAudio.Drv.bDelayAdded);

	return rc;
}

/*****************************************************************************/
void					audks_stop_ms
/*****************************************************************************/
(
Audio_tDrvKsMs *pMs
) 
{
	if(pMs->pPin)
	{
		pMs->pPin->SetState(KSSTATE_PAUSE);
		pMs->pPin->SetState(KSSTATE_STOP);
		pMs->pPin->ClosePin();
//		delete pMs->pPin;
		pMs->pPin = NULL;
	}
	if(pMs->pFilter)
	{
		delete pMs->pFilter;
		pMs->pFilter = NULL;
	}
}
/*****************************************************************************/
DWORD					audks_stop	
/*****************************************************************************/
(
) 
{
	DWORD rc = AUDIO_IF_ERR_NONE;
	Audio_tDrvKsSpk *pSpk = &gAudio.Drv.Ks.Spk;
	Audio_tDrvKsMic *pMic = &gAudio.Drv.Ks.Mic;

	if (pMic->bOpen)
	{
		audio_log_inf("audks_stop -- stopping mic");
		audks_stop_ms(&pMic->Ms);
		pMic->bOpen = false;
	}
	else
		rc |= AUDIO_IF_ERR_ALREADY_REMOVED;

	if (pSpk->bOpen)
	{
		audio_log_inf("audks_stop -- stopping spk");
		audks_stop_ms(&pSpk->Ms);
		pSpk->bOpen = false;
	}
	else
		rc |= AUDIO_IF_ERR_ALREADY_REMOVED;

	audio_log_inf("audks_stop -- mic and spk stopped");
	return rc;
}

