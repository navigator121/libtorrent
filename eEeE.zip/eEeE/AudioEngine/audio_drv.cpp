#include <xmmintrin.h>
#include "audio_defs.h"

DWORD auddx_init	(void);
DWORD auddx_start	(void);
DWORD auddx_poll	(int iEventNo);
DWORD auddx_stop	(void);

DWORD audks_init	(void);
DWORD audks_start	(void);
DWORD audks_poll	(int iEventNo);
DWORD audks_stop	(void);

static const char *aszMode[] = {
	"WAVE",
	"DirectSound",
	"KernelStreaming",
	"ASIO"
};
/*****************************************************************************/
static inline DWORD					audio_drv_init
/*****************************************************************************/
(
)
{
	DWORD rc = AUDIO_IF_ERR_NONE;
	switch (gAudio.Drv.iDrvMode)
	{
	case AUDIO_IF_DRV_MODE_ASIO:
	case AUDIO_IF_DRV_MODE_WDM: 
		rc = audks_init(); 
		if ((rc & ~AUDIO_IF_ERR_WARNING) == AUDIO_IF_ERR_NONE)
		{
			gAudio.Drv.iDrvMode = AUDIO_IF_DRV_MODE_WDM;
			break;
		}
		else // DELIBERATE FALL THROUGH !!!! 
		{
			audks_stop();
			audio_log_inf("audio_drv_init --FAILED with WDM, trying with DirectX "); 
		}

	case AUDIO_IF_DRV_MODE_DIRECTX:	
		rc = auddx_init(); 
		gAudio.Drv.iDrvMode = AUDIO_IF_DRV_MODE_DIRECTX;
		break;
	default:
		rc = AUDIO_IF_ERR_FAILED;
		break;
	}

	if (rc)
		audio_log_err("audio_drv_init -- failed with 0x%X", rc); 
	else
	{
		audio_log_inf("audio_drv_init -- mode = %s", aszMode[gAudio.Drv.iDrvMode]); 
		SetEvent(gAudio.Dbg.ahEvents[AUDIO_DBG_EVENT_WIN_OPEN]);
	}

	return rc;
}

/*****************************************************************************/
static inline DWORD					audio_drv_poll
/*****************************************************************************/
(
int iEventNo
)
{
	DWORD rc = AUDIO_IF_ERR_NOT_INITIALIZED;

	gAudio.Drv.bOutOfSinc = false;
	gAudio.Drv.bDelayAdded = false;

	switch (gAudio.Drv.iDrvMode)
	{
	case AUDIO_IF_DRV_MODE_DIRECTX:	rc = auddx_poll(iEventNo); break;
	case AUDIO_IF_DRV_MODE_WDM: rc = audks_poll(iEventNo); break;
	}

	if (gAudio.Drv.bOutOfSinc)
		audio_resync();
	else
		audio_resync(false);

	if (gAudio.Drv.bDelayAdded)
		audio_delay_added();

	if (rc)
		audio_log_err("audio_drv_poll -- failed with 0x%X", rc); 
	else ; // ok

	return rc;
}

/*****************************************************************************/
static inline DWORD					audio_drv_start
/*****************************************************************************/
(
)
{
	DWORD rc = AUDIO_IF_ERR_NOT_INITIALIZED;
	switch (gAudio.Drv.iDrvMode)
	{
	case AUDIO_IF_DRV_MODE_DIRECTX:	rc = auddx_start(); break;
	case AUDIO_IF_DRV_MODE_WDM: rc = audks_start(); break;
	}

	if (rc)
		audio_log_err("audio_drv_start -- failed with 0x%X", rc); 
	else
	{
		gAudio.Conf.aParty[AUDIO_IF_PARTY_HOST].bActive = true;
		audio_log_inf("audio_drv_start -- done"); 
	}
	return rc;
}
/*****************************************************************************/
static inline DWORD					audio_drv_stop
/*****************************************************************************/
(
)
{
	DWORD rc = AUDIO_IF_ERR_NOT_INITIALIZED;

	audio_log_inf("audio_drv_stop -- echo delay is %7.1f ms",
		0.125F*(gAudio.Aec.AecLL.Db.iRcvDelay + 5* GAEC_BANDS));
	audio_log_inf("audio_drv_stop -- erle=%7.1f dB erl=%7.1f dB",
		gAudio.Aec.AecLL.Db.fErleAv, gAudio.Aec.AecLL.Db.fErlAv);

	gAudio.Conf.aParty[AUDIO_IF_PARTY_HOST].bActive = false;

	switch (gAudio.Drv.iDrvMode)
	{
	case AUDIO_IF_DRV_MODE_DIRECTX:	rc = auddx_stop(); break;
	case AUDIO_IF_DRV_MODE_WDM: rc = audks_stop(); break;
	}


	if (rc)
		audio_log_err("audio_drv_stop -- failed with 0x%X", rc); 
	else
		audio_log_inf("audio_drv_stop -- done"); 

	return rc;
}

/*****************************************************************************/
static DWORD				_check_names
/*****************************************************************************/
(
char *pszMicDeviceName, 
char *pszSpkDeviceName
)
{
	DWORD rc = AUDIO_IF_ERR_NONE;
	MMRESULT mm;
	UINT outs = waveOutGetNumDevs();
	UINT ins = waveInGetNumDevs();
	UINT ui;

	WAVEOUTCAPS Caps = {0};
	WAVEINCAPS ICaps = {0};

	for (ui=0; ui < outs; ui++)
	{
		mm = waveOutGetDevCaps(ui, &Caps, sizeof(Caps));
		audio_log_inf("audio_drv_check_names: out[%d]=\"%s\"", ui, Caps.szPname);
	}
	for (ui=0; ui < ins; ui++)
	{
		mm = waveInGetDevCaps(ui, &ICaps, sizeof(ICaps));
		audio_log_inf("audio_drv_check_names: in[%d]=\"%s\"", ui, ICaps.szPname);
	}

	if (pszSpkDeviceName) 
	{
		for (ui=0; ui < outs; ui++)
		{
			mm = waveOutGetDevCaps(ui, &Caps, sizeof(Caps));

			if (mm == MMSYSERR_NOERROR)
			{
				if (strncmp(Caps.szPname, pszSpkDeviceName, strlen(pszSpkDeviceName)) == 0)
				{
					pszSpkDeviceName = Caps.szPname;
					audio_log_inf("audio_drv_check_names: \"%s\" == \"%s\"", pszSpkDeviceName, Caps.szPname);
					break;
				}
				else
				{
					audio_log_inf("audio_drv_check_names: \"%s\" != \"%s\"", pszSpkDeviceName, Caps.szPname);
				}
			}
		}
		if (ui >= outs) // not found
			pszSpkDeviceName = NULL;
	}

	if (pszMicDeviceName) 
	{
		for (ui=0; ui < ins; ui++)
		{
			mm = waveInGetDevCaps(ui, &ICaps, sizeof(ICaps));

			if (mm == MMSYSERR_NOERROR)
			{
				if (strncmp(ICaps.szPname, pszMicDeviceName, strlen(pszMicDeviceName)) == 0)
				{
					pszMicDeviceName = ICaps.szPname;
					audio_log_inf("audio_drv_check_names: \"%s\" == \"%s\"", pszSpkDeviceName, ICaps.szPname);
					break;
				}
				else
				{
					audio_log_inf("audio_drv_check_names: \"%s\" != \"%s\"", pszSpkDeviceName, ICaps.szPname);
				}
			}
		}
		if (ui >= ins) // not found
			pszMicDeviceName = NULL;
	}

	if (pszMicDeviceName && pszSpkDeviceName) // both names are set
	{
		; // done
	}
	else if (pszMicDeviceName && (!pszSpkDeviceName)) // only mic name is set
	{
		for (ui=0; ui < outs; ui++)
		{
			mm = waveOutGetDevCaps(ui, &Caps, sizeof(Caps));

			if (mm == MMSYSERR_NOERROR)
			{
				if (strncmp(Caps.szPname, pszMicDeviceName, strlen(pszMicDeviceName)) == 0)
				{
					pszSpkDeviceName = Caps.szPname;
					break;
				}
			}

		}
		if (!pszSpkDeviceName && outs) // just take first in line
		{
			mm = waveOutGetDevCaps(0, &Caps, sizeof(Caps));
			if (mm == MMSYSERR_NOERROR)
			{
				pszSpkDeviceName = Caps.szPname;
			}
		}
	}
	else if ((!pszMicDeviceName) && pszSpkDeviceName) // only spk is set
	{
		for (ui=0; ui < ins; ui++)
		{
			mm = waveInGetDevCaps(ui, &ICaps, sizeof(ICaps));

			if (mm == MMSYSERR_NOERROR)
			{
				if (strncmp(ICaps.szPname, pszSpkDeviceName, strlen(pszSpkDeviceName)) == 0)
				{
					pszMicDeviceName = ICaps.szPname;
					break;
				}
			}

		}
		if (!pszMicDeviceName && ins) // just take first in line
		{
			mm = waveInGetDevCaps(0, &ICaps, sizeof(ICaps));
			if (mm == MMSYSERR_NOERROR)
			{
				pszMicDeviceName = ICaps.szPname;
			}
		}
	}
	else if ((!pszMicDeviceName) && (!pszSpkDeviceName)) // none is set
	{
		for (ui=0; ui < outs; ui++)
		{
			mm = waveOutGetDevCaps(ui, &Caps, sizeof(Caps));
			if (mm == MMSYSERR_NOERROR)
			{
				int dlt = _strnicmp("Virtual", Caps.szPname, 7);
//				audio_log_inf("audio_drv_check_names -- Comparing \"%s\" to \"Virtual\", spkdlt=%d", Caps.szPname, dlt);
				if (0 != dlt)
				{
					pszSpkDeviceName = Caps.szPname;
					break;
				}
			}
		}

		if (ui < outs) // we found something
		{
			//shantanu@eyeball.com
			//June 19, 2007
			//take default/first mic from list, don't match with speaker

/*			for (ui=0; ui < ins; ui++)
			{
				mm = waveInGetDevCaps(ui, &ICaps, sizeof(ICaps));
				if (mm == MMSYSERR_NOERROR)
				{
					if (strcmp(ICaps.szPname, pszSpkDeviceName) == 0)
					{
						pszMicDeviceName = ICaps.szPname;
						break;
					}
				}
			}
*/
			if (!pszMicDeviceName && ins) // can't find a match
			{
				mm = waveInGetDevCaps(0, &ICaps, sizeof(ICaps));
				if (mm == MMSYSERR_NOERROR)
				{
					pszMicDeviceName = ICaps.szPname;
				}
			}
		}
	}

	audio_log_inf("audio_drv_check_names -- mic:\"%s\" spk:\"%s\"",
			pszMicDeviceName, pszSpkDeviceName);

	if (pszMicDeviceName && pszSpkDeviceName)
	{
		strncpy(
			gAudio.Drv.acMicDeviceName, 
			pszMicDeviceName, 
			AUDIO_IF_DEVICE_NAME_SZ);
		strncpy(
			gAudio.Drv.acSpkDeviceName, 
			pszSpkDeviceName, 
			AUDIO_IF_DEVICE_NAME_SZ);
	}
	else
	{
		rc = AUDIO_IF_ERR_FAILED;
	}
	// now both mic name and spk name must have been set
	return rc;
}


/*****************************************************************************/
DWORD WINAPI			AudioDrvThreadProc
/*****************************************************************************/
(
LPVOID lpParam 
) 
{ 
	DWORD rc = AUDIO_IF_ERR_NONE;
	static int iFailed = 0;
	float fTimeout;

	if (SetThreadPriority(GetCurrentThread(), gAudio.Drv.iThreadPriority))
	{
		audio_log_inf("AudioDrvThreadProc -- set to priority %d\n", 
			gAudio.Drv.iThreadPriority);
	}
	else
	{
		audio_log_err("AudioDrvThreadProc -- failed to set priority %d",
			gAudio.Drv.iThreadPriority);
	}

	rc |= audio_drv_init();

#if AUDIO_DRV_USE_MM_TMR 
	gAudio.Drv.uMmTimerId = timeSetEvent(
		AUDIO_DRV_THREAD_TIMEOUT, 
		0, 
		(LPTIMECALLBACK )gAudio.Drv.ahEvents[1], 
		0, 
		TIME_PERIODIC | TIME_CALLBACK_EVENT_SET | TIME_KILL_SYNCHRONOUS);

	if (gAudio.Drv.uMmTimerId == NULL)
	{
		audio_log_war("AudioThreadProc -- failed to create mm timer");
	}
#endif

	audio_tmr_start(AUDIO_TMR_SPK_EVENT);
	audio_tmr_start(AUDIO_TMR_MIC_EVENT);
	audio_tmr_start(AUDIO_TMR_WIN_TMR);
	audio_tmr_start(AUDIO_TMR_MM_TMR);

	audio_tmr_stop(AUDIO_TMR_DRV_THREAD, &fTimeout);
	audio_log_inf("AudioThreadProc -- started in %7.3fms", fTimeout);

#if 0//AUDIO_G729
	audio_SSE_init();
#else
	{
		_MM_SET_FLUSH_ZERO_MODE(_MM_FLUSH_ZERO_ON);
//		_MM_SET_ROUNDING_MODE(_MM_ROUND_TOWARD_ZERO);
	}
#endif
	audio_start();

	if (!(rc & (~AUDIO_IF_ERR_WARNING)))
	{
		rc = AUDIO_IF_ERR_NONE;
		rc |= audio_drv_start();

		if (!(rc & AUDIO_IF_ERR_FAILED))
		{
			gAudio.bRunning = true;
			SetEvent(gAudio.Drv.hStartEvent);
			

			for (;;)
			{
				DWORD dw = WaitForMultipleObjects(
					2+AUDIO_DRV_SPK_EVENTS+AUDIO_DRV_MIC_EVENTS,
					gAudio.Drv.ahEvents,
					FALSE,
					AUDIO_DRV_THREAD_TIMEOUT);

				audio_tmr_peek(AUDIO_TMR_BASE, &gAudio.Drv.fNow);

				if (dw == WAIT_TIMEOUT)
				{
					// AUDIO_THREAD_TIMEOUT ms expired
					// it's a highly unreliable timer. 
					// implemenation/os dependend.
					// can fire earler or later. 15.6ms avrg on my PC.
					audio_tmr_restart(AUDIO_TMR_WIN_TMR, NULL);
					audio_drv_poll(-1);

				}
				else if (dw == WAIT_FAILED)
				{
					audio_log_err("AudioThreadProc -- wait failed");
					iFailed++;
					if (iFailed > 10)
					{
						audio_log_err("AudioThreadProc -- too many failures");
						audio_drv_stop();
						rc = AUDIO_IF_ERR_FAILED;
						break;
					}
				}
				else
				{
					DWORD dwEvent = dw - WAIT_OBJECT_0;
					if (dwEvent == 0) // quit request
					{
						audio_drv_stop();
						break;
					}
					else if (dwEvent == 1) // mm timer
					{
						// AUDIO_THREAD_TIMEOUT ms expired
						audio_tmr_restart(AUDIO_TMR_MM_TMR, &fTimeout);
						audio_drv_poll(dwEvent);
					}
					else if (dwEvent < AUDIO_DRV_SPK_EVENTS+AUDIO_DRV_MIC_EVENTS+2)
					{
						if (dwEvent < AUDIO_DRV_SPK_EVENTS+2)
						{
							// it's a spk event
							audio_tmr_restart(AUDIO_TMR_SPK_EVENT, &fTimeout);
							// process spk events
						}
						else
						{
							audio_tmr_restart(AUDIO_TMR_MIC_EVENT, &fTimeout);
							// process mic events
						}
						// poll both - just in case
						audio_drv_poll(dwEvent);
					}
					else
					{
						audio_log_err("AudioThreadProc -- unknown event %d",
							dwEvent);
					}
				} // if dw == .... 
			} // end-of-for: 
		} // if start succesfull
		else
			SetEvent(gAudio.Drv.hStartEvent); // unlock AudioIf_
	} // if init succesfull
	else
		SetEvent(gAudio.Drv.hStartEvent); // unlock AudioIf_


	if (gAudio.Drv.uMmTimerId)
		timeKillEvent(gAudio.Drv.uMmTimerId);

	audio_stop();

	gAudio.bRunning = false;

	audio_utl_thread_stts(
		GetCurrentThread(), 
		&gAudio.CpuStts.fDrvThreadKernelModePercentage,
		&gAudio.CpuStts.fDrvThreadUserModePercentage);

	audio_log_inf("AudioThreadProc -- %7.2f%% in kernel, %7.2f%% in user mode", 
		gAudio.CpuStts.fDrvThreadKernelModePercentage,
		gAudio.CpuStts.fDrvThreadUserModePercentage
		);


	return rc;
}

/*****************************************************************************/
DWORD					AudioIf_drv_open
/*****************************************************************************/
(
char *pszMicDeviceName, 
char *pszSpkDeviceName, 
int iDrvMode,	// the same driver mode will be used both mic and spk
int iThreadPriority // 8...15
)
{
	if (!gAudio.bInitialized) return AUDIO_IF_ERR_NOT_INITIALIZED;

	DWORD rc = AUDIO_IF_ERR_NONE;
	audio_lock();
	audio_log_inf("AudioIf_drv_open -- mic=%s spk=%s mode=%d pri=%d",
			pszMicDeviceName,
			pszSpkDeviceName,
			iDrvMode,
			iThreadPriority);

	if (gAudio.bRunning)
	{
		audio_log_err("AudioIf_drv_open -- already running");
		rc |= AUDIO_IF_ERR_ALREADY_EXISTS;
	}
	else
	{
		audio_log_inf("AudioIf_drv_open -- zero objs");
		memset(&gAudio.Drv, 0, sizeof(gAudio.Drv));

		audio_tmr_init(&gAudio.TmrCtrl);
		audio_tmr_start(AUDIO_TMR_DRV_THREAD);

		for (int k = 0; k < 2+AUDIO_DRV_SPK_EVENTS+AUDIO_DRV_MIC_EVENTS; k++)
		{
			gAudio.Drv.ahEvents[k] = CreateEvent(NULL, FALSE, FALSE, NULL);
			if (gAudio.Drv.ahEvents[k] == NULL)
			{
				audio_log_err("AudioIf_drv_open -- CreateEvent failed");
				rc |= AUDIO_IF_ERR_FAILED;
				break;
			}
		}
	}

	rc |= _check_names(pszMicDeviceName, pszSpkDeviceName);

	if (rc == AUDIO_IF_ERR_NONE)
	{
		TIMECAPS TimeCaps = {0};

		timeGetDevCaps(&TimeCaps, sizeof(TimeCaps));
		audio_log_inf("AudioIf_drv_open -- tmr min %d tmr max %d",
			TimeCaps.wPeriodMin,
			TimeCaps.wPeriodMax	);

		gAudio.Drv.iDrvMode = iDrvMode;
		gAudio.Drv.iThreadPriority = iThreadPriority;

		gAudio.Drv.hStartEvent = CreateEvent(NULL, FALSE, FALSE, NULL);
		if (gAudio.Drv.hStartEvent == NULL)
		{
			audio_log_err("AudioIf_drv_open -- Create StartEvent failed");
			rc |= AUDIO_IF_ERR_FAILED;
		}
		else
		{
			gAudio.Drv.hThread = CreateThread(
				NULL, // can't be inherted LPSECURITY_ATTRIBUTES lpThreadAttributes,
				NULL, // default SIZE_T dwStackSize,
				AudioDrvThreadProc, // LPTHREAD_START_ROUTINE lpStartAddress,
				NULL, //LPVOID lpParameter,
				0, // DWORD dwCreationFlags,
				&gAudio.Drv.dwThreadId);//LPDWORD lpThreadId

			if (gAudio.Drv.hThread == NULL)
			{
				audio_log_err("AudioIf_drv_open -- CreateThread failed");
				rc |= AUDIO_IF_ERR_FAILED;
			}
			else
			{
				DWORD dw = WaitForSingleObject(gAudio.Drv.hStartEvent, 20000); // 2 sec max, made 20 sec, for testing, shantanu

				switch(dw)
				{
				case WAIT_OBJECT_0: // exit
					if (!gAudio.bRunning)
						rc |= AUDIO_IF_ERR_DRIVER_FAIL;
					break;

				case WAIT_ABANDONED:		//added more error codes by Shantanu
					rc |= AUDI0_IF_ERR_DRV_OPEN_WAIT_ABANDONED;
					break;

				case WAIT_TIMEOUT:
					rc |= AUDI0_IF_ERR_DRV_OPEN_WAIT_TIMEOUT;
					break;

				case WAIT_FAILED:
					rc |= AUDI0_IF_ERR_DRV_OPEN_WAIT_FAILED;
					break;

				default:
					rc |= AUDIO_IF_ERR_TIMING;
					break;
				}
			}
		}
	}
	if (rc)
		audio_log_err("AudioIf_drv_open -- rc=0x%08x", rc);
	else
		audio_log_inf("AudioIf_drv_open -- done");
	audio_unlock();
	return rc;
}
/*****************************************************************************/
DWORD				AudioIf_drv_spk_device_name_get
/*****************************************************************************/
(
char *pszDeviceName
)
{
	if (!gAudio.bInitialized) return AUDIO_IF_ERR_NOT_INITIALIZED;

	DWORD rc = AUDIO_IF_ERR_NONE;
	audio_lock();
	audio_log_inf("AudioIf_drv_spk_device_name_get -- p=%p",
			pszDeviceName);
	if (pszDeviceName)
	{
		strncpy(pszDeviceName, gAudio.Drv.acSpkDeviceName, AUDIO_IF_DEVICE_NAME_SZ);
	}
	else
	{
		rc |= AUDIO_IF_ERR_INVALID_PARAM;
	}
	if (rc)
		audio_log_err("AudioIf_drv_spk_device_name_get -- rc=0x%08x", rc);
	else
		audio_log_inf("AudioIf_drv_spk_device_name_get -- done");
	audio_unlock();
	return rc;
}
/*****************************************************************************/
DWORD				AudioIf_drv_mic_device_name_get
/*****************************************************************************/
(
char *pszDeviceName
)
{
	if (!gAudio.bInitialized) return AUDIO_IF_ERR_NOT_INITIALIZED;

	DWORD rc = AUDIO_IF_ERR_NONE;
	audio_lock();
	audio_log_inf("AudioIf_drv_mic_device_name_get -- p=%p",
			pszDeviceName);
	if (pszDeviceName)
	{
		strncpy(pszDeviceName, gAudio.Drv.acMicDeviceName, AUDIO_IF_DEVICE_NAME_SZ);
	}
	else
	{
		rc |= AUDIO_IF_ERR_INVALID_PARAM;
	}
	if (rc)
		audio_log_err("AudioIf_drv_mic_device_name_get -- rc=0x%08x", rc);
	else
		audio_log_inf("AudioIf_drv_mic_device_name_get -- done");
	audio_unlock();
	return rc;
}
/*****************************************************************************/
DWORD				AudioIf_drv_mode_get
/*****************************************************************************/
(
int *piDrvMode
)
{
	if (!gAudio.bInitialized) return AUDIO_IF_ERR_NOT_INITIALIZED;

	DWORD rc = AUDIO_IF_ERR_NONE;
	audio_lock();
	audio_log_inf("AudioIf_drv_mode_get -- p=%p", piDrvMode);
	if (piDrvMode)
	{
		*piDrvMode = gAudio.Drv.iDrvMode;
	}
	else
	{
		rc |= AUDIO_IF_ERR_INVALID_PARAM;
	}
	if (rc)
		audio_log_err("AudioIf_drv_mode_get -- rc=0x%08x", rc);
	else
		audio_log_inf("AudioIf_drv_mode_get -- done");
	audio_unlock();
	return rc;
}
/*****************************************************************************/
DWORD				AudioIf_drv_stts_get
/*****************************************************************************/
(
AudioIf_tDrvStts *pStts
)
{
	if (!gAudio.bInitialized) return AUDIO_IF_ERR_NOT_INITIALIZED;

	DWORD rc = AUDIO_IF_ERR_NONE;
	audio_lock();
	audio_log_inf("AudioIf_drv_stts_get -- p=%p", pStts);
	if (pStts)
	{
		pStts->iFramesTotal = gAudio.Drv.iFrameNo;
		pStts->fSpkMicDelayAverageUs = 0;// TBD

		pStts->MicStts.iFailures = 0;
		pStts->MicStts.fClkAvrUs = 0;
		pStts->MicStts.fClkDevUs = 0;
		pStts->MicStts.fDelayAverage = 0;
		audio_hstgm_analyse(&gAudio.TmrCtrl.aTmr[AUDIO_TMR_MIC_BLK].Hstgm);
		pStts->SpkStts.JitterHistogram = gAudio.TmrCtrl.aTmr[AUDIO_TMR_MIC_BLK].Hstgm;

		pStts->SpkStts.iFailures = 0;
		pStts->SpkStts.fClkAvrUs = 0;
		pStts->SpkStts.fClkDevUs = 0;
		pStts->SpkStts.fDelayAverage = 0;
		audio_hstgm_analyse(&gAudio.TmrCtrl.aTmr[AUDIO_TMR_SPK_BLK].Hstgm);
		pStts->SpkStts.JitterHistogram = gAudio.TmrCtrl.aTmr[AUDIO_TMR_SPK_BLK].Hstgm;
	}
	else
	{
		rc |= AUDIO_IF_ERR_INVALID_PARAM;
	}
	if (rc)
		audio_log_err("AudioIf_drv_stts_get -- rc=0x%08x", rc);
	else
		audio_log_inf("AudioIf_drv_stts_get -- done");
	audio_unlock();
	return rc;
}
/*****************************************************************************/
DWORD				AudioIf_drv_close
/*****************************************************************************/
(
char *pszTimingFileName
)
{
	if (!gAudio.bInitialized) return AUDIO_IF_ERR_NOT_INITIALIZED;

	DWORD rc = AUDIO_IF_ERR_NONE;
	audio_lock();
	audio_log_inf("AudioIf_drv_close -- p=%p", pszTimingFileName);

	if (!gAudio.bRunning)
	{
		audio_log_err("AudioIf_drv_close -- already stopped");
		rc |= AUDIO_IF_ERR_ALREADY_REMOVED;
	}
	else
	{
		rc |= audio_tmr_start(AUDIO_TMR_DRV_THREAD);
		
		//don't lock for the period of waiting, this creates deadlock in audio_process()
		audio_unlock();		

		if (SetEvent(gAudio.Drv.ahEvents[0]))
		{
			float fTimeout;
			// some driver are very slow to release pins
			DWORD dw = WaitForSingleObject(gAudio.Drv.hThread, 20000); 
			CloseHandle(gAudio.Drv.hThread);
			gAudio.Drv.hThread = NULL;

			//make sure to lock again
			audio_lock();	

			rc |= audio_tmr_stop(AUDIO_TMR_DRV_THREAD, &fTimeout);
			switch(dw)
			{
			case WAIT_OBJECT_0:
				audio_log_inf("AudioIf_drv_close -- thread stopped in %7.3f ms", 
					fTimeout);
				break;
			case WAIT_TIMEOUT:
				audio_log_err("AudioIf_drv_close -- timeout %7.3f ms", fTimeout);
				rc |= AUDIO_IF_ERR_WARNING;
				break;
			default:
				audio_log_err("AudioIf_drv_close -- unknown ret code 0x%x", dw);
				rc |= AUDIO_IF_ERR_WARNING;
				break;
			}

			audio_rec_close();
			audio_log_inf("audio_drv_stop -- RecQ overflows=%d", gAudio.Dbg.Rec.Q.iOverflows); 
			gAudio.Dbg.Rec.Q.iOverflows = 0;
			audio_log_inf("audio_drv_stop -- LogQ overflows=%d", gAudio.Dbg.LogQ.iOverflows); 
			gAudio.Dbg.LogQ.iOverflows = 0;

		}
		else
		{
			//make sure to lock again
			audio_lock();
			rc |= AUDIO_IF_ERR_FAILED;
		}

		for (int k = 0; k < 2+AUDIO_DRV_SPK_EVENTS+AUDIO_DRV_MIC_EVENTS; k++)
		{
			CloseHandle(gAudio.Drv.ahEvents[k]);
		}
		CloseHandle(gAudio.Drv.hStartEvent);
		SetEvent(gAudio.Dbg.ahEvents[AUDIO_DBG_EVENT_WIN_CLOSE]);
	}

	if (pszTimingFileName)
	{
		audio_tmr_dump(pszTimingFileName);
	}

	audio_jb_netq_free();

	if (rc)
		audio_log_err("AudioIf_drv_close -- rc=0x%08x", rc);
	else
		audio_log_inf("AudioIf_drv_close -- done\n\n");
	audio_unlock();
	return rc;
}
