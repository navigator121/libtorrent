#ifndef _AUDIO_ILBC_H_
#define _AUDIO_ILBC_H_

extern "C"
{
#include <iLBC_define.h>
#include <iLBC_decode.h>
#include <iLBC_encode.h>
}

/*****************************************************************************/

DWORD audio_iLBC_decoder_init
	(
	void *pDec
	);
DWORD audio_iLBC_encoder_init
	(
	void *pEnc
	);
int audio_iLBC_decode
	(
	void *pDec,
	short *psOut,
	BYTE *pcIn // can be NULL -> PLC
	);
int	audio_iLBC_encode
	(
	void *pEnc,
	BYTE *pcOut,
	short *psIn
	);

#endif // _AUDIO_ILBC_H_