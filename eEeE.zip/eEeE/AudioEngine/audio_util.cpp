#include "audio_defs.h"
/*
N=64;
fs=32000;
windI=hann(N);
windD=tukeywin(N,0.6);

F=[0 6000 7000 7200   8000 9200 fs/2]/(fs/2);
MD=[1  1   1.0  1.2   0.00   0    0];
MI=[1  1   1.0  0.7   0.00   0    0];
*/
_declspec (align(16)) static const float _af32to16[AUDIO_32TO16_FSZ] = {
  +0.0000000000F,   +0.0000000000F,   +0.0000000725F,   -0.0000003961F, 
  -0.0000003843F,   +0.0000054501F,   -0.0000047456F,   -0.0000251166F, 
  +0.0000435590F,   +0.0000504286F,   -0.0001429056F,   -0.0000753389F, 
  +0.0003429922F,   +0.0000943837F,   -0.0007001052F,   -0.0001013470F, 
  +0.0012804422F,   +0.0000986393F,   -0.0021608785F,   -0.0001003435F, 
  +0.0034242622F,   +0.0001335104F,   -0.0051448965F,   -0.0002441540F, 
  +0.0073460036F,   +0.0005588426F,   -0.0099624537F,   -0.0014655985F, 
  +0.0130350551F,   +0.0034324068F,   -0.0163400968F,   -0.0071329860F, 
  +0.0189950142F,   +0.0127345746F,   -0.0200232312F,   -0.0199226621F, 
  +0.0185522993F,   +0.0279915304F,   -0.0139933680F,   -0.0359655567F, 
  +0.0061945266F,   +0.0427727597F,   +0.0045637393F,   -0.0473694407F, 
  -0.0178150733F,   +0.0487754184F,   +0.0335513279F,   -0.0464473462F, 
  -0.0521127446F,   +0.0388352116F,   +0.0744518612F,   -0.0212448792F, 
  -0.0990962139F,   -0.0135102528F,   +0.1200440364F,   +0.0775380658F, 
  -0.1165947377F,   -0.1862448375F,   +0.0174752260F,   +0.3089855223F, 
  +0.4151865771F,   +0.2957106021F,   +0.1196821153F,   +0.0222101845F, 
};

_declspec (align(16)) static const float _af16to32A[AUDIO_16TO32_FSZ] = {
  +0.0000000000F,   -0.0000000030F,   +0.0000000392F,   -0.0000003549F,
  +0.0000021323F,   -0.0000095804F,   +0.0000359564F,   -0.0001077617F,
  +0.0002595190F,   -0.0005476916F,   +0.0010624959F,   -0.0019419525F,
  +0.0033833654F,   -0.0056429092F,   +0.0089948059F,   -0.0135541008F,
  +0.0188975072F,   -0.0239183597F,   +0.0267218419F,   -0.0246542526F,
  +0.0145217498F,   +0.0069566221F,   -0.0423681693F,   +0.0922617796F,
  -0.1526541207F,   +0.2100537935F,   -0.2313596145F,   +0.1455287534F,
  +0.1699828066F,   -0.7216446282F,   -0.4352032561F,   -0.0450616919F, 
};
_declspec (align(16)) static const float _af16to32B[AUDIO_16TO32_FSZ] = {
  +0.0000000000F,   +0.0000000037F,   -0.0000000115F,   +0.0000000032F,
  +0.0000000853F,   -0.0000002826F,   -0.0000046289F,   +0.0000328025F,
  -0.0001038961F,   +0.0002342614F,   -0.0004228840F,   +0.0006248193F,
  -0.0007029186F,   +0.0003451753F,   +0.0010673459F,   -0.0045436330F,
  +0.0112064655F,   -0.0220115801F,   +0.0373500434F,   -0.0565632852F, 
  +0.0774082674F,   -0.0954845285F,   +0.1036156889F,   -0.0912122853F, 
  +0.0439330890F,   +0.0547837641F,   -0.2140053032F,   +0.3939682813F,
  -0.3549447258F,   -0.7006011695F,   -0.1785818464F,   -0.0053923968F, 
};

/*****************************************************************************/
void					audio_utl_32to16
/*****************************************************************************/
(
float *pfSav, // AUDIO_32TO8_FSZ size
float *pfOut16, 
float *pfIn32
)
{
	_declspec (align(16)) float afTmp[AUDIO_FRSZ32 + AUDIO_32TO16_FSZ];
	int k;

	for (k = 0; k < AUDIO_32TO16_FSZ; k++)
	{
		afTmp[k] = pfSav[k];
	}
	for (k = 0; k < AUDIO_FRSZ32; k++)
	{
		afTmp[k+AUDIO_32TO16_FSZ] = pfIn32[k];
	}
	for (k = 0; k < AUDIO_32TO16_FSZ; k++)
	{
		pfSav[k] = afTmp[k+AUDIO_FRSZ32];
	}

	for (k = 0; k < AUDIO_FRSZ16; k++)
	{
		float ac0 = 0;
#if 0
		for (int tap = 0; tap < AUDIO_32TO16_FSZ; tap++)
		{
			ac0 += afTmp[k*2 + tap] * _af32to16[tap];
		}
#else
		float *pf = afTmp + k*2;
		__asm {
			mov		eax, pf
			lea		ecx, _af32to16
			mov		esi, AUDIO_32TO16_FSZ/16
			xorps	xmm5, xmm5
L32to16:	
				movups	xmm7, XMMWORD PTR [eax+0*16];
				mulps	xmm7, XMMWORD PTR [ecx+0*16];
				addps	xmm5, xmm7
				movups	xmm7, XMMWORD PTR [eax+1*16];
				mulps	xmm7, XMMWORD PTR [ecx+1*16];
				addps	xmm5, xmm7
				movups	xmm7, XMMWORD PTR [eax+2*16];
				mulps	xmm7, XMMWORD PTR [ecx+2*16];
				addps	xmm5, xmm7
				movups	xmm7, XMMWORD PTR [eax+3*16];
				mulps	xmm7, XMMWORD PTR [ecx+3*16];
				addps	xmm5, xmm7
				add		eax, 4*16
				add		ecx, 4*16
				sub		esi, 1
			jnz		L32to16

			movaps	xmm7, xmm5
			shufps	xmm7, xmm5, 0x4e
			addps	xmm5, xmm7
			movaps	xmm7, xmm5
			shufps	xmm7, xmm5, 0xb1
			addps	xmm5, xmm7
			movss	ac0, xmm5
		}
#endif
		pfOut16[k] = ac0;
	}
}
/*****************************************************************************/
void					audio_utl_16to32
/*****************************************************************************/
(
float *pfSav, // AUDIO_16TO32_FSZ size
float *pfOut32, 
float *pfIn16
)
{
	float afTmp[AUDIO_FRSZ16 + AUDIO_16TO32_FSZ];
	int k;

	for (k = 0; k < AUDIO_16TO32_FSZ; k++)
	{
		afTmp[k] = pfSav[k];
	}
	for (k = 0; k < AUDIO_FRSZ16; k++)
	{
		afTmp[k+AUDIO_16TO32_FSZ] = pfIn16[k];
	}
	for (k = 0; k < AUDIO_16TO32_FSZ; k++)
	{
		pfSav[k] = afTmp[k+AUDIO_FRSZ16];
	}

	for (k = 0; k < AUDIO_FRSZ16; k++)
	{
		float ac0;
#if 0
		int tap;
		ac0 = 0;
		for (tap = 0; tap < AUDIO_16TO32_FSZ; tap++)
		{
			ac0 += afTmp[k + tap] * _af8to32B[tap];
		}
		pfOut32[k*2+0] = ac0;

		ac0 = 0;
		for (tap = 0; tap < AUDIO_16TO32_FSZ; tap++)
		{
			ac0 += afTmp[k + tap] * _af8to32A[tap];
		}
		pfOut32[k*2+1] = ac0;
#else
		float *pf = afTmp + k;
		float ac1;
		__asm {
			mov		eax, pf
			lea		ecx, _af16to32B		
			lea		edx, _af16to32A

			movups	xmm5, XMMWORD PTR [eax+0*16];
			movaps	xmm4, xmm5
			mulps	xmm5, XMMWORD PTR [ecx+0*16];
			mulps	xmm4, XMMWORD PTR [edx+0*16];

			movups	xmm7, XMMWORD PTR [eax+1*16];
			movaps	xmm6, xmm7
			mulps	xmm7, XMMWORD PTR [ecx+1*16];
			mulps	xmm6, XMMWORD PTR [edx+1*16];
			addps	xmm5, xmm7
			addps	xmm4, xmm6
			movups	xmm7, XMMWORD PTR [eax+2*16];
			movaps	xmm6, xmm7
			mulps	xmm7, XMMWORD PTR [ecx+2*16];
			mulps	xmm6, XMMWORD PTR [edx+2*16];
			addps	xmm5, xmm7
			addps	xmm4, xmm6
			movups	xmm7, XMMWORD PTR [eax+3*16];
			movaps	xmm6, xmm7
			mulps	xmm7, XMMWORD PTR [ecx+3*16];
			mulps	xmm6, XMMWORD PTR [edx+3*16];
			addps	xmm5, xmm7
			addps	xmm4, xmm6
			movups	xmm7, XMMWORD PTR [eax+4*16];
			movaps	xmm6, xmm7
			mulps	xmm7, XMMWORD PTR [ecx+4*16];
			mulps	xmm6, XMMWORD PTR [edx+4*16];
			addps	xmm5, xmm7
			addps	xmm4, xmm6
			movups	xmm7, XMMWORD PTR [eax+5*16];
			movaps	xmm6, xmm7
			mulps	xmm7, XMMWORD PTR [ecx+5*16];
			mulps	xmm6, XMMWORD PTR [edx+5*16];
			addps	xmm5, xmm7
			addps	xmm4, xmm6
			movups	xmm7, XMMWORD PTR [eax+6*16];
			movaps	xmm6, xmm7
			mulps	xmm7, XMMWORD PTR [ecx+6*16];
			mulps	xmm6, XMMWORD PTR [edx+6*16];
			addps	xmm5, xmm7
			addps	xmm4, xmm6
			movups	xmm7, XMMWORD PTR [eax+7*16];
			movaps	xmm6, xmm7
			mulps	xmm7, XMMWORD PTR [ecx+7*16];
			mulps	xmm6, XMMWORD PTR [edx+7*16];
			addps	xmm5, xmm7
			addps	xmm4, xmm6
			// collect
			movaps	xmm7, xmm5
			shufps	xmm7, xmm5, 0x4e
			addps	xmm5, xmm7
			movaps	xmm7, xmm5
			shufps	xmm7, xmm5, 0xb1
			addps	xmm5, xmm7
			movss	ac0, xmm5
			// collect
			movaps	xmm6, xmm4
			shufps	xmm6, xmm4, 0x4e
			addps	xmm4, xmm6
			movaps	xmm6, xmm4
			shufps	xmm6, xmm4, 0xb1
			addps	xmm4, xmm6
			movss	ac1, xmm4
		}
		pfOut32[k*2+0] = ac0;
		pfOut32[k*2+1] = ac1;
#endif
	}
}

/*
N=64;
fs=32000;
windI=hann(N);
windD=tukeywin(N,0.5);


F=[0 3000 3400 3700   4000 4600 fs/2]/(fs/2);
MD=[1  1   1.2  1.2   0.10   0    0];
MI=[1  1   1    1.0   0.01   0    0];
bD=fir2(N-1,F,MD,windD);
bds=polystab(bD);
bds=bds*norm(bD)/norm(bds);

bI=fir2(N-1,F,MI,windI);
bis=polystab(bI);
bis=bis*norm(bI)/norm(bis);
*/
//decimation by 4
_declspec (align(16)) static const float _af32to8[AUDIO_32TO8_FSZ] = {
  +0.0000000000F,   +0.0000000000F,   -0.0000037609F,   +0.0000167214F, 
  +0.0000235624F,   -0.0000813035F,   -0.0001932497F,   -0.0000581226F, 
  +0.0003915589F,   +0.0007866807F,   +0.0005162443F,   -0.0006436451F, 
  -0.0020152209F,   -0.0022463144F,   -0.0003914934F,   +0.0029122849F, 
  +0.0053125384F,   +0.0042146075F,   -0.0009515304F,   -0.0072385046F, 
  -0.0098296890F,   -0.0058916868F,   +0.0031978390F,   +0.0122690520F, 
  +0.0152814107F,   +0.0091240622F,   -0.0040909171F,   -0.0176794407F, 
  -0.0237965285F,   -0.0177353009F,   -0.0008448486F,   +0.0195521365F, 
  +0.0332899706F,   +0.0322360126F,   +0.0146853352F,   -0.0125815615F, 
  -0.0366815700F,   -0.0450690127F,   -0.0320429646F,   -0.0021540284F, 
  +0.0312002615F,   +0.0516936683F,   +0.0478988382F,   +0.0194046765F, 
  -0.0219865169F,   -0.0569390156F,   -0.0673597974F,   -0.0452247327F, 
  +0.0027821562F,   +0.0572631051F,   +0.0939569902F,   +0.0938913164F, 
  +0.0510604768F,   -0.0249607867F,   -0.1122822688F,   -0.1849885095F, 
  -0.2230363759F,   -0.2194350417F,   -0.1815882835F,   -0.1265288108F, 
  -0.0727632502F,   -0.0329223737F,   -0.0105535303F,   -0.0018007457F, 
};

_declspec (align(16)) static const float _af8to32A[AUDIO_8TO32_FSZ] = {
  +0.0000000000F,   +0.0000113886F,   +0.0004758377F,   -0.0012508382F,
  +0.0018838778F,   -0.0023250542F,   +0.0035680559F,   -0.0102670390F,
  +0.0295034455F,   -0.0687384923F,   +0.1369537523F,   -0.2423057540F,
  +0.3757786752F,   -0.4001118610F,   -0.7268909417F,   -0.0962464038F, 
};
_declspec (align(16)) static const float _af8to32B[AUDIO_8TO32_FSZ] = {
  +0.0000000000F,   -0.0001055294F,   +0.0003346089F,   +0.0002852684F,
  -0.0026116920F,   +0.0076503522F,   -0.0161813975F,   +0.0253138941F,
  -0.0279109005F,   +0.0134777298F,   +0.0354455007F,   -0.1484817924F,
  +0.3705010623F,   -0.6711928278F,   -0.5504317617F,   -0.0359457193F, 
};
_declspec (align(16)) static const float _af8to32C[AUDIO_8TO32_FSZ] = {
  -0.0000038820F,   -0.0001154430F,   -0.0004490622F,   +0.0025480168F,
  -0.0071628786F,   +0.0160615740F,   -0.0321555890F,   +0.0559350513F,
  -0.0834683354F,   +0.1062365630F,   -0.1052862351F,   +0.0368273043F,
  +0.2064498437F,   -0.8237531607F,   -0.3621073722F,   -0.0095775766F, 
};
_declspec (align(16)) static const float _af8to32D[AUDIO_8TO32_FSZ] = {
  +0.0000196259F,   +0.0001595716F,   -0.0013138823F,   +0.0036525834F,
  -0.0078499302F,   +0.0157778585F,   -0.0319363093F,   +0.0606905159F,
  -0.1037240090F,   +0.1598067216F,   -0.2188243937F,   +0.2414700350F,
  -0.0773853343F,   -0.8349704360F,   -0.2043266700F,   -0.0013752757F, 
};
/*****************************************************************************/
void					audio_utl_32to8
/*****************************************************************************/
(
float *pfSav, // AUDIO_32TO8_FSZ size
float *pfOut8, 
float *pfIn32
)
{
	_declspec (align(16)) float afTmp[AUDIO_FRSZ32 + AUDIO_32TO8_FSZ];
	int k;

	for (k = 0; k < AUDIO_32TO8_FSZ; k++)
	{
		afTmp[k] = pfSav[k];
	}
	for (k = 0; k < AUDIO_FRSZ32; k++)
	{
		afTmp[k+AUDIO_32TO8_FSZ] = pfIn32[k];
	}
	for (k = 0; k < AUDIO_32TO8_FSZ; k++)
	{
		pfSav[k] = afTmp[k+AUDIO_FRSZ32];
	}

	for (k = 0; k < AUDIO_FRSZ8; k++)
	{
		float ac0 = 0;
#if 0
		for (int tap = 0; tap < AUDIO_32TO8_FSZ; tap++)
		{
			ac0 += afTmp[k*4 + tap] * _af32to8[tap];
		}
#else
		float *pf = afTmp + k*4;
		__asm {
			mov		eax, pf
			lea		ecx, _af32to8
			mov		esi, AUDIO_32TO8_FSZ/16
			xorps	xmm5, xmm5
L32to8:	
				movaps	xmm7, XMMWORD PTR [eax+0*16];
				mulps	xmm7, XMMWORD PTR [ecx+0*16];
				addps	xmm5, xmm7
				movaps	xmm7, XMMWORD PTR [eax+1*16];
				mulps	xmm7, XMMWORD PTR [ecx+1*16];
				addps	xmm5, xmm7
				movaps	xmm7, XMMWORD PTR [eax+2*16];
				mulps	xmm7, XMMWORD PTR [ecx+2*16];
				addps	xmm5, xmm7
				movaps	xmm7, XMMWORD PTR [eax+3*16];
				mulps	xmm7, XMMWORD PTR [ecx+3*16];
				addps	xmm5, xmm7
				add		eax, 4*16
				add		ecx, 4*16
				sub		esi, 1
			jnz		L32to8

			movaps	xmm7, xmm5
			shufps	xmm7, xmm5, 0x4e
			addps	xmm5, xmm7
			movaps	xmm7, xmm5
			shufps	xmm7, xmm5, 0xb1
			addps	xmm5, xmm7
			movss	ac0, xmm5
		}
#endif
		pfOut8[k] = ac0;
	}
}
/*****************************************************************************/
void					audio_utl_8to32
/*****************************************************************************/
(
float *pfSav, // AUDIO_8TO32_FSZ size
float *pfOut32, 
float *pfIn8
)
{
	float afTmp[AUDIO_FRSZ8 + AUDIO_8TO32_FSZ];
	int k;

	for (k = 0; k < AUDIO_8TO32_FSZ; k++)
	{
		afTmp[k] = pfSav[k];
	}
	for (k = 0; k < AUDIO_FRSZ8; k++)
	{
		afTmp[k+AUDIO_8TO32_FSZ] = pfIn8[k];
	}
	for (k = 0; k < AUDIO_8TO32_FSZ; k++)
	{
		pfSav[k] = afTmp[k+AUDIO_FRSZ8];
	}

	for (k = 0; k < AUDIO_FRSZ8; k++)
	{
		float ac0;
#if 0
		int tap;
		ac0 = 0;
		for (tap = 0; tap < AUDIO_8TO32_FSZ; tap++)
		{
			ac0 += afTmp[k + tap] * _af8to32D[tap];
		}
		pfOut32[k*4+0] = ac0;

		ac0 = 0;
		for (tap = 0; tap < AUDIO_8TO32_FSZ; tap++)
		{
			ac0 += afTmp[k + tap] * _af8to32C[tap];
		}
		pfOut32[k*4+1] = ac0;
		ac0 = 0;
		for (tap = 0; tap < AUDIO_8TO32_FSZ; tap++)
		{
			ac0 += afTmp[k + tap] * _af8to32B[tap];
		}
		pfOut32[k*4+2] = ac0;
		ac0 = 0;
		for (tap = 0; tap < AUDIO_8TO32_FSZ; tap++)
		{
			ac0 += afTmp[k + tap] * _af8to32A[tap];
		}
		pfOut32[k*4+3] = ac0;
#else
		// another way is vectorize ac0..ac3
		//	movss	xmm0, DWORD PTR [eax+4*z]
		//  shufps	xmm0, xmm0, 0x00
		float *pf = afTmp + k;
		float ac1, ac2, ac3;
		__asm {
			mov		eax, pf
			lea		ecx, _af8to32D		// preload
			movups	xmm0, XMMWORD PTR [eax+0*16];
			movups	xmm1, XMMWORD PTR [eax+1*16];
			movups	xmm2, XMMWORD PTR [eax+2*16];
			movups	xmm3, XMMWORD PTR [eax+3*16];

			movaps	xmm5, XMMWORD PTR [ecx+0*16];
			mulps	xmm5, xmm0
			movaps	xmm7, XMMWORD PTR [ecx+1*16];
			mulps	xmm7, xmm1
			addps	xmm5, xmm7
			movaps	xmm7, XMMWORD PTR [ecx+2*16];
			mulps	xmm7, xmm2
			addps	xmm5, xmm7
			movaps	xmm7, XMMWORD PTR [ecx+3*16];
			mulps	xmm7, xmm3
			addps	xmm5, xmm7
			// collect
			lea		ecx, _af8to32C		// preload
			movaps	xmm7, xmm5
			shufps	xmm7, xmm5, 0x4e
			addps	xmm5, xmm7
			movaps	xmm7, xmm5
			shufps	xmm7, xmm5, 0xb1
			addps	xmm5, xmm7
			movss	ac0, xmm5


			movaps	xmm5, XMMWORD PTR [ecx+0*16];
			mulps	xmm5, xmm0
			movaps	xmm7, XMMWORD PTR [ecx+1*16];
			mulps	xmm7, xmm1
			addps	xmm5, xmm7
			movaps	xmm7, XMMWORD PTR [ecx+2*16];
			mulps	xmm7, xmm2
			addps	xmm5, xmm7
			movaps	xmm7, XMMWORD PTR [ecx+3*16];
			mulps	xmm7, xmm3
			addps	xmm5, xmm7
			// collect
			lea		ecx, _af8to32B		// preload
			movaps	xmm7, xmm5
			shufps	xmm7, xmm5, 0x4e
			addps	xmm5, xmm7
			movaps	xmm7, xmm5
			shufps	xmm7, xmm5, 0xb1
			addps	xmm5, xmm7
			movss	ac1, xmm5


			movaps	xmm5, XMMWORD PTR [ecx+0*16];
			mulps	xmm5, xmm0
			movaps	xmm7, XMMWORD PTR [ecx+1*16];
			mulps	xmm7, xmm1
			addps	xmm5, xmm7
			movaps	xmm7, XMMWORD PTR [ecx+2*16];
			mulps	xmm7, xmm2
			addps	xmm5, xmm7
			movaps	xmm7, XMMWORD PTR [ecx+3*16];
			mulps	xmm7, xmm3
			addps	xmm5, xmm7
			// collect
			lea		ecx, _af8to32A		// preload
			movaps	xmm7, xmm5
			shufps	xmm7, xmm5, 0x4e
			addps	xmm5, xmm7
			movaps	xmm7, xmm5
			shufps	xmm7, xmm5, 0xb1
			addps	xmm5, xmm7
			movss	ac2, xmm5


			movaps	xmm5, XMMWORD PTR [ecx+0*16];
			mulps	xmm5, xmm0
			movaps	xmm7, XMMWORD PTR [ecx+1*16];
			mulps	xmm7, xmm1
			addps	xmm5, xmm7
			movaps	xmm7, XMMWORD PTR [ecx+2*16];
			mulps	xmm7, xmm2
			addps	xmm5, xmm7
			movaps	xmm7, XMMWORD PTR [ecx+3*16];
			mulps	xmm7, xmm3
			addps	xmm5, xmm7
			// collect
			movaps	xmm7, xmm5
			shufps	xmm7, xmm5, 0x4e
			addps	xmm5, xmm7
			movaps	xmm7, xmm5
			shufps	xmm7, xmm5, 0xb1
			addps	xmm5, xmm7
			movss	ac3, xmm5
		}
		pfOut32[k*4+0] = ac0;
		pfOut32[k*4+1] = ac1;
		pfOut32[k*4+2] = ac2;
		pfOut32[k*4+3] = ac3;
#endif
	}
}

/*
F=[0 12000 14000 15500 48000]/48000;
A=[1   1    1.35   0     0];
b=fir2(N-1,F,A,hann(N));
bs=polystab(b);bs=bs*norm(b)/norm(bs);
bs(N)=0;bs=fliplr(bs);
*/

_declspec (align(16)) static const float _af48to32A[AUDIO_48TO32_FSZ/2] = {
 +0.00000000e+000F, +5.01027469e-007F, +4.89233816e-005F, -2.62839353e-004F,
 +9.95477005e-004F, -1.88983669e-003F, +4.80142293e-004F, +5.65087117e-003F,
 -1.14219958e-002F, +2.38751416e-003F, +2.52928333e-002F, -3.40625352e-002F,
 -2.02303965e-002F, +7.92683257e-002F, -2.51347807e-002F, -1.09672856e-001F,
 +1.10624548e-001F, +1.04228607e-001F, -2.27618456e-001F, -9.78041550e-002F,
 +4.25766764e-001F, +5.23763515e-001F, +2.20919827e-001F, +2.83196344e-002F, 
};
_declspec (align(16)) static const float _af48to32B[AUDIO_48TO32_FSZ/2] = {
 +0.00000000e+000F, +1.10114254e-005F, -1.56869851e-004F, +3.40128345e-004F,
 +2.10762106e-004F, -2.58879177e-003F, +5.23853480e-003F, -1.70724731e-003F,
 -1.19581861e-002F, +2.16358244e-002F, +1.98397731e-003F, -4.93076459e-002F,
 +3.88995620e-002F, +5.64751905e-002F, -1.04879505e-001F, -1.80769739e-002F,
 +1.73576746e-001F, -6.77923224e-002F, -2.52450219e-001F, +1.71485525e-001F,
 +5.53805128e-001F, +3.84954046e-001F, +9.55572306e-002F, +4.39372666e-003F, 
};
_declspec (align(16)) static const float _af32to48A[AUDIO_48TO32_FSZ/3] = {
 +7.51541203e-007F, -2.35304776e-004F, +1.49321551e-003F, -3.88318765e-003F,
 +8.47630675e-003F, -1.79372792e-002F, +3.79392499e-002F, -7.39614689e-002F,
 +1.18902488e-001F, -1.57319257e-001F, +1.65936822e-001F, -1.01688484e-001F,
 -1.46706233e-001F, +8.30707692e-001F, +3.31379740e-001F, +6.59058999e-003F, 
};
_declspec (align(16)) static const float _af32to48B[AUDIO_48TO32_FSZ/3] = {
 +0.00000000e+000F, +1.65171381e-005F, -3.94259030e-004F, +3.16143159e-004F,
 +7.20213439e-004F, -2.56087096e-003F, +3.58127124e-003F, +2.97596596e-003F,
 -3.03455947e-002F, +8.47127858e-002F, -1.64509284e-001F, +2.60365119e-001F,
 -3.41427683e-001F, +2.57228287e-001F, +7.85645273e-001F, +1.43335846e-001F, 
};
_declspec (align(16)) static const float _af32to48C[AUDIO_48TO32_FSZ/3] = {
 +0.00000000e+000F, +7.33850724e-005F, +5.10192518e-004F, -2.83475504e-003F,
 +7.85780221e-003F, -1.71329937e-002F, +3.24537367e-002F, -5.10938029e-002F,
 +5.83493430e-002F, -3.77021711e-002F, -2.71154608e-002F, +1.56342911e-001F,
 -3.78675328e-001F, +6.38650146e-001F, +5.77431069e-001F, +4.24794517e-002F, 
};
/*****************************************************************************/
void					audio_utl_48to32
/*****************************************************************************/
(
float *pfSav, // AUDIO_48TO32_FSZ/2 size
float *pfOut, 
float *pfIn
)
{
	float afTmp[AUDIO_FRSZ48 + AUDIO_48TO32_FSZ/2];
	int k;

	for (k = 0; k < AUDIO_48TO32_FSZ/2; k++)
	{
		afTmp[k] = pfSav[k];
	}
	for (k = 0; k < AUDIO_FRSZ48; k++)
	{
		afTmp[k+AUDIO_48TO32_FSZ/2] = pfIn[k];
	}
	for (k = 0; k < AUDIO_48TO32_FSZ/2; k++)
	{
		pfSav[k] = afTmp[k+AUDIO_FRSZ48];
	}

	for (k = 0; k < AUDIO_FRSZ32/2; k++)
	{
		float ac0 = 0;
		float ac1 = 0;
#if 1
		float *pfA = &afTmp[k*3+0];
		float *pfB = &afTmp[k*3+2];
		__asm {
			mov		eax, pfA
			lea		ecx, _af48to32A 

			movups	xmm5, XMMWORD PTR [eax+16*0]
			mulps	xmm5, XMMWORD PTR [ecx+16*0]

			movups	xmm7, XMMWORD PTR [eax+16*1]
			mulps	xmm7, XMMWORD PTR [ecx+16*1]
			addps	xmm5, xmm7
			movups	xmm7, XMMWORD PTR [eax+16*2]
			mulps	xmm7, XMMWORD PTR [ecx+16*2]
			addps	xmm5, xmm7
			movups	xmm7, XMMWORD PTR [eax+16*3]
			mulps	xmm7, XMMWORD PTR [ecx+16*3]
			addps	xmm5, xmm7
			movups	xmm7, XMMWORD PTR [eax+16*4]
			mulps	xmm7, XMMWORD PTR [ecx+16*4]
			addps	xmm5, xmm7
			movups	xmm7, XMMWORD PTR [eax+16*5]
			mulps	xmm7, XMMWORD PTR [ecx+16*5]
			addps	xmm5, xmm7

			movaps	xmm7, xmm5
			shufps	xmm7, xmm5, 0x4e
			addps	xmm5, xmm7
			movaps	xmm7, xmm5
			shufps	xmm7, xmm5, 0xb1
			addps	xmm5, xmm7
			movss	ac0,  xmm5

			mov		eax, pfB
			lea		ecx, _af48to32B

			movups	xmm5, XMMWORD PTR [eax+16*0]
			mulps	xmm5, XMMWORD PTR [ecx+16*0]

			movups	xmm7, XMMWORD PTR [eax+16*1]
			mulps	xmm7, XMMWORD PTR [ecx+16*1]
			addps	xmm5, xmm7
			movups	xmm7, XMMWORD PTR [eax+16*2]
			mulps	xmm7, XMMWORD PTR [ecx+16*2]
			addps	xmm5, xmm7
			movups	xmm7, XMMWORD PTR [eax+16*3]
			mulps	xmm7, XMMWORD PTR [ecx+16*3]
			addps	xmm5, xmm7
			movups	xmm7, XMMWORD PTR [eax+16*4]
			mulps	xmm7, XMMWORD PTR [ecx+16*4]
			addps	xmm5, xmm7
			movups	xmm7, XMMWORD PTR [eax+16*5]
			mulps	xmm7, XMMWORD PTR [ecx+16*5]
			addps	xmm5, xmm7

			movaps	xmm7, xmm5
			shufps	xmm7, xmm5, 0x4e
			addps	xmm5, xmm7
			movaps	xmm7, xmm5
			shufps	xmm7, xmm5, 0xb1
			addps	xmm5, xmm7
			movss	ac1,  xmm5
		}
#else
		for (int tap = 0; tap < AUDIO_48TO32_FSZ/2; tap++)
		{
//			ac0 += afTmp[k*3 + 0 + tap] * _af48to32[2*tap+0];
//			ac1 += afTmp[k*3 + 2 + tap] * _af48to32[2*tap+1];
			ac0 += afTmp[k*3 + 0 + tap] * _af48to32A[tap];
			ac1 += afTmp[k*3 + 2 + tap] * _af48to32B[tap];
		}
#endif
		pfOut[2*k+0] = ac0;
		pfOut[2*k+1] = ac1;
	}

}
/*****************************************************************************/
void					audio_utl_32to48
/*****************************************************************************/
(
float *pfSav, // AUDIO_48TO32_FSZ/3 size
float *pfOut, 
float *pfIn
)
{
	float afTmp[AUDIO_FRSZ32 + AUDIO_48TO32_FSZ/3];
	int k;
	for (k = 0; k < AUDIO_48TO32_FSZ/3; k++)
	{
		afTmp[k] = pfSav[k];
	}
	for (k = 0; k < AUDIO_FRSZ32; k++)
	{
		afTmp[k+AUDIO_48TO32_FSZ/3] = pfIn[k];
	}
	for (k = 0; k < AUDIO_48TO32_FSZ/3; k++)
	{
		pfSav[k] = afTmp[k+AUDIO_FRSZ32];
	}

	for (k = 0; k < AUDIO_FRSZ48/3; k++)
	{
		float ac0 = 0;
		float ac1 = 0;
		float ac2 = 0;
#if 1
		float *pfAB = &afTmp[k*2+0];
		float *pfC  = &afTmp[k*2+1];
		__asm {
			mov		eax, pfAB
			lea		ecx, _af32to48A 

			movups	xmm5, XMMWORD PTR [eax+16*0]
			mulps	xmm5, XMMWORD PTR [ecx+16*0]

			movups	xmm7, XMMWORD PTR [eax+16*1]
			mulps	xmm7, XMMWORD PTR [ecx+16*1]
			addps	xmm5, xmm7
			movups	xmm7, XMMWORD PTR [eax+16*2]
			mulps	xmm7, XMMWORD PTR [ecx+16*2]
			addps	xmm5, xmm7
			movups	xmm7, XMMWORD PTR [eax+16*3]
			mulps	xmm7, XMMWORD PTR [ecx+16*3]
			addps	xmm5, xmm7

			movaps	xmm7, xmm5
			shufps	xmm7, xmm5, 0x4e
			addps	xmm5, xmm7
			movaps	xmm7, xmm5
			shufps	xmm7, xmm5, 0xb1
			addps	xmm5, xmm7
			movss	ac0,  xmm5


			;mov		eax, pfAB
			lea		ecx, _af32to48B

			movups	xmm5, XMMWORD PTR [eax+16*0]
			mulps	xmm5, XMMWORD PTR [ecx+16*0]

			movups	xmm7, XMMWORD PTR [eax+16*1]
			mulps	xmm7, XMMWORD PTR [ecx+16*1]
			addps	xmm5, xmm7
			movups	xmm7, XMMWORD PTR [eax+16*2]
			mulps	xmm7, XMMWORD PTR [ecx+16*2]
			addps	xmm5, xmm7
			movups	xmm7, XMMWORD PTR [eax+16*3]
			mulps	xmm7, XMMWORD PTR [ecx+16*3]
			addps	xmm5, xmm7

			movaps	xmm7, xmm5
			shufps	xmm7, xmm5, 0x4e
			addps	xmm5, xmm7
			movaps	xmm7, xmm5
			shufps	xmm7, xmm5, 0xb1
			addps	xmm5, xmm7
			movss	ac1,  xmm5


			mov		eax, pfC
			lea		ecx, _af32to48C

			movups	xmm5, XMMWORD PTR [eax+16*0]
			mulps	xmm5, XMMWORD PTR [ecx+16*0]

			movups	xmm7, XMMWORD PTR [eax+16*1]
			mulps	xmm7, XMMWORD PTR [ecx+16*1]
			addps	xmm5, xmm7
			movups	xmm7, XMMWORD PTR [eax+16*2]
			mulps	xmm7, XMMWORD PTR [ecx+16*2]
			addps	xmm5, xmm7
			movups	xmm7, XMMWORD PTR [eax+16*3]
			mulps	xmm7, XMMWORD PTR [ecx+16*3]
			addps	xmm5, xmm7

			movaps	xmm7, xmm5
			shufps	xmm7, xmm5, 0x4e
			addps	xmm5, xmm7
			movaps	xmm7, xmm5
			shufps	xmm7, xmm5, 0xb1
			addps	xmm5, xmm7
			movss	ac2,  xmm5
		}
#else
		// in  - |..|..| 
		// out - |.|.|.|
		for (int tap = 0; tap < AUDIO_48TO32_FSZ/3; tap++)
		{
//			ac0 += afTmp[k*2 + 0 + tap] * _af48to32[3*tap+2];
//			ac1 += afTmp[k*2 + 0 + tap] * _af48to32[3*tap+0];
//			ac2 += afTmp[k*2 + 1 + tap] * _af48to32[3*tap+1];
			ac0 += afTmp[k*2 + 0 + tap] * _af32to48A[tap];
			ac1 += afTmp[k*2 + 0 + tap] * _af32to48B[tap];
			ac2 += afTmp[k*2 + 1 + tap] * _af32to48C[tap];
		}
#endif
		pfOut[3*k+0] = ac0;
		pfOut[3*k+1] = ac1;
		pfOut[3*k+2] = ac2;
	}
}

_declspec (align(16)) static const float _afDctLL[AUDIO_FB4_SECTION_SZ] = {
  +0.9807852804F,   +0.8314696123F,   +0.5555702330F,   +0.1950903220F,
  -0.1950903220F,   -0.5555702330F,   -0.8314696123F,   -0.9807852804F,
  -0.9807852804F,   -0.8314696123F,   -0.5555702330F,   -0.1950903220F,
  +0.1950903220F,   +0.5555702330F,   +0.8314696123F,   +0.9807852804F
};
_declspec (align(16)) static const float _afDctLH[AUDIO_FB4_SECTION_SZ] = {
  -0.5555702330F,   -0.9807852804F,   -0.1950903220F,   +0.8314696123F,
  +0.8314696123F,   -0.1950903220F,   -0.9807852804F,   -0.5555702330F,
  +0.5555702330F,   +0.9807852804F,   +0.1950903220F,   -0.8314696123F,
  -0.8314696123F,   +0.1950903220F,   +0.9807852804F,   +0.5555702330F
};
_declspec (align(16)) static const float _afDctHL[AUDIO_FB4_SECTION_SZ] = {
  -0.5555702330F,   +0.9807852804F,   -0.1950903220F,   -0.8314696123F,
  +0.8314696123F,   +0.1950903220F,   -0.9807852804F,   +0.5555702330F,
  +0.5555702330F,   -0.9807852804F,   +0.1950903220F,   +0.8314696123F,
  -0.8314696123F,   -0.1950903220F,   +0.9807852804F,   -0.5555702330F
};
_declspec (align(16)) static const float _afDctHH[AUDIO_FB4_SECTION_SZ] = {
  +0.9807852804F,   -0.8314696123F,   +0.5555702330F,   -0.1950903220F,
  -0.1950903220F,   +0.5555702330F,   -0.8314696123F,   +0.9807852804F,
  -0.9807852804F,   +0.8314696123F,   -0.5555702330F,   +0.1950903220F,
  +0.1950903220F,   -0.5555702330F,   +0.8314696123F,   -0.9807852804F
};

_declspec (align(16)) static const float _afDec4Win[AUDIO_FB4_FSZ] = {
  +0.0000000000F,   -0.0000456830F,   -0.0001974661F,   -0.0004369325F, 
  -0.0006868491F,   -0.0008308621F,   -0.0007451183F,   -0.0003366564F, 
  +0.0004199952F,   +0.0014574159F,   +0.0026090694F,   +0.0036268273F, 
  +0.0042219840F,   +0.0041241898F,   +0.0031479892F,   +0.0012535421F, 
  -0.0014125631F,   -0.0045083421F,   -0.0075263748F,   -0.0098629142F, 
  -0.0109186160F,   -0.0102161343F,   -0.0075145586F,   -0.0028985492F, 
  +0.0031782271F,   +0.0099100741F,   +0.0162223880F,   +0.0209156698F, 
  +0.0228539305F,   +0.0211714283F,   +0.0154656013F,   +0.0059428004F, 
  -0.0065124062F,   -0.0203642382F,   -0.0335555400F,   -0.0437314681F, 
  -0.0485327634F,   -0.0459217380F,   -0.0344963383F,   -0.0137462117F, 
  +0.0157898248F,   +0.0524936562F,   +0.0937770888F,   +0.1363231684F, 
  +0.1764333871F,   +0.2104387469F,   +0.2351224341F,   +0.2480988850F, 
  +0.2480988850F,   +0.2351224341F,   +0.2104387469F,   +0.1764333871F, 
  +0.1363231684F,   +0.0937770888F,   +0.0524936562F,   +0.0157898248F, 
  -0.0137462117F,   -0.0344963383F,   -0.0459217380F,   -0.0485327634F, 
  -0.0437314681F,   -0.0335555400F,   -0.0203642382F,   -0.0065124062F, 
  +0.0059428004F,   +0.0154656013F,   +0.0211714283F,   +0.0228539305F, 
  +0.0209156698F,   +0.0162223880F,   +0.0099100741F,   +0.0031782271F, 
  -0.0028985492F,   -0.0075145586F,   -0.0102161343F,   -0.0109186160F, 
  -0.0098629142F,   -0.0075263748F,   -0.0045083421F,   -0.0014125631F, 
  +0.0012535421F,   +0.0031479892F,   +0.0041241898F,   +0.0042219840F, 
  +0.0036268273F,   +0.0026090694F,   +0.0014574159F,   +0.0004199952F, 
  -0.0003366564F,   -0.0007451183F,   -0.0008308621F,   -0.0006868491F, 
  -0.0004369325F,   -0.0001974661F,   -0.0000456830F,   +0.0000000000F
};
_declspec (align(16)) static float _afInt4[AUDIO_FB4_FSZ*4];

/*****************************************************************************/
void						audio_utl_fb4_analysis
/*****************************************************************************/
(
Audio_tFB4 *pDec,
float *pfIn
)
{
	int k;
	_declspec (align(16)) float af[AUDIO_FB4_FSZ+AUDIO_FRSZ32];
//	_declspec (align(16)) float afWin[AUDIO_FB4_SECTION_SZ];
//	_declspec (align(16)) float afWin2[AUDIO_FB4_SECTION_SZ];

	for (k = 0; k < AUDIO_FB4_FSZ; k++)
		af[k] = pDec->afDecSav[k];
	for (k = 0; k < AUDIO_FRSZ32; k++)
		af[k+AUDIO_FB4_FSZ] = pfIn[k];
	for (k = 0; k < AUDIO_FB4_FSZ; k++)
		pDec->afDecSav[k] = af[k+AUDIO_FRSZ32];

	for (k = 0; k < AUDIO_FRSZ8; k++)
	{
		float acLL = 0;
		float acLH = 0;
		float acHL = 0;
		float acHH = 0;
		float *pf = af+4*k;
#if 0
		int n, i;
		for (i = 0; i < AUDIO_FB4_SECTION_SZ; i++)
		{
			register float f = 0;
			for (n = 0; n < AUDIO_DEC4_SECTIONS; n++)
			{
				int idx = i+AUDIO_FB4_SECTION_SZ*n;
				f += pf[idx] * _afDec4Win[idx];
			}
			afWin[i] = f;
		}
#else
		__asm 
		{
			mov		eax, pf
			lea		ecx, _afDec4Win
			movaps	xmm0, XMMWORD PTR [eax+AUDIO_FB4_SECTION_SZ*0*4+0*16]
			mulps	xmm0, XMMWORD PTR [ecx+AUDIO_FB4_SECTION_SZ*0*4+0*16]
			movaps	xmm7, XMMWORD PTR [eax+AUDIO_FB4_SECTION_SZ*1*4+0*16]
			mulps	xmm7, XMMWORD PTR [ecx+AUDIO_FB4_SECTION_SZ*1*4+0*16]
			addps	xmm0, xmm7
			movaps	xmm7, XMMWORD PTR [eax+AUDIO_FB4_SECTION_SZ*2*4+0*16]
			mulps	xmm7, XMMWORD PTR [ecx+AUDIO_FB4_SECTION_SZ*2*4+0*16]
			addps	xmm0, xmm7
			movaps	xmm7, XMMWORD PTR [eax+AUDIO_FB4_SECTION_SZ*3*4+0*16]
			mulps	xmm7, XMMWORD PTR [ecx+AUDIO_FB4_SECTION_SZ*3*4+0*16]
			addps	xmm0, xmm7
			movaps	xmm7, XMMWORD PTR [eax+AUDIO_FB4_SECTION_SZ*4*4+0*16]
			mulps	xmm7, XMMWORD PTR [ecx+AUDIO_FB4_SECTION_SZ*4*4+0*16]
			addps	xmm0, xmm7
			movaps	xmm7, XMMWORD PTR [eax+AUDIO_FB4_SECTION_SZ*5*4+0*16]
			mulps	xmm7, XMMWORD PTR [ecx+AUDIO_FB4_SECTION_SZ*5*4+0*16]
			addps	xmm0, xmm7

			movaps	xmm1, XMMWORD PTR [eax+AUDIO_FB4_SECTION_SZ*0*4+1*16]
			mulps	xmm1, XMMWORD PTR [ecx+AUDIO_FB4_SECTION_SZ*0*4+1*16]
			movaps	xmm7, XMMWORD PTR [eax+AUDIO_FB4_SECTION_SZ*1*4+1*16]
			mulps	xmm7, XMMWORD PTR [ecx+AUDIO_FB4_SECTION_SZ*1*4+1*16]
			addps	xmm1, xmm7
			movaps	xmm7, XMMWORD PTR [eax+AUDIO_FB4_SECTION_SZ*2*4+1*16]
			mulps	xmm7, XMMWORD PTR [ecx+AUDIO_FB4_SECTION_SZ*2*4+1*16]
			addps	xmm1, xmm7
			movaps	xmm7, XMMWORD PTR [eax+AUDIO_FB4_SECTION_SZ*3*4+1*16]
			mulps	xmm7, XMMWORD PTR [ecx+AUDIO_FB4_SECTION_SZ*3*4+1*16]
			addps	xmm1, xmm7
			movaps	xmm7, XMMWORD PTR [eax+AUDIO_FB4_SECTION_SZ*4*4+1*16]
			mulps	xmm7, XMMWORD PTR [ecx+AUDIO_FB4_SECTION_SZ*4*4+1*16]
			addps	xmm1, xmm7
			movaps	xmm7, XMMWORD PTR [eax+AUDIO_FB4_SECTION_SZ*5*4+1*16]
			mulps	xmm7, XMMWORD PTR [ecx+AUDIO_FB4_SECTION_SZ*5*4+1*16]
			addps	xmm1, xmm7

			movaps	xmm2, XMMWORD PTR [eax+AUDIO_FB4_SECTION_SZ*0*4+2*16]
			mulps	xmm2, XMMWORD PTR [ecx+AUDIO_FB4_SECTION_SZ*0*4+2*16]
			movaps	xmm7, XMMWORD PTR [eax+AUDIO_FB4_SECTION_SZ*1*4+2*16]
			mulps	xmm7, XMMWORD PTR [ecx+AUDIO_FB4_SECTION_SZ*1*4+2*16]
			addps	xmm2, xmm7
			movaps	xmm7, XMMWORD PTR [eax+AUDIO_FB4_SECTION_SZ*2*4+2*16]
			mulps	xmm7, XMMWORD PTR [ecx+AUDIO_FB4_SECTION_SZ*2*4+2*16]
			addps	xmm2, xmm7
			movaps	xmm7, XMMWORD PTR [eax+AUDIO_FB4_SECTION_SZ*3*4+2*16]
			mulps	xmm7, XMMWORD PTR [ecx+AUDIO_FB4_SECTION_SZ*3*4+2*16]
			addps	xmm2, xmm7
			movaps	xmm7, XMMWORD PTR [eax+AUDIO_FB4_SECTION_SZ*4*4+2*16]
			mulps	xmm7, XMMWORD PTR [ecx+AUDIO_FB4_SECTION_SZ*4*4+2*16]
			addps	xmm2, xmm7
			movaps	xmm7, XMMWORD PTR [eax+AUDIO_FB4_SECTION_SZ*5*4+2*16]
			mulps	xmm7, XMMWORD PTR [ecx+AUDIO_FB4_SECTION_SZ*5*4+2*16]
			addps	xmm2, xmm7

			movaps	xmm3, XMMWORD PTR [eax+AUDIO_FB4_SECTION_SZ*0*4+3*16]
			mulps	xmm3, XMMWORD PTR [ecx+AUDIO_FB4_SECTION_SZ*0*4+3*16]
			movaps	xmm7, XMMWORD PTR [eax+AUDIO_FB4_SECTION_SZ*1*4+3*16]
			mulps	xmm7, XMMWORD PTR [ecx+AUDIO_FB4_SECTION_SZ*1*4+3*16]
			addps	xmm3, xmm7
			movaps	xmm7, XMMWORD PTR [eax+AUDIO_FB4_SECTION_SZ*2*4+3*16]
			mulps	xmm7, XMMWORD PTR [ecx+AUDIO_FB4_SECTION_SZ*2*4+3*16]
			addps	xmm3, xmm7
			movaps	xmm7, XMMWORD PTR [eax+AUDIO_FB4_SECTION_SZ*3*4+3*16]
			mulps	xmm7, XMMWORD PTR [ecx+AUDIO_FB4_SECTION_SZ*3*4+3*16]
			addps	xmm3, xmm7
			movaps	xmm7, XMMWORD PTR [eax+AUDIO_FB4_SECTION_SZ*4*4+3*16]
			mulps	xmm7, XMMWORD PTR [ecx+AUDIO_FB4_SECTION_SZ*4*4+3*16]
			addps	xmm3, xmm7
			movaps	xmm7, XMMWORD PTR [eax+AUDIO_FB4_SECTION_SZ*5*4+3*16]
			mulps	xmm7, XMMWORD PTR [ecx+AUDIO_FB4_SECTION_SZ*5*4+3*16]
			addps	xmm3, xmm7

//			lea		ecx, afWin
//			movaps	XMMWORD PTR [ecx + 16*0], xmm0
//			movaps	XMMWORD PTR [ecx + 16*1], xmm1
//			movaps	XMMWORD PTR [ecx + 16*2], xmm2
//			movaps	XMMWORD PTR [ecx + 16*3], xmm3
		}		

#endif

#if 1
		__asm {
//			lea		ecx,  afWin
//			movaps	xmm0, XMMWORD PTR [ecx + 16*0]
//			movaps	xmm1, XMMWORD PTR [ecx + 16*1]
//			movaps	xmm2, XMMWORD PTR [ecx + 16*2]
//			movaps	xmm3, XMMWORD PTR [ecx + 16*3]

			lea		ecx,  _afDctLL
			movaps	xmm5, XMMWORD PTR [ecx+0*16];
			mulps	xmm5, xmm0
			movaps	xmm4, XMMWORD PTR [ecx+1*16];
			mulps	xmm4, xmm1
			addps	xmm5, xmm4
			movaps	xmm4, XMMWORD PTR [ecx+2*16];
			mulps	xmm4, xmm2
			addps	xmm5, xmm4
			movaps	xmm4, XMMWORD PTR [ecx+3*16];
			mulps	xmm4, xmm3
			addps	xmm5, xmm4

			lea		ecx, _afDctLH

			movaps	xmm7, xmm5
			shufps	xmm7, xmm5, 0x4e
			addps	xmm5, xmm7
			movaps	xmm7, xmm5
			shufps	xmm7, xmm5, 0xb1
			addps	xmm5, xmm7
			movss	acLL, xmm5

			movaps	xmm5, XMMWORD PTR [ecx+0*16];
			mulps	xmm5, xmm0
			movaps	xmm4, XMMWORD PTR [ecx+1*16];
			mulps	xmm4, xmm1
			addps	xmm5, xmm4
			movaps	xmm4, XMMWORD PTR [ecx+2*16];
			mulps	xmm4, xmm2
			addps	xmm5, xmm4
			movaps	xmm4, XMMWORD PTR [ecx+3*16];
			mulps	xmm4, xmm3
			addps	xmm5, xmm4

			lea		ecx, _afDctHL

			movaps	xmm7, xmm5
			shufps	xmm7, xmm5, 0x4e
			addps	xmm5, xmm7
			movaps	xmm7, xmm5
			shufps	xmm7, xmm5, 0xb1
			addps	xmm5, xmm7
			movss	acLH, xmm5

			movaps	xmm5, XMMWORD PTR [ecx+0*16];
			mulps	xmm5, xmm0
			movaps	xmm4, XMMWORD PTR [ecx+1*16];
			mulps	xmm4, xmm1
			addps	xmm5, xmm4
			movaps	xmm4, XMMWORD PTR [ecx+2*16];
			mulps	xmm4, xmm2
			addps	xmm5, xmm4
			movaps	xmm4, XMMWORD PTR [ecx+3*16];
			mulps	xmm4, xmm3
			addps	xmm5, xmm4

			lea		ecx, _afDctHH

			movaps	xmm7, xmm5
			shufps	xmm7, xmm5, 0x4e
			addps	xmm5, xmm7
			movaps	xmm7, xmm5
			shufps	xmm7, xmm5, 0xb1
			addps	xmm5, xmm7
			movss	acHL, xmm5

			movaps	xmm5, XMMWORD PTR [ecx+0*16];
			mulps	xmm5, xmm0
			movaps	xmm4, XMMWORD PTR [ecx+1*16];
			mulps	xmm4, xmm1
			addps	xmm5, xmm4
			movaps	xmm4, XMMWORD PTR [ecx+2*16];
			mulps	xmm4, xmm2
			addps	xmm5, xmm4
			movaps	xmm4, XMMWORD PTR [ecx+3*16];
			mulps	xmm4, xmm3
			addps	xmm5, xmm4

			movaps	xmm7, xmm5
			shufps	xmm7, xmm5, 0x4e
			addps	xmm5, xmm7
			movaps	xmm7, xmm5
			shufps	xmm7, xmm5, 0xb1
			addps	xmm5, xmm7
			movss	acHH, xmm5
		}
#else
		for (i = 0; i < AUDIO_FB4_SECTION_SZ;i++)
		{
			acLL +=  aWin[i] * _afDctLL[i];
			acLH +=  aWin[i] * _afDctLH[i];
			acHL +=  aWin[i] * _afDctHL[i];
			acHH +=  aWin[i] * _afDctHH[i];
		}
#endif
		pDec->afLL[k] = acLL;
		pDec->afLH[k] = acLH;
		pDec->afHL[k] = acHL;
		pDec->afHH[k] = acHH;
	}
}
/*****************************************************************************/
void						audio_utl_fb4_set
/*****************************************************************************/
(
)
{
	int n,i;
	float *pf = _afInt4;
	for (i = 0; i < 4; i++)
	{
		float acc = 0;
		for (n = 0; n < AUDIO_FB4_FSZ/4; n++)
		{
			int idx = AUDIO_FB4_FSZ-4-n*4+i;
			*pf++ = 4*_afDec4Win[idx] * _afDctLL[idx & 0xf];
			*pf++ = 4*_afDec4Win[idx] * _afDctLH[idx & 0xf];
			*pf++ = 4*_afDec4Win[idx] * _afDctHL[idx & 0xf];
			*pf++ = 4*_afDec4Win[idx] * _afDctHH[idx & 0xf];
		}
	}
}
/*****************************************************************************/
void						audio_utl_fb4_synthesis
/*****************************************************************************/
(
Audio_tFB4 *pDec,
float *pfOut
)
{
	int k;
	_declspec (align(16)) float af[AUDIO_FB4_FSZ+AUDIO_FRSZ32];

	for (k = 0; k < AUDIO_FB4_FSZ; k++)
	{
		af[k] = pDec->afIntSav[k];
	}
	for (k = 0; k < AUDIO_FRSZ8; k++)
	{
		af[k*4+0+AUDIO_FB4_FSZ] = pDec->afLL[k];
		af[k*4+1+AUDIO_FB4_FSZ] = pDec->afLH[k];
		af[k*4+2+AUDIO_FB4_FSZ] = pDec->afHL[k];
		af[k*4+3+AUDIO_FB4_FSZ] = pDec->afHH[k];
	}
	for (k = 0; k < AUDIO_FB4_FSZ; k++)
	{
		pDec->afIntSav[k] = af[k+AUDIO_FRSZ32];
	}

	// here we need to inverse the filters
	for (k = 0; k < AUDIO_FRSZ8; k++)
	{
		for (int i = 0; i < 4; i++)
		{
			float *pfData = &af[4*k];
			float *pfFlt = _afInt4 + AUDIO_FB4_FSZ*i;
			float acc = 0;

#if 1
			__asm {
				mov		eax, pfFlt
				mov		ecx, pfData
				mov		esi, AUDIO_FB4_FSZ/32
				xorps	xmm5,xmm5
INT4:
					movaps	xmm7, XMMWORD PTR [eax+0*16];
					mulps	xmm7, XMMWORD PTR [ecx+0*16];
					addps	xmm5, xmm7

					movaps	xmm7, XMMWORD PTR [eax+1*16];
					mulps	xmm7, XMMWORD PTR [ecx+1*16];
					addps	xmm5, xmm7

					movaps	xmm7, XMMWORD PTR [eax+2*16];
					mulps	xmm7, XMMWORD PTR [ecx+2*16];
					addps	xmm5, xmm7

					movaps	xmm7, XMMWORD PTR [eax+3*16];
					mulps	xmm7, XMMWORD PTR [ecx+3*16];
					addps	xmm5, xmm7

					movaps	xmm7, XMMWORD PTR [eax+4*16];
					mulps	xmm7, XMMWORD PTR [ecx+4*16];
					addps	xmm5, xmm7

					movaps	xmm7, XMMWORD PTR [eax+5*16];
					mulps	xmm7, XMMWORD PTR [ecx+5*16];
					addps	xmm5, xmm7

					movaps	xmm7, XMMWORD PTR [eax+6*16];
					mulps	xmm7, XMMWORD PTR [ecx+6*16];
					addps	xmm5, xmm7

					movaps	xmm7, XMMWORD PTR [eax+7*16];
					mulps	xmm7, XMMWORD PTR [ecx+7*16];
					addps	xmm5, xmm7

					add		eax, 16*8
					add		ecx, 16*8
					sub		esi, 1
				jnz		INT4

				movaps	xmm7, xmm5
				shufps	xmm7, xmm5, 0x4e
				addps	xmm5, xmm7
				movaps	xmm7, xmm5
				shufps	xmm7, xmm5, 0xb1
				addps	xmm5, xmm7
				movss	acc,  xmm5
			}
#else
			for (int n = 0; n < AUDIO_FB4_FSZ; n++)
			{
				acc += *pfData++ * *pfFlt++;
			}
#endif
			*pfOut++ = acc;
		}
	}
}

/*-------------------------------------------------------------------------*/
void                     audio_utl_thread_stts
/*-------------------------------------------------------------------------*/
(
HANDLE hThread,
float *fKernel,
float *fUser
)
{
	__int64 qwCreated = {0};
	__int64 qwExited  = {0};
	__int64 qwKernel  = {0}; 
	__int64 qwUser	  = {0};
	__int64 qwNow	  = {0};

	GetSystemTimeAsFileTime((LPFILETIME)&qwNow);

	BOOL b = GetThreadTimes(hThread,
		(LPFILETIME)&qwCreated,
		(LPFILETIME)&qwExited,
		(LPFILETIME)&qwKernel,
		(LPFILETIME)&qwUser);

	if (b)
	{
		*fKernel = float(100.*qwKernel/(qwNow-qwCreated+1.0));
		*fUser   = float(100.*qwUser  /(qwNow-qwCreated+1.0));
	}
}

/*-------------------------------------------------------------------------*/
void                     audio_utl_set_wav
/*-------------------------------------------------------------------------*/
(
Audio_tWavHdr *pHdr,
DWORD dwFs,
WORD wChannels
)
{
    pHdr->acRiff[0] = 'R';
    pHdr->acRiff[1] = 'I';
    pHdr->acRiff[2] = 'F';
    pHdr->acRiff[3] = 'F';

    pHdr->dwLen1 = 36;
    pHdr->acWave[0] = 'W';
    pHdr->acWave[1] = 'A';
    pHdr->acWave[2] = 'V';
    pHdr->acWave[3] = 'E';

    pHdr->acFmt[0] = 'f';
    pHdr->acFmt[1] = 'm';
    pHdr->acFmt[2] = 't';
    pHdr->acFmt[3] = ' ';

    pHdr->dwLen2 = 16;
    pHdr->wMode  = 1;
    pHdr->wNumber = wChannels;
    pHdr->dwFs = dwFs;
    pHdr->dwBps = dwFs*2*wChannels;
    pHdr->wBytes = 2;
    pHdr->wBits = 16;

    pHdr->acData[0] = 'd';
    pHdr->acData[1] = 'a';
    pHdr->acData[2] = 't';
    pHdr->acData[3] = 'a';
    pHdr->dwLen3 = 0;
}

/*****************************************************************************/
void					audio_utl_short2float
/*****************************************************************************/
(
float *pf,
short *ps,
int iSz
)
{
	iSz >>= 4;
	for (int k = 0; k < iSz; k++)
	{
		for (int n = 0; n < 16; n++)
		{
			*pf++ = *ps++ * (1.F/32768.F);
		}
	}
}
/*****************************************************************************/
void					audio_utl_float2short
/*****************************************************************************/
(
short *ps,
float *pf,
int iSz
)
{
	iSz >>= 4;
	for (int k = 0; k < iSz; k++)
	{
		for (int n = 0; n < 16; n++)
		{
			int x = int(*pf++ * 32767);
			if (x > 32767)
				x = 32767;
			if (x < -32768)
				x = -32768;
			*ps++ = short(x);
		}
	}
}
/*****************************************************************************/
float					audio_utl_pktnrg
/*****************************************************************************/
(
short *ps,
int iSz
)
{
	int i, k;
	float fEn = 0.F;
	iSz >>= 4;
	if (iSz <= 0)
		return -120.F;

	for (i = 0; i < iSz; i++)
	{
		for (k = 0; k < 16; k++)
		{
			float x = ps[k] * (1.F/32768.F);
			fEn += 	x*x;
		}
		ps += 8;
	}
	fEn *= 0.5F/iSz;
	fEn += 1.e-12F;
	return 10.F*log10f(fEn);
}

/*****************************************************************************/
float					audio_utl_pktnrg
/*****************************************************************************/
(
float *ps,
int iSz
)
{
	int i, k;
	float fEn = 0.F;
	iSz >>= 4;
	if (iSz <= 0)
		return -120.F;

	for (i = 0; i < iSz; i++)
	{
		for (k = 0; k < 16; k++)
		{
			float x = ps[k];
			fEn += 	x*x;
		}
		ps += 8;
	}
	fEn *= 0.5F/iSz;
	fEn += 1.e-12F;
	return 10.F*log10f(fEn);
}

/*****************************************************************************/
void					audio_utl_iir1
/*****************************************************************************/
(
float *pfIO, // computations in place
float *pfSav,
const float *pfCoef, // b0 b1 a1 
DWORD dwSz
)
{
//	y(k) = -a1*y(k-1) + b0*x(k) + b1*x(k-1);
	dwSz >>= 4;

	register float b0 = pfCoef[0];
	register float b1 = pfCoef[1];
	register float a1 = pfCoef[2];
	register float d1 = pfSav[0];

	for (DWORD k = 0; k < dwSz; k++)
	{
		for (int i = 0; i < 16; i++)
		{
			register float d0 = *pfIO - d1 * a1;
			*pfIO++ = d0 * b0 + d1 * b1; 	// b2 = b0
			d1 = d0;
		}
	}
	pfSav[0] = d1;
}
/*****************************************************************************/
void					audio_utl_iir2s
/*****************************************************************************/
(
float *pfIO, // computations in place
float *pfSav,
const float *pfCoef, // b0 b1 b2 a1 a2
DWORD dwSz
)
{

#if 0
		float d1 = pfSav[0];
		float d2 = pfSav[1];

		float b0 = pfCoef[0];
		float b1 = pfCoef[1];
		float a1 = pfCoef[2];
		float a2 = pfCoef[3];
		__asm {
			movss	xmm1, d1
			movss	xmm2, d2
			movss	xmm3, b0
			movss	xmm4, b1
			movss	xmm5, a1
			movss	xmm6, a2
			mov		eax, dwSz
			sar		eax, 1		; size is always even
			mov		edx, pfIO
L0:
				movss	xmm0, dword ptr[edx+0]	; xmm0 = x
				movss	xmm7, xmm1
				mulss	xmm7, xmm5
				subss	xmm0, xmm7	; xmm0 = x-a1*d1
				movss	xmm7, xmm2
				mulss	xmm7, xmm6
				subss	xmm0, xmm7	; xmm0 = x-a1*d1-a2*d2
				movd	ecx,  xmm0 ; // preserve d0

				mulss	xmm0, xmm3	; xmm0 = d0*b0
				movss	xmm7, xmm1
				mulss	xmm7, xmm4
				addss	xmm0, xmm7	; xmm0 = d0*b0+d1*b1
				movss	xmm7, xmm2
				mulss	xmm7, xmm3
				addss	xmm0, xmm7	; xmm0 = d0*b0+d1*b1+d2*b0
				movss	dword ptr [edx+0], xmm0
				movss	xmm2, xmm1	; d2 = d1
				movd	xmm1, ecx	; d1 = d0


				movss	xmm0, dword ptr[edx+4]	; xmm0 = x
				movss	xmm7, xmm1
				mulss	xmm7, xmm5
				subss	xmm0, xmm7	; xmm0 = x-a1*d1
				movss	xmm7, xmm2
				mulss	xmm7, xmm6
				subss	xmm0, xmm7	; xmm0 = x-a1*d1-a2*d2
				movd	ecx,  xmm0 ; // preserve d0

				mulss	xmm0, xmm3	; xmm0 = d0*b0
				movss	xmm7, xmm1
				mulss	xmm7, xmm4
				addss	xmm0, xmm7	; xmm0 = d0*b0+d1*b1
				movss	xmm7, xmm2
				mulss	xmm7, xmm3
				addss	xmm0, xmm7	; xmm0 = d0*b0+d1*b1+d2*b0
				movss	dword ptr [edx+4], xmm0
				movss	xmm2, xmm1	; d2 = d1
				movd	xmm1, ecx	; d1 = d0

				add		edx, 8
				dec		eax
			jne		L0
			movss	d1, xmm1
			movss	d2, xmm2
		}
		pfSav[0] = d1;
		pfSav[1] = d2;
#else
		dwSz >>= 2;
		register float b0 = pfCoef[0];
		register float b1 = pfCoef[1];
		register float a1 = pfCoef[2];
		register float a2 = pfCoef[3];

		register float d1 = pfSav[0];
		register float d2 = pfSav[1];
		for (DWORD k = 0; k < dwSz; k++)
		{
			for (int i = 0; i < 4; i++)
			{
				register float d0 = *pfIO - d1 * a1 - d2 * a2;
				*pfIO++ = (d0 + d2) * b0 + d1 * b1; 	// b2 = b0
				d2 = d1;
				d1 = d0;
			}
		}
		pfSav[0] = d1;
		pfSav[1] = d2;
#endif
}

/*****************************************************************************/
void					audio_utl_iir8
/*****************************************************************************/
(
float *pfSav,
const float *pfCoef, // b0 ... b8, a1 ... a8
float *pfIn, 
float *pfOut, 
unsigned int iSz
)
{
	register const float *pfB = pfCoef;
	register const float *pfA = pfCoef + 10;
	float afD[8+4];
	unsigned int i;
	unsigned int k;

	for (i = 0; i < 8; i++)
	{
		afD[i+4] = pfSav[i];
	}

	for (i = 0; i < iSz >> 2; i++)
	{
		for (int j = 4; j > 0; j--)
		{
			register float d0 = *pfIn++;
			for (k = 0; k < 8; k++)
			{
				d0 -= afD[k+j] * pfA[k];
			}
			register float out = d0 * pfB[0];
			for (k = 0; k < 8; k++)
			{
				out += afD[k+j] * pfB[k+1];
			}
			*pfOut++ = out;

			afD[j-1] = d0;
		}
		for (k = 8+4-1; k > 4-1; k--)
		{
			afD[k] = afD[k-4];
		}
	}

	for (i = 0; i < 8; i++)
	{
		pfSav[i] = afD[i+4];
	}
}

#if 0
const static float _afSosDecCoef[5][4] = 
{
	// b0=b2   b1       a1        a2
    0.0092F,  0.0041F,  -1.7906F, 0.8134F,
    0.1288F, -0.1646F,  -1.7723F, 0.8697F,
    0.4151F, -0.6589F,  -1.7536F, 0.9302F,
    0.6767F, -1.1320F,  -1.7442F, 0.9693F,
    0.8092F, -1.3748F,  -1.7455F, 0.9916F
};

//[b,a]=cheby1(8,1.0,3400/16000);

static const float _afBQAQ[18] = {
	1.87621204921886e-006F,     1.50096963937509e-005F,     5.25339373781281e-005F,
    0.000105067874756256F,      0.00013133484344532F,        0.000105067874756256F,
    5.25339373781281e-005F,     1.50096963937509e-005F,     1.87621204921886e-006F,
	1.F,					   -6.54894231906703F,          19.5103711603154F,
   -34.4320851368036F,          39.2975228147713F,         -29.6676954732401F,
    14.4608680956208F,         -4.16094836365014F,          0.541448139056409F
};

// IIR8 filters for dividing band in low and high halfs
/*
dlt=0.0625;
order=8;
ripples=0.7;
[bl,al]=cheby1(order,ripples,0.5*(1-dlt));
[hl,f]=freqz(bl,al);
hl=20*log10(abs(hl)+eps);
[bh,ah]=cheby1(order,ripples,0.5*(1+dlt),'high');
*/
static const float _afBLAL[18] = {
	// bl
	1.096979339824860e-003F,    8.775834718598882e-003F,    3.071542151509609e-002F,
    6.143084303019217e-002F,    7.678855378774022e-002F,    6.143084303019217e-002F,
    3.071542151509609e-002F,    8.775834718598882e-003F,    1.096979339824860e-003F,
	// al
	1.000000000000000e+000F,   -2.836662225270310e+000F,    5.456619206511634e+000F,
   -7.178081688727042e+000F,    7.106459347444654e+000F,   -5.272380944902460e+000F,
    2.876607352822846e+000F,   -1.067124110621208e+000F,    2.189586929656014e-001F
};

static const float _afBHAH[18] = {
    1.096979339824847e-003F,   -8.775834718598779e-003F,    3.071542151509573e-002F,
   -6.143084303019146e-002F,    7.678855378773931e-002F,   -6.143084303019146e-002F,
    3.071542151509573e-002F,   -8.775834718598779e-003F,    1.096979339824847e-003F,
    1.000000000000000e+000F,    2.836662225270312e+000F,    5.456619206511638e+000F,
    7.178081688727050e+000F,    7.106459347444662e+000F,    5.272380944902470e+000F,
    2.876607352822853e+000F,    1.067124110621210e+000F,    2.189586929656021e-001F
};
#endif
