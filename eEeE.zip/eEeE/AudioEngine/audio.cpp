#include "audio_defs.h"
#include "audio_g711u.h"
#include "audio_g711a.h"
#include "audio_g729.h"
#include "aec8k_if.h"
#include "siren_if.h"


/* 
matlab for 80Hz HPF with 0 at 60Hz and DC

[b,a]=ellip(5,0.5,40,79/4000,'high'); 
[h,f]=freqz(b,a,80000,8000);
h=20*log10(abs(h));plot(f,h);
axis([0 200 -62 2]); 
grid on;
[z,p,k]=tf2zp(b,a);
sos=zp2sos(z,p,k);
format long
sos

*/
const static float _afSosHpfCoef[3][4] = 
{
	// b0=b2			b1					a1					a2
   0.93806447829438F,  -0.93806447935589F, -0.87612891916010F, 0.F,
   0.97276664432793F,  -1.94447317548890F, -1.94207293811977F, 0.94793355594305F,
   0.99565856353302F,  -1.98909205191453F, -1.98834194511214F, 0.99206728379004F
};
     
static const  float _afSos120Hz[4] = {
	// b0=b2			b1					a1					a2
	0.99686823577081F,  -1.98489799357971F, -1.98489799357971F,   0.99373647154161F
};


/*****************************************************************************/

/*****************************************************************************/
//			GLOBALS
/*****************************************************************************/
Audio_tCtrl gAudio = {0};


/*****************************************************************************/
void					audio_create
/*****************************************************************************/
(
)
{
	InitializeCriticalSection(&gAudio.Lock);
	gAudio.dwSD = AUDIO_SD;
	gAudio.dwED = AUDIO_ED;
	gAudio.dwDD0 = AUDIO_DD;
	gAudio.dwDD1 = AUDIO_DD;
	gAudio.dwDD2 = AUDIO_DD;
	gAudio.dwDD3 = AUDIO_DD;
	gAudio.dwDD4 = AUDIO_DD;

	audio_G711A_decoder_init();
	audio_G711A_encoder_init();
	audio_G711U_decoder_init();
	audio_G711U_encoder_init();
	siren_init();
	audio_utl_fb4_set();

	audio_agc_init(&gAudio.Agc, 0, NULL); // default params
	GAEC_init(&gAudio.Aec.AecLL); // init to default config
	gaec_hp_init(&gAudio.Aec.HpLH);
	gaec_sw_init(&gAudio.Aec.SwHL);
	gaec_sw_init(&gAudio.Aec.SwHH);

//#if AUDIO_G729
#if 0
	audio_CPU_info
		(
		&gAudio.Cpu.iType, 
		NULL,//&gAudio.Cpu.iMHz, 
		&gAudio.Cpu.iCacheSz
		);
	audio_log_inf("AudioIf_init -- CPU %d, F=%d MHz, Cache %d Bytes",
		gAudio.Cpu.iType,
		gAudio.Cpu.iMHz,
		gAudio.Cpu.iCacheSz);

#endif
}
/*****************************************************************************/
void					audio_start
/*****************************************************************************/
(
)
{
	GAEC_tCtrl Ctrl;
	Ctrl.uCmd = GAEC_CMD_RESET | GAEC_CMD_PRESERVE_FLT;

	GAEC_control(&gAudio.Aec.AecLL, &Ctrl); // init to default config
	gaec_hp_control(&gAudio.Aec.HpLH, &Ctrl);
	gaec_sw_reset(&gAudio.Aec.SwHL);
	gaec_sw_reset(&gAudio.Aec.SwHH);
	gAudio.Aec.bOn = true;

    //Added by zion@eyeball.com June 18, 2007
    //_afInt4 array was found to be filled with CDCDCDCDs after many calls
    audio_utl_fb4_set();

	memset(&gAudio.Jb, 0, sizeof(gAudio.Jb));
	memset(&gAudio.Tg, 0, sizeof(gAudio.Tg));
//	memset(&gAudio.Agc, 0, sizeof(gAudio.Agc));
	memset(&gAudio.Ns, 0, sizeof(gAudio.Ns));
	memset(&gAudio.Nrg, 0, sizeof(gAudio.Nrg));
	memset(&gAudio.Conf, 0, sizeof(gAudio.Conf));
	memset(&gAudio.Alarm, 0, sizeof(gAudio.Alarm));

	audio_agc_reset(&gAudio.Agc);

#if 0
	GAEC_tCtrl     Ctrl = {0};
	   Ctrl.uCmd = 0
//                | GAEC_CMD_ALL_OFF 
//                | GAEC_CMD_LOOPBACK 
//                | GAEC_CMD_NLP_OFF 
//                | GAEC_CMD_ADAPT_OFF 
//				| GAEC_CMD_NSE_RED_OFF
                | GAEC_CMD_RCV_NSE_OFF 
                | GAEC_CMD_SND_MUTED
				;
    Ctrl.uCmdMask = Ctrl.uCmd;
    GAEC_control(&gAudio.Aec.AecLL, &Ctrl);
    gaec_hp_control(&gAudio.Aec.HpLH, &Ctrl);
#endif
}
/*****************************************************************************/
void					audio_stop
/*****************************************************************************/
(
)
{
}

/*****************************************************************************/
void					audio_delete
/*****************************************************************************/
(
)
{

	DeleteCriticalSection(&gAudio.Lock);
}
/*****************************************************************************/
static void					audio_volume
/*****************************************************************************/
(
)
{
	float fGain = gaec_utl_exp(gAudio.fVolumeDb);

	for (int k = 0; k < AUDIO_FRSZ32; k++)
	{
		float x = gAudio.afRcv[k] * fGain;
		if (x > 1.0F)
			x = 1.0F;
		if (x < -1.0F)
			x = -1.0F;
		gAudio.afRcv[k]	= x;
		gAudio.afVol[k]	= x;
	}
	audio_recf32(AUDIO_IF_REC_VOL, 0, gAudio.afRcv);
}
/*****************************************************************************/
static void					audio_aec
/*****************************************************************************/
(
)
{
	int k;
	Audio_tAec *pAec = &gAudio.Aec;
	float fSndGain = gAudio.Agc.fGainDb + gAudio.Agc.Cfg.fExtraGain;

	audio_tmr_start(AUDIO_TMR_AEC);

	if (pAec->bOn)
	{
		audio_tmr_start(AUDIO_TMR_AEC_ANA);
		audio_utl_fb4_analysis(&pAec->Rcv, gAudio.afRcv);
		audio_utl_fb4_analysis(&pAec->Snd, gAudio.afSnd);

		// hi-pass LL and get rid of 120Hz
		audio_utl_iir1(
			pAec->Snd.afLL, 
			&pAec->aafSosHpf[0][0], 
			&_afSosHpfCoef[0][0], 
			AUDIO_FRSZ8); 
		for (k = 1; k < 3; k++)
		{
			audio_utl_iir2s(
				pAec->Snd.afLL, 
				&pAec->aafSosHpf[k][0], 
				&_afSosHpfCoef[k][0], 
				AUDIO_FRSZ8); 
		}
		audio_utl_iir2s(pAec->Snd.afLL, pAec->afSos120, _afSos120Hz, AUDIO_FRSZ8); 
		audio_tmr_stop (AUDIO_TMR_AEC_ANA);

		// --------------- AEC  ------------------
		// 0...4kHz;
		audio_tmr_start(AUDIO_TMR_AEC_LL);
		GAEC_process(
			&pAec->AecLL, 
			pAec->Rcv.afLL, 
			pAec->Snd.afLL, 
			fSndGain
			);
		audio_tmr_stop (AUDIO_TMR_AEC_LL);

		audio_tmr_start(AUDIO_TMR_AEC_LH);
		// 4kHz ... 8kHz
		gaec_hp_update(&pAec->HpLH, &pAec->AecLL.Db, &pAec->AecLL.Sc);
	//	gaec_hp_update(&pAec->HpHL, &pAec->AecLL.Db, &pAec->AecLL.Sc);

		gaec_hp_process(
			&pAec->HpLH, 
			&pAec->HpSc,
			pAec->Rcv.afLH, 
			pAec->Snd.afLH,
			fSndGain
			);
		audio_tmr_stop (AUDIO_TMR_AEC_LH);

		audio_tmr_start(AUDIO_TMR_AEC_H);
		gaec_sw_update(&pAec->SwHL,  &pAec->HpLH, &pAec->HpSc);
		gaec_sw_update(&pAec->SwHH,  &pAec->HpLH, &pAec->HpSc);

		// 8kHz ... 12kHz
		gaec_sw_process(
			&pAec->SwHL, 
			pAec->Rcv.afHL, 
			pAec->Snd.afHL,
			fSndGain
			);

		// 12kHz ... 16kHz
		gaec_sw_process(
			&pAec->SwHH, 
			pAec->Rcv.afHH, 
			pAec->Snd.afHH,
			fSndGain
			);
		audio_tmr_stop (AUDIO_TMR_AEC_H);

		// --------------- RCV SYNTHESIS ------------------

		audio_tmr_start(AUDIO_TMR_AEC_SYN);
		audio_utl_fb4_synthesis(&pAec->Rcv, gAudio.afRcv);
		audio_utl_fb4_synthesis(&pAec->Snd, gAudio.afSnd);

		audio_tmr_stop (AUDIO_TMR_AEC_SYN);
	}
	audio_tmr_stop(AUDIO_TMR_AEC);
}



/*****************************************************************************/
static void					audio_mic_preprocess
/*****************************************************************************/
(
short *pMicData
)
{
	float afData48[AUDIO_FRSZ48];
	int k;
	int iSaturationCnt = 0;

	for (k = 0; k < AUDIO_FRSZ48; k++) 
	{
		gAudio.asMic48[k] = pMicData[k];
		int x = abs(int(pMicData[k]));
		if (x > 32700)
			iSaturationCnt++;
	}

	if (iSaturationCnt > 0)
	{
		gAudio.Alarm.iMicClipCnt += iSaturationCnt;
		if (gAudio.Alarm.iMicClipCnt > AUDIO_FRSZ48*2)
			gAudio.Alarm.iMicClipCnt = AUDIO_FRSZ48*2;

		gAudio.Alarm.iMicClipFrames ++;
		if (gAudio.Alarm.iMicClipFrames > 10)
			gAudio.Alarm.iMicClipFrames = 10;
	}
	else
	{
		gAudio.Alarm.iMicClipCnt --;
		gAudio.Alarm.iMicClipFrames = 0;
	}

	if ((gAudio.Alarm.iMicClipCnt > AUDIO_FRSZ48) && 
		(gAudio.Alarm.iMicClipFrames >= 5))
	{
		gAudio.Alarm.uAlarm |= AUDIO_IF_ALARM_MIC_OVERFLOWN;
	}
	else if (gAudio.Alarm.iMicClipFrames > 2)
	{
		gAudio.Alarm.uAlarm |= AUDIO_IF_ALARM_MIC_SATURATED;
	}
	else if (iSaturationCnt > 0)
	{
		gAudio.Alarm.uAlarm |= AUDIO_IF_ALARM_MIC_CLIPPING;
	}


//	audio_recs48(AUDIO_IF_REC_MIC, 0, pMicData);
	audio_utl_short2float(afData48, pMicData, AUDIO_FRSZ48);

	audio_utl_48to32(gAudio.af48to32Sav, gAudio.afSnd, afData48);

	audio_recf32(AUDIO_IF_REC_MIC_FLT, 0, gAudio.afSnd);
}
/*****************************************************************************/
static void					audio_spk_postprocess
/*****************************************************************************/
(
)
{
	float afData48[AUDIO_FRSZ48];

	audio_recf32(AUDIO_IF_REC_SPK, 0, gAudio.afRcv);
	audio_utl_32to48(gAudio.af32to48Sav, afData48, gAudio.afRcv);
	audio_utl_float2short(gAudio.asSpk48, afData48, AUDIO_FRSZ48);
}
/*****************************************************************************/
static void				audio_check_delimeters
/*****************************************************************************/
(
char *pc
)
{
	if (gAudio.dwSD != AUDIO_SD) 
	{
		audio_log_err("audio_process -- SD %s", pc);
		gAudio.dwSD = AUDIO_SD;
	}
	if (gAudio.dwED != AUDIO_ED) 
	{
		audio_log_err("audio_process -- ED %s", pc);
		gAudio.dwED = AUDIO_ED;
	}
	if (gAudio.dwDD0 != AUDIO_DD) 
	{
		audio_log_err("audio_process -- DD0 %s", pc);
		gAudio.dwDD0 = AUDIO_DD;
	}
	if (gAudio.dwDD1 != AUDIO_DD) 
	{
		audio_log_err("audio_process -- DD1 %s", pc);
		gAudio.dwDD1 = AUDIO_DD;
	}
	if (gAudio.dwDD2 != AUDIO_DD) 
	{
		audio_log_err("audio_process -- DD2 %s", pc);
		gAudio.dwDD2 = AUDIO_DD;
	}
	if (gAudio.dwDD3 != AUDIO_DD) 
	{
		audio_log_err("audio_process -- DD3 %s", pc);
		gAudio.dwDD3 = AUDIO_DD;
	}
	if (gAudio.dwDD4 != AUDIO_DD) 
	{
		audio_log_err("audio_process -- DD4 %s", pc);
		gAudio.dwDD4 = AUDIO_DD;
	}
}
/*****************************************************************************/
void					audio_check
/*****************************************************************************/
(
)
{
	if ((gAudio.Drv.iFrameNo & 0xfff) == 0)
	{
		AudioIf_test_gen(AUDIO_IF_TEST_GEN_MODE_1000HZ);
	}
	if ((gAudio.Drv.iFrameNo & 0xfff) == 0x005)
	{
		AudioIf_test_gen();
	}
}
/*****************************************************************************/
short *					audio_process
/*****************************************************************************/
(
short *pMicData
)
{
	audio_lock();
	audio_check_delimeters("in");

	gAudio.Alarm.uAlarm = 0;

	audio_tmr_start(AUDIO_TMR_NETRCV);
	audio_jb_netq_poll();
	audio_jb_mux();
	audio_tmr_stop (AUDIO_TMR_NETRCV);

	gAudio.Nrg.fNetRcv = audio_utl_pktnrg(gAudio.afRcv, AUDIO_FRSZ32);

	audio_test_gen_rcv();
	audio_volume();
	gAudio.Nrg.fVol = audio_utl_pktnrg(gAudio.afRcv, AUDIO_FRSZ32);

	audio_mic_preprocess(pMicData);
	gAudio.Nrg.fMic = audio_utl_pktnrg(gAudio.afSnd, AUDIO_FRSZ32);

	audio_aec();

	gAudio.Nrg.fSpk = audio_utl_pktnrg(gAudio.afRcv, AUDIO_FRSZ32);
	gAudio.Nrg.fAec = audio_utl_pktnrg(gAudio.afSnd, AUDIO_FRSZ32);
	audio_recf8 (AUDIO_IF_REC_CNL, 0, gAudio.Aec.AecLL.afCnl);
	audio_recf8 (AUDIO_IF_REC_NLP, 0, gAudio.Aec.AecLL.afNlp);
	audio_recf32(AUDIO_IF_REC_NRD, 0, gAudio.afSnd);
	audio_spk_postprocess();

	if (gAudio.Nrg.fMicS < gAudio.Nrg.fAec)
		gAudio.Nrg.fMicS = gAudio.Nrg.fAec + 80.0F;
	else
		gAudio.Nrg.fMicS += (gAudio.Nrg.fAec + 80.0F - gAudio.Nrg.fMicS) *0.95F;
	if (gAudio.Nrg.fMicS < 0.F)
		gAudio.Nrg.fMicS = 0.F;
	if (gAudio.Nrg.fMicS > 86.F)
		gAudio.Nrg.fMicS = 86.F;

	audio_agc(&gAudio.Agc, gAudio.afSnd);
	gAudio.Alarm.uAlarm |= gAudio.Agc.uAlarm;

	audio_recf32(AUDIO_IF_REC_AGC, 0, gAudio.afSnd);
	gAudio.Nrg.fAgc = audio_utl_pktnrg(gAudio.afSnd, AUDIO_FRSZ32);

	audio_test_gen_snd();

	gAudio.Nrg.fNetSnd = audio_utl_pktnrg(gAudio.afSnd, AUDIO_FRSZ32);


	audio_tmr_start(AUDIO_TMR_NETSND);
	audio_net_snd();
	audio_tmr_stop (AUDIO_TMR_NETSND);


	if (gAudio.Alarm.iAlarmSoundCnt >= 60)
		gAudio.Alarm.uAlarm |= AUDIO_IF_ALARM_NO_SOUND;
	else if (gAudio.Alarm.fAlarmSoundCrit >= AUDIO_CRIT_MAX-AUDIO_CRIT_THR)
		gAudio.Alarm.uAlarm |= AUDIO_IF_ALARM_BAD_SOUND;
	else if (gAudio.Alarm.fAlarmSoundCrit > AUDIO_CRIT_THR)
		gAudio.Alarm.uAlarm |= AUDIO_IF_ALARM_POOR_SOUND;

	audio_check_delimeters("out");

	audio_unlock();
	return gAudio.asSpk48;
}
/*****************************************************************************/
void					audio_resync
/*****************************************************************************/
(
bool bOutOfSync
)
{
	if (bOutOfSync)
	{
		gAudio.Alarm.fAlarmSoundCrit += AUDIO_CRIT_MAX/3;
		if (gAudio.Alarm.fAlarmSoundCrit > AUDIO_CRIT_MAX)
		{
			gAudio.Alarm.fAlarmSoundCrit = AUDIO_CRIT_MAX;
			gAudio.Alarm.iAlarmSoundCnt += 20;
			if (gAudio.Alarm.iAlarmSoundCnt > 60)
				gAudio.Alarm.iAlarmSoundCnt = 60;
		}
	}
	else
	{
		gAudio.Alarm.fAlarmSoundCrit -= AUDIO_CRIT_MAX*(0.02F/3); // keeps for a sec
		if (gAudio.Alarm.fAlarmSoundCrit < 0)
			gAudio.Alarm.fAlarmSoundCrit = 0;

		gAudio.Alarm.iAlarmSoundCnt --;
		if (gAudio.Alarm.iAlarmSoundCnt < 0)
			gAudio.Alarm.iAlarmSoundCnt = 0;
	}
}
/*****************************************************************************/
void					audio_delay_added
/*****************************************************************************/
(
)
{
	// does not happen too often. just reset AEC
	GAEC_tCtrl     Ctrl = {0};
	Ctrl.uCmd = 0
                | GAEC_CMD_RESET
				;
    Ctrl.uCmdMask = Ctrl.uCmd;

    GAEC_control	(&gAudio.Aec.AecLL, &Ctrl);
	gaec_hp_control	(&gAudio.Aec.HpLH, &Ctrl);
}
/*****************************************************************************/
void					audio_lock
/*****************************************************************************/
(
)
{
	 EnterCriticalSection(&gAudio.Lock);
}
/*****************************************************************************/
void					audio_unlock
/*****************************************************************************/
(
)
{
	 LeaveCriticalSection(&gAudio.Lock);
}

/*****************************************************************************/
DWORD				AudioIf_volume
/*****************************************************************************/
(
float fVolumeDb
)
{
	if (!gAudio.bInitialized) return AUDIO_IF_ERR_NOT_INITIALIZED;

	DWORD rc = AUDIO_IF_ERR_NONE;
	audio_lock();

	audio_log_inf("AudioIf_volume -- gain=%f", fVolumeDb);

	if (fVolumeDb > 12.F)
	{
		audio_log_war("AudioIf_volume -- gain capped to +12 dB");
		rc |= AUDIO_IF_ERR_WARNING;
		fVolumeDb = 12.F;
	}
	gAudio.fVolumeDb = fVolumeDb;

	GAEC_tCtrl Ctrl = {0};
	Ctrl.uCmd = Ctrl.uCmdMask = GAEC_CMD_VOLUME;
	Ctrl.fVolumeDb = fVolumeDb;
	GAEC_control(&gAudio.Aec.AecLL, &Ctrl);
	gaec_hp_control(&gAudio.Aec.HpLH, &Ctrl);

	if (rc)
		audio_log_err("AudioIf_volume -- rc=0x%08x", rc);
	else
		audio_log_inf("AudioIf_volume -- done");

	audio_unlock();
	return rc;
}
/*****************************************************************************/
DWORD				AudioIf_volume
/*****************************************************************************/
(
float *pfVolumeDb
)
{
	if (!gAudio.bInitialized) return AUDIO_IF_ERR_NOT_INITIALIZED;

	DWORD rc = AUDIO_IF_ERR_NONE;
	audio_lock();

	audio_log_inf("AudioIf_volume get -- pgain=%p", pfVolumeDb);

	if (pfVolumeDb)
		*pfVolumeDb = gAudio.fVolumeDb;
	else
		rc = AUDIO_IF_ERR_INVALID_PARAM;

	if (rc)
		audio_log_err("AudioIf_volume get -- rc=0x%08x", rc);
	else
		audio_log_inf("AudioIf_volume get -- done");

	audio_unlock();
	return rc;
}

/*****************************************************************************/
DWORD				AudioIf_mic_mute
/*****************************************************************************/
(
const bool bMicMuted
)
{
	if (!gAudio.bInitialized) return AUDIO_IF_ERR_NOT_INITIALIZED;

	DWORD rc = AUDIO_IF_ERR_NONE;
	audio_lock();

	audio_log_inf("AudioIf_mic_mute -- On=%d", bMicMuted);

	gAudio.bMicMuted = bMicMuted;

	GAEC_tCtrl Ctrl = {0};
	Ctrl.uCmdMask = GAEC_CMD_SND_MUTED;
	Ctrl.uCmd = (bMicMuted) ? GAEC_CMD_SND_MUTED: 0;

	GAEC_control(&gAudio.Aec.AecLL, &Ctrl);
	gaec_hp_control(&gAudio.Aec.HpLH, &Ctrl);

	audio_log_inf("AudioIf_mic_mute -- done");

	audio_unlock();
	return rc;
}
/*****************************************************************************/
DWORD				AudioIf_mic_mute
/*****************************************************************************/
(
bool *pbMicMuted
)
{
	if (!gAudio.bInitialized) return AUDIO_IF_ERR_NOT_INITIALIZED;

	DWORD rc = AUDIO_IF_ERR_NONE;
	audio_lock();

	audio_log_inf("AudioIf_mic_mute get -- pOn=%p", pbMicMuted);

	if (pbMicMuted)
		*pbMicMuted = gAudio.bMicMuted;
	else
		rc = AUDIO_IF_ERR_INVALID_PARAM;

	if (rc)
		audio_log_err("AudioIf_mic_mute get -- rc=0x%08x", rc);
	else
		audio_log_inf("AudioIf_mic_mute get -- done");

	audio_unlock();
	return rc;
}
/*****************************************************************************/
DWORD				AudioIf_mic_level
/*****************************************************************************/
(
float *pfNrgDBFS		//  smoothed energy in dB Full Scale
)
{
	if (!gAudio.bInitialized) return AUDIO_IF_ERR_NOT_INITIALIZED;

	DWORD rc = AUDIO_IF_ERR_NONE;
	audio_lock();

	audio_log_trc("AudioIf_mic_level -- dwSrcId=x%x pfNrgDBFS=%p", 
					pfNrgDBFS);

	if (pfNrgDBFS)
	{
		*pfNrgDBFS = gAudio.Nrg.fMicS - 86.F;
		audio_log_trc("-- %7.2f dB FS", gAudio.Nrg.fMicS-86.F);
	}
	else
	{
		rc |= AUDIO_IF_ERR_INVALID_PARAM;
	}

	if (rc)
		audio_log_err("AudioIf_mic_level -- rc=0x%08x", rc);
	else
		audio_log_trc("AudioIf_mic_level -- done");

	audio_unlock();
	return rc;
}


/*****************************************************************************/
DWORD					AudioIf_aec
/*****************************************************************************/
(
const bool bOn, 
const AudioIf_tAecCfg *pCfg
)
{
	if (!gAudio.bInitialized) return AUDIO_IF_ERR_NOT_INITIALIZED;

	DWORD rc = AUDIO_IF_ERR_NONE;
	GAEC_tCtrl Ctrl = {0};
	GAEC_tCfg Cfg = gAudio.Aec.AecLL.Db.Cfg; // all the default values

	audio_lock();

	audio_log_inf("AudioIf_aec -- on/off=%d pCfg=%p", bOn, pCfg);

	gAudio.Aec.bOn = bOn;

	Ctrl.uCmdMask = GAEC_CMD_ALL_OFF;
	if (!bOn)
	{
		Ctrl.uCmd = GAEC_CMD_ALL_OFF | GAEC_CMD_RESET;
	}

	if (pCfg)
	{
		Cfg.fTCLdt = pCfg->fTCLdtDB;
		Cfg.fTCLst = pCfg->fTCLstDB;
		Cfg.fErlMin = pCfg->fWorstErlDB;
		Cfg.fRcvDistThr = pCfg->fSpkNonLinear1PercentDBFS;

		switch(pCfg->iAecMode)
		{
		case AUDIO_IF_AEC_MODE_LQ: 
			Cfg.iAdfSections = 4; 
			break;
		case AUDIO_IF_AEC_MODE_HQ: 
			Cfg.iAdfSections = 18; 
			break;
		case AUDIO_IF_AEC_MODE_MQ: 
		default:
			Cfg.iAdfSections = 10; 
			break;
		}
		Ctrl.uCmd |= GAEC_CMD_CFG;
		Ctrl.uCmdMask |= GAEC_CMD_CFG;
		Ctrl.pCfg = &Cfg;

//		audio_log_inf("AudioIf_aec -- %d sections", Ctrl.pCfg->iAdfSections);
	}

	GAEC_control(&gAudio.Aec.AecLL, &Ctrl);
	if (Ctrl.pCfg)
	{
		audio_log_inf("AudioIf_aec -- %d sections", Ctrl.pCfg->iAdfSections);
		Ctrl.pCfg->iAdfSections >>= 1;
	}
	gaec_hp_control(&gAudio.Aec.HpLH, &Ctrl);

	audio_log_inf("AudioIf_aec -- done");
	audio_unlock();
	return rc;
}
/*****************************************************************************/
DWORD					AudioIf_aec
/*****************************************************************************/
(
bool *pbOn, 
AudioIf_tAecCfg *pCfg
)
{
	if (!gAudio.bInitialized) return AUDIO_IF_ERR_NOT_INITIALIZED;

	DWORD rc = AUDIO_IF_ERR_NONE;
	audio_lock();

	audio_log_inf("AudioIf_aec get -- pbOn=%p pCfg=%p", 
				pbOn, pCfg);

	if (pbOn)
		*pbOn = gAudio.Aec.bOn;

	if (pCfg)
	{
		GAEC_tCfg *pDbCfg = &gAudio.Aec.AecLL.Db.Cfg;
		pCfg->fTCLdtDB = pDbCfg->fTCLdt;
		pCfg->fTCLstDB = pDbCfg->fTCLst;
		pCfg->fWorstErlDB = pDbCfg->fErlMin;
		pCfg->fSpkNonLinear1PercentDBFS = pDbCfg->fRcvDistThr;

		audio_log_inf("AudioIf_aec get -- %d sections",pDbCfg->iAdfSections);

		pCfg->iAecMode = AUDIO_IF_AEC_MODE_MQ;
		if (pDbCfg->iAdfSections > 10)
			pCfg->iAecMode = AUDIO_IF_AEC_MODE_HQ;
		if (pDbCfg->iAdfSections < 10)
			pCfg->iAecMode = AUDIO_IF_AEC_MODE_LQ;
	}

	audio_log_inf("AudioIf_aec get -- done");
	audio_unlock();
	return rc;
}
/*****************************************************************************/
DWORD					AudioIf_denoiser
/*****************************************************************************/
(
const bool bOn, 
const float fStrength
)
{
	if (!gAudio.bInitialized) return AUDIO_IF_ERR_NOT_INITIALIZED;

	DWORD rc = AUDIO_IF_ERR_NONE;
	GAEC_tCtrl Ctrl = {0};
	audio_lock();

	audio_log_inf("AudioIf_denoiser -- on/off=%d strength=%f", 
				bOn, fStrength);

	Ctrl.uCmdMask = GAEC_CMD_NSE_RED_OFF;
	Ctrl.uCmd = (bOn) ? 0: GAEC_CMD_ALL_OFF;

	GAEC_control(&gAudio.Aec.AecLL, &Ctrl);
	gaec_hp_control(&gAudio.Aec.HpLH, &Ctrl);

	audio_log_inf("AudioIf_denoiser -- done");
	audio_unlock();
	return rc;
}
/*****************************************************************************/
DWORD					AudioIf_denoiser
/*****************************************************************************/
(
bool *pbOn, 
float *pfStrength
)
{
	if (!gAudio.bInitialized) return AUDIO_IF_ERR_NOT_INITIALIZED;

	DWORD rc = AUDIO_IF_ERR_NONE;
	audio_lock();

	audio_log_inf("AudioIf_denoiser get -- pbOn=%p pfStrength=%p", 
				pbOn, pfStrength);

	if (pbOn)
		*pbOn = (gAudio.Aec.AecLL.Db.uControl & GAEC_CMD_NSE_RED_OFF) ? false:true;

	if (pfStrength)
		*pfStrength = 1.0F;

	audio_log_inf("AudioIf_denoiser get -- done");
	audio_unlock();
	return rc;
}
/*****************************************************************************/
DWORD					AudioIf_cpu_stts_get
/*****************************************************************************/
(
AudioIf_tCpuStts *pStts
)
{
	if (!gAudio.bInitialized) return AUDIO_IF_ERR_NOT_INITIALIZED;

	DWORD rc = AUDIO_IF_ERR_NONE;
	audio_lock();

	audio_log_inf("AudioIf_cpu_stts_get -- pStts=%p", pStts);

	if (pStts)
	{
		audio_utl_thread_stts(
			gAudio.Dbg.hThread, 
			&gAudio.CpuStts.fDbgThreadKernelModePercentage,
			&gAudio.CpuStts.fDbgThreadUserModePercentage);
		
		audio_utl_thread_stts(
			gAudio.Drv.hThread, 
			&gAudio.CpuStts.fDrvThreadKernelModePercentage,
			&gAudio.CpuStts.fDrvThreadUserModePercentage);

		audio_hstgm_analyse(&gAudio.TmrCtrl.aTmr[AUDIO_TMR_DEC].Hstgm);
		gAudio.CpuStts.Decoding = gAudio.TmrCtrl.aTmr[AUDIO_TMR_DEC].Hstgm;

		audio_hstgm_analyse(&gAudio.TmrCtrl.aTmr[AUDIO_TMR_ENC].Hstgm);
		gAudio.CpuStts.Encoding = gAudio.TmrCtrl.aTmr[AUDIO_TMR_ENC].Hstgm;

		audio_hstgm_analyse(&gAudio.TmrCtrl.aTmr[AUDIO_TMR_AEC].Hstgm);
		gAudio.CpuStts.Aec = gAudio.TmrCtrl.aTmr[AUDIO_TMR_AEC].Hstgm;

		audio_hstgm_analyse(&gAudio.TmrCtrl.aTmr[AUDIO_TMR_PROCESS].Hstgm);
		gAudio.CpuStts.SignalProcessingTotal = gAudio.TmrCtrl.aTmr[AUDIO_TMR_PROCESS].Hstgm;

		audio_log_inf("dbg kernel=%7.2f%% user=%7.2f%%", 
			gAudio.CpuStts.fDbgThreadKernelModePercentage,
			gAudio.CpuStts.fDbgThreadUserModePercentage);

		audio_log_inf("drv kernel=%7.2f%% user=%7.2f%%", 
			gAudio.CpuStts.fDrvThreadKernelModePercentage,
			gAudio.CpuStts.fDrvThreadUserModePercentage);

		int k = AUDIO_TMR_PROCESS;
		audio_log_inf("PROCESS (ms) Avrg=%7.3f Min=%7.3f Max=%7.3f Called=%d",
				gAudio.TmrCtrl.aTmr[k].Hstgm.fAvrg,
				gAudio.TmrCtrl.aTmr[k].Hstgm.fMin,
				gAudio.TmrCtrl.aTmr[k].Hstgm.fMax,
				gAudio.TmrCtrl.aTmr[k].Hstgm.iTotal);

		k = AUDIO_TMR_AEC;
		audio_log_inf("AEC     (ms) Avrg=%7.3f Min=%7.3f Max=%7.3f Called=%d",
				gAudio.TmrCtrl.aTmr[k].Hstgm.fAvrg,
				gAudio.TmrCtrl.aTmr[k].Hstgm.fMin,
				gAudio.TmrCtrl.aTmr[k].Hstgm.fMax,
				gAudio.TmrCtrl.aTmr[k].Hstgm.iTotal);

		k = AUDIO_TMR_ENC;
		audio_log_inf("ENCODER (ms) Avrg=%7.3f Min=%7.3f Max=%7.3f Called=%d",
				gAudio.TmrCtrl.aTmr[k].Hstgm.fAvrg,
				gAudio.TmrCtrl.aTmr[k].Hstgm.fMin,
				gAudio.TmrCtrl.aTmr[k].Hstgm.fMax,
				gAudio.TmrCtrl.aTmr[k].Hstgm.iTotal);

		k = AUDIO_TMR_DEC;
		audio_log_inf("DECODER (ms) Avrg=%7.3f Min=%7.3f Max=%7.3f Called=%d",
				gAudio.TmrCtrl.aTmr[k].Hstgm.fAvrg,
				gAudio.TmrCtrl.aTmr[k].Hstgm.fMin,
				gAudio.TmrCtrl.aTmr[k].Hstgm.fMax,
				gAudio.TmrCtrl.aTmr[k].Hstgm.iTotal);
	}
	else
	{
		rc |= AUDIO_IF_ERR_INVALID_PARAM;
	}

	if (rc)
		audio_log_err("AudioIf_cpu_stts_get -- rc=0x%08x", rc);
	else
		audio_log_inf("AudioIf_cpu_stts_get -- done");

	audio_unlock();
	return rc;
}