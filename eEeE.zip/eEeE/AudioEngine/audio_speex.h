#ifndef _AUDIO_SPEEX_H_
#define _AUDIO_SPEEX_H_

#include <speex/speex.h>

typedef struct {
	void *				pState;
	SpeexBits			Bits;
	WORD				wMode;
	int					iLostCnt;
} Audio_tSpeex;

/*****************************************************************************/

DWORD audio_speex_decoder_init
	(
	void *pDec,
	WORD wMode
	);
DWORD audio_speex_encoder_init
	(
	void *pEnc,
	WORD wMode
	);
int audio_speex_decode
	(
	void *pDec,
	short *psOut,
	BYTE *pcIn, // can be NULL
	int  iSz
	);
int	audio_speex_encode
	(
	void *pEnc,
	BYTE *pcOut,
	short *psIn
	);
void audio_speex_decoder_delete
	(
	void *pDec
	);
void audio_speex_encoder_delete
	(
	void *pDec
	);

#endif //_AUDIO_SPEEX_H_