//**@@@*@@@****************************************************
//
// Microsoft Windows
// Copyright (C) Microsoft Corporation. All rights reserved.
//
//**@@@*@@@****************************************************

//
// FileName:    pin.cpp
//
// Abstract:
//      This is the implementation file for C++ classes that expose
//      functionality of KS pin objects
//

#include "audks_common.h"

typedef
KSDDKAPI
DWORD
WINAPI
KSCREATEPIN(
    IN HANDLE FilterHandle,
    IN PKSPIN_CONNECT Connect,
    IN ACCESS_MASK DesiredAccess,
    OUT PHANDLE ConnectionHandle
    ) ;

class CKSUSER
{
public:
    HMODULE         hmodKsuser;
    KSCREATEPIN*    DllKsCreatePin;

    CKSUSER(void)
    {
        hmodKsuser = NULL;
        DllKsCreatePin = NULL;
    }

    DWORD KsCreatePin
    (
        IN HANDLE           FilterHandle,
        IN PKSPIN_CONNECT   Connect,
        IN ACCESS_MASK      DesiredAccess,
        OUT PHANDLE         ConnectionHandle
    )
    {
        if (NULL == DllKsCreatePin)
        {
            if (NULL == hmodKsuser)
            {
                hmodKsuser = LoadLibrary(TEXT("ksuser.dll"));
                if (NULL == hmodKsuser) {
                    return ERROR_FILE_NOT_FOUND;
                }
            }

            DllKsCreatePin = (KSCREATEPIN*)GetProcAddress(hmodKsuser, "KsCreatePin");
            if (NULL == DllKsCreatePin) {
                return ERROR_FILE_NOT_FOUND;
            }
        }
        
        return DllKsCreatePin(FilterHandle,
                            Connect,
                            DesiredAccess,
                            ConnectionHandle);
    }
};

static CKSUSER  KSUSER;


// ============================================================================
//
//   CKsPin
//
//=============================================================================



////////////////////////////////////////////////////////////////////////////////
//
//  CKsPin::CKsPin()
//
//  Routine Description:
//      Copy constructor for CKsPin
//
//  Arguments:
//      A parent filter,
//      A Pin to copy from,
//      An HRESULT to indicate success or failure
//
//
//  Return Value:
//
//     S_OK on success
//


CKsPin::CKsPin(
    IN  CKsFilter*    pFilter,
    IN  ULONG           PinId,
    OUT HRESULT*        phr)
    : CKsIrpTarget(INVALID_HANDLE_VALUE),
    m_pFilter(pFilter),
    m_nId(PinId),
    m_pLinkPin(NULL),
    m_ksState(KSSTATE_STOP),
    m_pksPinCreate(NULL),
    m_cbPinCreateSize(0),
    m_guidCategory(GUID_NULL)
{
    AUDKS_TRACE_ENTER();
    HRESULT hr = S_OK;

    // non-atomic initializations
    ZeroMemory(&m_Descriptor, sizeof m_Descriptor);
    ZeroMemory(m_szFriendlyName, sizeof m_szFriendlyName);

    //Initialize
    if (SUCCEEDED(hr))
    {
        hr = CKsPin::Init();
    }

     AUDKS_TRACE_LEAVE_HRESULT(hr);
    *phr = hr;
    return;
}

////////////////////////////////////////////////////////////////////////////////
//
//  CKsPin::~CKsPin()
//
//  Routine Description:
//      Destructor
//
//  Arguments:
//      None
//
//
//  Return Value:
//      None
//


CKsPin::~CKsPin()
{
    AUDKS_TRACE_ENTER();
    HRESULT hr = S_OK;

    ClosePin();

    // Need to cast to BYTE *, because that's how CKsAudRenPin::CKsAudRenPin
    // and CKsAudRenPin::SetFormat allocate the memory
    delete[] (BYTE *)m_pksPinCreate;

    // Need to cast to BYTE *, because that's how CKsFilter::GetPinPropertyMulti allocates the memory
    delete[] (BYTE *)m_Descriptor.pmiDataRanges;
    delete[] (BYTE *)m_Descriptor.pmiInterfaces;
    delete[] (BYTE *)m_Descriptor.pmiMediums;


	// commented out -- causes a crash after 2 calls
	//	FreeLibrary(KSUSER.hmodKsuser);

    AUDKS_TRACE_LEAVE();
    return;
}


////////////////////////////////////////////////////////////////////////////////
//
//  CKsPin::ClosePin()
//
//  Routine Description:
//      Closes the pin
//
//  Arguments:
//      None
//
//
//  Return Value:
//
//     S_OK on success
//


void CKsPin::ClosePin(void)
{
    AUDKS_TRACE_ENTER();

    if (IsValidHandle(m_handle))
    {
        SetState(KSSTATE_STOP);

        SafeCloseHandle(m_handle);
    }

    AUDKS_TRACE_LEAVE();
    return;
}

////////////////////////////////////////////////////////////////////////////////
//
//  CKsPin::SetState()
//
//  Routine Description:
//      SetState
//
//  Arguments:
//      SetState
//
//
//  Return Value:
//
//     S_OK on success
//


HRESULT CKsPin::SetState(
    IN  KSSTATE ksState)
{
    AUDKS_TRACE_ENTER();
    HRESULT hr = S_OK;

    hr = SetPropertySimple(
            KSPROPSETID_Connection,
            KSPROPERTY_CONNECTION_STATE,
            &ksState,
            sizeof (ksState));

    if (SUCCEEDED(hr))
    {
        m_ksState = ksState;
    }

    if (FAILED(hr))
    {
        audio_log_err("CKsPin::SetState -- Failed to Set Pin State");
    }

    AUDKS_TRACE_LEAVE_HRESULT(hr);
    return hr;
}

////////////////////////////////////////////////////////////////////////////////
//
//  CKsPin::Instantiate()
//
//  Routine Description:
//      Instantiate
//
//  Arguments:
//      fLooped
//
//
//  Return Value:
//
//     S_OK on success
//


HRESULT CKsPin::Instantiate()
{
    AUDKS_TRACE_ENTER();
    HRESULT hr = S_OK;
    DWORD dwResult = 0;

    if (!m_pksPinCreate)
//        return FALSE;
		return E_FAIL;

    if (m_pLinkPin)
    {
        assert( KSPIN_COMMUNICATION_SINK == m_pLinkPin->m_Descriptor.Communication ||
            KSPIN_COMMUNICATION_BOTH == m_pLinkPin->m_Descriptor.Communication);

        m_pksPinCreate->PinToHandle = m_pLinkPin->m_handle;
    }

//    m_pksPinCreate->Interface.Id = KSINTERFACE_STANDARD_STREAMING;


    dwResult = KSUSER.KsCreatePin(
        m_pFilter->m_handle,
        m_pksPinCreate,
        GENERIC_WRITE | GENERIC_READ,
        &m_handle
        );

    if (ERROR_SUCCESS != dwResult)
    {
         hr = HRESULT_FROM_WIN32(dwResult);
         if (SUCCEEDED(hr))
         {
                // Sometimes the error codes don't map to error HRESULTs.
                hr = E_FAIL;
         }
    }

    if (FAILED(hr))
    {
        audio_log_err("CKsPin::Instantiate -- Failed. hr=0x%08x", hr);
    }

    AUDKS_TRACE_LEAVE_HRESULT(hr);
    return hr;
}

#if 0
////////////////////////////////////////////////////////////////////////////////
//
//  CKsPin::GetState()
//
//  Routine Description:
//      Gets the KSSTATE of Pin
//
//  Arguments:
//      PKSSTATE pksState -- State is returned here
//
//
//  Return Value:
//
//     S_OK on success
//


HRESULT CKsPin::GetState(
    KSSTATE* pksState)
{
    AUDKS_TRACE_ENTER();
    HRESULT hr = S_OK;


    if (NULL == pksState)
    {
        hr = E_INVALIDARG;
        audio_log_err("pksState == NULL");
    }
    else if (!IsValidHandle(m_handle))
    {
        hr = E_FAIL;
        audio_log_err("No valid pin handle");
    }

    if (SUCCEEDED(hr))
    {
        hr = GetPropertySimple(
            KSPROPSETID_Connection,
            KSPROPERTY_CONNECTION_STATE,
            pksState,
            sizeof(pksState));
    }

    AUDKS_TRACE_LEAVE_HRESULT(hr);
    return hr;
}
////////////////////////////////////////////////////////////////////////////////
//
//  CKsPin::Reset()
//
//  Routine Description:
//      Reset the pin
//
//  Arguments:
//      None
//
//
//  Return Value:
//
//     S_OK on success
//


HRESULT CKsPin::Reset(void)
{
    AUDKS_TRACE_ENTER();
    HRESULT hr = S_OK;
    ULONG   ulIn=0;
    ULONG   ulBytesReturned = 0;

    ulIn = KSRESET_BEGIN;

    hr = SyncIoctl(
        m_handle,
        IOCTL_KS_RESET_STATE,
        &ulIn,
        sizeof(ULONG),
        NULL,
        0,
        &ulBytesReturned);

    if (FAILED(hr))
    {
        audio_log_err("IOCTL_KS_RESET_STATE failed");
    }

    ulIn = KSRESET_END;
    hr = SyncIoctl(
        m_handle,
        IOCTL_KS_RESET_STATE,
        &ulIn,
        sizeof(ULONG),
        NULL,
        0,
        &ulBytesReturned);

    if (FAILED(hr))
    {
        audio_log_err("IOCTL_KS_RESET_STATE failed");
    }

    AUDKS_TRACE_LEAVE_HRESULT(hr);
    return hr;
}
#endif

////////////////////////////////////////////////////////////////////////////////
//
//  CKsPin::WriteData()
//
//  Routine Description:
//      Submit some data to the pin, using the provided KSSTREAM_HEADER and OVERLAPPED structures.
//      If the caller submits a valid event in the KSSTREAM_HEADER, the event must be unsignaled.
//
//  Arguments:
//      Pointer to the KSSTREAM_HEADER structure describing the data to send to the pin
//      Pointer to the OVERLAPPED structure to use when doing the asynchronous I/O
//
//  Return Value:
//
//     S_OK on success
//


HRESULT CKsPin::WriteData(
    KSSTREAM_HEADER *pKSSTREAM_HEADER,
    OVERLAPPED *pOVERLAPPED)
{
    AUDKS_TRACE_ENTER();
    HRESULT hr = S_OK;
    DWORD cbReturned = 0;

    // submit the data
    BOOL fRes = DeviceIoControl(
        m_handle,
        IOCTL_KS_WRITE_STREAM,
        NULL,
        0,
        pKSSTREAM_HEADER,
        pKSSTREAM_HEADER->Size,
        &cbReturned,
        pOVERLAPPED);

    // we're paused, we should return false!
    if (fRes) // done OK
    {
        //audks_debug_printf(AUDKS_TRACE_HIGH,TEXT("DeviceIoControl returned TRUE even though the pin is paused"));
    }
    else
    {
        // if it did return FALSE then GetLAstError should return ERROR_IO_PENDING
        DWORD dwError = GetLastError();

        if (ERROR_IO_PENDING == dwError)
        {
            //Life is good
            hr = S_OK;
        }
        else
        {
            hr = E_FAIL;
            audio_log_err("CKsPin::WriteData's DeviceIoControl Failed!  Error=0x%#08x",dwError);
        }
    }

    AUDKS_TRACE_LEAVE_HRESULT(hr);
    return hr;
}

////////////////////////////////////////////////////////////////////////////////
//
//  CKsPin::ReadData()
//
//  Routine Description:
//      Submit some memory for the pin to read into, using the provided KSSTREAM_HEADER and OVERLAPPED structures.
//      If the caller submits a valid event in the KSSTREAM_HEADER, the event must be unsignaled.
//
//  Arguments:
//      Pointer to the KSSTREAM_HEADER structure describing where to store the data read from the pin
//      Pointer to the OVERLAPPED structure to use when doing the asynchronous I/O
//
//  Return Value:
//
//     S_OK on success
//


HRESULT CKsPin::ReadData(
    KSSTREAM_HEADER *pKSSTREAM_HEADER,
    OVERLAPPED *pOVERLAPPED)
{
    AUDKS_TRACE_ENTER();
    HRESULT hr = S_OK;
    DWORD cbReturned = 0;

    BOOL fRes = DeviceIoControl(
        m_handle,
        IOCTL_KS_READ_STREAM,
        NULL,
        0,
        pKSSTREAM_HEADER,
        pKSSTREAM_HEADER->Size,
        &cbReturned,
        pOVERLAPPED);

    // we're paused, we should return false!
    if (fRes)
    {
        //audks_debug_printf(AUDKS_TRACE_HIGH,TEXT("DeviceIoControl returne TRUE even though the pin is paused"));
    }
    else
    {
        // if it did return FALSE then GetLAstError should return ERROR_IO_PENDING
        DWORD dwError = GetLastError();

        if (ERROR_IO_PENDING == dwError)
        {
            //Life is good
            hr = S_OK;
        }
        else
        {
            hr = E_FAIL;
            audio_log_err("DeviceIoControl Failed!  Error=0x%08x",dwError);
        }

    }

    AUDKS_TRACE_LEAVE_HRESULT(hr);
    return hr;
}

////////////////////////////////////////////////////////////////////////////////
//
//  CKsPin::Init()
//
//  Routine Description:
//      Does some basic data structure initialization
//
//  Arguments:
//     None
//
//
//  Return Value:
//
//     S_OK on success
//


HRESULT CKsPin::Init()
{
    AUDKS_TRACE_ENTER();
    HRESULT hr = S_OK;
    BOOL fFailure = FALSE;

    // Get COMMUNICATION
    hr = m_pFilter->GetPinPropertySimple(
        m_nId,
        KSPROPSETID_Pin,
        KSPROPERTY_PIN_COMMUNICATION,
        &m_Descriptor.Communication,
        sizeof(KSPIN_COMMUNICATION));

    if (FAILED(hr))
    {
        audio_log_err("Failed to retrieve pin property KSPROPERTY_PIN_COMMUNICATION on PinID: %d",m_nId);
        fFailure = TRUE;
    }


   //get PKSPIN_INTERFACES
    hr = m_pFilter->GetPinPropertyMulti(
        m_nId,
        KSPROPSETID_Pin,
        KSPROPERTY_PIN_INTERFACES,
        &m_Descriptor.pmiInterfaces);

    if (SUCCEEDED(hr))
    {
        m_Descriptor.cInterfaces = m_Descriptor.pmiInterfaces->Count;
        m_Descriptor.pInterfaces = (PKSPIN_INTERFACE)(m_Descriptor.pmiInterfaces+1);
    }
    else
    {
        audio_log_err("Failed to retrieve pin property KSPROPETY_PIN_INTERFACES on PinID: %d",m_nId);
        fFailure = TRUE;
    }

    // get PKSPIN_MEDIUMS
    hr = m_pFilter->GetPinPropertyMulti(
        m_nId,
        KSPROPSETID_Pin,
        KSPROPERTY_PIN_MEDIUMS,
        &m_Descriptor.pmiMediums);

    if (SUCCEEDED(hr))
    {
        m_Descriptor.cMediums = m_Descriptor.pmiMediums->Count;
        m_Descriptor.pMediums = (PKSPIN_MEDIUM)(m_Descriptor.pmiMediums +1);
    }
    else
    {
        audio_log_err("Failed to retrieve pin property KSPROPERTY_PIN_MEDIUMS on PinID: %d",m_nId);
        fFailure = TRUE;
    }



    // get PKSPIN_DATARANGES
    hr = m_pFilter->GetPinPropertyMulti(
        m_nId,
        KSPROPSETID_Pin,
        KSPROPERTY_PIN_DATARANGES,
        &m_Descriptor.pmiDataRanges);

    if (SUCCEEDED(hr))
    {
        m_Descriptor.cDataRanges = m_Descriptor.pmiDataRanges->Count;
        m_Descriptor.pDataRanges = (PKSDATARANGE)(m_Descriptor.pmiDataRanges +1);
    }
    else
    {
        audio_log_err("Failed to retrieve pin property KSPROPERTY_PIN_DATARANGES on PinID: %d",m_nId);
        fFailure = TRUE;
    }



    //get dataflow information
    hr = m_pFilter->GetPinPropertySimple(
        m_nId,
        KSPROPSETID_Pin,
        KSPROPERTY_PIN_DATAFLOW,
        &m_Descriptor.DataFlow,
        sizeof(KSPIN_DATAFLOW));

    if (FAILED(hr))
    {
        audio_log_err("Failed to retrieve pin property KSPROPERTY_PIN_DATAFLOW on PinID: %d",m_nId);
        fFailure = TRUE;
    }



    //get instance information
    hr = m_pFilter->GetPinPropertySimple(
        m_nId,
        KSPROPSETID_Pin,
        KSPROPERTY_PIN_CINSTANCES,
        &m_Descriptor.CInstances,
        sizeof(KSPIN_CINSTANCES));

    if (FAILED(hr))
    {
        audio_log_err("Failed to retrieve pin property KSPROPERTY_PIN_CINSTANCES on PinID: %d",m_nId);
        fFailure = TRUE;
    }



    // Get Global instance information
    hr = m_pFilter->GetPinPropertySimple(
        m_nId,
        KSPROPSETID_Pin,
        KSPROPERTY_PIN_GLOBALCINSTANCES,
        &m_Descriptor.CInstancesGlobal,
        sizeof(KSPIN_CINSTANCES));

    if (FAILED(hr))
    {
        audio_log_err("Failed to retrieve pin property KSPROPERTY_PIN_GLOBALCINSTANCES on PinID: %d",m_nId);
        fFailure = TRUE;
    }

    // Get Pin Category Information
    hr = m_pFilter->GetPinPropertySimple(
        m_nId,
        KSPROPSETID_Pin,
        KSPROPERTY_PIN_CATEGORY,
        &m_guidCategory,
        sizeof(m_guidCategory));
    if (FAILED(hr))
    {
        audio_log_err("Failed to retrieve pin property KSPROPERTY_PIN_CATEGORY on PinID: %d",m_nId);
        fFailure = TRUE;
    }

    // Get Pin Name
    hr = m_pFilter->GetPinPropertySimple(
        m_nId,
        KSPROPSETID_Pin,
        KSPROPERTY_PIN_NAME,
        &m_szFriendlyName,
        sizeof(m_szFriendlyName)-1);

    if (SUCCEEDED(hr))
    {
        audio_log_inf("CKsPin::Init -- KSPROPERTY_PIN_NAME: %ls",m_szFriendlyName);
    }
    else
    {
        audio_log_inf("CKsPin::Init -- Failed to retrieve pin property KSPROPERTY_PIN_NAME on PinID: %d",m_nId);
        fFailure = TRUE;
    }



    // if we experienced any failures, return S_FALSE, otherwise S_OK
    hr = fFailure ? S_FALSE : S_OK;

    AUDKS_TRACE_LEAVE_HRESULT(hr);
    return hr;
}

////////////////////////////////////////////////////////////////////////////////
//
//  CKsPin::GetId()
//
//  Routine Description:
//      Returns the Pin ID
//
//  Arguments:
//      None
//
//
//  Return Value:
//
//     The Pin ID
//


ULONG CKsPin::GetId()
{
    AUDKS_TRACE_ENTER();
    AUDKS_TRACE_LEAVE();
    return m_nId;
}



