#include "audio_plc.h"

static const float _afRampUp[AUDIO_PLC_RAMP] = {
	0.0250F,    0.0750F,    0.1250F,    0.1750F,    0.2250F,
	0.2750F,    0.3250F,    0.3750F,    0.4250F,    0.4750F,
	0.5250F,    0.5750F,    0.6250F,    0.6750F,    0.7250F,
	0.7750F,    0.8250F,    0.8750F,    0.9250F,    0.9750F
};
static const float _afRampDn[AUDIO_PLC_RAMP] = {
	0.9750F,    0.9250F,    0.8750F,    0.8250F,    0.7750F,
	0.7250F,    0.6750F,    0.6250F,    0.5750F,    0.5250F,
	0.4750F,    0.4250F,    0.3750F,    0.3250F,    0.2750F,
	0.2250F,    0.1750F,    0.1250F,    0.0750F,    0.0250F
};

/* ------------------------------------------------------------------- */
void					audio_plc_reset
/* ------------------------------------------------------------------- */
(
Audio_tPlc *pPlc
)
{
	memset(pPlc, 0, sizeof(*pPlc));
	pPlc->afGain[0] = 1.0F;
	pPlc->iPitch = AUDIO_PLC_MIN;
	pPlc->fPitch = AUDIO_PLC_MIN;
	pPlc->fVadNse = AUDIO_VAD_NSE_MAX;
	pPlc->dwSD = AUDIO_SD;
	pPlc->dwED = AUDIO_ED;
}
/*-------------------------------------------------------------------------*/
void					audio_plc_vad
/*-------------------------------------------------------------------------*/
(
Audio_tPlc *pPlc,
float *pfIO
)
{
	float fNrg = audio_utl_pktnrg(pfIO, AUDIO_FRSZ8);

	float fCoef = 1.F / (1.F + (7.F/50.F) * pPlc->iVadCnt);


    // ignore total silence - mute
    if (fNrg > AUDIO_VAD_NSE_MIN)
    {
        float fDlt = fNrg - pPlc->fVadNse;

        pPlc->fVadCrit += (fDlt + AUDIO_CRIT_MIN);

        if (pPlc->fVadCrit > AUDIO_CRIT_MAX)
            pPlc->fVadCrit = AUDIO_CRIT_MAX;
        if (pPlc->fVadCrit < AUDIO_CRIT_MIN)
            pPlc->fVadCrit = AUDIO_CRIT_MIN;
    
        if (pPlc->fVadCrit < 0)
        {
            pPlc->fVadNse += fDlt * (1.F/4.F) * fCoef;

            if (pPlc->fVadNse > AUDIO_VAD_NSE_MAX)
                pPlc->fVadNse = AUDIO_VAD_NSE_MAX;
            if (pPlc->fVadNse < AUDIO_VAD_NSE_MIN)
                pPlc->fVadNse = AUDIO_VAD_NSE_MIN;
        }
        else
        {
            if (fNrg < AUDIO_VAD_NSE_MAX)
            {
                pPlc->fVadNse += (1.F/16.F) * fCoef;
            }
        }
    } 
    else // nse too low
    {
        pPlc->fVadCrit -= AUDIO_CRIT_THR;
        if (pPlc->fVadCrit < AUDIO_CRIT_MIN)
            pPlc->fVadCrit = AUDIO_CRIT_MIN;
    }

	pPlc->iVadCnt++;
	if (pPlc->iVadCnt > 50)
		pPlc->iVadCnt = 50;
}

/* ------------------------------------------------------------------- */
void					audio_plc_pda
/* ------------------------------------------------------------------- */
(
Audio_tPlc *pPlc
)
{
	int ip;
	for (ip = AUDIO_PLC_MIN; ip < AUDIO_PLC_MAX; ip++)
	{
		float ac1 = AUDIO_EPS;
		float ac2 = AUDIO_EPS;
		float acx = 0;
		int i1 = AUDIO_PLC_SSZ - 3 - ip*2;
		int i2 = AUDIO_PLC_SSZ - 3 - ip;
		float *pf1 = &pPlc->afSaf[i1];
		float *pf2 = &pPlc->afSaf[i2];

		for (int k = 0; k < ip; k++)
		{
			ac1 += pf1[k] * pf1[k];
			acx += pf1[k] * pf2[k];
			ac2 += pf2[k] * pf2[k];
		}
		float fGain = acx/ac1;
		float fPredErr  = 1.F - (acx * acx) /(ac1*ac2);

//		for (int k = 0; k < ip; k++)		{
//			float x = pf2[k] - pf1[k]*fGain;
//			fPredErr += x * x;
//		}
//		fPredErr /= ac22;

		if (fPredErr > 1.0F)
		{
			fGain = 0.F;
		}
		else // prediction error < signal norm
		{
			if (fGain < 0.F) // positive gains only
			{
				fGain = 0.F;
			}
			else
			{
				if (fGain > 1.0F) 
				{
					fGain = 1.0F; // no amplificatioon allowed
				}
				else
				{
					; // gain is good
				}
			}
		}

		pPlc->afPredErr[ip] = fPredErr;
		pPlc->afGain[ip] = fGain;
	}

	// find ip that is the best
	float fMin = pPlc->afPredErr[AUDIO_PLC_MIN];
	int iMin = AUDIO_PLC_MIN;
	for (ip = AUDIO_PLC_MIN+1; ip < AUDIO_PLC_MAX; ip++)
	{
		if (pPlc->afGain[ip] > 0.01F)
		{
			if (fMin > pPlc->afPredErr[ip])
			{
				fMin = pPlc->afPredErr[ip];
				iMin = ip;
			}
		}
	}
	pPlc->fPredErrMin = fMin;

	// we may have jumped into another min
	// let's also look into local min around old pitch
	int ip_min = pPlc->iPitch - 3;
	int ip_max = pPlc->iPitch + 3;
	if (ip_min < AUDIO_PLC_MIN)
		ip_min = AUDIO_PLC_MIN;
	if (ip_max > AUDIO_PLC_MAX)
		ip_max = AUDIO_PLC_MAX;

	float fLocalMin = pPlc->afPredErr[ip_min];
	int iLocalMin = iMin;
	for (ip = ip_min; ip <= ip_max; ip++)
	{
		if (pPlc->afGain[ip] > 0.01F)
		{
			if (fLocalMin > pPlc->afPredErr[ip])
			{
				fLocalMin = pPlc->afPredErr[ip];
				iLocalMin = ip;
			}
		}
	}

	if (abs(iLocalMin - iMin) > 10)
	{
		if (fLocalMin < fMin * 1.1F + 0.05F)
		{
			iMin = iLocalMin;
		}
	}

	if (fMin < 0.5) // 6 dB gain min
	{
		pPlc->iPitch = iMin;
		// sqrtf is empiric
		pPlc->fGain = sqrtf(pPlc->afGain[iMin]);

		if ((iMin > AUDIO_PLC_MIN) && (iMin < AUDIO_PLC_MAX)) 
		{
			float y0 = pPlc->afPredErr[pPlc->iPitch];
			float yp = pPlc->afPredErr[pPlc->iPitch+1] - y0;
			float ym = pPlc->afPredErr[pPlc->iPitch-1] - y0;
			float dx = (ym-yp)/(2*(ym+yp));
			if (dx < -1.F)
				dx = -1.F;
			if (dx > 1.F)
				dx = 1.F;
			pPlc->fPitch = pPlc->iPitch + dx;
		}
		else
		{
			pPlc->fPitch = float(pPlc->iPitch);
		}
	}
	else
	{
		; // keep whatever we have
	}

	if (pPlc->fVadCrit < 0)
	{
		pPlc->fGain = 1.F;
	}
#if 1
	else if (pPlc->fGain < sqrtf(pPlc->fPredErrMin))
	{
		pPlc->fGain = sqrtf(pPlc->fPredErrMin);
	}
#endif
}

/* ------------------------------------------------------------------- */
void					audio_plc_update
/* ------------------------------------------------------------------- */
(
Audio_tPlc *pPlc,
float *pfIO
)
{
	int k;

	// shift old data
	for (k = AUDIO_FRSZ8; k < AUDIO_PLC_SSZ; k++)
	{
		pPlc->afSav[k-AUDIO_FRSZ8] = pPlc->afSav[k];
		pPlc->afSaf[k-AUDIO_FRSZ8] = pPlc->afSaf[k];
	}

	// add new data
	for (k = 0; k < AUDIO_FRSZ8; k++)
	{
		pPlc->afSav[k+AUDIO_PLC_SSZ-AUDIO_FRSZ8] = pfIO[k];
	}
	for (k = 0; k < AUDIO_FRSZ8; k++)
	{
		float *pf = &pPlc->afSav[k+AUDIO_PLC_SSZ-AUDIO_FRSZ8-3];
		float ac0 = (pf[0] + 2*pf[1] + 2*pf[2] + pf[3]) * (1.F/6.F);

		pPlc->afSaf[k+AUDIO_PLC_SSZ-AUDIO_FRSZ8] = ac0;
	}
}
/* ------------------------------------------------------------------- */
void					audio_plc_predict
/* ------------------------------------------------------------------- */
(
Audio_tPlc *pPlc
)
{
	int iRu = AUDIO_PLC_SSZ - AUDIO_PLC_RAMP - pPlc->iPitch;
	int iRd = AUDIO_PLC_SSZ - AUDIO_PLC_RAMP;
	int k;

	// first, let's find repeatable pitch
	for (k = 0; k < pPlc->iPitch; k++)
	{
		pPlc->afR[k] = 0.25F * (
			pPlc->afSav[iRu + k - 1] + 
			pPlc->afSav[iRu + k - 0]*2.F + 
			pPlc->afSav[iRu + k + 1]);
	}
	for (k = pPlc->iPitch; k < AUDIO_PLC_MAX; k++)
	{
		pPlc->afR[k] = 0;
	}


	// we do not know if this is right, 
	// there may be discontinuities at the ends
	// we know that preceeding x samples shall be the same as
	// the samples at the end, 

	for (k = 0; k < AUDIO_PLC_RAMP; k++)
	{
		// at the beginning
		pPlc->afR[k] =	
			pPlc->afR  [    k] * (1.0F - 0.5F * _afRampDn[k]) +
//			pPlc->afSav[iRu+k] * (1.0F - 0.5F * _afRampDn[k]) +
			pPlc->afSav[iRd+k] * 0.5F * _afRampDn[k] * pPlc->fGain; 
		// at the end -- dowe need to do the same - not sure - TBD

		pPlc->afR[pPlc->iPitch-1-k] =	
			pPlc->afR  [pPlc->iPitch-1-k] * (1.0F - 0.5F * _afRampDn[k]) +
//			pPlc->afSav[iRu+k] * (1.0F - 0.5F * _afRampDn[k]) +
			pPlc->afSav[iRu-1-k] * 0.5F * _afRampDn[k] * pPlc->fGain; 
	}

	for (int idx = 0; idx < AUDIO_FRSZ8 + AUDIO_PLC_RAMP*2;)
	{
		for (int k = 0; 
			(k < pPlc->iPitch) && (idx < AUDIO_FRSZ8 + AUDIO_PLC_RAMP*2); 
			k++)
		{
#if 1
			float x = pPlc->afR[k] * pPlc->fGain;
			pPlc->afPredicted[idx] = x;
			pPlc->afR[k] = x ;
#else
			float x = pPlc->afSav[iRu + k] * pPlc->fGain;

			if (k < AUDIO_PLC_RAMP)
			{
				pPlc->afPredicted[idx] = 
					_afRampDn[k] * pPlc->afSav[iRd + k] + 
					_afRampUp[k] * x;
			}
			else
			{
				pPlc->afPredicted[idx] = x;
			}
			pPlc->afSav[iRu + k] = x;
#endif
			idx++;
		}
	}

	// now, let's blend ramp in
	for (k = 0; k < AUDIO_PLC_RAMP; k++)
	{
		pPlc->afPredicted[k] = 
			pPlc->afPredicted[k] * _afRampUp[k] + 
			pPlc->afSav[iRd+k]   * _afRampDn[k];
	}
}

/* ------------------------------------------------------------------- */
void					audio_plc_ramp
/* ------------------------------------------------------------------- */
(
Audio_tPlc *pPlc,
float *pfIO
)
{
	int k;
	for (k = 0; k < AUDIO_PLC_RAMP; k++)
	{
		pfIO[k] = _afRampUp[k] * pfIO[k] + 
				  _afRampDn[k] * pPlc->afPredicted[k+AUDIO_FRSZ8+AUDIO_PLC_RAMP];
	}
#if 0
	// low-pass filter it
	float afa[AUDIO_PLC_RAMP*2];
	for (k = 0; k < AUDIO_PLC_RAMP*2; k++)
	{
		afa[k] = (1.F/12.F) * (pfIO[k+0] + 3*pfIO[k+1]+4*pfIO[k+2]+3*pfIO[k+3] + pfIO[k+4]);
	}
	for (k = 0; k < AUDIO_PLC_RAMP*2; k++)
	{
		pfIO[k+2] = afa[k];
	}
#endif
}
/* ------------------------------------------------------------------- */
void					audio_plc_replace
/* ------------------------------------------------------------------- */
(
Audio_tPlc *pPlc,
float *pfIO
)
{
	for (int k = 0; k < AUDIO_FRSZ8; k++)
	{
		pfIO[k] = pPlc->afPredicted[k];
	}
}
/* ------------------------------------------------------------------- */
void					audio_plc_delay
/* ------------------------------------------------------------------- */
(
Audio_tPlc *pPlc,
float *pfIO
)
{
	for (int k = 0; k < AUDIO_FRSZ8; k++)
	{
		pfIO[k] = pPlc->afSav[AUDIO_PLC_SSZ - AUDIO_FRSZ8 - AUDIO_PLC_RAMP + k];
	}
}
/* ------------------------------------------------------------------- */
void					audio_plc_zero
/* ------------------------------------------------------------------- */
(
Audio_tPlc *pPlc,
float *pfIO
)
{
	short sSeed = pPlc->sNseSeed;
	float fLast = pPlc->fNseLast;

	for (int k = 0; k < AUDIO_FRSZ8; k++)
	{
	    int ac0 = sSeed * (int) 31821;
		ac0 += 13849;
		sSeed = (short)ac0;

		fLast = fLast * 0.9F + sSeed * (1.F/32768.F);

		pfIO[k] = fLast * 1.0e-5F; // -100 dBm
	}
	pPlc->sNseSeed = sSeed;
	pPlc->fNseLast = fLast;
}
/* ------------------------------------------------------------------- */
bool					audio_plc_process
/* ------------------------------------------------------------------- */
(
Audio_tPlc *pPlc,
float *pfIO,
bool bLost
)
{
	bool bReplaced = false;
	if (bLost)
	{
		audio_plc_zero(pPlc, pfIO);
#if 0
		extern long        _Frame;
		extern U16         DEMO_StepMode;
	    if(_Frame >= 196) 
		{
			DEMO_StepMode = TRUE;
		}
#endif
	}
	else
	{
		audio_plc_vad(pPlc, pfIO);
	}

	switch (pPlc->iState)
	{
	case AUDIO_PLC_ST_INIT:
		if (bLost)
		{
			audio_plc_update(pPlc, pfIO);
		}
		else
		{
			audio_plc_ramp(pPlc, pfIO);
			audio_plc_update(pPlc, pfIO);
			pPlc->iState = AUDIO_PLC_ST_OK;
		}
		break;
	case AUDIO_PLC_ST_OK:
		if (bLost)
		{
#if AUDIO_PLC_DIFF
			audio_plc_predict_diff(pPlc);
#else
			audio_plc_predict(pPlc);
#endif
			audio_plc_replace(pPlc, pfIO);
			bReplaced = true;
			audio_plc_update(pPlc, &pPlc->afPredicted[AUDIO_PLC_RAMP]);
			pPlc->iState++;
		}
		else //
		{
			audio_plc_update(pPlc, pfIO);
		}
		break;
	default:
		if (bLost) 
		{
			pPlc->iState ++;
			if (pPlc->iState > AUDIO_PLC_ST_BAD)
			{
				audio_plc_update(pPlc, pfIO);
				pPlc->iState = AUDIO_PLC_ST_BAD;
			}
			else
			{
//				pPlc->fGain *= 1.F/(0.1F+pPlc->iState - AUDIO_PLC_ST_OK);
				pPlc->fGain *= 1.F/pPlc->iState;
#if AUDIO_PLC_DIFF
				audio_plc_predict_diff(pPlc);
#else
				audio_plc_predict(pPlc);
#endif
				audio_plc_replace(pPlc, pfIO);
				bReplaced = true;
				audio_plc_update(pPlc, &pPlc->afPredicted[AUDIO_PLC_RAMP]);
			}
		}
		else // first good packet
		{
			audio_plc_ramp(pPlc, pfIO);
			audio_plc_update(pPlc, pfIO);
			pPlc->iState = AUDIO_PLC_ST_OK;
		}
		break;
	}
	audio_plc_pda(pPlc);
#if AUDIO_PLC_DIFF
	audio_plc_pda_diff(pPlc);
#endif

	if (!bReplaced)
		audio_plc_delay(pPlc, pfIO);

	if ((pPlc->dwSD != AUDIO_SD) ||
		(pPlc->dwED != AUDIO_ED))
		return false;
	else 
		return true;
}
/* ------------------------------------------------------------------- */
bool					audio_plc_process
/* ------------------------------------------------------------------- */
(
void *p,
short *psIO,
bool bLost
)
{
	Audio_tPlc *pPlc = (Audio_tPlc *)p;
	bool b = true;

	float afIO[AUDIO_FRSZ8];
	audio_utl_short2float(afIO, psIO, AUDIO_FRSZ8);
	b = audio_plc_process(pPlc, afIO, bLost);
	audio_utl_float2short(psIO, afIO, AUDIO_FRSZ8);
	return b;
}
#if AUDIO_PLC_DIFF
/* ------------------------------------------------------------------- */
void					audio_plc_pda_diff
/* ------------------------------------------------------------------- */
(
Audio_tPlc *pPlc
)
{
	int ip;
	int ip_min = pPlc->iPitch - AUDIO_PLC_CHANGE;
	int ip_max = pPlc->iPitch + AUDIO_PLC_CHANGE;
	if (ip_min < AUDIO_PLC_MIN)
		ip_min = AUDIO_PLC_MIN;
	if (ip_max > AUDIO_PLC_MAX)
		ip_max = AUDIO_PLC_MAX;

	for (ip = ip_min; ip < ip_max; ip++)
	{
		float ac1 = AUDIO_EPS;
		float ac2 = AUDIO_EPS;
		float acx = 0;
		int i1 = AUDIO_PLC_SSZ - AUDIO_FRSZ8 - ip*2;
		int i2 = AUDIO_PLC_SSZ - AUDIO_FRSZ8 - ip;
		float *pf1 = &pPlc->afSaf[i1];
		float *pf2 = &pPlc->afSaf[i2];

		for (int k = 0; k < ip; k++)
		{
			ac1 += pf1[k] * pf1[k];
			acx += pf1[k] * pf2[k];
			ac2 += pf2[k] * pf2[k];
		}
		float fGain = acx/ac1;
		float fPredErr  = 1.F - (acx * acx) /(ac1*ac2);

//		for (int k = 0; k < ip; k++)		{
//			float x = pf2[k] - pf1[k]*fGain;
//			fPredErr += x * x;
//		}
//		fPredErr /= ac22;

		if (fPredErr > 1.0F)
		{
			fGain = 0.F;
		}
		else // prediction error < signal norm
		{
			if (fGain < 0.F) // positive gains only
			{
				fGain = 0.F;
			}
			else
			{
				if (fGain > 1.0F) 
				{
					fGain = 1.0F; // no amplificatioon allowed
				}
				else
				{
					; // gain is good
				}
			}
		}

		pPlc->afPredErrDiff[ip-ip_min] = fPredErr;
		pPlc->afGainDiff[ip-ip_min] = fGain;
	}

	// find ip that is the best
	float fMin = pPlc->afPredErrDiff[0];
	int iMin = ip_min;
	for (ip = 1; ip <= ip_max-ip_min; ip++)
	{
		if (pPlc->afGainDiff[ip] > 0.01F)
		{
			if (fMin > pPlc->afPredErrDiff[ip])
			{
				fMin = pPlc->afPredErrDiff[ip];
				iMin = ip;
			}
		}
	}

	if (fMin < 0.5) // 6 dB gain min
	{
		pPlc->iPitchDiff = (iMin+ip_min) - pPlc->iPitch;

		if ((iMin > 0) && (iMin < ip_max-ip_min)) 
		{
			float y0 = pPlc->afPredErrDiff[iMin];
			float yp = pPlc->afPredErrDiff[iMin+1] - y0;
			float ym = pPlc->afPredErrDiff[iMin-1] - y0;

			float dx = (ym-yp)/(2*(ym+yp));
			if (dx < -1.F)
				dx = -1.F;
			if (dx > 1.F)
				dx = 1.F;

			float f = (iMin+ip_min) + dx;
			pPlc->fPitchOff = f - pPlc->fPitch;
			pPlc->fPitchDiff += 0.25F*(1.F-fMin) * 
				(pPlc->fPitchOff -  pPlc->fPitchDiff);
		}
	}
	else
	{
		pPlc->iPitchDiff = 0;
		pPlc->fPitchDiff = 0;
	}
}
#endif
#if AUDIO_PLC_DIFF
/* ------------------------------------------------------------------- */
void					audio_plc_predict_diff
/* ------------------------------------------------------------------- */
(
Audio_tPlc *pPlc
)
{
//	float fGainLast = 1;
	int iRu = AUDIO_PLC_SSZ - AUDIO_PLC_RAMP - pPlc->iPitch;
//	int iSt = AUDIO_PLC_SSZ - pPlc->iPitch;
	int iRd = AUDIO_PLC_SSZ - AUDIO_PLC_RAMP;

	float af[AUDIO_PLC_MAX + AUDIO_PLC_RAMP];

	for (int k = 0; k < pPlc->iPitch+AUDIO_PLC_RAMP; k++)
	{
		af[k] = pPlc->afSav[iRu + k];
	}

//	float fPhase = 0;
//	float fDlt = pPlc->fPitchDiff * (2.F/AUDIO_FRSZ8);

	for (int idx = 0; idx < AUDIO_FRSZ8 + AUDIO_PLC_RAMP*2;)
	{
		for (int k = 0; 
			(k < pPlc->iPitch) && (idx < AUDIO_FRSZ8 + AUDIO_PLC_RAMP*2); 
			k++)
		{
//			float x = pPlc->afSav[iRu + k] * pPlc->fGain;
			float x = af[k] * pPlc->fGain;

			if (k < AUDIO_PLC_RAMP)
			{
				pPlc->afPredicted[idx] = 
					_afRampDn[k] * af[k+pPlc->iPitch] + 
					_afRampUp[k] * x;
			}
			else
			{
				pPlc->afPredicted[idx] = x;
			}
			idx++;
		}

		for (int k = 0; k < pPlc->iPitch+AUDIO_PLC_RAMP; k++)
		{
			af[k] *= pPlc->fGain;
		}
	}
}
#endif

#if 0
		if ((iMin > AUDIO_PLC_MIN+1) && (iMin < AUDIO_PLC_MAX-1)) 
		{
			float y0 = pPlc->afPredErr[pPlc->iPitch];
			float yp = pPlc->afPredErr[pPlc->iPitch+2] - y0;
			float ym = pPlc->afPredErr[pPlc->iPitch-2] - y0;
			float dx = 2.f*(ym-yp)/(2*(ym+yp));
			if (dx < -1.F)
				dx = -1.F;
			if (dx > 1.F)
				dx = 1.F;
			pPlc->fPitch1 = pPlc->iPitch + dx;
		}
#endif
