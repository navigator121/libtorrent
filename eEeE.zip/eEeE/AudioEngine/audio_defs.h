#pragma once

//#define _CRT_SECURE_NO_DEPRECATE 1
#pragma warning (disable : 4996)

#include "audks_common.h"

#include <windows.h>
#include <dsound.h>
//#include <varargs.h>
#include <stdarg.h>
#include <stdio.h>
#include <math.h>

#include "audio_if.h"
#include "gaeci.h"
#include "gaec_hp.h"

// switch it to 0 to exclude G.729 off the build
#define AUDIO_G729					(1)

/*****************************************************************************/

#define AUDIO_PI					(3.14159265358979F)
#define AUDIO_DRV_FS				(48000)
#define AUDIO_FS32					(32000)
#define AUDIO_FS16					(16000)
#define AUDIO_FS8					(8000)
//#define AUDIO_FS					(AUDIO_FS8)
#define AUDIO_FRMS					(20)
#define AUDIO_FRSZ48				(AUDIO_FRMS*(AUDIO_DRV_FS/1000))
#define AUDIO_FRSZ32				(AUDIO_FRMS*(AUDIO_FS32/1000))
#define AUDIO_FRSZ16				(AUDIO_FRMS*(AUDIO_FS16/1000))
#define AUDIO_FRSZ8					(AUDIO_FRMS*(AUDIO_FS8/1000))
//#define AUDIO_FRSZ					(AUDIO_FRSZ8)

#define AUDIO_SD					(0xeca86420)
#define AUDIO_ED					(0xfdb97531)
#define AUDIO_DD					(0x12345678)

// 32<->48 resampling filter size
#define AUDIO_48TO32_FSZ			(48)
// 32->4*8 filterbank
#define AUDIO_FB4_SECTION_SZ		(16)
#define AUDIO_FB4_SECTIONS			(6)
#define AUDIO_FB4_FSZ				(AUDIO_FB4_SECTION_SZ*AUDIO_FB4_SECTIONS)

#define AUDIO_32TO8_FSZ				(64)
#define AUDIO_8TO32_FSZ				(AUDIO_32TO8_FSZ/4)

#define AUDIO_32TO16_FSZ			(AUDIO_32TO8_FSZ)
#define AUDIO_16TO32_FSZ			(AUDIO_32TO16_FSZ/2)

/*****************************************************************************/

#define AUDIO_DRV_USE_MM_TMR		(1)
#define AUDIO_DRV_THREAD_TIMEOUT	(5)
#define AUDIO_GEN_THREAD_TIMEOUT	(2)


#define AUDIO_DRV_SPK_BLK_SZ		((AUDIO_FRMS/2)*sizeof(short)*AUDIO_DRV_FS/1000) // 10 ms
#define AUDIO_DRV_SPK_BLKS			(32)
#define AUDIO_DRV_SPK_BUF_SZ		(AUDIO_DRV_SPK_BLKS*AUDIO_DRV_SPK_BLK_SZ) // 320 ms
#define AUDIO_DRV_SPK_PRIME			(3)
#define AUDIO_DRV_SPK_EVENTS		(AUDIO_DRV_SPK_BLKS)
#define AUDIO_DRV_SPK_QSZ			(8)	// must be 2^n

#define AUDIO_DRV_MIC_BLK_SZ		(AUDIO_FRMS*sizeof(short)*AUDIO_DRV_FS/1000) // 20 ms
#define AUDIO_DRV_MIC_BLKS			(4)
#define AUDIO_DRV_MIC_BUF_SZ		(AUDIO_DRV_MIC_BLKS*AUDIO_DRV_MIC_BLK_SZ) // 80 ms
#define AUDIO_DRV_MIC_EVENTS		(AUDIO_DRV_MIC_BLKS)
#define AUDIO_DRV_MIC_PTAU			(1.e-3F)
#define AUDIO_DRV_MIC_NTAU			(3.e-1F)

enum {
	AUDIO_DRV_SPK_MODE_NONE,
	AUDIO_DRV_SPK_MODE_PRIORITY,
	AUDIO_DRV_SPK_MODE_NORMAL,
	AUDIO_DRV_SPK_MODE_FAILED,
	AUDIO_DRV_SPK_MODE_MAX
};

#define AUDIO_TEST_GEN_DTMF_QSZ		(32) // 15 is enough, though

/*****************************************************************************/

enum {
	AUDIO_DBG_EVENT_QUIT,
	AUDIO_DBG_EVENT_ACTION,
	AUDIO_DBG_EVENT_WIN_OPEN,
	AUDIO_DBG_EVENT_WIN_CLOSE,

	AUDIO_DBG_EVENTS
};
#define AUDIO_DBG_THREAD_TIMEOUT	(100)
#define AUDIO_DBG_LOGQ_SZ			(256) // 2^n
#define AUDIO_DBG_LOGQ_ITEM_SZ		(MAX_PATH)
#define AUDIO_DBG_RECQ_SZ			(256*2)
#define AUDIO_DBG_WIN_PENS			(4*4*4)
#define AUDIO_DBG_WIN_COLORS		AUDIO_DBG_WIN_PENS

#define AUDIO_DBG_REC_MAX			(16)

enum {
	AUDIO_DBG_REC_PKT,
	AUDIO_DBG_REC_PCM8,
	AUDIO_DBG_REC_PCM32,
	AUDIO_DBG_REC_PCM48,

	AUDIO_DBG_REC_TYPES
};
/*****************************************************************************/

#define AUDIO_CRIT_MAX				(30.F)
#define AUDIO_CRIT_MIN				(-6.F)
#define AUDIO_CRIT_THR				(3.F)
#define AUDIO_EPS					(1.e-8F)

#define AUDIO_AGC_ZC_MIN			(0.1F)
#define AUDIO_AGC_ZC_MAX			(0.33F)
#define AUDIO_VAD_NSE_MIN			(-65.F)
#define AUDIO_VAD_NSE_MAX			(-35.F)

/*****************************************************************************/

enum {
	AUDIO_TMR_BASE,
	AUDIO_TMR_WIN_TMR,
	AUDIO_TMR_MM_TMR,
	AUDIO_TMR_SPK_BLK,
	AUDIO_TMR_MIC_BLK,
	AUDIO_TMR_SPK_POLL,
	AUDIO_TMR_MIC_POLL,
	AUDIO_TMR_SPK_OVERRUN,
	AUDIO_TMR_MIC_OVERRUN,
	AUDIO_TMR_SPK_EVENT,
	AUDIO_TMR_MIC_EVENT,
	AUDIO_TMR_MIC_JITTER,
	AUDIO_TMR_PROCESS,
	AUDIO_TMR_DEC,
	AUDIO_TMR_ENC,
	AUDIO_TMR_AEC,
	AUDIO_TMR_NETRCV,
	AUDIO_TMR_NETSND,

	AUDIO_TMR_AEC_ANA,
	AUDIO_TMR_AEC_LL,
	AUDIO_TMR_AEC_LH,
	AUDIO_TMR_AEC_H,
	AUDIO_TMR_AEC_SYN,


	AUDIO_TMR_GEN_THREAD,
	AUDIO_TMR_DBG_THREAD,
	AUDIO_TMR_DRV_THREAD,
	AUDIO_TMR_MAX
};

#if defined (AUDIO_DRV_TMR_C)
static char *aTmrName[AUDIO_TMR_MAX] = {
	"Base",
	"WIN Tmr",
	"MM Tmr",
	"SpkBlk",
	"MicBlk",
	"SpkPoll",
	"MicPoll",
	"SpkOver",
	"MicOver",
	"SpkEvnt",
	"MicEvnt",
	"MicJttr",
	"Process",
	"decoder",
	"encoder",
	"AEC",
	"netrcv",
	"netsnd",
	"aecAnal",
	"aecLL",
	"aecLH",
	"aecH",
	"aecSynt",
	"GenThrd",
	"DbgThrd",
	"DrvThrd"
};
#endif

/*****************************************************************************/

#define AUDIO_JB_NETQ_SZ			(AUDIO_IF_PARTY_MAX*4) // provide for net jum
#define AUDIO_JB_QSZ				(32)				  // 640 ms max
#define AUDIO_JB_INVALID_IDX		(WORD(-1))
#define	AUDIO_JB_OOS_MAX			(4)

#define AUDIO_CSZ_G711				(160) // 20ms, 64kb/s
#define AUDIO_CSZ_G711				(160) // 20ms, 64kb/s
#define AUDIO_CSZ_G729A				(10)  // 10ms, 8kb/s
#define AUDIO_CSZ_SPEEX_NB			(38)  // 20ms, 15.2kb/s
#define AUDIO_CSZ_ILBC				(38)  // 20ms, 15.2kb/s
#define AUDIO_CSZ_GSM				(33)  // 20ms, 13.2kb/s
#define AUDIO_CSZ_SPEEX_WB			(70)  // 
#define AUDIO_CSZ_SPEEX_UWB			(90)
#define AUDIO_CSZ_SIREN1424			(60)
#define AUDIO_CSZ_SIREN1432			(80)
#define AUDIO_CSZ_SIREN1448			(120)
#define AUDIO_CSZ_SIREN1416			(40)
#define	AUDIO_CSZ_SPEEX_VBR_NB		(-1)
#define AUDIO_CSZ_SPEEX_VBR_WB		(-1)
#define AUDIO_CSZ_SPEEX_VBR_UWB		(-1)

/*****************************************************************************/
typedef struct {
	WORD		wPT;
	WORD		wSN;
	WORD		wIdx;
	DWORD		dwTS;
} Audio_tRtpHdr;

typedef struct {
    char acRiff[4];
    DWORD  dwLen1;
    char acWave[4];

    char acFmt[4];
    DWORD  dwLen2;
    WORD  wMode;
    WORD  wNumber;
    DWORD  dwFs;
    DWORD  dwBps;
    WORD  wBytes;
    WORD  wBits;

    char acData[4];
    DWORD  dwLen3;
} Audio_tWavHdr;

//defines to include RTP, UDP and IP header bitrate in
#define AUDIO_IP_HEADER_SIZE			20
#define AUDIO_UDP_HEADER_SIZE			8
#define AUDIO_RTP_HEADER_SIZE			12
#define AUDIO_PACKET_HEADER_SIZE (AUDIO_IP_HEADER_SIZE + AUDIO_UDP_HEADER_SIZE + AUDIO_RTP_HEADER_SIZE)

///////////////////////////////////////////////////////////////////////////////
//
//				DRIVER
//
typedef struct {
	DWORD				dwSD;

	LPGUID				lpGUID;
	LPDIRECTSOUND8		pDs;
	LPDIRECTSOUNDBUFFER pDsBuf;
	HANDLE				ahEvent			[AUDIO_DRV_SPK_EVENTS];
	DWORD				dwReadOffset;
	DWORD				dwWriteOffset;
	float				fCrit;
	int					iLookAhead;
	int					iMode;
	int					iQSz;
	int					iQWriteIdx;
	int					iQReadIdx;
	short				asQ				[(AUDIO_DRV_SPK_BLK_SZ/2)*AUDIO_DRV_SPK_QSZ];

	DWORD				dwED;
} Audio_tDrvDxSpk;

typedef struct {
	DWORD				dwSD;

	LPGUID				lpGUID;
	LPDIRECTSOUNDCAPTURE8 		pDs;
	LPDIRECTSOUNDCAPTUREBUFFER  pDsBuf;
	HANDLE				ahEvent			[AUDIO_DRV_MIC_EVENTS];
	DWORD				dwReadOffset;
	float				fCrit;
	int					iBlksRead;
	float				fTime;
	float				fStartTime;
	float				fTimeMin;
	int					iTimeCnt;
	short				asData			[AUDIO_DRV_MIC_BLK_SZ/2];

	DWORD				dwED;

} Audio_tDrvDxMic;


typedef struct {
	bool				bRunning;
	__int64				llBase;
	float				fLast;
	AudioIf_tHstgm		Hstgm;
} Audio_tTmr;

typedef struct {
	bool				bInitialized;
	__int64				llFreq;
	float				fInvFreq;
	Audio_tTmr			aTmr			[AUDIO_TMR_MAX];
} Audio_tTmrCtrl;


typedef struct {
	Audio_tDrvDxSpk	Spk;
	Audio_tDrvDxMic	Mic;
} Audio_tDrvDx;

typedef struct {
	CKsAudPin*			pPin;
	CKsFilter*			pFilter;
} Audio_tDrvKsMs; // from MS's ks sample

typedef struct {
	DWORD				dwSD;

	Audio_tDrvKsMs		Ms;

	bool				bOpen;
	int					iChannels;
	AUDKS_DATA_PACKET	aPkt			[AUDIO_DRV_MIC_BLKS];
	short				aasBuf			[AUDIO_DRV_MIC_BLKS][2*(AUDIO_DRV_MIC_BLK_SZ/2)];
	short				asPktState		[AUDIO_DRV_MIC_BLKS];
	short				sPktState;
	__declspec(align(8)) 
		DWORDLONG		dwlReadOffset;
	short				asData			[AUDIO_FRSZ48];

	int					iPutIdx;
	int					iGetIdx;
	float				fTime;
	float				fStartTime;

	DWORD				dwED;
} Audio_tDrvKsMic;

typedef struct {
	DWORD				dwSD;

	Audio_tDrvKsMs		Ms;

	bool				bOpen;
	int					iChannels;
	AUDKS_DATA_PACKET	aPkt			[AUDIO_DRV_SPK_BLKS];
	short				aasBuf			[AUDIO_DRV_SPK_BLKS][8*(AUDIO_DRV_SPK_BLK_SZ/2)];
	__declspec(align(8)) 
		DWORDLONG		dwlWriteOffset;
	short				asData			[AUDIO_FRSZ48];

	float				fCrit;
	int					iLookAhead;
	int					iQSz;
	int					iQWriteIdx;
	int					iQReadIdx;
	short				asQ				[(AUDIO_DRV_SPK_BLK_SZ/2)*AUDIO_DRV_SPK_QSZ];

	int					idx;

	DWORD				dwED;
} Audio_tDrvKsSpk;

typedef struct {
	Audio_tDrvKsMic		Mic;
	Audio_tDrvKsSpk		Spk;
} Audio_tDrvKs;

typedef struct {
	int					iFrameNo;
//	int					iState;
	Audio_tDrvDx		Dx;
	Audio_tDrvKs		Ks;
	HANDLE				hThread;
	DWORD				dwThreadId;
	HANDLE				ahEvents		[2+AUDIO_DRV_SPK_EVENTS+AUDIO_DRV_MIC_EVENTS];
	HANDLE				hStartEvent;
	UINT				uMmTimerId;

	char				acMicDeviceName	[AUDIO_IF_DEVICE_NAME_SZ];
	char				acSpkDeviceName	[AUDIO_IF_DEVICE_NAME_SZ];
	int					iDrvMode;
	int					iThreadPriority;

	bool				bOutOfSinc;
	bool				bDelayAdded;

	float				fNow; // time of the last WaitForMultipleObjects();
} Audio_tDrv;

///////////////////////////////////////////////////////////////////////////////
//
//				DEBUG
//
typedef struct {
	__declspec(align(4)) LONG volatile		lSz;
	__declspec(align(4)) LONG volatile		lWriteIdx;
	FILE				*fdLog;
	int					iReadIdx; // onl one reader
	int					iOverflows;
	char				aacData			[AUDIO_DBG_LOGQ_SZ][AUDIO_DBG_LOGQ_ITEM_SZ];
} Audio_tDbgLogQ;


typedef struct {
	WORD				wPt;
	WORD				wStream;
	WORD				wType;
	int					iFrameNo;
	union {
		struct {
			short			asData		[AUDIO_FRSZ48];
			WORD			wDataSz;
		} Pcm;
		struct {
			float			fArrived;
			WORD			wDataSz;
			Audio_tRtpHdr	Hdr;
			BYTE	acData		[AUDIO_FRSZ48];
		} Pkt;
	} u;
} Audio_tDbgRecQItem;


typedef struct {
	__declspec(align(4)) LONG volatile		lSz;
	long				lWriteIdx;
	int					iReadIdx; // onl one reader
	int					iOverflows;
	Audio_tDbgRecQItem	aItem			[AUDIO_DBG_RECQ_SZ];
} Audio_tDbgRecQ;

typedef struct {
	WORD				wMask;
	FILE*				aafd			[AUDIO_DBG_REC_MAX][AUDIO_IF_PARTY_MAX+1];
	DWORD				aadwSz			[AUDIO_DBG_REC_MAX][AUDIO_IF_PARTY_MAX+1];
	DWORD				aadwFs			[AUDIO_DBG_REC_MAX][AUDIO_IF_PARTY_MAX+1];
	Audio_tDbgRecQ		Q;
} Audio_tDbgRec;

typedef struct {
	WORD				wUiMode;
	bool				bActive;
	bool				bCreated;
	HINSTANCE			hInstance;
	HDC					hDc;
	HBRUSH				hBlackBrush;
	HPEN				ahPen			[AUDIO_DBG_WIN_PENS];
	HGDIOBJ				hSysPen;
	COLORREF			aColor			[AUDIO_DBG_WIN_COLORS];
	HWND				hWnd;
	int					x;


} Audio_tDbgWin;

typedef struct {
	DWORD				dwSD;

	bool				bRunning;
	HANDLE				hThread;
	DWORD				dwThreadId;
	int					iLogLevel;
	char				acRecFilesDirectory	[MAX_PATH];
	HANDLE				ahEvents		[AUDIO_DBG_EVENTS];
	HANDLE				hStartEvent;

	Audio_tDbgWin		Win;
	Audio_tDbgLogQ		LogQ;
	Audio_tDbgRec		Rec;

	DWORD				dwED;
} Audio_tDbg;

///////////////////////////////////////////////////////////////////////////////
//
//				JITTER BUFFER
//
typedef struct {
	Audio_tRtpHdr		Hdr;
	BYTE		*pcData;
	WORD				wDataSz;
	float				fArrived;

	WORD				wFrsPerPkt;
} Audio_tJbNetQItem;

typedef struct {
	__declspec(align(4)) LONG volatile		lSz;
	__declspec(align(4)) LONG volatile		lWriteIdx;
	int					iReadIdx; // onl one reader
	int					iOverflows;
	int					iBadSrcId;
	int					iBadType;
	int					iAllocFalied;
	Audio_tJbNetQItem	aItem			[AUDIO_JB_NETQ_SZ];
} Audio_tJbNetQ;

typedef struct {
	DWORD				dwSD;

	WORD				wIdx;
	WORD				wPayloadType;
	bool				bRunning;
	WORD				wWriteIdxStart;
	DWORD				dwTsFrame;
	float				fGainDb;
	bool				bMixToSpk;

	Audio_tJbNetQItem	aItem			[AUDIO_JB_QSZ];
	WORD				wWriteIdx;
	WORD				wReadIdx;
	WORD				wFrsPerPkt;

	// used for writing into Q
	DWORD				dwTsLast;
	WORD				wSnLast;
	int					iOosCnt;
	int					iLateCnt;

	// used for reading from Q
	bool				bDecoderActive;
	WORD				wLateIdxC;
	WORD				wRdIdxC;
	WORD				wRdFrs;
	void *				pvDecoder;

	short				asOut			[AUDIO_FRSZ32];
	float				afIntSav		[AUDIO_16TO32_FSZ];//[AUDIO_8TO32_FSZ];
	float				afOut			[AUDIO_FRSZ32];

	int					iPtrAdjustments;
	float				fCrit;
	float				fNrg;
	float				fPeak;
	int					iBytes;
	float				fStartedAt;
	bool				bRestart;
	AudioIf_tSrcStts	Stts;

	DWORD				dwED;
} Audio_tJbParty;

typedef struct {
	Audio_tJbParty*		apParty			[AUDIO_IF_PARTY_MAX+1];
	Audio_tJbNetQ		NetQ;
} Audio_tJb;

///////////////////////////////////////////////////////////////////////////////
//
//				NETWORK SEND
//
typedef struct {
	DWORD				dwSD;

	WORD				wIdx;
	WORD				wPayloadType;
	DWORD				dwTsFrame;
	WORD				wFrsPerPkt;
	WORD				wCodedFrSz;

	bool				bMixMic;
	int					iMixSz;
	WORD				awMixSrcIds		[AUDIO_IF_PARTY_MAX];

	DWORD				dwTS;

	WORD				wFrs;
	int					iEncoded;
	void *				pvEncoder;

	float				afFrame			[AUDIO_FRSZ32];
	float				afDcmSav		[AUDIO_32TO8_FSZ];
	short				asFrame			[AUDIO_FRSZ32];

	BYTE*				pcCode;

	float				fNrg;
	float				fPeak;
	AudioIf_tDstStts	Stts;

	DWORD				dwED;
} Audio_tNsParty;

typedef struct {
	Audio_tNsParty*		apParty			[AUDIO_IF_PARTY_MAX+1];
} Audio_tNs;


///////////////////////////////////////////////////////////////////////////////
//
//				AUDIO PROCESSING 
//
typedef struct {
	WORD				awQDigits		[AUDIO_TEST_GEN_DTMF_QSZ];
	WORD				wQIdxWrite;
	WORD				wQIdxRead;
	int					iQSz;
	float				fFreq1;
	float				fFreq2;
	float				fPhase1;
	float				fPhase2;
	WORD				wFrameCnt;
	float				afFrame			[AUDIO_FRSZ32];
} Audio_tTestGenDtmf;

typedef struct {
	struct {
		float			fTargetNrg;
		float			fMinNrg;
		float			fOverNoise;
		float			fExtraGain;
		float			fMaxGain;
		float			fFastAdapt;
		float			fSlowAdapt;
	} Cfg;
	bool				bOn;
	float				afSosAW[2];
	float				fAwNse;
	float				fGainDb;
	float				fPeakNrg;
	float				fVadCrit;
	float				fVadNse;
	int					iCnt;
	int					iNoSignalCnt;
	int					iSoftTalkerCnt;
	U16					uAlarm;
	struct {
		float				fNrg;
		float				fZc;
		float				fZcFactor;
	} Last;
} Audio_tAgc;

typedef struct {
	int					iMode;
	Audio_tTestGenDtmf	Dtmf;
	float				fFreq;
	float				fPhase;
	short				sSeed;
	float				fLpSav;
	struct {
		FILE*			fd;
		bool			bPlay;
		bool			bPause;
		bool			bLoop;
		Audio_tWavHdr	WavHdr;
	} Player;
	struct {
		FILE*			fd;
		bool			bPause;
		Audio_tWavHdr	WavHdr;
		float			afDcmSav		[AUDIO_32TO8_FSZ];
	} RecordCall;
} Audio_tTestGen;

typedef struct {
	int					iType;
	int					iMHz;
	int					iCacheSz;
} Audio_tCpu;

typedef struct {
	float				fNetRcv;
	float				fNetSnd;
	float				fMic;
	float				fAgc;
	float				fAec;
	float				fMicS;
	float				fSpk;
	float				fVol;
} Audio_tNrg;

typedef struct {
	struct {
		bool	bActive;
	} aConf[AUDIO_IF_CONF_MAX+1];

	struct {
		bool	bActive;
		WORD	wConfId;
	} aParty[AUDIO_IF_PARTY_MAX+1];
} Audio_tConf;

typedef struct {
	_declspec (align(16)) float	afDecSav	[AUDIO_FB4_FSZ];
	_declspec (align(16)) float	afIntSav	[AUDIO_FB4_FSZ];

	_declspec (align(16)) float	afLL		[AUDIO_FRSZ8];
	_declspec (align(16)) float	afLH		[AUDIO_FRSZ8];
	_declspec (align(16)) float	afHL		[AUDIO_FRSZ8];
	_declspec (align(16)) float	afHH		[AUDIO_FRSZ8];
} Audio_tFB4;

typedef struct {

	GAEC_tObj			AecLL;

	GAEC_tHpDb			HpLH;
//	GAEC_tHpDb			HpHL;

	GAEC_tSwDb			SwHL;
	GAEC_tSwDb			SwHH;

	GAEC_tHpSc			HpSc;

	Audio_tFB4			Rcv;
	Audio_tFB4			Snd;

	float				aafSosHpf		[3][2];
	float				afSos120		[2];
	bool				bOn;

} Audio_tAec;

typedef struct {
	int					iMicClipCnt;
	int					iMicClipFrames;
	int					iAlarmSoundCnt;
	float				fAlarmSoundCrit;
	U16					uAlarm;
} Audio_tAlarm;

typedef struct {
	CRITICAL_SECTION	Lock;

	DWORD				dwSD;
	bool				bInitialized;
	bool				bRunning;

	bool				bMicMuted;
	float				fVolumeDb;

	Audio_tTmrCtrl		TmrCtrl;
	Audio_tDrv			Drv;

	Audio_tJb			Jb;
	Audio_tTestGen		Tg;
	Audio_tAgc			Agc;
	Audio_tNs			Ns;
//	GAEC_tObj			Aec;
	Audio_tAec			Aec;
	Audio_tNrg			Nrg;
	Audio_tAlarm		Alarm;
	Audio_tConf			Conf;



	DWORD				dwDD0;

	short				asSpk48			[AUDIO_FRSZ48];
	short				asMic48			[AUDIO_FRSZ48];
	DWORD				dwDD1;


	float				afMux			[AUDIO_FRSZ32];
	float				afVol			[AUDIO_FRSZ32];


	float				afRcv			[AUDIO_FRSZ32];
	float				afSnd			[AUDIO_FRSZ32];

	DWORD				dwDD2;

	// saved data
	float				af48to32Sav		[AUDIO_48TO32_FSZ/2];
	float				af32to48Sav		[AUDIO_48TO32_FSZ/3];
//	float				aafSosDec		[5][2];
//	float				aafSosInt		[5][2];



	DWORD				dwDD3;

	AudioIf_tNetSndCallback		pNetSendCallback;
	void*				pNetSendThis;

	DWORD				dwDD4;

	Audio_tDbg			Dbg;
	Audio_tCpu			Cpu;
	AudioIf_tCpuStts	CpuStts;

	DWORD				dwED;
} Audio_tCtrl;


/*****************************************************************************/
extern Audio_tCtrl gAudio;

/*****************************************************************************/

void audio_create(void);
void audio_delete(void);

void audio_lock(void);
void audio_unlock(void);

void audio_start(void);
void audio_stop(void);

short *audio_process(short *);

void audio_resync(bool boutOfSync = true);
void audio_delay_added(void);

DWORD audio_hstgm_init(AudioIf_tHstgm *pHstgm,int iRange=AUDIO_IF_HSTGM_MAX_SZ);
DWORD audio_hstgm_reset(AudioIf_tHstgm *pHstgm);
DWORD audio_hstgm_add(AudioIf_tHstgm *pHstgm, float fNew);
DWORD audio_hstgm_analyse(AudioIf_tHstgm *pHstgm);


DWORD audio_tmr_init(Audio_tTmrCtrl *pTmrCtrl);
DWORD audio_tmr_start(int iTmrId);
DWORD audio_tmr_stop(int iTmrId,float *pfTimeout = NULL);
DWORD audio_tmr_restart(int iTmrId,float *pfTimeout);
DWORD audio_tmr_reset(int iTmrId);
DWORD audio_tmr_peek(int iTmrId,float *pfTimeout);
DWORD audio_tmr_dump(char *pszFileName);


//DWORD audio_dbg_start(char *pszLogFileName, 
//					  WORD wDbgRecMask,
//					  DWORD dwGrMode);
//DWORD audio_dbg_stop(void);
void audio_dbg_plot(void);
void audio_dbg_poll_rec(void);
bool audio_dbg_open_win(void);
void audio_dbg_delete_win(HWND hWnd);
void audio_dbg_win_activate(bool bOn);

void audio_jb_netq_poll(void);
void audio_jb_netq_free(void);
void audio_jb_mux(void);
void audio_test_gen_rcv(void);
void audio_test_gen_snd(void);
void audio_net_snd(void);
void audio_net_snd_mix_log(void);

void audio_utl_32to48
	(
	float *pfSav, // AUDIO_48TO32_FSZ/3 size
	float *pfOut, 
	float *pfIn
	);
void audio_utl_48to32
	(
	float *pfSav, // AUDIO_48TO32_FSZ/2 size
	float *pfOut, 
	float *pfIn
	);
void audio_utl_fb4_set(void);
void audio_utl_fb4_analysis
	(
	Audio_tFB4 *pDec,
	float *pfIn
	);
void audio_utl_fb4_synthesis
	(
	Audio_tFB4 *pDec,
	float *pfOut
	);
void audio_utl_32to8
	(
	float *pfSav, // AUDIO_32TO8_FSZ size
	float *pfOut8, 
	float *pfIn32
	);
void audio_utl_8to32
	(
	float *pfSav, // AUDIO_8TO32_FSZ size
	float *pfOut32, 
	float *pfIn8
	);
void audio_utl_32to16
	(
	float *pfSav, // AUDIO_32TO16_FSZ size
	float *pfOut16, 
	float *pfIn32
	);
void audio_utl_16to32
	(
	float *pfSav, // AUDIO_16TO32_FSZ size
	float *pfOut32, 
	float *pfIn16
	);

void  audio_utl_short2float(float *pf,short *ps,int iSz = AUDIO_FRSZ32);
void  audio_utl_float2short(short *ps,float *pf,int iSz = AUDIO_FRSZ32);
void  audio_utl_iir2s(float *pfIO, 
					float *pfSav, // d0 d1
					const float *pfCoef, // b0 b1 a1 a2
					DWORD iSz);
void  audio_utl_iir1   (float *pfIO, 
					float *pfSav, // d0 d1
					const float *pfCoef, // b0 b1 a1 
					DWORD iSz);
void  audio_utl_set_wav(Audio_tWavHdr *pHdr,DWORD dwFs = AUDIO_FS32, WORD wChannels=1);
float audio_utl_pktnrg(short *ps,int iSz = AUDIO_FRSZ8);
float audio_utl_pktnrg(float *ps,int iSz = AUDIO_FRSZ8);
void  audio_utl_thread_stts(HANDLE hThread,float *fKernel,float *fUser);

void audio_agc_init (Audio_tAgc *pAgc, float fMicExtraGainDB, const AudioIf_tAgcCfg *pCfg);
void audio_agc_reset(Audio_tAgc *pAgc);
void audio_agc		(Audio_tAgc *pAgc,float *pfSnd);

void audio_log_err(char *, ...);
void audio_log_war(char *, ...);
void audio_log_inf(char *, ...);
void audio_log_trc(char *, ...);

void audio_recf32	(WORD wPt, WORD wStream, float *pfData);
void audio_recf8	(WORD wPt, WORD wStream, float *pfData);
void audio_recs8	(WORD wPt, WORD wStream, short *psData);
void audio_recf48	(WORD wPt, WORD wStream, float *pfData);
void audio_recs48	(WORD dwPt, WORD dwStream, short *psData);
void audio_rec_pkt	
	(
	WORD	wPt,
	WORD	wStream,
	Audio_tRtpHdr*	pHdr,
	BYTE *pcData,
	WORD	wDataSz,
	float	fArrived
	);
void audio_rec_close(void);


void audio_SSE_init(void); // g729.cpp
bool audio_CPU_info
	(
	int *piType, 
	int *piMhz, 
	int *piCacheSz
	);


typedef DWORD (*AudioGenRecvCallback)
	(
	void*	arg,
	WORD	wSrcId,				// shall be one of used in AudioIf_src_add()
	WORD	wPayloadType,		// extract it from RTP header
	WORD	wSequenceNumber,	// sequence number
	DWORD	dwTimeStamp,		// timestamp
	BYTE*	pcRtpData,	// ptr to the start of RTP data
	WORD	wRtpDataSz
	);

typedef struct {
	bool				bRunning;
	WORD				wIdx;
	int					iSrcId;
	int					iPT;
	int					iTS;
	int					iSN;
	int					iFPP;
	int					iLoops;
	int					iCurrentFrame;
	int					iCurrentLoop;
	int					iAllocSz;
	int					iEncodedTotal;
	DWORD				dwTsFrame;
	void*				pvEncoder;
	FILE*				fd;	
	BYTE*				pcCode;

	// dtx operations
	bool				bDtx;
	int					iDtxCnt;
	int					iDtxSend;
	int					iDtxPause;
} Audio_tGenStream;

typedef struct {
	volatile bool		bRunning;
	HANDLE				ahEvents[2];
	UINT				uMmTimerId;
	HANDLE				hThread;
	DWORD				dwThreadId;
	float				fBaseTS;
	float				fTS;
	float				fLost;
	float				fOOS;
	float				fJitter;
	volatile float		fSkew;
	Audio_tGenStream	aStream[AUDIO_IF_PARTY_MAX];
	int					iSendMode;
	int					iCnt;
	int					iEvents;
	float				fNow;
	struct {void *arg; AudioGenRecvCallback fp;} pCallback;
} Audio_tGen;
extern Audio_tGen  gAudioGen;

void  audio_gen_set_callback(void* arg, AudioGenRecvCallback pCallback);
DWORD audio_gen_start(int iSendMode = 0);
DWORD audio_gen_set_jitter(float fLost, float fOOS, float fJitter, float fSkew);
DWORD audio_gen_stop(void);
DWORD audio_gen_add_stream(int iSrcIdx, int iPT, int iTS, int iSN, int iFPP, int iLoops, char *pcToken);
DWORD audio_gen_dtx(int iSrcIdx, bool bDtx, int iDtxSend, int iDtxPause);
DWORD audio_gen_rem_stream(int iSrcIdx);

class Audio_CNetWr {
	void*			m_pvDecoder;
	WORD			m_wPT;
	FILE*			m_fd;
	Audio_tWavHdr	m_WavHdr;

public:
	Audio_CNetWr	();
	bool			open  (WORD wPayloadType, char *pszFileName);
	bool			active(void);
	void			write (BYTE *pCode, WORD wDataSz);
	void			close (void);
};

