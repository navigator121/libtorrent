//**@@@*@@@****************************************************
//
// Microsoft Windows
// Copyright (C) Microsoft Corporation. All rights reserved.
//
//**@@@*@@@****************************************************

//
// FileName:    util.cpp
//
// Abstract:    
//      This is the implementation file for general helper functions
//
#define _CRT_SECURE_NO_DEPRECATE 1

#include "audks_common.h"
#include <mmsystem.h>
#include <math.h>
#include <float.h>


////////////////////////////////////////////////////////////////////////////////
//
//  GetWfxSize()
//
//  Routine Description:
//      Returns the size of the wave format
//  
//  Arguments: 
//      Pointer to the wave format
//
//  Return Value:
//  
//     Size of the wave format
//
DWORD GetWfxSize(const WAVEFORMATEX* pwfxSrc)
{
    assert(pwfxSrc);

    DWORD dwSize;
    if(WAVE_FORMAT_PCM == pwfxSrc->wFormatTag)
    {
        dwSize = sizeof(WAVEFORMATEX);
    }
    else
    {
        dwSize = sizeof(WAVEFORMATEX) + pwfxSrc->cbSize;
    }

    return dwSize;
}




