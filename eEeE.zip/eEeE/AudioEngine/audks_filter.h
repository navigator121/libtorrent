//**@@@*@@@****************************************************
//
// Microsoft Windows
// Copyright (C) Microsoft Corporation. All rights reserved.
//
//**@@@*@@@****************************************************

//
// FileName:    filter.h
//
// Abstract:    
//      This is the header file for C++ classes that expose
//      functionality of KS filters
//

#pragma once
#ifndef __KSFILTER_H
#define __KSFILTER_H

// Forward Declarations
class CKsPin;
class CKsAudPin;

////////////////////////////////////////////////////////////////////////////////
//
//  class CKsFilter
//
//  Class Description:
//      This is the base class for classes that proxy Ks filters from user mode.
//      Basic usage is 
//          instantiate a CKsFilter (or derived class)
//          call Instantiate, which creates a file object (instantiates the KS filter)
//                  whose handle is stored as m_handle
//          call EnumeratePins, EnumerateNodes, to deduce the filter's topology
//          call CKsIrpTarget functions to get/set properties
//
//
//


class CKsFilter : public CKsIrpTarget
{
public:
    CKsFilter(
        IN LPCTSTR pszName,
		const char *pszFriendlyName,
        OUT HRESULT* phr);

    virtual ~CKsFilter(void);
    virtual HRESULT Instantiate(void);
	virtual HRESULT EnumeratePins(bool bCapture);
    CKsAudPin* CreatePin(const WAVEFORMATEX* pwfx);


    HRESULT GetPinPropertySimple(
        IN  ULONG   nPinID,
        IN  REFGUID guidPropertySet,
        IN  ULONG   nProperty,
        OUT PVOID   pvValue,
        OUT ULONG   cbValue);

    HRESULT GetPinPropertyMulti(
        IN  ULONG   nPinID,
        IN  REFGUID guidPropertySet,
        IN  ULONG   nProperty,
        OUT PKSMULTIPLE_ITEM* ppKsMultipleItem OPTIONAL);

	char m_szFriendlyName[MAX_PATH];

protected:

    // This is the "ROOT LIST" for all pins
    TList<CKsPin>   m_listPins;

   
private:
    TCHAR       m_szFilterName[MAX_PATH];   // Filter Path

   
// Friends
friend class CKsPin;
friend class CKsAudPin;

};

CKsFilter * audks_find_filter
(
const GUID* aguidCategories,
const int   cguidCategories,
const char*	pszFriendlyName,
const bool	bCapture,
int*		piSimilarNames
);

#endif //__KSFILTER_H
