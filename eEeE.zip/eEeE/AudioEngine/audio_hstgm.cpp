
#include "audio_defs.h"

/*****************************************************************************/
unsigned long			audio_hstgm_init
/*****************************************************************************/
(
AudioIf_tHstgm *pHstgm,
int iRange
)
{
	unsigned long rc = AUDIO_IF_ERR_NONE;
	memset(pHstgm, 0, sizeof(*pHstgm));

	if (iRange < 1)
	{
		iRange = 1;
//		rc |= AUDIO_IF_ERR_WARNING | AUDIO_IF_ERR_RANGE;
	}
	if (iRange > AUDIO_IF_HSTGM_MAX_SZ)
	{
		iRange = AUDIO_IF_HSTGM_MAX_SZ;
//		rc |= AUDIO_IF_ERR_WARNING | AUDIO_IF_ERR_RANGE;
	}
	pHstgm->iRange = iRange;
	pHstgm->fMin = float(iRange);
	return rc;
}
/*****************************************************************************/
unsigned long			audio_hstgm_reset
/*****************************************************************************/
(
AudioIf_tHstgm *pHstgm
)
{
	return audio_hstgm_init(pHstgm, pHstgm->iRange);
}

/*****************************************************************************/
unsigned long			audio_hstgm_add
/*****************************************************************************/
(
AudioIf_tHstgm *pHstgm,
float fNew // in ms
)
{
	unsigned long rc = AUDIO_IF_ERR_NONE;

	pHstgm->iTotal++;
	// integer oveflow may happen for really:-))) long calls 
	// (2^31)/50/60/60/24 = 497.1 days
	if (pHstgm->iTotal < 1) 
	{
		pHstgm->iTotal = 1;
//		rc |= AUDIO_IF_ERR_WARNING | AUDIO_IF_ERR_OVERFLOW;
	}

	if (pHstgm->fMin > fNew)
		pHstgm->fMin = fNew;
	if (pHstgm->fMax < fNew)
		pHstgm->fMax = fNew;

	pHstgm->dSum += fNew;
//	pHstgm->fAvrg = float(pHstgm->dSum/double(pHstgm->iTotal));

	if (fNew < 0)
	{
		pHstgm->aiData[0]++;
	}
	else
	{
		if (fNew > pHstgm->iRange)
		{
			pHstgm->aiData[pHstgm->iRange+1]++;
		}
		else // normal
		{
			int idx = int(fNew);
			pHstgm->aiData[idx+1]++;
		}
	}

	return rc;
}
/*****************************************************************************/
unsigned long			audio_hstgm_analyse
/*****************************************************************************/
(
AudioIf_tHstgm *pHstgm
)
{
	unsigned long rc = AUDIO_IF_ERR_NONE;
	int k;
	int iSum;
	float fThr;

	if(pHstgm->iTotal > 0)
		pHstgm->fAvrg = float(pHstgm->dSum/double(pHstgm->iTotal));
	else
		pHstgm->fAvrg = 0;
	
	iSum = 0;
	fThr = pHstgm->iTotal * 0.5F;
	for (k = 0; k < pHstgm->iRange+1;k++)
	{
		iSum += pHstgm->aiData[k];
		if (iSum > fThr)
		{
			float fDlt = 1.0F;
			if (k > 0)
			{
				fDlt = float(pHstgm->aiData[k]) / 
					float( pHstgm->aiData[k] + pHstgm->aiData[k-1]);
			}
			pHstgm->f50 = (k - 1) + fDlt;
			break;
		}
	}

	iSum = 0;
	fThr = pHstgm->iTotal * 0.9F;
	for (k = 0; k < pHstgm->iRange+1;k++)
	{
		iSum += pHstgm->aiData[k];
		if (iSum > fThr)
		{
			float fDlt = 1.0F;
			if (k > 0)
			{
				fDlt = float(pHstgm->aiData[k]) / 
					float( pHstgm->aiData[k] + pHstgm->aiData[k-1]);
			}
			pHstgm->f90 = (k - 1) + fDlt;
			break;
		}
	}

	iSum = 0;
	fThr = pHstgm->iTotal * 0.99F;
	for (k = 0; k < pHstgm->iRange+1;k++)
	{
		iSum += pHstgm->aiData[k];
		if (iSum > fThr)
		{
			float fDlt = 1.0F;
			if (k > 0)
			{
				fDlt = float(pHstgm->aiData[k]) / 
					float( pHstgm->aiData[k] + pHstgm->aiData[k-1]);
			}
			pHstgm->f99 = (k - 1) + fDlt;
			break;
		}
	}

	return rc;
}
